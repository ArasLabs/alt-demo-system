﻿// © Copyright by Aras Corporation, 2004-2008.

/*
 *   The ItemType methods extension for the Aras Object.
 *
 */


/*-- newItemType
 *
 *   Method to create a new ItmeType
 *   itemTypeName = the name of the itemType and if not passed is prompted for
 *
 */
Aras.prototype.newItemType = function() {
  if (arguments.length == 0) {
    var name = top.aras.prompt('Enter an ItemType name:','');
    if (!name) return;
  } else var name = arguments[0];

  with (this) {
    if (getItemTypeByName(name)) {
      top.aras.AlertError('The ItemType ' + name + ' already exists.', "", "");
      return;
    }
  }

  var xml = '<Item type="ItemType" id="' + document.uniqueID + '">' +
    '<name>' + name + '</name><Relationships/></Item>';

  var itemType = this.createXMLDocument();
  itemType.loadXML(xml);

  return this.dom.selectSingleNode('/Innovator/Items').appendChild(itemType.documentElement);
}

/*-- getItemTypeProperties
 *
 *   Method to get the properties for the ItemType
 *   itemType = the itemType
 *
 */
Aras.prototype.getItemTypeProperties = function(itemType) {
  if (!itemType) return;
  with (this) {
    return itemType.selectNodes('Relationships/Item[@type="Property"]');
  }
}

/*-- addItemTypeProperty
 *
 *   Method to add a property to the ItemType
 *   itemType = the itemType
 *   property = the property name
 *   idxTYpe  =
 *
 */
Aras.prototype.addItemTypeProperty = function(itemType,property,idxType)
{
  if (!itemType) return;

  with (this)
  {
    if (!property)
    {
      var name = top.aras.prompt('Enter a new Property name:','');
      if(!name) return;

      var property = newNodeElementAttribute(dom.selectSingleNode('/Innovator/Items'), 'Item', 'type', 'Property');
      if(!property) return;

      property.setAttribute('id',document.uniqueID);
      setNodeElement(property,'name',name);
    }

    var first = itemType.selectSingleNode('Relationships/Item[@type="Property"]')==null;
    if (!idxType) idxType = first ? 'full' : 'plain';

    var rels = itemType.selectSingleNode('Relationships');
    if (!rels) rels = itemType.appendChild(dom.createElement('Relationships'));

    var prop = newNodeElementAttribute(rels,'Item','type', 'Property');
    prop.setAttribute('id',document.uniqueID);

    setNodeElement(prop,'related_id',property.getAttribute('id'));
    setNodeElement(prop,'relationship_id',getItemFromServerByName('Property',idxType,'id').getID());
  }

  return property;
}

/*-- loadItemTypes
 *
 *   Method to load the ItemType items
 *
 */
Aras.prototype.loadItemTypes = function() {
  with (this) {
    var statusId = showStatusMessage(0, '   Loading Item Types...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('GetItem', '<Item type="ItemType" levels="0"></Item>');
    var statusId = clearStatusMessage(statusId);

    if (res.getFaultCode() != 0) return false;

    var items = res.results.selectNodes(top.aras.XPathResult('/Item'));
    for (var i=0; i<items.length; ++i) {
      var item  = items.item(i);
      var xpath = '/Innovator/Items/Item[@id="' + item.getAttribute('id') + '"]';
      if (! dom.selectSingleNode(xpath))
        newNodeElementAttribute(dom.selectSingleNode('/Innovator/Items'),'Item','id',item.getAttribute('id'));
      updateDOM(xpath, item.xml);
    }
  }

  with (this) {
    var statusId = showStatusMessage(0, '   Loading Relationship Types...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('GetItem', '<Item type="RelationshipType" levels="0"></Item>');
    clearStatusMessage(statusId);
    if (res.getFaultCode() != 0) return false;

    var relationshipTypes = res.results.selectNodes(top.aras.XPathResult('/Item'));
    for (var i=0; i<relationshipTypes.length; ++i) {
      var relationshipType = relationshipTypes.item(i);
      var xpath = '/Innovator/Items/Item[@id="' + relationshipType.getAttribute('id') + '"]';
      if (! dom.selectSingleNode(xpath))
        newNodeElementAttribute(dom.selectSingleNode('/Innovator/Items'),'Item','id',relationshipType.getAttribute('id'));
      updateDOM(xpath, relationshipType.xml);
    }
  }

  this.loadItems('Exclusion');

  return true;
}

/*-- getItemTypeByName
 *
 *   Method to get the ItemType by name from the dom cache
 *
 */
Aras.prototype.getItemTypeByName = function(typeName) {
  return this.dom.selectSingleNode('/Innovator/Items/Item[@type="ItemType"][name="' + typeName + '"]');
}

/*-- getItemTypeById
 *
 *   Method to get the ItemType by id from the dom cache
 *
 */
Aras.prototype.getItemTypeById = function(id) {
  return this.dom.selectSingleNode('/Innovator/Items/Item[@type="ItemType" and @id="' + id + '"]');
}

/*-- deleteItemType
 *
 *   Method to delete the ItemType
 *   id = the id for the ItemType
 *
 */
Aras.prototype.deleteItemType = function(id) {
  with (this) {
    if (isTempID(id)) {
      var itemType = getItemTypeById(id);
      if (itemType) {
        itemType.parentNode.removeChild(itemType);
        return true;
      }
      return false;
    }

    var statusId = showStatusMessage(0, '   Delete ItemType...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('DeleteItemType', '<Item type="ItemType" id="' + id + '"/>');
    clearStatusMessage(statusId);

    if (res.getFaultCode() != 0) {
      top.aras.AlertError('Error: ' + res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var itemType = getItemTypeById(id);
    itemType.parentNode.removeChild(itemType);
    return true;
  }
}

/*-- saveItemType
 *
 *   Method to save the ItemType
 *   id = the id for the ItemType
 *
 */
Aras.prototype.saveItemType = function(id) {
  var itemType = getItemTypeById(id);
  var method   = 'UpdateItemType';

  with (this) {
    if (isTempID(id)) {
      method = 'AddItemType';

      itemType = itemType.cloneNode(true);
      itemType.setAttribute('action','add');
      itemType.removeAttribute('id');

      //just now this function (saveItemType) is never used; but if it will be used
      //somewhere in future the next line should be checked (under XP with IE6).
      //The reason is problem with XPath. See function addItem() in item_methods.js.
      //I've made no changes for now, just place this comment.
      var properties = itemType.selectNodes('Relationships/Item[@type="Property"]');

      if (properties && properties.length>0) {
        for(var i=0; i<properties.length; i++) {
          var property = properties.item(i);
          property.setAttribute('action','add');
          property.removeAttribute('id');

          var relatedItem   = property.selectSingleNode('related_id');
          var relatedItemId = relatedItem.text;
          relatedItem.text='';

          var propertyType = getItemById('PropertyType',relatedItemId).cloneNode(true);
          propertyType.setAttribute('action','add');
          propertyType.removeAttribute('id');
          relatedItem.appendChild(propertyType);

          var relationshipItem   = property.selectSingleNode('relationship_id');
          var relationshipItemId = relationshipItem.text;
          relationshipItem.text='';

          var relationshipItemName = getNodeElement(getItemById('Property', relationshipItemId),'name');
          var node = newNodeElementAttribute(relationshipItem,'Item','type','Property');
          node.setAttribute('action','get');

          setNodeElement(node,'name',relationshipItemName);
        }
      }
    }

    var statusId = showStatusMessage(0, '   Save ItemType...','../images/Animated/ProgressSmall.gif');
    var res = soapSend(method, itemType.xml);
    clearStatusMessage(statusId);

    if (res.getFaultCode() != 0) {
      top.aras.AlertError('Error: ' + res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    if (isTempID(id)) {
      var itemType   = getItemTypeById(id);
      var relatedItems = itemType.selectNodes('Relationships/Item[@type="Property"]/related_id');

      if (relatedItems && relatedItems.length>0) {
        for(var i=0; i<relatedItems.length; i++) {
          var relatedItemId = relatedItems.item(i).text;
          var propertyType  = getItemById('PropertyType',relatedItemId);
          propertyType.parentNode.removeChild(propertyType);
        }
      }

      itemType.parentNode.removeChild(itemType);
      var newID = res.results.selectSingleNode(top.aras.XPathResult()).text;

      res = soapSend('GetItem', '<Item type="ItemType" levels="0" id="' + newID + '"/>');

      if (res.getFaultCode() != 0) return false;

      var items = res.results.selectNodes(top.aras.XPathResult('/Item'));
      for (var i=0; i<items.length; ++i) {
        var item  = items.item(i);
        var xpath = '/Innovator/Items/Item[@id="' + item.getAttribute('id') + '"]';
        updateDOM(xpath, item.xml);
      }

      return newID;
    }

    return true;
  }
}

Aras.prototype.rebuildView = function(viewId)
{
  if (!viewId)
  {
    top.aras.AlertError('The view to be rebuilt was not specified.', "", "");
    return false;
  }

  with (this)
  {
    var statusId = showStatusMessage(0, ' Rebuilding View for ItemType...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('RebuildView', '<Item type="View" id="'+viewId+'" />');
    clearStatusMessage(statusId);
    if (res.getFaultCode() != 0)
    {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var formNd = res.results.selectSingleNode('//Item[@type="Form"]');
    if (!formNd) return false;
    var xpath = '/Innovator/Items/Item[@type="ItemType"]/Relationships/Item[@type="View" and @id="'+viewId+'"]';
    var oldView = dom.selectSingleNode(xpath);



    var domNodes = dom.selectSingleNode('/Innovator/Items');
    domNodes.appendChild(formNd.cloneNode(true));

    var formId = formNd.getAttribute("id");
    var newView = getItem("View", 'related_id/Item/@id="' + formId + '"', "<related_id>"+formId+"</related_id>", 0);

    if (oldView)
      oldView.parentNode.replaceChild(newView, oldView);
    if (uiFindWindowEx(viewId)) uiReShowItemEx(viewId, newView);
  }
  return true;
}

Aras.prototype.isPolymorphic = function(itemType) {
	var implementationType = this.getItemProperty(itemType,'implementation_type');
  return (implementationType=='polymorphic');
}

Aras.prototype.getMorphaeList = function(itemType) {
	var itemTypesList = [];
	var morphae = itemType.selectNodes("Relationships/Item[@type='Morphae']/related_id/Item");
	for(var i=0; i<morphae.length; i++) {
	  var m     = morphae(i);
	  var id    = m.getAttribute("id");
	  var name  = this.getItemProperty(m,"name");
	  var label = this.getItemProperty(m,"label");
	  if (label==null || label==='') label = name;
	  itemTypesList.push({id:id, name:name, label:label});
	  m = null;
	}
	morphae = null;
	return itemTypesList;
}