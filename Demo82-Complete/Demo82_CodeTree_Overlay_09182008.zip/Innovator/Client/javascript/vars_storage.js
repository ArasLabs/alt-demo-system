﻿function VarsStorageClass()
{
  this.unknownStorage = {};
  this.log = "";
  var self = this;
  this.a = top.aras;
  this.dom = this.a.createXMLDocument();
  this.loadFromDB = true;
  var prefsXml = "" +
  "<Innovator>" +
    "<Preferences>" +
      "<Core_GlobalLayout/>" +
      "<Core_ItemGridLayout/>" +
      "<Core_RelGridLayout/>" +
    "</Preferences>" +
  "</Innovator>";
  this.dom.loadXML(prefsXml);

  this.global = this.dom.selectSingleNode("/Innovator/Preferences/Core_GlobalLayout");
  this.itemGrid = this.dom.selectSingleNode("/Innovator/Preferences/Core_ItemGridLayout");
  this.relGrid = this.dom.selectSingleNode("/Innovator/Preferences/Core_RelGridLayout");
  
  var xml = "" +
  "<Item type='Preference' action='get' select='id'>" +
    this.a.inner_getConditionForUser() +
  "</Item>";
  
  var res = this.a.applyItem(xml);
  
  var checkPrefs = false;
  if(typeof(res)=="string")
  {
    var tmpDom = this.a.createXMLDocument();
    tmpDom.loadXML(res);
    if(tmpDom.parseError.errorCode == 0)
    {
      if(tmpDom.selectSingleNode("//Item")) checkPrefs = true;
    }
  }
           
  if(checkPrefs)
  {
    if(!loadGlobal()) makeDefaultGlobal();
  }
  else
  {
    if(!loadPreferencesFromXML()) makeDefaultGlobal();
    this.loadFromDB = false; // because we know that there is nothing into DB
  }
  
  function loadPreferencesFromXML()
  {
    var vault = self.a.vault;
    var filepath = self.a.getWorkingDir() + "\\UserPreferences.xml";
    var dbName = self.a.getDatabase();
    var prefsRoot;
    var dom = self.a.createXMLDocument();
    var xml = "";
    try { xml = vault.readText(filepath); } catch(e) { return false; }
    if(xml != "") dom.loadXML(xml);
    else return false;
    if(dom.documentElement)
    {
      prefsRoot = dom.selectSingleNode('//Database[@name="' + dbName + '"]');
      if(!prefsRoot) return false;
      for(var i=0;i<prefsRoot.attributes.length;i++)
      {
        var attr = prefsRoot.attributes[i];
        self.setVariable(attr.nodeName,attr.text);
      }
    }
    else return false;
    return true;
  }
    
  function loadGlobal()
  {
    var globalPrefObj = self.a.getPreference("Core_GlobalLayout", "0");
    if(globalPrefObj)
    {
      if(globalPrefObj.prefType == 1) // Site
      {
        var prefItem = self.a.newItem("Core_GlobalLayout");
        var sitePref = globalPrefObj.itemNode;
        var props = sitePref.selectNodes("*");
        for(var i=0;i<props.length;i++)
        {
          prefItem.appendChild(props[i]);
        }
        self.global.appendChild(prefItem);
      }
      else
      {
        var globalPref = globalPrefObj.itemNode;
        if(!globalPref) globalPref = globalPrefObj.itemNodes[0];
        if(globalPref)
        {
          self.global.appendChild(globalPref);
        }
      }
    }
    else return false;
    return true;
  }
   
  function makeDefaultGlobal()
  {
    // List of global preferences.
    var propsNames = "core_view_mode,core_structure_layout,core_use_wildcards,core_show_scan_button_for_file,core_show_item_properties," +
    "core_tear_off,core_show_labels,core_append_items,core_no_tabs_in_tab_view,core_debug,core_in_basket_history,core_drag_full_windows,core_load_favorite_metadata";

    var xml = "" +
      "<Item type='Core_GlobalLayout' action='get' select='" + propsNames + "'>" +
      "  <source_id>" +
      "    <Item type='Preference' action='get' select='id'>" +
      "      <identity_id>" +
      "        <Item type='Identity' action='get' select='id'>" +
      "          <name>World</name>" +
      "        </Item>" +
      "      </identity_id>" +
      "    </Item>" +
      "  </source_id>" +
      "</Item>";
  
    var res = self.a.applyItem(xml);

    if(typeof(res) == "string")
    {
      var tmpDom = self.a.createXMLDocument();
      tmpDom.loadXML(res);
      if(tmpDom.parseError.errorCode == 0)
        initializeNewGlobalPreferences(tmpDom.selectSingleNode("Item[@type='Core_GlobalLayout']"), propsNames);
      else
        initializeNewGlobalPreferences(null, propsNames);
    }
  }
  
  function initializeNewGlobalPreferences(worldPrefItem, propsNames)
  {
    var prefItem = self.a.newItem("Core_GlobalLayout");

    if (worldPrefItem)
    {
      var props = propsNames.split(",");   
      for (var i = 0; i < props.length; i++)
      {
        var prop = worldPrefItem.selectSingleNode(props[i]);

        if (prop && prop.text)
          self.a.setItemProperty(prefItem, props[i], prop.text);      
      }
    }
    else
    {
      self.a.setItemProperty(prefItem, "core_view_mode", "tab view");
      // TRUE
      self.a.setItemProperty(prefItem, "core_use_wildcards", "true");
      self.a.setItemProperty(prefItem, "core_show_item_properties", "true");
      self.a.setItemProperty(prefItem, "core_tear_off", "true");
      // FALSE
      self.a.setItemProperty(prefItem, "core_show_labels", "false");
      self.a.setItemProperty(prefItem, "core_append_items", "false");
      self.a.setItemProperty(prefItem, "core_no_tabs_in_tab_view", "false");
      self.a.setItemProperty(prefItem, "core_debug", "false");
      self.a.setItemProperty(prefItem, "core_show_scan_button_for_file", "1");
      self.a.setItemProperty(prefItem, "core_drag_full_windows", "0");
    }
    
    // We do this because type of properties "core_in_basket_history" and "core_structure_layout" is string, 
    // so if default values for them is not set, getItem will not return them, so there can be inaccuracy.
    if (!self.a.getItemProperty(prefItem, "core_in_basket_history"))
      self.a.setItemProperty(prefItem, "core_in_basket_history", "1|0|0|Active");
    if (!self.a.getItemProperty(prefItem, "core_structure_layout"))
      self.a.setItemProperty(prefItem, "core_structure_layout", "9");

    self.global.appendChild(prefItem);
  }
}

VarsStorageClass.prototype.save = function VarsStorageClass_save()
{
  var itemsToApply = this.dom.selectNodes("/Innovator/Preferences/*/Item[@action]");
  if(itemsToApply.length > 0)
  {
    this.a.setPreference(itemsToApply,2);
  }
}

VarsStorageClass.prototype.parseVariableName = function VarsStorageClass_parseVariableName(varName)
{
  var res = {};

  if(varName.search(/^[A-Za-z]+$/)!=-1) // core layout
  {
    res.varType = "global";
    var tmp = varName;
    tmp = tmp.replace(/([a-z])([A-Z])/g,"$1_$2");
    tmp = tmp.toLowerCase();
    tmp = "core_" + tmp;
    res.varName = tmp;
  }
  else if(varName.search(/^IT_[A-Fa-f0-9]{32}_[A-Za-z_]+$/)!=-1) // itemGrid layout
  {
    res.varType = "itemGrid";
    var match = varName.match(/^IT_([A-Fa-f0-9]{32})_([A-Za-z_]+)$/);
    res.varId   = match[1];
    var tmp = match[2];
    tmp = tmp.replace(/([a-z])([A-Z])/g,"$1_$2");
    tmp = tmp.toLowerCase();
    res.varName = tmp;
  }
  else if(varName.search(/^RT_[A-Fa-f0-9]{32}_[A-Za-z_]+$/)!=-1) // relGrid layout
  {
    res.varType = "relGrid";
    var match = varName.match(/^RT_([A-Fa-f0-9]{32})_([A-Za-z_]+)$/);
    res.varId   = match[1];
    var tmp = match[2];
    tmp = tmp.replace(/([a-z])([A-Z])/g,"$1_$2");
    tmp = tmp.toLowerCase();
    res.varName = tmp;
  }
  else if(typeof(varName)!="object" && typeof(varName)!="undefined")
  {
    res.varType = "unknown";
    res.varName = varName.toString();
  }
  else return null;

  return res;
}

VarsStorageClass.prototype.getVariable = function VarsStorageClass_getVariable(varName)
{
  var res = "";
  var prefItem;
  var varDef = this.parseVariableName(varName);
  
  switch(varDef.varType)
  {
    case "global" :
      prefItem = this.global.selectSingleNode("Item");
      res = this.a.getItemProperty(prefItem,varDef.varName);
      break;
    case "itemGrid" :
      prefItem = this.itemGrid.selectSingleNode("Item[item_type_id='" + varDef.varId + "']");
      if (prefItem && !this.preferencesWereCorrupted(varName, null))
        res = this.a.getItemProperty(prefItem, varDef.varName);
      else if(this.loadFromDB)
      {
        var xml = "" +
        "<Item type='Core_ItemGridLayout' action='get'>" +
          "<item_type_id>" + varDef.varId + "</item_type_id>" +
        "</Item>";
        prefObj = this.a.getPreference(null,null,xml,2);
        if(prefObj)
        {
          prefItem = prefObj.itemNode;
          if (!prefItem && prefObj.itemNodes) prefItem = prefObj.itemNodes[0];
          if(prefItem)
          {
            this.itemGrid.appendChild(prefItem);
            if (!this.preferencesWereCorrupted(varName, null))
              res = this.a.getItemProperty(prefItem,varDef.varName);
            else
              return null;
          }
        }
      }
      break;
    case "relGrid" :
      prefItem = this.relGrid.selectSingleNode("Item[rel_type_id='" + varDef.varId + "']");
      if(prefItem)
      {
        res = this.a.getItemProperty(prefItem,varDef.varName);
      }
      else if(this.loadFromDB)
      {
        var xml = "" +
        "<Item type='Core_RelGridLayout' action='get'>" +
          "<rel_type_id>" + varDef.varId + "</rel_type_id>" +
        "</Item>";
        prefObj = this.a.getPreference(null,null,xml,2);
        if(prefObj)
        {
          prefItem = prefObj.itemNode;
          if (!prefItem && prefObj.itemNodes) prefItem = prefObj.itemNodes[0];
          if(prefItem)
          {
            this.relGrid.appendChild(prefItem);
            res = this.a.getItemProperty(prefItem,varDef.varName);
          }
        }
      }
      break;
    case "unknown":
      res = this.unknownStorage[varDef.varName];
      break;
    default:
      break;
  }
  
  if(typeof(res)!="string" || res == "")
  {
    if(prefItem && prefItem.selectSingleNode(varDef.varName))
    {
      res = "";
    }
    else
    {
      res = null;
    }
  }
  
//  this.log += "-G-:" + varName + "=" + res + ":" + typeof(res) + "\n";
  return res;
}

VarsStorageClass.prototype.setVariable = function VarsStorageClass_setVariable(varName,varValue)
{
//  this.log += "+S+:" + varName + "," + varValue + "\n";
  if(typeof(varValue)!="string")
  {
    if (varValue != null && varValue != undefined)
      varValue = varValue.toString();
    else
      varValue = null;
  }
  var self = this;
  var varDef = this.parseVariableName(varName);
  
  function getReadyItem(typeName,prefCont,id,noNeedInNew)
  {
    cond = "";
    if(id)
    {
      if(typeName=="Core_ItemGridLayout")
      {
        cond = "[item_type_id='" + id + "']";
      }
      else if(typeName=="Core_RelGridLayout")
      {
        cond = "[rel_type_id='" + id + "']";
      }
    }
    var prefItem = prefCont.selectSingleNode("Item" + cond);

    if(!prefItem)
    {
      if(!noNeedInNew)
      {
        prefItem = self.a.newItem(typeName);
        if(typeName=="Core_ItemGridLayout")
        {
          self.a.setItemProperty(prefItem,"item_type_id",id);
        }
        else if(typeName=="Core_RelGridLayout")
        {
          self.a.setItemProperty(prefItem,"rel_type_id",id);
        }
        prefCont.appendChild(prefItem);
      }
    }
    else // prefItem && !noNeedInNew -> !(!prefItem || noNeedInNew)
    {
      prefItemAction = prefItem.getAttribute("action");
      if(prefItemAction != "add" && prefItemAction != "edit")
      {
        prefItem.setAttribute("action","edit");
      }
    }
    return prefItem;
  }
  
  function setNull(prefItem,varName)
  {
    var valNode = prefItem.selectSingleNode(varName);
    if(valNode)
    {
      valNode.text = "";
      valNode.setAttribute("is_null","1");
    }
  }
  
  if(varValue!=null)
  {
    switch(varDef.varType)
    {
      case "global":
        var prefItem = getReadyItem("Core_GlobalLayout",this.global);
        this.a.setItemProperty(prefItem,varDef.varName,varValue);
        break;
      case "itemGrid":
        var prefItem = getReadyItem("Core_ItemGridLayout", this.itemGrid, varDef.varId);
        if (!this.preferencesWereCorrupted(varName, varValue))
          this.a.setItemProperty(prefItem, varDef.varName, varValue);
        break;
      case "relGrid":
        var prefItem = getReadyItem("Core_RelGridLayout",this.relGrid,varDef.varId);
        this.a.setItemProperty(prefItem,varDef.varName,varValue);
        break;
      case "unknown":
        this.unknownStorage[varDef.varName] = varValue;
        break;
    }
  }
  else // varValue == null
  {
    switch(varDef.varType)
    {
      case "global":
        var prefItem = getReadyItem("Core_GlobalLayout",this.global,null,true);
        if(prefItem)
        {
          setNull(prefItem,varDef.varName);
        }
        break;
      case "itemGrid":
        var prefItem = getReadyItem("Core_ItemGridLayout",this.itemGrid,varDef.varId,true);
        if(prefItem)
        {
          setNull(prefItem,varDef.varName);
        }
        break;
      case "relGrid":
        var prefItem = getReadyItem("Core_RelGridLayout",this.relGrid,varDef.varId,true);
        if(prefItem)
        {
          setNull(prefItem,varDef.varName);
        }
        break;
      case "unknown":
        this.unknownStorage[varDef.varName] = varValue;
        break;
    }
  }
}

//IR-007887 "Preferences: Identitygrid has lost its way repeately."
VarsStorageClass.prototype.preferencesWereCorrupted = function VarsStorageClass_preferencesWereCorrupted(varName, varVal)
{
  var varDef = this.parseVariableName(varName);
  var prefItem = this.itemGrid.selectSingleNode("Item[item_type_id='" + varDef.varId + "']");

  var varValue = (varVal != null) ? varVal : this.a.getItemProperty(prefItem, varDef.varName);

  if (varName.search(/^IT_[A-Fa-f0-9]{32}_[A-Za-z_]+$/) != -1)
  {
    var match = varName.match(/^IT_([A-Fa-f0-9]{32})_([A-Za-z_]+)$/);
    if (match && match[2].toString() == "colWidths")
    {
      var arr = varValue.split(";");
      for (var i = 0 ; i < arr.length; i++)
        if (arr[i] != "0") return false;

      return true;
    }
  }
}
