﻿// © Copyright by Aras Corporation, 2004-2007.

//////////////+++++++++  CacheResponse  +++++++++//////////////////////////
function CacheResponse (success, msg, item) {
	if (success == undefined) success = false;
	if (msg == undefined) msg   = '';
	
	this.success = success;
	this.message = msg;
	this.item    = item;
}
//////////////---------  CacheResponse  ---------//////////////////////////

//////////////+++++++++  ClientCache  +++++++++//////////////////////////
function ClientCache(arasObj) {
  this.arasObj = arasObj;
	this.dom = arasObj.dom;
}

ClientCache.prototype.makeResponse = function ClientCache_makeResponse(success, msg, item) {
	return (new CacheResponse(success, msg, item));
}

ClientCache.prototype.addItem = function ClientCache_addItem(item) {
	this.dom.selectSingleNode('/Innovator/Items').appendChild(item.cloneNode(true));
}

ClientCache.prototype.updateItem = function ClientCache_updateItem(item) {
	var itemID = item.getAttribute('id');
	var prevItem = this.dom.selectSingleNode('/Innovator/Items/Item[@id="'+itemID+'"]');
	
	if (prevItem) prevItem.parentNode.replaceChild(item.cloneNode(true), prevItem);
	else this.addItem(item);
}

ClientCache.prototype.updateItemEx = function ClientCache_updateItemEx(oldItm, newItm)
{
  var oldID = oldItm.getAttribute('id');
  var newID = newItm.getAttribute('id');

  var prevItem = this.dom.selectSingleNode('/Innovator/Items/Item[@id="'+oldID+'"]');
  if (prevItem) prevItem.parentNode.replaceChild(newItm.cloneNode(true), prevItem);
  if (!prevItem && (!oldItm || !oldItm.parentNode)) this.addItem(newItm);

  if (oldItm)
  {
    if (oldItm.parentNode)
    {
      if (oldItm.parentNode.baseName == "related_id" && !this.arasObj.isTempEx(oldItm))
      {
        var relNd = oldItm.parentNode.parentNode;
        var relNdBehaviour = this.arasObj.getItemProperty(relNd, "behavior");
        if (relNdBehaviour != "float" && relNdBehaviour != "hard_float")
        {        
          var strBody = '<Item action="get" type="'+relNd.getAttribute('type')+
                      '" id="'+relNd.getAttribute('id')+'" select="related_id" />';
          var res = this.arasObj.soapSend('ApplyItem', strBody);
          if (res.getFaultCode() == 0)
          {
            var tmpItm = res.results.selectSingleNode(this.arasObj.XPathResult('/Item/related_id/Item'));
            if (tmpItm) newItm = tmpItm;
          }
        }
      }
     
     var newItmCloned = newItm.cloneNode(true);
     oldItm.parentNode.replaceChild(newItmCloned, oldItm);
    }
  		
    var oldItms = oldItm.selectNodes('.//Item[@isTemp="1" or @isDirty="1"]');
    for (var i=0; i<oldItms.length; i++)
    {
      var oldItmID  = oldItms(i).getAttribute('id');
      if (oldItmID  == newID) continue;
      var newOldItm = newItm.selectSingleNode('.//Item[@id="'+oldItmID+'"]');

      if (newOldItm) this.updateItem(newOldItm);
      else this.deleteItem(oldItmID);
    }
  }
}

ClientCache.prototype.deleteItem = function ClientCache_deleteItem(itemID) {
	var prevItem = this.dom.selectSingleNode('/Innovator/Items/Item[@id="'+itemID+'"]');
	if (prevItem) prevItem.parentNode.removeChild(prevItem);
}

ClientCache.prototype.getItem = function ClientCache_getItem(itemID) {
	var item = this.dom.selectSingleNode('/Innovator/Items/Item[@id="'+itemID+'"]');
	return item;
}

ClientCache.prototype.hasItem = function ClientCache_hasItem(itemID) {
	return (this.dom.selectSingleNode('/Innovator/Items/Item[@id="'+itemID+'"]') != null);
}
//////////////---------  ClientCache  ---------//////////////////////////
