﻿// © Copyright by Aras Corporation, 2004-2007.

function isFunctionDisabled(ItemTypeName,aFunction){
  if (this.disabledFunctions[ItemTypeName]){
    return this.disabledFunctions[ItemTypeName][aFunction];
  } else {
  	return false;
  }
}

var disabledFunctions = new Array ("Workflow Process","DFMEA","Process Planner","Project","Project Template");
disabledFunctions["DFMEA"] = new Array ("Save As", "Version");
disabledFunctions["DFMEA"]["Save As"] = true;
disabledFunctions["DFMEA"]["Version"] = true;
disabledFunctions["Process Planner"] = new Array ("Save As", "Version");
disabledFunctions["Process Planner"]["Save As"] = true;
disabledFunctions["Process Planner"]["Version"] = true;
disabledFunctions["Project"] = new Array ("Save As");
disabledFunctions["Project"]["Save As"] = true;
disabledFunctions["Project Template"] = new Array ("Save As");
disabledFunctions["Project Template"]["Save As"] = true;
disabledFunctions["Workflow Process"] = new Array ("Promote");
disabledFunctions["Workflow Process"]["Promote"]= true;
disabledFunctions["Workflow Process"]["No Tabs"]=true;
