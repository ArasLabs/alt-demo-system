﻿
// © Copyright by Aras Corporation, 2007 - Company Confidential.

/*-----------------------------------------------------------------------
 * FileName: favorite_meta_object.js
 * 
 * Purpose:
 * Collect information about meta-data loaded by the user
 * in order to use it for preloading most often used types, forms, etc.
 *-----------------------------------------------------------------------*/ 
 
/*
 * statistical entry that collects information about a particular type
 * of meta-data request.
 */
function MetaDataEntry( typeParam, keyParam )
{
  // Just a constant (31-bit mask) for later use
  this.max = parseInt( "0x7FFFFFFF", 16 );
  
  // 32-bit mask that contains info about usage of the meta-data
  // in the last 31 sessions. If the meta-data is not requested
  // from the server in the last 31 sessions, it will not be preloaded.
  this.mask = 0;
  
  // how many times the meta-data was used in the last 32 sessions.
  // The value is calculated from the mask.
  this.counter = 0;
  
  // Type of meta-data:
  //   IT - ItemType
  //   FR - Form
  //   RT - RelationshipType
  //   LT - List
  this.type = typeParam;
  
  // Key, can be either name or id (in which case the syntax is: id=xxx), 
  // e.g. 'Part', 'id=BFDEFE0CEE174B52B8972D49B446B812', etc.
  this.key = keyParam;
}

MetaDataEntry.prototype.countSessions = function MetaDataEntry_countSessions()
{
  for( var i = 0; i < 31; i++ )
  {
    var seed = Math.pow( 2, i );
    if( this.mask & seed )
      this.counter++;
  }
}

MetaDataEntry.prototype.dropOldest = function MetaDataEntry_dropOldest()
{
  this.mask = (this.mask << 1) & this.max;
}

/*
 * Sorting function for MetaDataEntries
 */
function sort_fmdata( a1, a2 )
{
  if( a1.counter > a2.counter )
    return -1;
  else if( a1.counter < a2.counter )
    return 1;
  else
  {
    // If masks has the same amount of '1's, mask that has 
    // more recent '1's gets in front.
    if( a1.mask < a2.mask )
      return -1;
    else if( a1.mask > a2.mask )
      return 1;
  }

  return 0;
}

/*
 * Collection of statistical entries.
 */
function FavoriteMetaData()
{
  // Constant (1) used for marking usage in the current session
  this.lowbit = parseInt( "0x1", 16 );
  
  // Array on meta-data entries
  this.fmdata = new Array();
  
  // 'Core_FavoriteMetaData' pref ID
  this.prefID = null;
}

/*
 * Increase counter for existing entry or create a new entry
 */
FavoriteMetaData.prototype.markAsRequested = function FavoriteMetaData_markAsRequested( type, key )
{
  //debugger;
  var entry = this.findEntry( type, key );
  if( !entry )
  {
    entry = new MetaDataEntry( type, key );
    this.fmdata.push( entry );
  }
  
  entry.mask = entry.mask | this.lowbit;
}

/*
 * Populate the fmdata array from user preferences in db and add fmdata entries into
 * the passed array that is used by the background process for preloading meta-data.
 * The method must be called only once on start of Innovator (right now it's called from
 * setup.aspx:onload).
 */
FavoriteMetaData.prototype.populateFromPrefs = function FavoriteMetaData_populateFromPrefs(arasObj, preloads)
{
  //debugger;

  var pref = arasObj.getPreference( "Core_FavoriteMetaData", 1, "", 2 );
  var isDefaultMD;
  if( !pref )
  {
    pref = arasObj.getPreference("Core_FavoriteMetaData", null, null, 1);
    if (!pref || !pref.itemNode) return;
    var fmd = pref.itemNode.selectSingleNode("metadata");
    if (!fmd) return;
    fmd = fmd.text;
    var defaultFmdDoc = arasObj.createXMLDocument();
    defaultFmdDoc.loadXML(fmd);
    var xp = arasObj.getUserType();
    xp = "/*/*[@user_type" + (xp == "admin" ? "" : "!") + "='admin']/*";
    fmd = defaultFmdDoc.selectSingleNode(xp);
    if (!fmd) return;
    pref.itemNode.selectSingleNode("metadata").text = fmd.xml;
    isDefaultMD = true;
  }
  
  this.prefID = (isDefaultMD) ? null : pref.itemNode.selectSingleNode( "id" ).text;
  
  var mdata_node = pref.itemNode.selectSingleNode( "//Item/metadata" );
  var mdata_xml = mdata_node.text;
  
  var mdata_doc = arasObj.createXMLDocument();
  mdata_doc.loadXML( mdata_xml );
  
  var entries = mdata_doc.selectNodes( "//metaentry" );
  if( !entries || entries.length == 0 )
    return;

  var indx = 0;
  for( indx = 0; indx < entries.length; indx++ )
  {
    var enode = entries[indx];
    var type = enode.selectSingleNode( "type" ).text;
    var key = enode.selectSingleNode( "key" ).text;
    var mvalue = enode.selectSingleNode( "mask" ).text;
    
    var entry = new MetaDataEntry( type, key );
    entry.mask = parseInt( mvalue, 10 );
    this.fmdata.push( entry );
  }
  
  // Count the counter for each meta-data entry and drop the oldest session
  for( indx = 0; indx < this.fmdata.length; indx++ )
  {
    var entry = this.fmdata[indx];
    entry.countSessions();
    entry.dropOldest();
  }
  
  // sort the array based on 'session_counter'
  if( this.fmdata.length > 0 )
    this.fmdata.sort( sort_fmdata );
    
  // add fmddata entries into array of data to be preloaded
  for( indx = 0; indx < this.fmdata.length; indx++ )
  {
    var entry = this.fmdata[indx];
    preloads.push( entry.type + ":" + entry.key );
  }
}

/*
 * Save data in user preferences on server. The method must be called only once
 * on exit from Innovator (right now it's called from aras.logout()).
 */
FavoriteMetaData.prototype.saveInPrefs = function FavoriteMetaData_saveInPrefs(arasObj)
{
  var xml = "<Item type='Core_FavoriteMetaData' action='";
  xml += ( this.prefID == null ? "add" : "update' id='" + this.prefID );
  xml += "'><metadata><![CDATA[<metadata>";
  for( var indx = 0; indx < this.fmdata.length; indx++ )
  {
    var entry = this.fmdata[indx];
    xml += "<metaentry><type>" + entry.type + "</type><key>" + 
           entry.key + "</key><mask>" + entry.mask + "</mask></metaentry>";
  }
  xml += "</metadata>]]></metadata></Item>";
  
  //debugger;
    
  var pref_doc = arasObj.createXMLDocument();
  pref_doc.loadXML( xml );
  arasObj.setPreference( pref_doc.selectNodes( "/Item" ) );
}

/*
 * Search entry by its key
 */
FavoriteMetaData.prototype.findEntry = function FavoriteMetaData_findEntry( typeParam, keyParam )
{
  for( var indx = 0; indx < this.fmdata.length; indx++ )
  {
    var entry = this.fmdata[indx];
    if( entry.type == typeParam && entry.key == keyParam )
      return entry;
  }
  
  return null;
}
