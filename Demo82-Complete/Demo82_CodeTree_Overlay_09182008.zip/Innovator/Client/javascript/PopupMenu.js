﻿// © Copyright by Aras Corporation, 2004-2007.

//constants
var fontSize_const = '8';
var popupMenuFont_const = 'normal normal normal '+fontSize_const+'pt normal';
var borderWidth_const = 2;
var leftRightMargin_const = 0;
var topBottomMargin_const = 1;
var labelHeight_const = 13;
var arasScrollBar_const = 15;
var separatorImgPath_const = '../images/lines/100x4_divider.gif';

function setSeparatorImgPath(newPath) {
	separatorImgPath_const = newPath;
}

/*
PopupMenu:

setLabel(menuLabel)
setShowLabel(showLabel)
setOnClick(onClick_handler)
setFont(newFont) //font-style font-variant font-weight font-size line-height
setParentWindow(win)

getId()
getLabel()
getLabel()
getOnClick()
getFont()
getParentWindow()

show(left, top)
hide()
hideAll()


-----------------------------
MenuItem:

setLabel(label)
setEnabled(enabled)
setChecked(checked)

getId()
getLabel()
isEnabled()
*/

// ++++++++++   PopupMenu   ++++++++++ //
function PopupMenu(menuID, menuLabel, showLabel) {
	if (menuID == undefined) menuID = 'id_';
	if (menuLabel==undefined) menuLabel = '';
	else menuLabel = menuLabel.toString();
	if (showLabel==undefined) showLabel = false;
	
	this.isMenu = true;
	
	this.id = menuID;
	this.label = menuLabel;
	this.showLabel = showLabel;
	this.onClick = null;
	this.font = popupMenuFont_const;
	this.win = window;
	
	this.contentArr = new Array();
	this.contentMap = new Object();
	this.submenus   = new Object();
	
	this.isShown = false;
	this.parentMenu = null;
	this.shownSubMenu = null;
	this.clickedID = '';
	this.enabled = true;
	
	this.oPopup = null;
	
	this.top = 0;
	this.left = 0;
	this.width = 0;
	this.height = 0;
}

PopupMenu.prototype.isOpen = function PopupMenu_isOpen() {
  if (this.oPopup == null) return false;
  return this.oPopup.isOpen;
}

PopupMenu.prototype.setLabel = function PopupMenu_setLabel(menuLabel) {
	if (menuLabel == undefined) return;
	this.label = menuLabel.toString();
}

PopupMenu.prototype.setShowLabel = function PopupMenu_setLabel(showLabel) {
	if (showLabel == undefined) return;
	this.showLabel = showLabel;
}

PopupMenu.prototype.setOnClick = function PopupMenu_setOnClick(onClick_handler) {
	if (!onClick_handler || typeof(onClick_handler)!='function') return;
	
	this.onClick = onClick_handler;
}

PopupMenu.prototype.setFont = function PopupMenu_setFont(newFont) {
	if (!newFont) return;
	this.font = newFont;
}

PopupMenu.prototype.setParentWindow = function PopupMenu_setParentWindow(win) {
	if (!win) return;
	this.win = win;
}

PopupMenu.prototype.setEnabled = function PopupMenu_setEnabled(enabled) {
	this.enabled = enabled;
}

PopupMenu.prototype.getId = function PopupMenu_getId() {
	return this.id;
}

PopupMenu.prototype.getLabel = function PopupMenu_getLabel() {
	return this.label;
}

PopupMenu.prototype.getShowLabel = function PopupMenu_getLabel() {
	return this.showLabel;
}

PopupMenu.prototype.getOnClick = function PopupMenu_getOnClick() {
	return this.onClick;
}

PopupMenu.prototype.getFont = function PopupMenu_getFont() {
	return this.font;
}

PopupMenu.prototype.getParentWindow = function PopupMenu_getParentWindow() {
	return this.win;
}

PopupMenu.prototype.isEnabled = function PopupMenu_isEnabled() {
	return this.enabled;
}

PopupMenu.prototype.setClickedID = function PopupMenu_setClickedID(clickedID) {
	if (!clickedID) return;
	this.clickedID = clickedID;
	if (this.contentMap[clickedID] && this.contentMap[clickedID].isCheckable) {
		var prevState = this.contentMap[clickedID].isChecked();
		this.contentMap[clickedID].setChecked(!prevState);
	}
	if (!this.onClick && this.parentMenu) return this.parentMenu.setClickedID(clickedID);
	
	this.hideAll();
	
	if (this.onClick) this.onClick(this.getItemById(clickedID));
}

PopupMenu.prototype.getClickedID = function PopupMenu_getClickedID() {
	return this.clickedID;
}

PopupMenu.prototype.getSeparator = function () {
  return '<div style="border-top:solid #808080 1px; border-bottom:solid #ffffff 1px; margin-left:2px; margin-right:2px;"></div>';
}

PopupMenu.prototype.show = function PopupMenu_show(left, top) {
	if (this.contentArr.length == 0) return; //to not show empty menu
	
	if (left == undefined) left = 0;
	if (top  == undefined) top  = 0;
	
	if (this.isShown) return true;
	
	this.win.oPopup = this.win.createPopup();
	this.oPopup = this.win.oPopup;
	var oPopup = this.oPopup;
	
	var doc = oPopup.document.open();
	var font = this.getFont();
	
	doc.writeln('<html>\n'+
	'<head><style type="text/css">\n'+
	'body {overflow-y: hidden; overflow-x: hidden; border-style:outset; border-color:grey; '+
		'cursor:default; background-color:buttonface;'+
		'border-width:'+borderWidth_const+'; '+
		'margin-top:'+topBottomMargin_const+'; '+
		'margin-bottom:'+topBottomMargin_const+'; '+
		'margin-left:'+leftRightMargin_const+'; '+
		'margin-right:'+leftRightMargin_const+'; '+
		'font:'+(font ? font : '')+'; '+
		'font-family:Tahoma; '+
	        'scrollbar-3dlight-color:buttonface;\n'+
		'}\n'+
	'table {font:'+(font ? font : '')+'; font-family:Tahoma; '+
		'width:100%; height:'+(fontSize_const*2.5)+'px;'+
		'}\n'+
	'span {float:none; width:100%;}\n'+
	'.st   {color:; background-color:;}\n'+
	'.sth  {color:highlighttext; background-color:highlight;}\n'+
  ".labelTD {width:100%;}\n" +
  ".csignZone {font-family:Marlett; font-size:x-small; margin-right:0.1em; visibility:hidden; }\n" +//border:solid red 1px;
  ".labelZone {margin-right:2em;}\n" +//border:solid green 1px;
  ".smsignZone {font-family:Marlett; font-size:x-small; margin-right:0.1em;}\n"+ //border:solid blue 1px;
	'</style></head>\n');
	
	doc.creator_owner = this;
    
    //+++ define the very first and very last non separator rows +++
    var firstRowId = "";
    var lastRowId = "";
    var cntArr = this.contentArr;
    if (cntArr && cntArr.length>0)
    {
      var i=0;
      do
      {
        firstRowId = (cntArr[i].getId) ? cntArr[i].getId() : "";
        i++;
      } while (!firstRowId && i<cntArr.length)
      i = cntArr.length - 1;
      do
      {
        lastRowId = (cntArr[i].getId) ? cntArr[i].getId() : "";
        i--;
      } while (!lastRowId && i>=0)
    }
    //--- define the very first and very last non separator rows ---
	
	doc.writeln('<script>\n'+
	
	'function getSpanElement(elem) {\n'+
	' if (elem.tagName=="SPAN") return elem;\n'+
	' if (elem.tagName=="BODY") return null;\n'+
	' if (!elem.parentElement) return null;\n'+
	' return getSpanElement(elem.parentElement);\n'+
	'}\n'+
	
	'var highlightedRow = null;\n'+
	'displayArasScrollBar = false;\n'+
	'var firstRowId = "'+firstRowId+'";\n'+
	'var lastRowId = "'+lastRowId+'";\n'+
      
	'var maxScrollTop = null;\n'+
	'function setHighLighted(row) {\n'+
	' if (row === highlightedRow) return;\n'+
	' if (highlightedRow && highlightedRow.id==firstRowId && row.id==lastRowId && '+this.contentArr.length+'>2) return;\n'+
	' if (highlightedRow && highlightedRow.id==lastRowId && row.id==firstRowId && '+this.contentArr.length+'>2) return;\n'+
	' if (highlightedRow) {\n'+
	'  if (document.creator_owner.getItemById(highlightedRow.id).isEnabled()) highlightedRow.className = "st";\n'+
	'  else highlightedRow.className = "std";\n'+
	' }\n'+
	' if (document.creator_owner.getItemById(row.id).isEnabled()) row.className = "sth";\n'+
	' else row.className = "sthd";\n'+
	' highlightedRow = row;\n'+
	' if (row.id==firstRowId || row.id==lastRowId) bMousePressedDown=false;\n'+
	' var docB = document.getElementById("mainDiv"); \n'+
	' var iOffsetTop = row.offsetTop;\n'+
	' var iClientHeight = row.clientHeight;\n'+
	' var st=docB.scrollTop;\n'+
	' if (iOffsetTop - st<=0) docB.scrollTop = iOffsetTop;\n'+
	' if (iOffsetTop + iClientHeight - docB.clientHeight - st>5) docB.scrollTop = st+iClientHeight;\n'+
	' if (row.id==lastRowId) maxScrollTop = docB.scrollTop;\n'+
	' document.all("UpArrowButton").disabled = (docB.scrollTop === 0 ? true : false);\n'+
	' document.all("DownArrowButton").disabled = ((maxScrollTop!==null && maxScrollTop<=docB.scrollTop) ? true : false);\n'+
	'}\n'+

	'var bMousePressedDown=false;\n'+
	'function upDownArrowButtonClick(isUp)'+
    '{\n'+
	' var kCode = (isUp) ? 38 : 40;\n'+
	' if (bMousePressedDown) onKeyPress({keyCode:kCode});\n'+
	' if (bMousePressedDown) setTimeout("upDownArrowButtonClick("+isUp+")", 100);\n'+
	'}\n'+
      
	'function showSubMenu(row) {\n'+
	' var docB = document.getElementById("mainDiv"); \n'+
	' var left = document.creator_owner.width;\n'+
	' var top = row.offsetTop + '+(borderWidth_const+topBottomMargin_const)+'+'+(this.showLabel ? labelHeight_const:'0')+'+(document.displayArasScrollBar?('+arasScrollBar_const+'):0) - docB.scrollTop;\n'+
	' document.creator_owner.showSubMenu(row.id, left, top);\n'+
	'}\n'+
	
	'document.onselectionchange = function () {return false;}\n'+
	
	'function onMouseOverRow(row) {\n'+
	' if (row === highlightedRow) return;\n'+
	' setHighLighted(row);\n'+
	' if (row.clss == "submenu") showSubMenu(row);\n'+
	' else document.creator_owner.highlightItem(row.id);\n'+
	'}\n'+

	'function onClick(row) {\n'+
	' if (row.clss == "menuitem") {\n'+
	'  document.creator_owner.setClickedID(row.id);\n'+
	' }\n'+
	' else if (row.clss == "submenu") {\n'+
	'  if (document.creator_owner.shownSubMenu) document.creator_owner.hideSubMenu();\n'+
	'  else showSubMenu(row);\n'+
	' }\n'+
	'}\n'+
	
	'function onKeyPress(event) {\n'+
	' var keyCode = event.keyCode;\n'+
	' if (keyCode == 27) {\n'+
	'  document.creator_owner.hideAll();\n'+
	' }\n'+
	' else if (keyCode == 13) {\n'+
	'  if (highlightedRow) {\n'+
	'   if (highlightedRow.clss == "menuitem") {\n'+
	'    document.creator_owner.setClickedID(highlightedRow.id);\n'+
	'   }\n'+
	'   else if (highlightedRow.clss) {\n'+
	'    if (document.creator_owner.shownSubMenu) document.creator_owner.hideSubMenu();\n'+
	'    else showSubMenu(highlightedRow);\n'+
	'   }\n'+
	'  }\n'+
	' }\n'+
	' else if (keyCode == 40) {\n'+//down arrow
//  " debugger;\n" +
	'  var nextRow = null;\n'+
	'  if (highlightedRow) nextRow = highlightedRow.nextSibling;\n'+
	'  else {\n'+
	'   var tables = document.all("mainTable").all.tags("TABLE");\n'+
	'   if (tables && tables.length>0) nextRow = tables(0);\n'+
	'  }\n'+
	'  if (nextRow) for( ; nextRow.tagName!="TABLE" || nextRow.disabled==true; ) {\n'+
	'   nextRow = nextRow.nextSibling;\n'+
	'   if (!nextRow) break;\n'+
	'  }\n'+
	
//	'  if (!nextRow || nextRow.tagName!="TABLE" || nextRow.disabled) nextRow = null;\n'+
	'  if (!nextRow || nextRow.tagName!="TABLE" || nextRow.disabled) { \n'+
	'     var tables = document.all("mainTable").all.tags("TABLE");\n'+
	'     if (tables && tables.length>0) nextRow = tables(0);\n'+	
	'  }\n'+
	'  if (nextRow) for( ; nextRow.tagName!="TABLE" || nextRow.disabled==true; ) {\n'+
	'   nextRow = nextRow.nextSibling;\n'+
	'   if (!nextRow) break;\n'+
	'  }\n'+
	'  if (!nextRow || nextRow.tagName!="TABLE" || nextRow.disabled) nextRow = null;\n'+	
	
	
	'  if (nextRow) setHighLighted(nextRow);\n'+
	' }\n'+
	' else if (keyCode == 39) {\n'+//right arrow
	'  if (highlightedRow && highlightedRow.clss == "submenu") showSubMenu(highlightedRow);\n'+
	' }\n'+
	' else if (keyCode == 38) {\n'+//up arrow
	'  var prevRow = null;\n'+
	'  if (highlightedRow) prevRow = highlightedRow.previousSibling;\n'+
	'  else {\n'+
	'   var tables = document.all("mainTable").all.tags("TABLE");\n'+
	'   if (tables && tables.length>0) prevRow = tables(tables.length-1);\n'+
	'  }\n'+
	'  if (prevRow) for( ; prevRow.tagName!="TABLE" || prevRow.disabled==true; ) {\n'+
	'   prevRow = prevRow.previousSibling;\n'+
	'   if (!prevRow) break;\n'+
	'  }\n'+
	
	'  if (!prevRow || prevRow.tagName!="TABLE" || prevRow.disabled) {\n'+
	'     var tables = document.all("mainTable").all.tags("TABLE");\n'+
	'     if (tables && tables.length>0) prevRow = tables(tables.length-1);\n'+	
	'   }\n'+	
	'  if (prevRow) for( ; prevRow.tagName!="TABLE" || prevRow.disabled==true; ) {\n'+
	'   prevRow = prevRow.previousSibling;\n'+
	'   if (!prevRow) break;\n'+
	'  }\n'+
    
	
	'  if (!prevRow || prevRow.tagName!="TABLE" || prevRow.disabled) prevRow = null;\n'+
	'  if (prevRow) setHighLighted(prevRow);\n'+
	' }\n'+
	' else if (keyCode == 37) {\n'+//left arrow
	'  if (document.creator_owner.parentMenu) document.creator_owner.hide();\n'+
	' }\n'+
	'}\n'+
	'</script>\n'+
	
	'<body '+
	'oncontextmenu="return false;" ondblclick="return false;" onselectstart="return false;"'+
	'onkeydown="onKeyPress(event); return false;" '+
	'onunload="document.creator_owner.hideAll();" '+
	'>');

	if (this.showLabel) {
		var label2display = this.getLabel().replace(/ /g, '&nbsp;');
		doc.writeln('<center><span id="labelSpan" align="center">&nbsp;&nbsp;'+label2display+'&nbsp;&nbsp;</span></center>');
		doc.writeln(this.getSeparator());
	}

    doc.writeln('<center><span id="UpArrow" class="smsignZone" style="display:expression(document.displayArasScrollBar ? \'block\':\'none\'); cursor:hand;" onmouseover="bMousePressedDown=true; upDownArrowButtonClick(true);" onmouseout="bMousePressedDown=false;"><button id="UpArrowButton" DISABLED class="smsignZone" style="background-color:buttonface; width:expression(document.body.clientWidth); cursor:hand; border:none;">&#53;</button></span></center>');
                
    doc.writeln('<div id="mainDiv" width="100%" style="overflow:hidden; height:expression(document.body.clientHeight-(document.displayArasScrollBar? (2*'+arasScrollBar_const+'):0)'+(this.showLabel?("-document.all(\'labelSpan\').offsetHeight"):"")+')">' +
                '<table id="mainTable" cellspacing="0" cellpadding="0" border="0"><tr><td nowrap valign="middle">');
	
	var const1 = '<font style="visibility:hidden" face="Marlett" size="1">&#97;</font>';
	var const2 = '<font face="Marlett"  size="1">&#97;</font>';

	for (var i=0; i<this.contentArr.length; i++) {
		var itm = this.contentArr[i];
		if (itm.isSeparator) doc.write(this.getSeparator());
		else {
      var str =
        '<table clss="' + (itm.isMenu ? 'submenu' : 'menuitem') + '" id="'+itm.getId().toString().replace(/"/g, '&quot;')+'" onmouseover="onMouseOverRow(this); return false;" '+
        'onclick="onClick(this); return false;" cellpadding="0" cellspacing="0" border="0"><tr>'+
        '<td align="left" valign="middle"><span class="csignZone" ' + ((!itm.isMenu && itm.isChecked()) ? 'style="visibility:visible;"' : '') + '>&#97;</span></td>'+
        '<td align="left" valign="middle" class="labelTD" nowrap><span class="labelZone">'+itm.getLabel()+'</span></td>'+
        (itm.isMenu ? '<td align="left" valign="middle"><span class="smsignZone">&#52;</span></td>' : '')+
        '</tr></table>';
      
      doc.write(str);
		}
	}
	
	doc.writeln(
		'<script>\n'+
		'var elem = null;'
	);
	for (var i=0; i<this.contentArr.length; i++) {
		var itm = this.contentArr[i];
		if (!itm.isSeparator && !itm.isEnabled()) {
			doc.writeln(
				'elem = document.getElementById("'+itm.getId()+'");\n'+
				'if (elem && !elem.length) elem.disabled = true;'
			);
		}
	}
	doc.writeln('</script>');
	
	doc.writeln('</td></tr></table></div>');
    doc.writeln('<center><span id="DownArrow" class="smsignZone" style="display:expression(document.displayArasScrollBar ? \'block\':\'none\'); cursor:hand;" onmouseover="bMousePressedDown=true; upDownArrowButtonClick(false);" onmouseout="bMousePressedDown=false;"><button id="DownArrowButton" class="smsignZone" style="background-color:buttonface; width:expression(document.body.clientWidth); cursor:hand; border:none;">&#54;</button></span></center>');
    doc.writeln('</body></html>');
	doc.close();
	
	this.isShown = true;
	oPopup.show(left, top, 1, 1, this.win.document.body);
    var w1 = doc.all('mainTable').offsetWidth;
    var w2 = (this.showLabel ? doc.all('labelSpan').offsetWidth : 0);
	var width = ((w1-w2<0) ? w2:w1) + 2 * borderWidth_const + 2 * leftRightMargin_const;
	var height = doc.all('mainTable').offsetHeight + 2 * borderWidth_const + 2 * topBottomMargin_const + (this.showLabel ? doc.all('labelSpan').offsetHeight:0);
	
	var maxHeight = window.screen.availHeight;
	this.left = left;
	this.top  = top;
	this.width = width;
	this.height = (height-maxHeight<=0) ? height : maxHeight;
    oPopup.document.displayArasScrollBar = (height-maxHeight<=0) ? false : true;
	
	oPopup.show(this.left, this.top, this.width, this.height, this.win.document.body);
	return true;
}

PopupMenu.prototype.highlightItem = function PopupMenu_highlightItem(menuitemID) {
	var submenu = this.submenus[menuitemID];
	if (this.shownSubMenu && (!submenu || this.shownSubMenu!==submenu)) this.hideSubMenu();
}

PopupMenu.prototype.showSubMenu = function PopupMenu_showSubMenu(submenuID, left, top) {
	var submenu = this.submenus[submenuID];
	if (!submenu) return false;
	if (this.shownSubMenu === submenu) return true;
	
	if (this.shownSubMenu) this.hideSubMenu();
	
	submenu.setParentWindow(this.oPopup.document.parentWindow);
	submenu.show(left, top);
	this.shownSubMenu = submenu;
	return true;
}

PopupMenu.prototype.hideSubMenu = function PopupMenu_hideSubMenu() {
	if (!this.shownSubMenu) return false;
	
	this.shownSubMenu.hide();
	this.shownSubMenu = null;
}

PopupMenu.prototype.hide = function PopupMenu_hide() {
	if (!this.isShown) return true;
	
	if (this.shownSubMenu) this.shownSubMenu.hide();
	if (this.parentMenu && this.parentMenu.shownSubMenu===this) this.parentMenu.shownSubMenu = null;
	
	this.oPopup.document.body.onunload = '';
	this.oPopup.hide();
	
	this.isShown = false;
	return true;
}

PopupMenu.prototype.hideAll = function PopupMenu_hideAll(event) {
	if (!this.isShown) return true;
	
	if (this.parentMenu) this.parentMenu.hideAll();
	else this.hide();
}

PopupMenu.prototype.getItemCount = function PopupMenu_getItemCount() {
	return this.contentArr.length;
}

PopupMenu.prototype.getItem = function PopupMenu_getItem(pos) {
	var res = this.contentArr[pos];
	if (!res) res = null;
	return res;
}

PopupMenu.prototype.getItemById = function PopupMenu_getItemById(id) {
	var res = this.contentMap[id];
	if (!res) {
		for (var submenuID in this.submenus) {
			res = this.submenus[submenuID].getItemById(id);
			if (res) break;
		}
		if (!res) res = null;
	}
	
	return res;
}

PopupMenu.prototype.add = function PopupMenu_add(arg1, arg2, arg3, arg4) {
	return this.insert(this.contentArr.length, arg1, arg2, arg3, arg4);
}

PopupMenu.prototype.addSeparator = function PopupMenu_addSeparator() {
	return this.insertSeparator(this.contentArr.length);
}

PopupMenu.prototype.insert = function(pos, arg2, arg3, arg4, arg5) {
	if (pos==undefined) return null;
	pos = parseInt(pos);
	if (isNaN(pos)) return null;
	
	if (arguments.length >= 2 && typeof(arg2) == 'object' && arg2.isMenu) return this.insertSubMenu(pos, arg2, arg3);
	else return this.insertMenuItem(pos, arg2, arg3, arg4, arg5);
}

PopupMenu.prototype.insertSeparator = function PopupMenu_insertSeparator(pos) {
	if (pos==undefined) return null;
	pos = parseInt(pos);
	if (isNaN(pos)) return null;
	
	var newItm = new MenuSeparator;
	if (!newItm) return null;
	
	if (pos < 0) pos = 0;
	else if (pos > this.contentArr.length) pos = this.contentArr.length;
	
	if (pos == this.contentArr.length) this.contentArr.push(newItm);
	else if (pos == 0) {
		var tmpArr = new Array(newItm);
		this.contentArr = tmpArr.concat(this.contentArr);
	}
	else {
		var tmpArr1 = this.contentArr.slice(0, pos);
		var tmpArr2 = this.contentArr.slice(pos);
		tmpArr1.push(newItm);
		this.contentArr = tmpArr1.concat(tmpArr2);
	}
	
	return newItm;
}

PopupMenu.prototype.insertMenuItem = function PopupMenu_MenuItem(pos, pointID, pointLabel, pointEnabled, isCheckable) {
	if (pointID == undefined) pointID = 'id_';
	if (pointLabel == undefined) pointLabel = pointID;
	if (pointEnabled == undefined) pointEnabled = true;
	if (isCheckable == undefined) isCheckable = false;
	
	var newItm = new MenuItem(pointID, pointLabel, pointEnabled, isCheckable);
	if (!newItm) return null;
	
	if (this.contentMap[newItm.getId()]) return null;
	
	if (pos < 0) pos = 0;
	else if (pos > this.contentArr.length) pos = this.contentArr.length;
	
	if (pos == this.contentArr.length) this.contentArr.push(newItm);
	else if (pos == 0) {
		var tmpArr = new Array(newItm);
		this.contentArr = tmpArr.concat(this.contentArr);
	}
	else {
		var tmpArr1 = this.contentArr.slice(0, pos);
		var tmpArr2 = this.contentArr.slice(pos);
		tmpArr1.push(newItm);
		this.contentArr = tmpArr1.concat(tmpArr2);
	}
	
	this.contentMap[newItm.getId()] = newItm;
	
	return newItm;
}

PopupMenu.prototype.insertSubMenu = function PopupMenu_insertSubMenu(pos, subMenu, enabled) {
	if (enabled == undefined) enabled = true;
	
	if (this.contentMap[subMenu.getId()]) return null;
	
	if (pos < 0) pos = 0;
	else if (pos > this.contentArr.length) pos = this.contentArr.length;
	
	if (pos == this.contentArr.length) this.contentArr.push(subMenu);
	else if (pos == 0) {
		var tmpArr = new Array(subMenu);
		this.contentArr = tmpArr.concat(this.contentArr);
	}
	else {
		var tmpArr1 = this.contentArr.slice(0, pos);
		var tmpArr2 = this.contentArr.slice(pos);
		tmpArr1.push(subMenu);
		this.contentArr = tmpArr1.concat(tmpArr2);
	}
	
	this.submenus[subMenu.getId()] = subMenu;
	this.contentMap[subMenu.getId()] = subMenu;
	subMenu.setEnabled(enabled);
	subMenu.parentMenu = this;
}

PopupMenu.prototype.remove = function PopupMenu_remove(pos) {
	if (pos < 0) return null;
	if (pos >= this.getItemCount()) return null;
	
	var res = this.contentArr[pos];
	if (res.isSeparator) {}
	else if (res.isMenu) {
		delete this.submenus[res.getId()];
	}
	else {
		delete this.contentMap[res.getId()];
	}
	
	this.contentArr.splice(pos, 1);
	this.hide();
	
	return res;
}

PopupMenu.prototype.removeAll = function PopupMenu_removeAll() {
	this.contentArr = new Array();
	this.submenus = new Object();
	this.contentMap = new Object();
	
	this.hide();
}
// ----------   PopupMenu   ---------- //

// ********************************************************************* //

// ++++++++++   MenuItem   ++++++++++ //
function MenuItem(id, label, enabled, isCheckable) {
	if (id == undefined) id = 'id_';
	if (label == undefined) label = id;
	if (enabled == undefined) enabled = true;
	if (isCheckable == undefined) isCheckable = false;
	
	this.isMenuItem = true;
	
	this.id = id;
	this.label = label.toString();
	this.enabled = enabled;
	this.isCheckable = isCheckable;
	this.checked = false;
}

MenuItem.prototype.setLabel = function MenuItem_setLabel(label) {
	if (label == undefined) return;
	this.label = label.toString();
}

MenuItem.prototype.setEnabled = function MenuItem_setEnabled(enabled) {
	if (enabled == undefined) return;
	this.enabled = enabled;
}

MenuItem.prototype.setChecked = function MenuItem_setChecked(checked) {
	if (checked == undefined) return;
	this.checked = checked;
}

MenuItem.prototype.getId = function MenuItem_getId() {
	return this.id;
}

MenuItem.prototype.getLabel = function MenuItem_getLabel() {
	return this.label;
}

MenuItem.prototype.isEnabled = function MenuItem_isEnabled() {
	return this.enabled;
}

MenuItem.prototype.isChecked = function MenuItem_isChecked() {
	return this.checked;
}
// ----------   MenuItem   ---------- //

// ********************************************************************* //

// ++++++++++   MenuSeparator   ++++++++++ //
function MenuSeparator() {
	this.isSeparator = true;
}
// ----------   MenuSeparator   ---------- //

//++++++ Unit tests ++++++
// To run tests just uncomment this section, include this js file to html page, browse the html page.
/*
  //+++ Commont Section +++
function populateMenu(menu, obj) {
    for (var propID in obj) {
        var point = obj[propID];
        if (point=="separator")
        {
          menu.addSeparator();
        } else if (typeof(point) == 'object') {
            var m = new PopupMenu(propID, propID+'\'s Properties', false);
            populateMenu(m, point);
            menu.add(m);
        }
        else menu.add(propID, point, true);
    }
}

function onPPMClick(menuItm)
{
  var menuID = menuItm.getId();
  alert("Selected menu id is " + menuID);
}
  //--- Commont Section ---
  
  //+++ Test 01 +++
function test01()
{
    var ppm = new PopupMenu('test01_ppm', '', false);
    setSeparatorImgPath('../images/lines/100x4_divider.gif');
    populatePropsList01(ppm);
    ppm.setOnClick(onPPMClick);
    window.focus();
    ppm.show(300, 300);
}
function populatePropsList01(ppm) {
    var obj = new Object();
    for (var i=0; i<10; i++)
      obj["sep"+i] = "separator";
    for (var i=0; i<50; i++)
    {
        obj[i] = "test01 Menu Item Number " + (i+1);
        var r = i/5;
        if (Math.ceil(r)==Math.floor(r))
          obj["sep2"+i] = "separator";
        r = i/10;
        if (Math.ceil(r)==Math.floor(r))
          obj["submenu"+r] = {p1:"menuItem 1", p2:"menuItem 2", p3:"menuItem 3"};
        r = i/7;
        if (Math.ceil(r)==Math.floor(r))
          obj["submenu2"+r] = {p0:"separator", p1:"menuItem 1", p2:"menuItem 2", p3:"menuItem 3", p4:"separator"};
        
    }
    for (var i=0; i<10; i++)
      obj["sep3"+i] = "separator";
    populateMenu(ppm, obj);
}
test01();
  //--- Test 01 ---
*/
//------ Unit tests ------