﻿// (c) Copyright by Aras Corporation, 2004-2007.

/*----------------------------------------
 * FileName: soap_object.js
 * 
 * Purpose:
 * Provide a way to comminucate with InnovatorServer using SOAP messages
 *
 */

/// <summary>
/// For internal use only.
/// Stores a set of Soap related constants.
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
var SoapConstants = new Object();

/// <summary>
/// URI to SOAP 1.1 schema
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.SoapEnvUri = "http://schemas.xmlsoap.org/soap/envelope/";

/// <summary>
/// Namespace used to return SOAP messages.
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.SoapNamespace = "SOAP-ENV";

/// <summary>
/// Opening tags Envelope, Body
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyStart = "<" + SoapConstants.SoapNamespace + ":Envelope xmlns:" + SoapConstants.SoapNamespace + "=\"" + SoapConstants.SoapEnvUri + "\"><" + SoapConstants.SoapNamespace + ":Body>";

/// <summary>
/// 
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyEnd = "</" + SoapConstants.SoapNamespace + ":Body></" + SoapConstants.SoapNamespace + ":Envelope>";

/// <summary>
/// Opening tags Envelope, Body, Fault
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyFaultStart = SoapConstants.EnvelopeBodyStart + "<" + SoapConstants.SoapNamespace + ":Fault>";

/// <summary>
/// 
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyFaultEnd = "</" + SoapConstants.SoapNamespace + ":Fault>" + SoapConstants.EnvelopeBodyEnd;

/// <summary>
/// Check of namespace to be used in XPath
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.SoapNamespaceCheck = "namespace-uri()='" + SoapConstants.SoapEnvUri + "' or namespace-uri()=''";

/// <summary>
/// XPath for Envelope
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeXPath = "*[local-name()='Envelope' and (" + SoapConstants.SoapNamespaceCheck + ")]";

/// <summary>
/// XPath for Body
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.BodyXPath = "*[local-name()='Body' and (" + SoapConstants.SoapNamespaceCheck + ")]";

/// <summary>
/// XPath for Fault
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.FaultXPath = "*[local-name()='Fault' and (" + SoapConstants.SoapNamespaceCheck + ")]";

/// <summary>
/// XPath for Envelope/Body
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyXPath = SoapConstants.EnvelopeXPath + "/" + SoapConstants.BodyXPath;

/// <summary>
/// XPath for Envelope/Body/Fault
/// </summary>
/// <remarks>
/// </remarks>
/// <history>
/// </history>
SoapConstants.EnvelopeBodyFaultXPath = SoapConstants.EnvelopeBodyXPath + "/" + SoapConstants.FaultXPath;


/*
SoapController is designed to manage asynchronous soap requests.
Contains:
  callback - function which is called when request is finished
             The parameter is passed to constructor.
  stop     - readonly parameter. Function which can be used to abort request
*/
function SoapController(callback)
{
  this.isInvalid = false;
  this.callback = callback;
  this.stop     = null;
}

//marks soap controller instance as invalid. For example when callback is no longer valid (for example when window is closed)
//this will prevent script errors.
SoapController.prototype.markInvalid = function SoapController_markInvalid()
{
  this.isInvalid = true;
}

/*
IOMAsAras is designed to have some methods (used in SOAP) named as in aras object.
Contains:
  parentIOMObj - IOM object (Innovator or Item is supposed).
*/
function IOMAsAras(parentIOMObj)
{
  this.parent = parentIOMObj;
}

IOMAsAras.prototype.getServerURL = function IOMAsAras_getServerURL()
{
  return this.parent.credentials.innovatorServerURL;
}

IOMAsAras.prototype.getVariable = function IOMAsAras_getVariable()
{
  return;
}

IOMAsAras.prototype.getCurrentPassword = function IOMAsAras_getCurrentPassword()
{
  return this.parent.credentials.password;
}

IOMAsAras.prototype.getPassword = function IOMAsAras_getPassword()
{
  return this.parent.credentials.password;
}

IOMAsAras.prototype.getCurrentLoginName = function IOMAsAras_getCurrentLoginName()
{
  return this.parent.credentials.loginName;
}

IOMAsAras.prototype.getDatabase = function IOMAsAras_getDatabase()
{
  return this.parent.credentials.database;
}

IOMAsAras.prototype.refreshWindows = function IOMAsAras_refreshWindows(message, results)
{
  return top.aras.refreshWindows(message, results);
}

IOMAsAras.prototype.getMainWindow = function IOMAsAras_getMainWindow()
{
  return ((top.aras) ? top.aras.getMainWindow() : null);
}

IOMAsAras.prototype.AlertError = function IOMAsAras_AlertError(a1, a2, a3)
{
  if (top.aras) top.aras.AlertError(a1, a2, a3);
}

IOMAsAras.prototype.getScriptsURL = function IOMAsAras_getScriptsURL()
{
  return ((top.aras) ? top.aras.getScriptsURL() : "");
}

IOMAsAras.prototype.createXMLDocument = function IOMAsAras_createXMLDocument()
{
  return this.parent.newXMLDocument();
}

IOMAsAras.prototype.getCommonPropertyValue = function IOMAsAras_getCommonPropertyValue(propNm)
{
  return ((top.aras) ? top.aras.getCommonPropertyValue(propNm) : null);
}

IOMAsAras.prototype.setCommonPropertyValue = function IOMAsAras_setCommonPropertyValue(propNm, propVal)
{
  if (top.aras) top.aras.setCommonPropertyValue(propNm, propVal);
}
//----- END of IOMAsAras
 
function SOAP(parent) {
  this.parent = parent;//parent Object (aras or an IOM object with type = Item, Innovator)
  var isIOM = false;
  if (parent && parent.constructor)
  {
    var funcStr = parent.constructor.toString().toLowerCase();
    if (funcStr.indexOf("aras")<0 || funcStr.indexOf("aras") > funcStr.indexOf("(")) isIOM = true;
  }
  this.isParentIOM = isIOM;
  
  if (isIOM && parent)
  {
    // adjust IOM object to have some methods named as in Aras object
    this.parent = new IOMAsAras(parent);
  }
}

var IOMSoap = SOAP; //pseudonym for SOAP to use in IOM.

SOAP.prototype.send = function SOAP_send(methodName, bodyStr, url, saveChanges, soapController, is_bgrequest) {
/*----------------------------------------
 * send
 * 
 * Purpose:
 * send xml to InovatorServer and return result.
 * returns SOAPResults object
 *
 * Arguments:
 * methodName - string with Innovator Server method name (ApplyItem, GetItem, ...)
 * bodyStr    - xml string to send
 * url        - url of Innovator Server (by default url is built from this.parent.baseURL)
 *
 * soapController - an instance of SoapController
 */
  var xmlhttp = new ActiveXObject("Msxml2.XMLHTTP.3.0");
  
  var arasableObj = this.parent;
  if (!arasableObj) return null;
  var SessIsClosedMsg_cnst = "The session is closed.";
  
  var self = this;
  var SessionTimeOut_consts = new Object();
  SessionTimeOut_consts.SessionAlive = "ok";
  SessionTimeOut_consts.SessionRestored = "Session was idle, but restored";
  SessionTimeOut_consts.SessionTimeout = "The current session is idle";
  SessionTimeOut_consts.ValidateFailed = "User validation is failed";
  SessionTimeOut_consts.ValidateCancelled = "User validation is cancelled";
  SessionTimeOut_consts.ValidateCancelledByUser = "User validation is cancelled by the user";
  var initalParams = new Object();
  initalParams.methodName = methodName;
  initalParams.bodyStr = bodyStr;
  initalParams.url = url;
  initalParams.saveChanges = saveChanges;
  initalParams.soapController = soapController;
  
  var semaphore = null;
  if( top.aras.semaphore )
    semaphore = top.aras.semaphore;
  
  if (methodName == undefined) return null;
  if (bodyStr == undefined) bodyStr = '';
  if ((url == undefined) || (url == '')) url = arasableObj.getServerURL();
  
  var soapStr = ''+
    SoapConstants.EnvelopeBodyStart +
    '<' + methodName + '>'+
      bodyStr+
    '</' + methodName + '>'+
    SoapConstants.EnvelopeBodyEnd;
  
  // save soap message to local file system
  if (arasableObj.getVariable("SaveRequest") == "true") {
    var fn = this.getDateStamp();
    fn = fn.replace(/:/g,'_');
    fn = arasableObj.getWorkingDir(true) + '\\' + methodName + '_' + fn + '.xml';
    try {
      var vaultApplet = arasableObj.vault;
      var f = vaultApplet.fileCreate(fn);
      f = vaultApplet.fileOpenAppend(fn);
      
      vaultApplet.fileWriteLine(soapStr);
      vaultApplet.fileWriteLine('\n\n\n');
      vaultApplet.fileClose();
    }
    catch (excep) {
    }
  }

  // save soap message to log window
  if (!this.isParentIOM && top.main && top.main.soapSent) {
    with (top.main.soapSent.document) {
      write("<hr><font color='blue'>Request Time stamp:</font><b>" + this.getDateStamp() + "</b><br>");
      arasableObj.uiViewXMLstringInFrame(top.main.soapSent, soapStr);
      write("<font color='blue'>Time stamp:</font><b>" + this.getDateStamp() + "</b><br>");
    }
  }
  
  var pwd = arasableObj.getCurrentPassword();
  var errDescription = "";
  var resStr = "";
  
  if (!pwd) {
    errDescription = "Password to communicate with Innovator Server cannot be empty."
  }
  else
  {
    var async = Boolean(soapController && soapController.callback);
    if (async)
    {
      function clearOnreadystatechangeHandler()
      {
        xmlhttp.onreadystatechange = new Function();
        xmlhttp = null;
      }
      
      var dt1;
      function abortRequest()
      {
        if (xmlhttp)
        {
          var tmp_xmlhttp = xmlhttp;
          clearOnreadystatechangeHandler();
          tmp_xmlhttp.abort();
          tmp_xmlhttp = null;
        }
      }
      soapController.stop = abortRequest;
      
      function onreadystatechangeHandler()
      {
        if ( xmlhttp && (xmlhttp.readyState==4) )
        {
          var resStr = xmlhttp.responseText;
          clearOnreadystatechangeHandler();
          
          if( semaphore && !is_bgrequest )
            semaphore.EndMainRequest();
          
          if (soapController.isInvalid) return;
          
          var res = new SOAPResults(arasableObj, resStr, false, saveChanges);
          if (!arasableObj.getCommonPropertyValue("ignoreSessionTimeoutInSoapSend") && arasableObj.getCommonPropertyValue("exitWithoutSavingInProgress"))
          {
            res = new SOAPResults(arasableObj, getFaultXml(SessIsClosedMsg_cnst), false, saveChanges);
            soapController.callback(res);
            return;
          }
          var sessionTimeOutMsg;
          if (!arasableObj.getCommonPropertyValue("ignoreSessionTimeoutInSoapSend")) sessionTimeOutMsg = checkIsSessionTimeOut(res);
          if (sessionTimeOutMsg == SessionTimeOut_consts.SessionRestored)
          {
            self.send(initalParams.methodName, initalParams.bodyStr, initalParams.url, initalParams.saveChanges, initalParams.soapController);
          }
          else
          {
            if (sessionTimeOutMsg == SessionTimeOut_consts.ValidateCancelledByUser)
            {
              exitInnovatorWithoutSaving();
              res = new SOAPResults(arasableObj, getFaultXml(SessIsClosedMsg_cnst), false, saveChanges);
            }
            soapController.callback(res);
          }
        }
      }
      
      xmlhttp.onreadystatechange = onreadystatechangeHandler;
    }
    else
    {
      if (!arasableObj.getCommonPropertyValue("ignoreSessionTimeoutInSoapSend") && arasableObj.getCommonPropertyValue("exitWithoutSavingInProgress"))
      {
        return new SOAPResults(arasableObj, getFaultXml(SessIsClosedMsg_cnst), false, saveChanges);
      }
    }
    
    if( semaphore && !is_bgrequest )
      semaphore.StartMainRequest();
    
    xmlhttp.open('POST', url, async);
    xmlhttp.setRequestHeader("SOAPaction", methodName);
    xmlhttp.setRequestHeader("AUTHUSER", arasableObj.getCurrentLoginName());
    xmlhttp.setRequestHeader("AUTHPASSWORD", pwd);
    xmlhttp.setRequestHeader("DATABASE", arasableObj.getDatabase());
    
    try {
      xmlhttp.send(soapStr);
      if (async) return;
      resStr = xmlhttp.responseText;
    }
    catch (excep) {
      if (this.isParentIOM)
        errDescription = "SOAP Send to " + url + " failed !\nDescription: " + excep.description;
      else
        arasableObj.showExceptionDetails(excep);
    }
    xmlhttp = null;
  }
  
  if( semaphore && !is_bgrequest )
    semaphore.EndMainRequest();
  
  if (errDescription) {
    resStr = getFaultXml(errDescription);
  }
  var finalRetVal = new SOAPResults(arasableObj, resStr, false, saveChanges);
  if (!arasableObj.getCommonPropertyValue("ignoreSessionTimeoutInSoapSend"))
  {
    var sessionTimeOutMsg = checkIsSessionTimeOut(finalRetVal);
    if (sessionTimeOutMsg == SessionTimeOut_consts.SessionRestored)
    {
      return this.send(initalParams.methodName, initalParams.bodyStr, initalParams.url, initalParams.saveChanges, initalParams.soapController);
    }
    else if (sessionTimeOutMsg == SessionTimeOut_consts.ValidateCancelledByUser)
    {
      exitInnovatorWithoutSaving();
      return new SOAPResults(arasableObj, getFaultXml(SessIsClosedMsg_cnst), false, saveChanges);
    }
  }
  
  return finalRetVal;
  
  function getFaultXml(descr)
  {
    var faultRetVal = 
      SoapConstants.EnvelopeBodyFaultStart +
        "<faultcode>1</faultcode><detail>" + descr + "</detail>" +
      SoapConstants.EnvelopeBodyFaultEnd;
    return faultRetVal;
  }
  
  //returns value from SessionTimeOut_consts hash only.
  function checkIsSessionTimeOut(soapRes2Check)
  {
    var SkipSsTmOutVldtn_const = "SkipSessTmOutValidation_75F1F8B7B39E4FB891B40010B69CD645";
    var retVal = SessionTimeOut_consts.SessionAlive;
    if (!self[SkipSsTmOutVldtn_const] && soapRes2Check && typeof(soapRes2Check)=="object" && soapRes2Check.isSessionTimeOutFault())
    {
      var IsConfirmPwdDialogOpened_const = "IsConfirmPwdDialogOpened_75F1F8B7B39E4FB891B40010B69CD645";
      var mainWnd = arasableObj.getMainWindow();
      var isModalDlgOpened = mainWnd[IsConfirmPwdDialogOpened_const];
      if (isModalDlgOpened)
      {
        mainWnd.DoFocusAfterAlert = true;
        return SessionTimeOut_consts.ValidateCancelled;
      }
      arasableObj.AlertError(soapRes2Check.getFaultDetails(), soapRes2Check.getFaultString(), soapRes2Check.getFaultActor());
      isModalDlgOpened = mainWnd[IsConfirmPwdDialogOpened_const];
      if (isModalDlgOpened)
      {
        mainWnd.DoFocusAfterAlert = true;
        return SessionTimeOut_consts.ValidateCancelled;
      }
      else
      {
        self[SkipSsTmOutVldtn_const] = true;
        var tmpSoapRes = self.send('generateNewGUID', '', url);//very simple request
        delete self[SkipSsTmOutVldtn_const];
        if (!tmpSoapRes.isSessionTimeOutFault()) return SessionTimeOut_consts.SessionRestored;
      }
      var scriptsUrl = arasableObj.getScriptsURL();
      if (mainWnd && scriptsUrl)
      {
        var changePwdUrl = scriptsUrl+"changeMD5Dialog.html";
        var data = new Object();
        data['title'] = 'Confirm Password';
        data['md5'] = arasableObj.getPassword();
        data['fieldName2ReturnMD5'] = 'oldmd5';
        data['oldMsg'] = 'Confirm Password: ';
        data['oldPwdOnly'] = true;
        data.aras = arasableObj;
        var isPwdConfirmed = false;
        while (!isPwdConfirmed)
        {
          mainWnd.focus();
          mainWnd[IsConfirmPwdDialogOpened_const] = true;
          isPwdConfirmed = mainWnd.showModalDialog(changePwdUrl, data, "dialogHeight:120px; dialogWidth:300px; center:yes; resizable:no; status:no; help:no;");
          mainWnd[IsConfirmPwdDialogOpened_const] = undefined;
          mainWnd.DoFocusAfterAlert = undefined;
          if (isPwdConfirmed === undefined)
          {
            var p = new Object();
            p.buttons = new Object();
            p.buttons.btnReturn  = "Return to Login";
            p.buttons.btnExit    = "Exit Innovator";
            p.defaultButton = "btnReturn";
            p.btnstyles = {btnReturn:"", btnExit:""};
            p.message = "You are going to exit Innovator. If you have any unsaved items your changes will be lost.";
            mainWnd[IsConfirmPwdDialogOpened_const] = true;
            var tmpRes = mainWnd.showModalDialog(scriptsUrl + "groupChgsDialog.html", p, "dialogHeight:150px;dialogWidth:300px;center:yes;resizable:no;status:no;help:no;");
            mainWnd[IsConfirmPwdDialogOpened_const] = undefined;
            if (tmpRes != "btnReturn")
            {
              isPwdConfirmed = true;
              retVal = SessionTimeOut_consts.ValidateCancelledByUser;
            }
          }
          else if (isPwdConfirmed != arasableObj.getPassword())
          {
            isPwdConfirmed = false;
            mainWnd[IsConfirmPwdDialogOpened_const] = true;
            mainWnd.DoFocusAfterAlert = true;
            arasableObj.AlertError("The Password Is Wrong!");
          }
          else
          {
            isPwdConfirmed = true;
            var r2 = self.send("ValidateUser", "");
            if(r2.getFaultCode()!=0)
            {
              retVal = SessionTimeOut_consts.ValidateFailed;
            }
            else
            {
              retVal = SessionTimeOut_consts.SessionRestored;
            }
          }
        }
      }
      else
      {
        retVal = SessionTimeOut_consts.SessionTimeout;
      }
    }
    return retVal;
  }
  
  function exitInnovatorWithoutSaving()
  {
    arasableObj.setCommonPropertyValue("exitWithoutSavingInProgress", true);
    var mainWnd = arasableObj.getMainWindow();
    if (mainWnd && arasableObj.utils)
    {
      arasableObj.utils.CloseRootWindow(mainWnd);
    }
  }
}

SOAP.prototype.getDateStamp = function SOAP_getDateStamp() {
  var date = new Date();
  var now = date.getFullYear() + "-";
  if (date.getMonth() < 10) now += "0"
  now += date.getMonth() + "-";
  if (date.getDate() < 10) now += "0"
  now += date.getDate() + ' ' +
    date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds() + ':' + date.getMilliseconds();
  return now;
}

///////////////////////////////////////////////////////////////////////////////////////////
// SOAPResults

function SOAPResults(arasableObj, resultsXML, silentMode, saveChanges)
{
  this.arasableObj = arasableObj;//parent aras object
  this.results    = arasableObj.createXMLDocument();
  this.resultsXML = resultsXML;
  
  with (this)
  {
    if (resultsXML != "")
    {
      results.loadXML(resultsXML);
      if (results.parseError.errorCode!=0)
      {
        if (top.main && top.main.soapReturn)
        {
          with (top.main.soapReturn.document)
          {
            write("<hr><font color='blue'>Response Time stamp:</font><b>" + getDateStamp() + "</b><br>");
            write(getResponseText());
            write("<font color='blue'>Time stamp:</font><b>" + getDateStamp() + "</b><br>");
          }
        }
        if (!silentMode)
          top.aras.soapErrorDialog(resultsXML);
      }
      else if (top.main && top.main.soapReturn)
      {
        with (top.main.soapReturn.document)
        {
          write("<hr><font color='blue'>Response Time stamp:</font> <b>" + getDateStamp() + "</b><br>");
          top.aras.uiViewXMLstringInFrame(top.main.soapReturn, getResponseText());
          write("<font color='blue'>Time stamp:</font> <b>" + getDateStamp() + "</b><br>");
        }
      }
    }
    
    if ( getFaultCode() == 'disconnected' ) top.aras.AlertError(getFaultDetails(), getFaultString(), res.getFaultActor());

    var message = getMessage();
    arasableObj.refreshWindows(message,results,saveChanges);
  }
}

SOAPResults.prototype.getResponseText = function() {
  return this.resultsXML;
}

SOAPResults.prototype.getParseError = function() {
  var res;
  res = "*** Wrong SOAP message! *** " + "\n\n" +
        "Error: " + this.results.parseError.srcText.replace("H1", "H3") + "\n" +
        "ErrorCode: " + this.results.parseError.errorCode + "\n" +
        "Reason: " + this.results.parseError.reason;
  return res;
}

SOAPResults.prototype.isFault = function SOAPResults_isFault() {
  if (this.results.parseError.errorCode != 0)
      return this.getParseError();
    
  var fault = this.results.selectSingleNode(top.aras.XPathFault());
  if (fault) return true;
  else return false;
}

SOAPResults.prototype.isSessionTimeOutFault = function SOAPResults_isSessionTimeOutFault()
{
  var sessionTimeoutFaultCode_const = 110;
  var sessionTimeoutSubstring_const = "session has expired";
  var xml = this.resultsXML;
  return (this.getFaultCode()==sessionTimeoutFaultCode_const && xml && typeof(xml)=="string" && xml.toLowerCase().indexOf(sessionTimeoutSubstring_const)>-1);
}

SOAPResults.prototype.getFaultCode = function() {
  if (this.results.parseError.errorCode != 0)
      return this.getParseError();
    
  var faultcode = this.results.selectSingleNode(top.aras.XPathFault("/faultcode"));
  if (faultcode) return faultcode.text;
  else return 0;
}

SOAPResults.prototype.getFaultString = function() {
  if (this.results.parseError.errorCode != 0) 
      return this.getParseError();

  var faultstring = this.results.selectSingleNode(top.aras.XPathFault("/faultstring"));
  if (faultstring) return faultstring.text;
  else return '';
}

SOAPResults.prototype.getFaultActor = function() {
  if (this.results.parseError.errorCode != 0) 
    return this.getParseError();

  var faultactor = this.results.selectSingleNode(top.aras.XPathFault("/faultactor"));
  if (faultactor) return faultactor.text;
  else return '';
}

SOAPResults.prototype.getFaultDetailsFull = function() {
  if (this.results.parseError.errorCode != 0) 
    return this.getParseError();
    
  var detail = this.results.selectSingleNode(top.aras.XPathFault("/detail"));
  if (detail) return detail.text;
  else return '';
}

SOAPResults.prototype.getFaultDetails = function() {
  if (this.results.parseError.errorCode != 0) 
    return this.getParseError();

  var detail = this.results.selectSingleNode(top.aras.XPathFault("/detail"));
  var msg = '';
  if (detail) {
    msg = detail.text;//.replace(/^.+\]/,'');
//    msg = msg.replace(/,.+$/,'');
  }
  return msg;
}

SOAPResults.prototype.getServerMessage = function SOAPResults_getServerMessage()
{
  var faultNd = this.results.selectSingleNode(top.aras.XPathFault());
  if (faultNd && faultNd.parentNode)
  {
    var serverMessageNd = faultNd.parentNode.selectSingleNode("server_message");
    if (serverMessageNd) return serverMessageNd.xml;
  }
}

SOAPResults.prototype.getResultsBody = function() {
  var res = this.getResult();
  var items = res.selectNodes("Item");
  return items.length==1 ? items(0).xml : res.xml;
}

SOAPResults.prototype.getResult = function() {
  var res = null;
  if (this.results && this.results.documentElement) {
    res = this.results.selectSingleNode(top.aras.XPathResult());
  }
  
  if (!res) {
    var subst = this.arasableObj.createXMLDocument();
    subst.loadXML(SoapConstants.EnvelopeBodyStart + '<Result />' + SoapConstants.EnvelopeBodyEnd);
    res = subst.documentElement.selectSingleNode(top.aras.XPathResult());
  }
  
  return res;
}

SOAPResults.prototype.getMessage = function() {
  var res = null;
  if (this.results && this.results.documentElement) {
    res = this.results.selectSingleNode(top.aras.XPathMessage());
  }
  
  if (!res) {
    var subst = this.arasableObj.createXMLDocument();
    subst.loadXML(SoapConstants.EnvelopeBodyStart + '<Message />' + SoapConstants.EnvelopeBodyEnd);
    res = subst.documentElement.selectSingleNode(top.aras.XPathMessage());
  }
  
  return res;
}

SOAPResults.prototype.getDateStamp = function() {
  var date = new Date();
  var now = date.getFullYear() + "-";
  if (date.getMonth() < 10) now += "0"
  now += date.getMonth() + "-";
  if (date.getDate() < 10) now += "0"
  now += date.getDate() + ' ' +
    date.getHours() + ':' + date.getMinutes() + ':' + date.getSeconds() + ':' + date.getMilliseconds();
  return now;
}

