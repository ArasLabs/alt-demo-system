﻿// © Copyright by Aras Corporation, 2004-2007.

/* ------------------------------------------------------------------------------
/* ------------------------------------------------------------------------------
/* ------------------------------------------------------------------------------

 - You need to include TabsStyle.css in your html file for correct work
 - You need add next lines in your html file:
		"<div id='_Tabs_Div' class='TabsDiv' onResize='_TabsCorrectWidth();' onContextMenu='_TabsShowMenu();'>"
		"<table style='margin:0;border:0;' width='100%'><tr>"
		"<td width=10 id=_Tabs_TDleft><button class='_TabsB' id=_Tab_btn_left disabled>&lt;</button></td>"
		"<td width=* id=_Tabs_TD></td>"
		"<td width=10 id=_Tabs_TDright><button class='_TabsB' id=_Tab_btn_right disabled>&gt;</button></td>"
		"<tr></table></div>"
 

-----------------------------

Tabs functions:

_TabsCreateTabs(ParentObj, OnClickFuncStr)

  // OnClickFuncStr - event handler for tab select event
	// Function prototype:
	// OnClickFuncStr(TabNo, TabLabel)
	//   TabNo     - zero-based index of selected Tab
	//   TabLabel  - Label of selected Tab
	// additional properties avialabel from 'window.event.srcElement'

_TabsAddTab(Label, OnClickFuncStr)

 	// OnClickFuncStr - event handler for tab select event
	// if 'OnClickFuncStr' is null then will take
	// 'OnClickFuncStr' passed into CreateTabs

_TabsDeleteTab(Label)
_TabsDeleteTabByID(ID)
_TabsGetID(Label)
_TabsGetSelectedID()
_TabsSetLabel(ID, Label)
_TabsChangeLabel(OldLabel, NewLabel)
_TabsSetTabData(TabID, data)
_TabsGetTabData(TabID)

-----------------------------

Correct next functions for your oun task:
	// in addition you need to correct 'Menu section' 
	// in _TabCreateTabs function

_TabsShowMenu()
_TabsOnMenuClick()

*/

/* Used variables ------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */

var _TabsDiv = null;
var _TabsTotal = 0;
var _TabsSelectedID = "";
var _TabsContextID = "";
var _TabsMenu = null;
var _TabsOnClickFuncStr = null;

/* Tabs functions ------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */

function _TabsCreateTabs(ParentObj, OnClickFuncStr){
	if(!ParentObj) return;

//	var TabStr="<div id='_Tabs_Div' class='TabsDiv' onResize='_TabsCorrectWidth();' onContextMenu='_TabsShowMenu();'>";
//	TabStr += "<table style='margin:0;border:0;' width='100%'><tr>";
//	TabStr += "<td width=10 id=_Tabs_TDleft><button class='_TabsB' id=_Tab_btn_left disabled>&lt;</button></td>";
//	TabStr += "<td width=* id=_Tabs_TD></td>";
//	TabStr += "<td width=10 id=_Tabs_TDright><button class='_TabsB' id=_Tab_btn_right disabled>&gt;</button></td>";
//	TabStr += "<tr></table></div>";

//	ParentObj.innerHTML = TabStr + ParentObj.innerHTML;
	_TabsDiv = ParentObj.all._Tabs_Div;
	_TabsOnClickFuncStr = OnClickFuncStr;	
	_TabsCorrectWidth();	
	
	// ----------  Menu section -----------------------
	
	_TabsMenu = new PopupMenu(1);
	
	_TabsMenu.setParentWindow(window);
	_TabsMenu.add('_Import',"Import Type");
	_TabsMenu.add('_Property',"Add Property");	
	_TabsMenu.addSeparator();
	_TabsMenu.add('_TabsAdd',"Add Tab");
	_TabsMenu.add('_TabsDel',"Remove Tab");
	
	_TabsMenu.setOnClick(_TabsOnMenuClick);
}

function _TabsAddTab(Label, OnClickFuncStr){
  if(!_TabsIsOK()) return;
  if(!Label) return;
	 
	var IDStr = "_Tab_btn_" + _TabsTotal;
	var ElemStr = "<button id='" + IDStr + "' ";
	ElemStr += "title='Click to view' ";
	ElemStr += "name='Tab' ";
	ElemStr += "onClick='_TabsBtnClick();";
	if(OnClickFuncStr) ElemStr += OnClickFuncStr + "("+_TabsTotal+",window.event.srcElement.innerText);";
	else if(_TabsOnClickFuncStr) ElemStr += _TabsOnClickFuncStr + "("+_TabsTotal+",window.event.srcElement.innerText);";
	ElemStr += "' class='TabsB'>";
	ElemStr += Label + "</button>";

	_TabsDiv.all._Tabs_TD.insertAdjacentHTML("beforeEnd", ElemStr);	 
	_TabsTotal += 1;
	 
	_TabsDiv.all._Tabs_TD.all[IDStr]._TabsData = null;
	if(!_TabsSelectedID) _TabsSelBtn(_TabsDiv.all._Tabs_TD.all[IDStr], true);
}

function _TabsDeleteTab(label){
	if(!label) return;	
	_TabsDeleteTabByID(_TabsGetID(Label));
}

function _TabsDeleteTabByID(ID){
	if(!_TabsIsOK()) return;
	if(!ID) return;
	
	if(_TabsSelectedID == ID) {
		_TabsSelectedID = "";
		parent.frames.fr_target.clearMapping();	
	}
	if (_TabsDiv.all._Tabs_TD.all[ID]) _TabsDiv.all._Tabs_TD.removeChild(_TabsDiv.all._Tabs_TD.all[ID]);
	if(_TabsSelectedID == "")
		if(_TabsDiv.all._Tabs_TD.all[0]) _TabsDiv.all._Tabs_TD.all[0].click();
}

function _TabsGetID(Label){
	if(!_TabsIsOK()) return null;
	if(!Label) return null;
	
	var Btns = _TabsDiv.all._Tabs_TD.all;
	for(i=0; Btns && i<Btns.length; i++)
		if(Btns[i].innerText == label) return Btns[i].id;
	return null;
}

function _TabsGetLabel(ID){
	if(!_TabsIsOK()) return null;
	if(!ID) return null;
	
	var Btn = _TabsDiv.all._Tabs_TD.all[ID];
	if (!Btn) return null;
	
	return (Btn.innerText);	
}

function _TabsGetSelectedID(){
	if(!_TabsIsOK()) return null;
	return _TabsSelectedID;
}

function _TabsSetLabel(ID, Label){
	if(!_TabsIsOK()) return;
	if(!ID) return;
	if(!Label) return;
	
	if(_TabsDiv.all._Tabs_TD.all[ID])
		_TabsDiv.all._Tabs_TD.all[ID].innerText = Label;
}

function _TabsChangeLabel(OldLabel, NewLabel){
	_TabsSetLabel(_TabsGetID(OldLabel), NewLabel);
}

function _TabsSetTabData(TabID, data){
	if(!_TabsIsOK()) return;
	if(!TabID || !_TabsDiv.all._Tabs_TD.all[TabID]) return;
	_TabsDiv.all._Tabs_TD.all[TabID]._TabsData = data;
}

function _TabsGetTabData(TabID){
	if(!_TabsIsOK()) return;
	if(!TabID || !_TabsDiv.all._Tabs_TD.all[TabID]) return;
	return _TabsDiv.all._Tabs_TD.all[TabID]._TabsData;
}

/* Additional functions ------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------- */

function _TabsOnMenuClick(){
	switch(_TabsMenu.getClickedID()){
		case '_Import':
			OnImportTypeMenu();
			break;
		case '_Property':
			OnAddPropertyMenu();
			break;
		case '_TabsAdd':
			_TabsAddTab("New Tab");
			break;
		case '_TabsDel':
			_TabsDeleteTabByID(_TabsContextID);
			break;
	}
}

function _TabsShowMenu(){
	window.event.returnValue = false;
	if(window.event.srcElement.getAttribute("name") == "Tab"){
	  _TabsContextID = window.event.srcElement.id;
		
		_TabsMenu.getItem(0).setEnabled(true);
		if(_TabsGetTabData(_TabsContextID) != null && top.batchTool.isFileLoaded()){
			_TabsMenu.getItem(1).setEnabled(true);
		} else _TabsMenu.getItem(1).setEnabled(false);				
		_TabsMenu.getItem(4).setEnabled(true);
	} else {
		_TabsMenu.getItem(0).setEnabled(false);
		_TabsMenu.getItem(1).setEnabled(false);
		_TabsMenu.getItem(4).setEnabled(false);
		_TabsContextID = "";
	}
	_TabsMenu.show(window.event.clientX, window.event.clientY);
}

function _TabsIsOK(){
   if (!_TabsDiv) return false;
   return true;
}

function _TabsCorrectWidth(){
	_TabsDiv.all._Tabs_TD.width = 
		_TabsDiv.clientWidth - 
		_TabsDiv.all._Tabs_TDleft.clientWidth - 
		_TabsDiv.all._Tabs_TDright.clientWidth;
}

function _TabsSelBtn(Btn, bSel){
	if(bSel){
		Btn.className = 'TabsBsel';
		_TabsSelectedID = Btn.id;
	} else {
		Btn.className = 'TabsB';
		_TabsSelectedID = "";
	}
}

function _TabsBtnClick(){
	var Btn;
	
	Btn = _TabsDiv.all[_TabsSelectedID];
	if(Btn) _TabsSelBtn(Btn, false);
	
	Btn = window.event.srcElement;
	if(Btn) _TabsSelBtn(Btn, true);	
}

function _TabsGetAllTabData() {
  dom = new ActiveXObject("Msxml2.DOMDocument.4.0");
  dom.async = false;
  dom.preserveWhiteSpace = true;
	var str = "<Tabs />";
	dom.loadXML(str);
	var tabsNd = dom.documentElement;
	
	for (var i = 0; i < _TabsTotal; i++) {
		var TabID = "_Tab_btn_" + i;
		var data = _TabsGetTabData(TabID);
		if (data)	{
			tabsNd.appendChild(data.cloneNode(true));
		}
	}
	return tabsNd;
}

function _TabsDeleteAllTab(){
	for (var i = 0; i < _TabsTotal; i++) {
		var TabID = "_Tab_btn_" + i;
	 _TabsDeleteTabByID(TabID);
	}
	_TabsTotal = 0;
}
