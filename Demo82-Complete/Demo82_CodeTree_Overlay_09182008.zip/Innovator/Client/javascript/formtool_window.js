﻿// (c) Copyright by Aras Corporation, 2004-2007.

function updateItemsGrid (updatedItem)
{
  if (!updatedItem || !window.isTearOff) return false;
  var updatedID = updatedItem.getAttribute('id');

  if (opener.main.work.isItemsGrid)
  {
    if (opener.main.work.itemTypeName==itemTypeName)
    {
		  var gridApplet = opener.main.work.gridContainer;
      if (gridApplet.getRowIndex(itemID) > -1 )
      {
        var wasSelected = (gridApplet.getSelectedItemIds(';').search(itemID) > -1);

        if (updatedID != itemID) opener.main.work.deleteRow(item);
        opener.main.work.updateRow(updatedItem);

        if (wasSelected)
        {
          if (updatedID == itemID) 
            opener.main.work.onSelectItem(itemID);
          else
          {
            var currSel = gridApplet.getSelectedId();
            //if (currSel)
            opener.main.work.onSelectItem(currSel);
          }
        }//if (wasSelected)
      }
    }
  }//if (opener.main.work.isItemsGrid)
}

function updateMenuState()
{
  if (top.isTearOff && document.frames['editor'] && document.frames['editor'].refreshMenuState)
    document.frames['editor'].refreshMenuState();
}

function getEditorFrame()
{
  return (top.isTearOff ? document.frames["editor"] : window);
}

function onSaveCommand()
{
  var statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.saveItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return true;

  res = loadForm();
  
  if (top.isTearOff) updateItemsGrid(res);
  
  top.aras.uiReShowItemEx(itemID, res, viewMode);

  return true;
}

function onLockCommand()
{
  var statusId = top.aras.showStatusMessage(0, 'locking...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.lockItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return true;

  res = loadForm();

  if (top.isTearOff) updateItemsGrid(res);
  
  isEditMode = true;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;
}

function onUnlockCommand()
{
  var statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
  
  var res = top.aras.unlockItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return false;
  
  res = loadForm();

  if (top.isTearOff) updateItemsGrid(res);
  
  isEditMode = false;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  
  return true;
}

function onUndoCommand()
{
  if (!top.aras.isDirtyEx(item))
  {
    top.aras.AlertError('Nothing to undo.');
    return true;
  }

  if (!confirm('Undo will discard your changes. Are you sure?')) return true;
  if (!top.aras.isTempEx(item))
  {
    top.aras.removeFromCache(itemID);
    var res = top.aras.getItemById(itemTypeName, itemID, 0);
    if (!res) return true;
  }

  if (window.isTearOff) updateItemsGrid(res);
  top.aras.uiReShowItemEx(itemID, res, viewMode);

  return true;
}

function onPurgeCommand()
{
  return onPurgeDeleteCommand('purge');
}

function onDeleteCommand()
{
  return onPurgeDeleteCommand('delete');
}

function onPurgeDeleteCommand(command)
{
  var editor = getEditorFrame();
  var res = false;
  
  if (command == 'purge') res = top.aras.purgeItem('Form', editor.currFormId, false);
  else res = top.aras.deleteItem('Form', editor.currFormId, false);
  
  if (res)
  {
    if (top.isTearOff) window.close();
    else
    {
      var formIT = top.aras.getItemFromServerByName('ItemType','Form','id');
      if (formIT) top.main.work.location.replace('itemsGrid.html?itemtypeID='+formIT.getAttribute('id'));
      else top.main.work.location.replace('about:blank');
    }
  }

  if (top.isTearOff && opener.main.work.isItemsGrid && opener.main.work.itemTypeName==itemTypeName)
  {
	  var gridApplet = opener.main.work.gridContainer;
    if (gridApplet.getRowIndex(itemID) > -1 ) gridApplet.deleteRow(itemID);
  }

  return true;
}

function onPrintCommand()
{
  var editor = getEditorFrame();
  top.aras.uiShowItemEx(editor.currFormNd, 'print view', true);
  return true;
}

function onExport2OfficeCommand(targetAppType)
{
  var editor = getEditorFrame();
  var itm = editor.currFormNd;
  if (itm)
  {
    top.aras.export2Office("", targetAppType, itm); 
  }
}

function onSaveUnlockAndExitCommand()
{
  var editor = getEditorFrame();
  
  var statusId;
  if (top.isTearOff) statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.saveItemEx(editor.currFormNd, false);
  if (top.isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
  if (!res) return true;
  
  if (top.isTearOff) statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
  res = top.aras.unlockItemEx(res);
  if (top.isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
  if (!res) return true;
  
  if (top.isTearOff)
  {
    res = loadForm();

    updateItemsGrid(res);
    window.close();
  }
  
  return true;
}

function onCloseCommand()
{
  if (window.isTearOff) window.close();
  return true;
}

function loadForm()
{
  var res = top.aras.getItemById("Form", itemID, 0);

  var tmp = top.aras.getFormForDisplay(itemID);
  top.aras.mergeItemRelationships(res, tmp.node);
  
  return res;
}

var windowReady = true;