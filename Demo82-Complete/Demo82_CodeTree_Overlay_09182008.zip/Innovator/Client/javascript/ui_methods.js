﻿// (c) Copyright by Aras Corporation, 2004-2007.

                       ///--- User Interface methods ---///
/*
 * uiShowItem
 *
 * parameters:
 * 1) itemTypeName - may be empty string if item is in client cache
 * 2) itemID       - obligatory
 * 3) viewMode     - 'tab view', 'tree view', 'print view', 'where used' or 'openFile'
 *                    if not specified top.aras.getVariable('viewMode') is used
 * 4) isTearOff    - true or false, if not specified top.aras.getVariable('TearOff') is used
 */
Aras.prototype.uiShowItem = function(itemTypeName, itemID, viewMode, isTearOff)
{
  if (!itemID) return false;
  if (viewMode == undefined ) viewMode = this.getVariable('ViewMode');
  if (isTearOff == undefined ) isTearOff = this.getVariable('TearOff')=='true';

  var itemNd = this.getItemUsingIdAsParameter(itemTypeName, itemID, 0);

  if (!itemNd) return false;
  return this.uiShowItemEx(itemNd, viewMode, isTearOff);
}


/*
* uiReShowItem
*
* parameters:
* 1) oldItemId- old id of item to be shown
* 2) itemId   - id of item to be shown //usually itemId==oldItemId
* 2) editMode - 'view', 'edit' or 'print'
* 3) viewMode - 'tab view', 'tree view', 'where used' or 'openFile'
* 4) isTearOff- true or false.
*/
Aras.prototype.uiReShowItem = function(oldItemId, itemId, editMode, viewMode, isTearOff) {
  if (!oldItemId || !itemId) return false;

  var itemNd = this.getItemById('', itemId, 0);
  if (!itemNd) return false;

  if (editMode == undefined || editMode.search(/^view$|^edit$|^print$/)==-1) {
    if ( this.isTempID(itemId) || this.getNodeElement(itemNd, 'locked_by_id')==this.getCurrentUserID() )
      editMode = 'edit';
    else editMode = 'view';
  }//print mode should be turned on explicitly

  if (editMode == 'print') viewMode = 'print view';

  if (viewMode == undefined ) viewMode = this.getVariable('ViewMode');
  if (isTearOff == undefined ) isTearOff = this.getVariable('TearOff')=='true';

  return this.uiReShowItemEx(oldItemId, itemNd, viewMode);
}

Aras.prototype.uiViewXMLInFrame = function(frame,dom) {
  if (! frame) return;
  with (frame.document) {
    var xsl = this.createXMLDocument();
    xsl.load('../styles/default.xsl');
    frame.document.write(dom.transformNode(xsl));
  }
}

Aras.prototype.uiViewXMLstringInFrame = function(frame,string) {
  if (! frame) return;
  with (frame.document) {
    var dom = this.createXMLDocument();
    dom.loadXML(string);

    var xsl = this.createXMLDocument();
    xsl.load('../styles/default.xsl');

    frame.document.write(dom.transformNode(xsl));
  }
}

Aras.prototype.uiFormUpdateItem = function(uiForm, item) {
  with (this) {
    var xml      = uiForm2XML(uiForm);
    var tmpDom   = createXMLDocument();
    tmpDom.loadXML(xml);

    if (item != undefined) {
      for (var i=0; i<tmpDom.documentElement.childNodes.length; i++) {
        var node = tmpDom.documentElement.childNodes.item(i).cloneNode(true);
        if (item.selectSingleNode(node.nodeName)) item.replaceChild(node,item.selectSingleNode(node.nodeName));
        else item.appendChild(node);
      }

      if ((item.getAttribute('action')!='add') && (item.getAttribute('action')!='create')) item.setAttribute('action','update');
    }
    else {
      var items = dom.selectNodes('//Item[@id="' + uiForm.itemID + '"]');
      for (var j=0; j<items.length; j++) {
        item = items[j];
        if (!item) continue;
        for (var i=0; i<tmpDom.documentElement.childNodes.length; i++) {
          var node = tmpDom.documentElement.childNodes.item(i).cloneNode(true);
          if(item.selectSingleNode(node.nodeName)) item.replaceChild(node,item.selectSingleNode(node.nodeName));
          else item.appendChild(node);
        }
        if ((item.getAttribute('action')!='add')&&(item.getAttribute('action')!='create')) item.setAttribute('action','update');
      }
    }
    //prompt(222, item.xml);
  }
}

Aras.prototype.uiForm2XML = function(uiForm) {
  var xml = '<uiForm>';

  if (uiForm && uiForm.elements) for (var i=0; i<uiForm.elements.length; i++)
    if (uiForm.elements[i].id && (uiForm.elements[i].id.search(/^tmp/)!=0) ) {
      xml += this.uiField2XML(uiForm.elements[i]);
      var fieldType = uiForm.elements[i].type;
      if ( (fieldType == "radio") || (fieldType == "checkbox") ) {//supposed, that radios and checkboxes are elemets[i],..,elements[i+cnt-1]
        var name = uiForm.elements[i].name;
        var cnt = uiForm.elements[name].length;
        if (cnt != undefined)  i += cnt-1;
      }
    }

  xml += '</uiForm>';

  return xml;
}

Aras.prototype.uiField2XML = function(uiField) {
  if (!uiField) return '';

  var fldId = uiField.id;//if ok fldId ~~ "fieldNd.id : itemNd.id : propNd.id"
  if (!fldId) return '';

  var ids = fldId.split(':');
  if (ids.length != 3) return '';

  var propId = ids[2];
  if (!propId) return '';

  var propNd = this.dom.selectSingleNode('//Item[@type="Property" and @id="'+propId+'"]');
  if (!propNd) return '';

  var propNm = this.getNodeElement(propNd, 'name');
  if (!propNm) return '';

  var value = this.uiFieldGetValue(uiField);
  if (value == null) return '';

  if (uiField.field_type == 'item') {
    return '<'+propNm+'>'+value+'</'+propNm+'>';
  }
  else {
    var elm = this.dom.createElement(propNm);
    value = this.dom.createTextNode(value);
    elm.appendChild(value);
    return elm.xml;
  }
}

Aras.prototype.uiFieldGetValue = function(uiField) {
  var uiForm  = uiField.form;
  var name    = uiField.name;
  var type    = uiField.type;
  var value   = null;

  if (uiField.field_type == 'item') value = uiField.internal_value;
  else if (type.search(/^text|^hidden$/) == 0) {
    if (uiField.internal_value) value = uiField.internal_value;
    else value = uiField.value;
  }
  else if (type == 'password') {
    if (uiField.pwdChanged==1) value = calcMD5(uiField.value);
    else value = uiField.internal_value;
  }
  else if (type == 'checkbox')   value = (uiField.checked) ? 1 : 0;
  else if (type == 'select-one') {
    if (uiField.selectedIndex != -1) value = uiField.options[uiField.selectedIndex].value;
  }
  else if (type == 'radio') {///SNNicky: check!!!!!
    value = '';
    for (var i=0; i<uiForm[name].length; i++) {
      if (uiForm[name][i].checked) {
        value = uiForm[name][i].value;
        break;
      }
    }
  }
  else if (type == 'checkbox_group') {
    value = '';
    for (var i=0; i<uiForm[name].length; i++) {
      if (uiForm[name][i].checked) {
        if (value != '') value += ',';
        value += uiForm[name][i].value;
      }
    }
  }
  top.aras.AlertError(name + ":" + value, "", "") //what does this do??
  return value;
}


Aras.prototype.uiPopulateMenubar = function(applet,dom) {
  var menu = applet.addMenubar(this.getItemProperty(dom,'id'));
  var rels = dom.selectNodes('Relationships/Item[@type="Menu"]/related_id/Item');
  if (rels && rels.length>0) {
    for (var i=0; i<rels.length; i++) {
      var menu_item = rels(i);
      this.uiPopulateSubmenu(applet,menu_item,menu);
    }
  }
}

Aras.prototype.uiPopulateSubmenu = function(applet,menu_item,menu) {
  var name    = this.getItemProperty(menu_item,'name');
  var id      = this.getItemProperty(menu_item,'id');
  var enabled = (this.getItemProperty(menu_item,'is_enabled') == '0') ? false : true;
  var rels    = menu_item.selectNodes('Relationships/Item[@type="Submenu"]/related_id/Item');

  if (rels && rels.length>0) {
    var submenu = menu.addSubmenu(name, id, enabled);
    for (var i=0; i<rels.length; i++) {
      var rel = rels(i);
      this.uiPopulateSubmenu(applet,rel,submenu);
    }
  }
  else if (name.search(/^Separator$/) == 0) {
    menu.addSeparatorItem();
  }
  else if (this.getItemProperty(menu_item,'has_state') == '1') {
    var checked = (this.getItemProperty(menu_item,'checked') == '0') ? false : true;
    menu.addCheckItem(name,id,checked,enabled);
  }
  else menu.addItem(name,id,enabled);
}


Aras.prototype.uiInitItemsGridSetups = function Aras_uiInitItemsGridSetups(itemTypeName, itemTypeId,  visibleProps) {
  if (!itemTypeName) return null;
  var self = this;
//  var _itemTypeName_ = itemTypeName.replace(/\s/g, '_');

  var varName_colOrder = 'IT_' + itemTypeId + '_colOrder';
  var varName_colWidths= 'IT_' + itemTypeId + '_colWidths';
  var varName_searchVis= 'IT_' + itemTypeId + '_searchVis';

  var gridSetups = this.sGridsSetups[itemTypeName];
  if (!gridSetups) {
    gridSetups = this.newObject();
    this.sGridsSetups[itemTypeName] = gridSetups;
  }

  var colWidths = this.getVariable(varName_colWidths);
  var colOrder = this.getVariable(varName_colOrder);
  var visible_search_row = this.getVariable(varName_searchVis);

  var flg = (   (colWidths == null || colWidths == "")
             || (colOrder == null || colOrder == "")
             || (visible_search_row == null || visible_search_row == "")
             || (colWidths.split(";").length != colOrder.split(";").length)
             || (visible_search_row.split(";").length != colOrder.split(";").length)
             || (visible_search_row.split(";").length != visibleProps.length+1)
            );

  if (!flg) {
    //check if already saved setups are valid
    colOrder = colOrder.replace(/(^|;)L($|;)/, "$1$2");

    function CheckCorrectColumnsInfo(arr, suffix) {
      if (!arr) return;

      for (var i=0; i<arr.length; i++) {
        var colNm = self.getItemProperty(arr[i], "name") + "_" + suffix;
        var re = new RegExp("(^|;)" + colNm + "(;|$)");
        if (colOrder.search(re) == -1) {
          flg = true;
          break;
        }
        colOrder = colOrder.replace(re, "$1$2");
      }
    }

    if (!flg) CheckCorrectColumnsInfo(visibleProps, "D");
    if (!flg) {
      colOrder = colOrder.replace(/;/g, "");
      if (colOrder != "") flg = true;
    }
  }

  if (flg)
  {
    colOrder = this.newArray();
    colWidths = this.newArray();
    visible_search_row = this.newArray();
    colOrder[0] = "L";
    colWidths[0] = 24;
    visible_search_row[0] = "";

    for (var i=0; i<visibleProps.length; i++)
    {
      var prop = visibleProps[i];
      var name = this.getItemProperty(prop, "name") + "_D";
      var width= parseInt(this.getItemProperty(prop, "column_width"));
      if (isNaN(width) || width == 0) width = 100;

      colOrder.push( name );
      colWidths.push( width );
    }

    for (var i=0; i < visibleProps.length; i++)
    {
      var propNd = visibleProps[i];
      var defSearch = this.getItemProperty(propNd, "default_search");
      visible_search_row.push( defSearch );
    }

    this.setVariable(varName_colWidths, colWidths.join(";"));
    this.setVariable(varName_colOrder, colOrder.join(";"));
    this.setVariable(varName_searchVis, visible_search_row.join(";"));

    gridSetups['visible_search_row'] = visible_search_row;
  }
  else
  {
    colWidths = colWidths.split(';');
    flg = false;

    //check for zero-width columns
    for (var i=0; i<colWidths.length; i++) {
      var newVal = parseInt(colWidths[i]);
      if ( isNaN(newVal) || newVal < 0) {
        newVal = ( i == 0 ? 24 : parseInt(this.getItemProperty(visibleProps[i-1], 'column_width')) );
        if ( isNaN(newVal) || newVal <= 0 ) newVal = 100;
        colWidths[i] = newVal;
        flg = true;
      }
    }

    if (flg) this.setVariable(varName_colWidths, colWidths.join(";"));

    if (!gridSetups['visible_search_row']) {
      gridSetups['visible_search_row'] = this.newArray().concat( visible_search_row.split(";") );
    }
  }
}

Aras.prototype.uiInitRelationshipsGridSetups = function Aras_uiInitRelationshipsGridSetups(relationshiptypeID,  Dprops, Rprops, grid_view)
{
  if (!grid_view) grid_view = "left";

  var self = this;

  var varName_colOrder = "RT_" + relationshiptypeID + "_colOrder";
  var varName_colWidths= "RT_" + relationshiptypeID + "_colWidths";
  var varName_searchVis= "RT_" + relationshiptypeID + "_searchVis";

  var colWidths = this.getVariable(varName_colWidths);
  var colOrder  = this.getVariable(varName_colOrder);
  var visible_search_row = this.getVariable(varName_searchVis);

  var flg = (   (colWidths == null || colWidths == "")
             || (colOrder == null || colOrder == "")
             || (visible_search_row == null || visible_search_row == "")
             || (colWidths.split(";").length != colOrder.split(";").length)
             || (colWidths.split(";").length != visible_search_row.split(";").length)
            );

  if (!flg) {
    //check if already saved setups are valid
    if (Rprops) colOrder = colOrder.replace(/(^|;)L($|;)/, "$1$2");

    function CheckCorrectColumnsInfo(arr, suffix) {
      if (!arr) return;

      for (var i=0; i<arr.length; i++) {
        var colNm = self.getItemProperty(arr[i], "name") + "_" + suffix;
        var re = new RegExp("(^|;)" + colNm + "(;|$)");
        if (colOrder.search(re) == -1) {
          flg = true;
          break;
        }
        colOrder = colOrder.replace(re, "$1$2");
      }
    }

    if (!flg) CheckCorrectColumnsInfo(Dprops, "D");
    if (!flg) CheckCorrectColumnsInfo(Rprops, "R");
    if (!flg) {
      colOrder = colOrder.replace(/;/g, "");
      if (colOrder != "") flg = true;
    }

    if (!flg) {
      colOrder = this.getVariable(varName_colOrder).split(";");
      colWidths = colWidths.split(';');
      flg = false;

      function getColumnDefaultWidth(colNum) {
        var colNm = colOrder[colNum];
        if (colNm == "L") return 24;

        var DR = colNm.substr(colNm.length-1);
        var propNm = colNm.substr(0, colNm.length-2);

        var propArr = null;
        if (DR == "D") propArr = Dprops;
        else if (DR == "R") propArr = Rprops;

        if (propArr) for (var i=0; i<propArr.length; i++) {
          var prop = propArr[i];
          if (self.getItemProperty(prop, "name") == propNm) {
            var column_width = parseInt( self.getItemProperty(prop, "column_width") );
            if ( isNaN(column_width) ) column_width = 100;
            return column_width;
          }
        }

        return 100;
      }

      //check for zero-width columns
      for (var i=0; i<colWidths.length; i++) {
        var newVal = parseInt(colWidths[i]);
        if ( isNaN(newVal) || newVal < 0) {
          newVal = getColumnDefaultWidth(i);
          colWidths[i] = newVal;
          flg = true;
        }
      }

      if (flg) this.setVariable(varName_colWidths, colWidths.join(";"));

      return;
    }
  }

  colOrder = this.newArray();
  colWidths = this.newArray();
  visible_search_row = this.newArray();
  if (Rprops) {
    colOrder[0] = "L";
    colWidths[0] = 24;
    visible_search_row[0] = "";
  }

  // +++ sort columns
  var Dpriority = 0, Rpriority = 0;
  if (grid_view == "left") {
    //related item goes first
    Dpriority = 1;
    Rpriority = 0;
  }
  else if (grid_view == "intermix") {
    Dpriority = 0;
    Rpriority = 0;
  }
  else {
    Dpriority = 0;
    Rpriority = 1;
  }

  var allPropsInfoArr = new Array();
  if (Dprops) for (var i=0; i<Dprops.length; i++)
  {
    var prop = Dprops[i];

    allPropsInfoArr.push(
      {
        name:this.getItemProperty(prop, "name") + "_D",
        width:this.getItemProperty(prop, "column_width"),
        sort_order:this.getItemProperty(prop, "sort_order"),
        default_search:this.getItemProperty(prop, "default_search"),
        priority:Dpriority
      }
    );
  }

  if (Rprops) for (var i=0; i<Rprops.length; i++)
  {
    var prop = Rprops[i];

    allPropsInfoArr.push(
      {
        name:this.getItemProperty(prop, "name") + "_R",
        width:this.getItemProperty(prop, "column_width"),
        sort_order:this.getItemProperty(prop, "sort_order"),
        default_search:this.getItemProperty(prop, "default_search"),
        priority:Rpriority
      }
    );
  }

  function sorterF(p1, p2)
  {
    var c1 = parseInt(p1.priority);
    var c2 = parseInt(p2.priority);

    if (c1 < c2) return -1;
    else if (c2 < c1) return 1;
    else {
      c1 = parseInt(p1.sort_order);
      c2 = parseInt(p2.sort_order);

      if ( isNaN(c2) ) return -1;
      if ( isNaN(c1) ) return 1;

      if (c1 < c2) return -1;
      else if (c2 < c1) return 1;
      else {
        c1 = p1.name;
        c2 = p2.name;

        if (c1 < c2) return -1;
        else if (c2 < c1) return 1;
        else return 0;
      }
    }
  }

  allPropsInfoArr = allPropsInfoArr.sort(sorterF);
  // --- sort columns

  for (var i=0; i<allPropsInfoArr.length; i++)
  {
    colOrder.push( allPropsInfoArr[i].name );

    var width = parseInt(allPropsInfoArr[i].width);
    if ( isNaN(width) ) width = 100;
    colWidths.push( width );
    visible_search_row.push(allPropsInfoArr[i].default_search);
  }

  this.setVariable(varName_colWidths, colWidths.join(";"));
  this.setVariable(varName_colOrder, colOrder.join(";"));
  this.setVariable(varName_searchVis, visible_search_row.join(";"));
}

Aras.prototype.uiToggleCheckbox = function(uiField) {
  uiField.checked = uiField.checked ? false : true;
}

Aras.prototype.uiLoadWindow = function(name) {
  with (this.windowsByName[name].frames[0].document) {
    write(this.drawFormByName(name));
    close();
  }
}

Aras.prototype.uiViewObjectModelInFrame = function(frame) {
  frame.location = 'javascript:top.aras.uiObjectModel()';
}

Aras.prototype.uiObjectModel = function(objStr) {
  if (arguments.length == 0) var objStr = 'top.aras';

  var obj = eval(objStr);

  var parentObj = objStr.substr(0,objStr.lastIndexOf("."));
  var endObj    = objStr.substr(objStr.lastIndexOf(".")+1);

  var props = this.newArray();
  for (var prop in obj) {
    props[props.length] = prop;
  }

  content = '<table border="0" cellspacing="1" cellpadding="2" bgcolor="#99cccc" width="100%">' +
    '<tr><td colspan=3 bgcolor=#cccccc><b>Object:</b>' +
    '<a href=javascript:top.aras.uiObjectModel("' + parentObj + '")>' +
    parentObj + '</a>.' + endObj + '</td></tr><tr>' +
    '<th bgcolor="#eeeeee" width="1%">Property</th>' +
    '<th bgcolor="#eeeeee" width="1%">Type</th>' +
    '<th bgcolor="#eeeeee">Value</th></tr>';

  props.sort(function(a,b) {
    if      (a < b) return -1;
    else if (a > b) return 1;
    else            return 0;
  });

  for (var i=0; i<props.length; ++i) {
    var prop    = props[i];
    var bgcolor = (i%2 == 0) ? "#ffffff" : "#eeeeee";

    content += '<tr valign=top bgcolor="' + bgcolor + '"><td>' + prop + '</td><td>';

    if (typeof(obj[prop]) == 'function') {
      content += '<a href=javascript:' + objStr + '.' + prop + '()>' +
      typeof(obj[prop]) + '</a>' +
      '</td><td></td></tr>';
    } else {
      if (parseInt(prop)) {
        content += '<a href=javascript:top.aras.uiObjectModel("' + objStr + '[' + prop + ']")>' +
        typeof(obj[prop]) + '</a>' +
        '</td><td>' + obj[prop] + '</td></tr>';
      } else {
        if (obj[prop].documentElement) {
          var f = 'top.main.work.results';

          content += typeof(obj[prop]) + '</td><td>' +
          '<iframe name="' + prop +
          '" width="100%" height="100%" border="0" frameborder="no" framespacing="0" marginwidth="0" marginheight="0" ' +
          'src="javascript:top.aras.uiViewXMLInFrame(' + f + '.' + prop + ',' + objStr + '.' + prop + ')"></iframe>';
        } else {
          content += '<a href=javascript:top.aras.uiObjectModel("' + objStr + '.' + prop + '")>' +
          typeof(obj[prop]) + '</a></td><td>' + obj[prop];
        }
        content += '</td></tr>';
      }
    }
  }

  content += '</table>';
  return content;
}

Aras.prototype.uiGenerateGridXML = function Aras_uiGenerateGridXML(inDom, Dprops, Rprops, id, params, getCached) {
  var sXsl = "";

  var key = id;
  if (params) for (var k in params) {
    key += ";" + k + "=" + params[k];
  }

  if (this.items2gridXSL[key]!=undefined && (getCached == undefined || getCached == true)) sXsl = this.items2gridXSL[key];
  else {
    sXsl = this.uiGenerateGridXSLT(Dprops, Rprops, params);
    this.items2gridXSL[key] = sXsl;
  }

  return this.applyXsltString(inDom, sXsl);
}

Aras.prototype.uiGenerateItemsGridXML = function Aras_uiGenerateItemsGridXML(inDom, props, itemtypeID, params) {
  return this.uiGenerateGridXML(inDom, props, undefined, itemtypeID, params);
}//uiGenerateItemsGridXML

Aras.prototype.uiGenerateRelationshipsGridXML = function Aras_uiGenerateRelationshipsGridXML(inDom, Dprops, Rprops, relationshiptypeID, params, getCached) {
  return this.uiGenerateGridXML(inDom, Dprops, Rprops, relationshiptypeID, params, getCached);
}//uiGenerateRelationshipsGridXML


Aras.prototype.uiGenerateMainTreeXML = function Aras_uiGenerateMainTreeXML(inDom) {
  return this.applyXsltFile(inDom, this.getScriptsURL()+'../styles/mainTree.xsl');
}

Aras.prototype.uiGenerateParametersGrid = function Aras_uiGenerateParametersGrid(itemTypeName, classification) {
/*----------------------------------------
 * uiGenerateParametersGrid
 *
 * Purpose:
 * sends request to Innovator Server to generate xml for parameters grid for
 * specified ItemType and classification. Returns xml string.
 *
 * Arguments:
 * itemTypeName - name of ItemType
 * classification - classification of an Item
 */

  var res = null;
  if (itemTypeName && classification)
  {
    var classificationDom = this.createXMLDocument();
    classificationDom.loadXML("<Item><classification /></Item>");
    classificationDom.documentElement.setAttribute("type", itemTypeName);
    classificationDom.selectSingleNode("Item/classification").text = classification;
    res = this.soapSend("GenerateParametersGrid", classificationDom.xml);
    res = res.getResult().selectSingleNode("table");
  }

  if (res) {
    res = res.xml;
  }
  else {
    var emptyTableXML =
    "<table editable='true' font='Arial-8' sel_bgColor='#ffff00' sel_TextColor='#ffffff' draw_grid='true' enableHtml='false' enterAsTab='false' bgInvert='false' " +
    " onStart='onGridLoad' onEditCell='onParamsGridCellEdit' onXMLLoaded='onXmlLoaded' " +
    " onKeyPressed='onGridKeyPressed' >" +
    "<thead>" +
    " <th align='center'>Property</th>" +
    " <th align='center'>Value</th>" +
    "</thead>" +
    "<columns>" +
    " <column width='20%' edit='NOEDIT' align='left' order='0'/>" +
    " <column width='80%' edit='FIELD' align='left' order='1'/>" +
    "</columns>" +
    "</table>";

    res = emptyTableXML;
  }

  var resDom = this.createXMLDocument();
  resDom.loadXML(res);

  return resDom;
}

Aras.prototype.uiIsParamTabVisible = function Aras_uiIsParamTabVisible(itemNd, itemTypeName)
{
  var res = false;
  if (itemNd && itemNd.xml && !itemTypeName){ itemTypeName = itemNd.getAttribute("type");}
  if (!(itemTypeName && itemNd)) return res;
  var itemTypeNd = this.getItemTypeDictionary(itemTypeName).node;
  if (!itemTypeNd || !itemTypeNd.xml) return res;
  var show_parameters_tabNd = itemTypeNd.selectSingleNode("show_parameters_tab");
  var show_parameters_tab = "1";
  if (show_parameters_tabNd) show_parameters_tab = show_parameters_tabNd.text;
  
  switch (show_parameters_tab){
    case "0":
      break;
    case "1":
      var class_structureNd = itemTypeNd.selectSingleNode("class_structure");
      if (class_structureNd) {
        var classificationNd = itemNd.selectSingleNode("classification");
        var classification   = (classificationNd) ? classificationNd.text : "";
        if (!this.isClassPathRoot(classification, itemTypeName))
        {
          var propsOfClassPath = this.selectPropNdsByClassPath(classification, itemTypeNd);
          if (propsOfClassPath && propsOfClassPath.length>0)
          {
            var props = new Array();
            for (var i=0; i<propsOfClassPath.length; i++)
            {
              var prop = propsOfClassPath[i];
              var class_path = this.getItemProperty(prop, "class_path");
              if (!this.isClassPathRoot(class_path, itemTypeName))
                props.push(prop);
            }
            
            res = (props.length>0);
          }
        }
      }
      break;
    case "2":
      res = true;
      break;
  }
  return res;
}

Aras.prototype.uiGenerateRelationshipsTabbar = function Aras_uiGenerateRelationshipsTabbar(itemTypeName,itemID) {
  var res = null;
  if (itemTypeName && itemID) {
    res = this.soapSend("GenerateRelationshipsTabbar", "<Item type='" + itemTypeName + "' id='" + itemID + "'/>");
    res = res.getResult().selectSingleNode("tabbar");
  }

  if (res) {
    res = res.xml;
  }
  else {
    var emptyTableXML = "<tabbar/>";

    res = emptyTableXML;
  }

  var resDom = this.createXMLDocument();
  resDom.loadXML(res);

  return resDom;
}

Aras.prototype.uiGenerateRelationshipsTable = function Aras_uiGenerateRelationshipsTable(itemTypeName, itemID, relationshiptypeID) {
  var res = null;
  if (itemTypeName && itemID ) {
    res = this.soapSend("GenerateRelationshipsTable", "<Item type='" + itemTypeName + "' id='" + itemID + "' relationshiptype='" + relationshiptypeID + "'/>");
    res = res.getResult().xml;
  }
  else {
    res = "<Result />";
  }

  var resDom = this.createXMLDocument();
  resDom.loadXML(res);

  return resDom;
}

Aras.prototype.uiPrepareDOM4GridXSLT = function Aras_uiPrepareDOM4GridXSLT(dom) {
/*
adds <table editable="true"><columns /><inputrow/></table> to Envelope Body Result.

removes previous entry <table> entry
*/
  var res = dom.selectSingleNode(top.aras.XPathResult());
  var tableNd = res.selectSingleNode("table");
  if (tableNd) res.removeChild(tableNd);

  tableNd = res.appendChild( dom.createElement("table") );
  tableNd.appendChild( dom.createElement("columns") );
  tableNd.appendChild( dom.createElement("inputrow") );
}

Aras.prototype.uiGenerateGridXSLT = function Aras_uiGenerateGridXSLT(DescByProps_Arr, RelatedProps_Arr, params) {
  var self = this;

  if (params === undefined) params = new Object();

  var showLockColumn = Boolean( (RelatedProps_Arr === undefined) || RelatedProps_Arr);
  var table_xpath = top.aras.XPathResult("/table");
  var enable_links = (params["enable_links"] === undefined || params["enable_links"] === true);
  var params_bgInvert = (params["bgInvert"] === undefined || params["bgInvert"] === false) ? "false" : "true";

  var middleXSLTPart =
  "<table editable='true' " +
  "font=\"Dialog-8\" enableHTML=\"false\" sel_bgColor=\"#ffff00\" sel_TextColor=\"#ffffff\" " +
  "link_func=\"onLink\" draw_grid=\"true\" multiselect=\"true\" column_draggable=\"true\" " +
  "enterAsTab=\"false\" bgInvert=\"" + params_bgInvert + "\" onClick=\"onSelectItem\" onDoubleClick=\"onDoubleClick\" " +
  "onStart=\"onGridAppletLoad\" onEditCell=\"onEditCell\" onMenuInit=\"onMenuCreate\" " +
  "onMenuClick=\"onMenuClicked\" onXMLLoaded=\"onXmlLoaded\" onKeyPressed=\"onKeyPressed\">" +
    "<xsl:if test='" + table_xpath + "/@editable'>" +
      "<xsl:attribute name='editable'><xsl:value-of select='" + table_xpath + "/@editable'/>" +
    "</xsl:attribute></xsl:if>";

  // +++ create header row
  function AddHeaderColumn(name, header) {
    middleXSLTPart +=
      "<xsl:if test='" + table_xpath + "/columns/column[@name=\"" + name + "\"]'>" +
        "<th align='c'>" + self.escapeXMLAttribute(header) + "</th>" +
      "</xsl:if>"
  }

  function AddHeaderColumns(propsArr, suffix) {
    var f2Header = ' [...]';
    
    if (!propsArr) return;
    for (var i=0; i<propsArr.length; i++) {
      var prop = propsArr[i];
      var propName = self.getItemProperty(prop, "name");
      var header = self.getItemProperty(prop, "label");
      if (header == "") header = propName;
      
      var dataType = self.getItemProperty(prop, "data_type");
      if (dataType == 'item')
      {
        var propDS = self.getItemProperty(prop, 'data_source');
        if (propDS)
        {
          var it = self.getItemFromServer('ItemType',propDS,'name');
          if (it) header += f2Header;
        }
      }
      else if (dataType == 'date' || dataType == 'text' || dataType == 'image' || dataType == 'formatted text' || dataType == 'color')
      {
        header += f2Header;
      }
      
      AddHeaderColumn(propName + suffix, header);
    }    
  }

  middleXSLTPart += "<thead>";

  if (showLockColumn) AddHeaderColumn("L", "");

  AddHeaderColumns(DescByProps_Arr, "_D");

  AddHeaderColumns(RelatedProps_Arr, "_R");

  middleXSLTPart += "</thead>";
  // --- create header row

  var lists = this.newObject();
  var reservedListsNum = 2;//because we reserve 2 lists for special needs (e.g. build properties list for filter list pattern in relationships grid)
  var listNum = reservedListsNum-1;

  // +++ create columns
  function AddColumn(name, d_width, edit, align, sortStr, bgInvert, password, textColorInvert)
  {
    middleXSLTPart +=
    "<xsl:if test='" + table_xpath + "/columns/column[@name=\"" + name + "\"]'>" +
      "<column width='" + d_width + "' edit='" + edit + "' align='" + align + "' " + sortStr + " bginvert='" + bgInvert + "' password='" + password + "' textcolorinvert='" + textColorInvert + "'>" +
        "<xsl:variable name='width_val' select='" + table_xpath + "/columns/column[@name=\"" + name + "\"]/@width' />" +
        "<xsl:if test='$width_val'>" +
          "<xsl:attribute name='width'><xsl:value-of select='$width_val'/></xsl:attribute>" +
        "</xsl:if>" +
        "<xsl:variable name='order_val' select='" + table_xpath + "/columns/column[@name=\"" + name + "\"]/@order' />" +
        "<xsl:if test='$order_val'>" +
          "<xsl:attribute name='order'><xsl:value-of select='$order_val'/></xsl:attribute>" +
        "</xsl:if>" +
      "</column>" +
    "</xsl:if>";
  }

  function AddColumns(propsArr, suffix) {
    if (!propsArr) return;

    for (var i=0; i<propsArr.length; i++) {
      var prop = propsArr[i];
      var propName = self.getItemProperty(prop, "name");
      var header = self.getItemProperty(prop, "label");
      if (header == "") header = propName;

      var column_width = self.getItemProperty(prop, "column_width");
      if (column_width == "") column_width = "100";

      var column_alignment = self.getItemProperty(prop, "column_alignment");
      if (column_alignment == "") column_alignment = "l";
      else column_alignment = column_alignment.charAt(0);

      var data_type = self.getItemProperty(prop, "data_type");
      if (data_type == "foreign") {
        var sourceProperty = self.uiMergeForeignPropertyWithSource( prop );
        if (sourceProperty) {
          prop = sourceProperty;
          data_type = self.getItemProperty(prop, "data_type");
        }
      }

      var editStr;
      if (data_type.search(/list$/) != -1) {
        var listInfo = self.newObject();
        listInfo.listID = self.getItemProperty(prop, "data_source");
        listInfo.listType = data_type;

        listNum++;
        lists[listNum] = listInfo;
        editStr = "COMBO:" + listNum;
      }
      else editStr = "FIELD";

      var sortStr = "";
      if (data_type == "date") {
        var format = self.getItemProperty(prop, "pattern");
        if (!format) format = "MM/dd/yyyy";
        sortStr = 'sort="DATE" inputformat="' + format + '" locale="enUS"';
      }
      else if (data_type == "float" || data_type == "decimal") {
        sortStr = 'sort="NUMERIC" inputformat="###.##" locale="enUS"';
      }
      else if (data_type == "integer") {
        sortStr = 'sort="NUMERIC" inputformat="#####" locale="enUS"';
      }

      var bgInvert = "true";
      var textColorInvert = "false";
      if (data_type == "color" || data_type == "color list")
      {
        bgInvert = "false";
        textColorInvert = "true";
      }
      
      var password = "false";
      if (data_type == "md5") password = "true";

      AddColumn(propName + suffix, column_width, editStr, column_alignment, sortStr, bgInvert, password, textColorInvert);
    }
  }

  middleXSLTPart += "<columns>";

  if (showLockColumn) AddColumn("L", "24", "FIELD", "c", "")

  AddColumns(DescByProps_Arr, "_D");

  AddColumns(RelatedProps_Arr, "_R");

  middleXSLTPart += "</columns>";
  // --- create columns

  // +++ create lists
  //reserve reservedListsNum lists for special needs
  for (var listNum=0; listNum<reservedListsNum; listNum++)
    middleXSLTPart += "<list id='" + listNum + "'/>";
  
  //prepare to request all lists values
  var reqListsArr = this.newArray();
  for (var listNum in lists)
  {
    var listInfo = lists[listNum];
    var listID   = listInfo.listID;
    var relType;
    if (listInfo.listType == "filter list") relType = "Filter Value";
    else relType = "Value";
    
    var listDescr = this.newObject();
    listDescr.id = listID;
    listDescr.relType = relType;
    
    reqListsArr.push(listDescr);
  }
  
  if (reqListsArr.length > 0)
  {
    var resLists = this.getSeveralListsValues(reqListsArr);
    
    for (var listNum in lists) {
      var listInfo = lists[listNum];
      var listID = listInfo.listID;
  
      middleXSLTPart +=
      "<list id='" +listNum+ "'>" +
        "<listitem value='' label='' />";
  
      var listVals = resLists[listID];
      if (listVals)
      {
        for (var i=0; i<listVals.length; i++) {
          var valNd = listVals[i];
          var val = this.getItemProperty(valNd, "value");
          var lab = this.getItemProperty(valNd, "label");
          if (lab == "") lab = val;
          val = this.escapeXMLAttribute(val);
          lab = this.escapeXMLAttribute(lab);
          middleXSLTPart += "<listitem value=\"" + val + "\" label=\"" + lab + "\" />";
        }
      }
      middleXSLTPart += "</list>";
    }
  }
  // --- create lists

  var resXSLT = "" +
  "<xsl:stylesheet version=\"1.0\" " +
    "xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\" " +
    "xmlns:msxsl=\"urn:schemas-microsoft-com:xslt\" " +
    "xmlns:aras=\"http://www.aras.com\" " +
    "xmlns:usr=\"urn:the-xml-files:xslt\">\n" +

    "<msxsl:script language=\"JScript\" implements-prefix=\"usr\"><![CDATA[\n" +
      "function initItemCSS(css) {\n" +
      "  if (css.length != 1) return '';\n" +
      "  css = css[0].text.replace(/[ \\t]*\\{[ \\t]*/g, '{');\n" +
      "  css = css.replace(/[ \\t]*\\}[ \\t]*/g, '}');\n" +
      "  css = css.replace(/[ \\t]*:[ \\t]*/g, ':');\n" +
      "  css = css.replace(/[ \\t]*;[ \\t]*/g, ';');\n" +
      "  css = css.replace(/[ \\t]*-[ \\t]*/g, '-');\n" +
      "  return css;\n" +
      "}\n" +

      "var styleTmplt = new RegExp();\n" +
      "function getPropertyStyle(css, propName, styleName) {\n" +
      "  styleTmplt.compile('.' + propName + '(\\{.*?\\})');\n" +
      "  if (css.search(styleTmplt) == -1) return '';\n" +
      "  var styles = RegExp.$1;\n" +
      "  styleTmplt.compile('[\\{;]' + styleName + ':(.*?)[;\\}]');\n" +
      "  if (styles.search(styleTmplt) == -1) return '';\n" +
      "  return RegExp.$1;\n" +
      "};\n" +

      "function getPropertyStyleEx(css, fed_css, propName, styleName) {\n" +
      "  var style = getPropertyStyle(css, propName, styleName);\n" +
      "  if (!style) style = getPropertyStyle(fed_css, propName, styleName);\n" +
      "  return style;\n" +
      "};\n" +

      "var colorTmplt = /#[a-fA-F0-9]{6}/;\n" +
      "function isGoodColor(color) {\n" +
      "  if (color.length != 1) return false;\n" +
      "  var colorVal = color[0].text;\n" +
      "  return colorTmplt.test(colorVal);\n" +
      "}\n" +
      "]]></msxsl:script>" +

      "<xsl:output method=\"xml\" version=\"1.0\" omit-xml-declaration=\"yes\" cdata-section-elements=\"td\" encoding=\"UTF-8\"/>" +

      "<xsl:template match=\"/\">\n" +
        middleXSLTPart +
          "<xsl:apply-templates select=\"//Result\" />\n" +
        "</table>\n" +
      "</xsl:template>\n" +

      "<xsl:template match=\"inputrow\">\n" +
        "<inputrow>\n" +
          "<xsl:for-each select=\"td\">" +
            "<td bgColor=\"#BDDEF7\"><xsl:value-of select=\".\" /></td>" +
          "</xsl:for-each>\n" +
        "</inputrow>\n" +
      "</xsl:template>\n" +

      "<xsl:template match=\"Result\">\n" +

        "<xsl:apply-templates select=\"./table/inputrow\" />\n" +

        "<xsl:for-each select=\"Item\">\n" +
          "<xsl:variable name='itemCSS' select='usr:initItemCSS(css)'></xsl:variable>\n" +
          "<xsl:variable name='itemFedCSS' select='usr:initItemCSS(fed_css)'></xsl:variable>\n" +
          (
          RelatedProps_Arr ?
          "<xsl:variable name='rItemCSS' select='usr:initItemCSS(related_id/Item/css)'></xsl:variable>\n" +
          "<xsl:variable name='rItemFedCSS' select='usr:initItemCSS(related_id/Item/fed_css)'></xsl:variable>\n"
          : ""
          ) +
          "<xsl:variable name='predefined_textColor'>" +
            "<xsl:if test=\"./@action[.='purge' or .='delete']\">#b0b0b0</xsl:if>" +
          "</xsl:variable>\n"+
          "<xsl:variable name='predefined_font'>" +
            "<xsl:if test=\"./@action[.='purge' or .='delete']\">Arial-italic-8</xsl:if>" +
          "</xsl:variable>\n"+

          "<tr>\n" +
            "<xsl:attribute name='id'><xsl:value-of select='@id'/></xsl:attribute>\n" +
            "<xsl:attribute name='action'>'<xsl:value-of select='@id'/>'</xsl:attribute>\n";

  // +++ lock icon
  if (showLockColumn) {
    resXSLT +=
             "<xsl:if test='" + table_xpath + "/columns/column[@name=\"L\"]'>\n" ;
    resXSLT +=
            "<td>";

    if (RelatedProps_Arr) {
      resXSLT +=
            "<xsl:if test='not(related_id/Item) and (not(related_id) or related_id=\"\")'>&lt;img src='icons/20x20nullrelated.gif'/&gt;</xsl:if>" +
            "<xsl:if test='related_id/Item'><xsl:for-each select='related_id/Item'>";
    }

      resXSLT +=
            "<xsl:if test=\"@isTemp=\'1\' or locked_by_id!=\'\'\">&lt;img src=\"" +
              "<xsl:if test='@isTemp=\"1\"'>icons/20x20new.gif</xsl:if>" +
              "<xsl:if test='not(@isTemp=\"1\") and locked_by_id=\"" + this.getCurrentUserID() + "\"'>" +
                "<xsl:if test='not(@isDirty=\"1\")'>icons/locked.gif</xsl:if>" +
                "<xsl:if test='@isDirty=\"1\"'>icons/locked_dirty.gif</xsl:if>" +
              "</xsl:if>" +
              "<xsl:if test='not(@isTemp=\"1\") and locked_by_id!=\"" + this.getCurrentUserID() + "\" and locked_by_id!=\"\"'>icons/locked_else.gif</xsl:if>" +
              "\"/&gt;" +
            "</xsl:if>" +
            "<xsl:if test='not(@isTemp) and (not(locked_by_id) or locked_by_id=\"\")'>&lt;img src=''/&gt;</xsl:if>";

    if (RelatedProps_Arr) {
      resXSLT +=
            "</xsl:for-each></xsl:if>";
    }

      resXSLT +=
            "</td>\n";
      resXSLT +=
            "</xsl:if>";
  }
  // --- lock icon

  // +++ gird rows
  function GenerateRows(propsArr, xpath_prefix, special_td_attributes, cellCSSVariableName1, cellCSSVariableName2) {
    if (!propsArr) return;

    for (var i=0; i <propsArr.length; ++i) {
      var propItem = propsArr[i];

      var name = self.getItemProperty(propItem, "name");
      var xpath = xpath_prefix + name;
      var data_type = self.getItemProperty(propItem, "data_type");

      if (data_type == "foreign") {
        var sourceProperty = self.uiMergeForeignPropertyWithSource( propItem );
        if (sourceProperty) {
          propItem = sourceProperty;
          data_type = self.getItemProperty(propItem, "data_type");
        }
      }

      resXSLT += "<td " + special_td_attributes + ">";

      if (data_type == "item" || data_type == "color" || data_type == "color list") {
        resXSLT += "<xsl:if test='" + xpath + "'>";
        if (data_type == "item") {
          if (enable_links) {
            var data_source = propItem.selectSingleNode("data_source");
            if (data_source) {
              data_source = data_source.getAttribute("name");
              if (data_source==null) data_source = "";
            }
            else data_source = "";

            resXSLT +=
              "<xsl:attribute name='textColor'>#0000ff</xsl:attribute>" +
              "<xsl:if test='" + xpath + "'><xsl:attribute name='link'>" +
              "<xsl:if test='not(" + xpath + "/Item) and " + xpath + "!=\"\"'>'" +
                 "<xsl:choose>"+
                 "  <xsl:when test='data_type=\"list\"'>List</xsl:when> "+
                 "  <xsl:when test='data_type=\"sequence\"'>Sequence</xsl:when> "+
                 "  <xsl:when test='data_type=\"filter list\"'>List</xsl:when> "+
                 "  <xsl:when test='data_type=\"color list\"'>List</xsl:when> "+
                 "  <xsl:otherwise>"+data_source+"</xsl:otherwise> "+
                 "</xsl:choose>"+
                 "','<xsl:value-of select=\"" + xpath + "\"/>'"+
              "</xsl:if>" +
              "<xsl:if test='" + xpath + "/Item'>'"+
                 "<xsl:choose>"+
                 "  <xsl:when test='data_type=\"list\"'>List</xsl:when> "+
                 "  <xsl:when test='data_type=\"sequence\"'>Sequence</xsl:when> "+
                 "  <xsl:when test='data_type=\"filter list\"'>List</xsl:when> "+
                 "  <xsl:when test='data_type=\"color list\"'>List</xsl:when> "+
                 "  <xsl:otherwise>"+data_source+"</xsl:otherwise>"+
                 "</xsl:choose>"+
                 "','<xsl:value-of select=\"" + xpath + "/Item/@id\"/>'"+
              "</xsl:if>"+
              "</xsl:attribute></xsl:if>";
          }
        }
        else if (data_type == "color" || data_type == "color list") {
          resXSLT +=
            "<xsl:if test='usr:isGoodColor(" + xpath + ")'><xsl:attribute name='bgColor'><xsl:value-of select='" + xpath + "'/></xsl:attribute></xsl:if>";
        }
        resXSLT += "</xsl:if>";
      }

      resXSLT +=
        "<xsl:if test=\"$" + cellCSSVariableName1 + "!='' or $" + cellCSSVariableName2 + "!=''\">" +
        "<xsl:variable name='font_color' select='usr:getPropertyStyleEx($" + cellCSSVariableName1 + ",$" + cellCSSVariableName2 + ",\"" + name + "\",\"color\")' />"+
        "<xsl:if test=\"$font_color!=''\"><xsl:attribute name='textColor'><xsl:value-of select='$font_color' /></xsl:attribute></xsl:if>"+
        "<xsl:variable name='background_color' select='usr:getPropertyStyleEx($" + cellCSSVariableName1 + ",$" + cellCSSVariableName2 + ",\"" + name + "\",\"background-color\")' />"+
        "<xsl:if test='usr:isGoodColor(" + xpath + ")=\"\"'>"+
        "<xsl:if test=\"$background_color!=''\"><xsl:attribute name='bgColor'><xsl:value-of select='$background_color' /></xsl:attribute></xsl:if></xsl:if>"+

        "<xsl:variable name='font_family' select='usr:getPropertyStyleEx($" + cellCSSVariableName1 + ",$" + cellCSSVariableName2 + ",\"" + name + "\",\"font\")' />"+
        "<xsl:if test=\"$font_family!=''\"><xsl:attribute name='font'>" +
          "<xsl:value-of select='$font_family' />"+
          "<xsl:variable name='font_style' select='usr:getPropertyStyleEx($" + cellCSSVariableName1 + ",$" + cellCSSVariableName2 + ",\""+name+"\",\"font-style\")' />"+
          "<xsl:if test=\"$font_style!=''\">-<xsl:value-of select='$font_style' /></xsl:if>"+
          "<xsl:variable name='font_size' select='usr:getPropertyStyleEx($" + cellCSSVariableName1 + ",$" + cellCSSVariableName2 + ",\""+name+"\",\"font-size\")' />"+
          "<xsl:if test=\"$font_size!=''\">-<xsl:value-of select='$font_size' /></xsl:if>"+
        "</xsl:attribute></xsl:if>" +
        "</xsl:if>" +

        "<xsl:if test=\"$predefined_textColor!=''\"><xsl:attribute name='textColor'><xsl:value-of select='$predefined_textColor' /></xsl:attribute></xsl:if>" +
        "<xsl:if test=\"$predefined_font!=''\"><xsl:attribute name='font'><xsl:value-of select='$predefined_font' /></xsl:attribute></xsl:if>";

      if (data_type == "item") {
        resXSLT +=
          "<xsl:if test='"+xpath+"/@keyed_name'><xsl:value-of select='"+xpath+"/@keyed_name' /></xsl:if>"+
          "<xsl:if test='not("+xpath+"/@keyed_name)'><xsl:value-of select=\""+xpath+"\" /></xsl:if>";
      }
      else if (data_type == "image") {
        resXSLT +=
          '&lt;img src="<xsl:value-of select="' + xpath + '"/>"/&gt;';
      }
      else if (data_type == "boolean") {
        resXSLT +=
          "<xsl:if test='not("+xpath+")'>&lt;checkbox state=\"0\"/&gt;</xsl:if>"+
          "<xsl:if test='"+xpath+"'>&lt;checkbox state=\"<xsl:value-of select=\"" + xpath + "\"/>\"/&gt;</xsl:if>";
      }
      else if (data_type == "md5") {
        resXSLT += "***";
      }
      else if (data_type == "color") {
        resXSLT += "";
      }
      else {
        resXSLT +=
          "<xsl:value-of select=\"" + xpath + "\" />";
      }

      resXSLT += "</td>\n";
    }
  }

  var special_td_attributes = "";
  if (RelatedProps_Arr) special_td_attributes = "bgColor='#f3f3f3'";
  GenerateRows(DescByProps_Arr, "", special_td_attributes, "itemCSS", "itemFedCSS");
  GenerateRows(RelatedProps_Arr, "related_id/Item/", "", "rItemCSS", "rItemFedCSS");
  // --- gird rows

  resXSLT +=
        "</tr>\n" +
      "</xsl:for-each>\n" +
    "</xsl:template>\n" +
  "</xsl:stylesheet>";

  return resXSLT;
}

/*
* uiItemTypeSelectionDialog
*
* parameters:
* 1) itemTypesList - an array of objects like [{id:5, name:'Type5'}]
*/
Aras.prototype.uiItemTypeSelectionDialog = function Aras_uiItemTypeSelectionDialog(itemTypesList, wnd)
{
  if (!wnd) wnd = window;
  if (!itemTypesList) return;
  var arguments = {itemTypesList:itemTypesList};
  var res = wnd.showModalDialog(this.getScriptsURL()+"ItemTypeSelectionDialog.html", arguments, "dialogHeight: 280px; dialogWidth: 400px; status:0; help:0; resizable:0");
  wnd.focus();//this line is required to workaround IE7 bug described in IR-008867 "New Document window opens behind project (IE7)"
  return res;
}

Aras.prototype.uiItemCanBeLockedByUser = function Aras_uiItemCanBeLockedByUser(itemNd, isRelationship, useSrcAccess)
{
/*
this function is for internal use *** only ***.
----------------------------------------------
  isRelationship - perhaps, this parameter will be removed in future
------------------------------------------
full list of places where function is used:
  item_window.js: updateMenuState
  itemsGrid.html: setMenuState
  relationshipsGrid.html: updateControls, onMenuCreate
*/
  if (this.isTempEx(itemNd)) return false;
  
  var IsMainItemLocked = true;
  if (isRelationship && useSrcAccess)
  {
    IsMainItemLocked = false;
    var tmpItem;
    
    var source_id = this.getItemProperty(itemNd, "source_id");
    if (source_id) tmpItem = itemNd.selectSingleNode("parent::Relationships/parent::Item[@id='" + source_id + "']");
    else tmpItem = itemNd.selectSingleNode("parent::Relationships/parent::Item");
    
    if (!tmpItem && source_id)
    {
      var tmpItemTypeName = this.getItemPropertyAttribute(itemNd, "source_id", "type");
      tmpItem = this.getItemUsingIdAsParameter(tmpItemTypeName, source_id, 0);
    }
    
    if (tmpItem)
    {
      IsMainItemLocked = this.isLockedByUser(tmpItem);
      tmpItem = null;
    }
  }
  
  var locked_by = this.getItemProperty(itemNd, "locked_by_id");
  return (IsMainItemLocked && locked_by=="");
}

Aras.prototype.uiIsCheckOutPossible = function Aras_uiIsCheckOutPossible(itemNd, ItemCanBeLockedByUser, ItemIsLockedByUser, ItemTypeNd) {
/*
this function is for internal use *** only ***.
----------------------------------------------
------------------------------------------
full list of places where function is used:
  item_window.js: updateMenuState
  itemsGrid.html: setMenuState
  relationshipsGrid.html: updateControls, onMenuCreate
*/
  if ( !(ItemCanBeLockedByUser || ItemIsLockedByUser) ) return false;
  
  var filePropNds = this.getPropertiesOfTypeFile(ItemTypeNd);
  
  var ThereAreFiles = false;
  for (var i=0; i<filePropNds.length; i++) {
    var propNm = this.getItemProperty(filePropNds[i], "name");
    var file = itemNd.selectSingleNode(propNm + "/Item");
    if (!file) {
      file = this.getItemProperty(itemNd, propNm);
      if (file)
        file = this.getItemById('File', file, 0);
    }
    
    if (file) {
      ThereAreFiles = true;
      var FileIsLocked = this.isLocked(file);
      var FileIsTemp   = this.isTempEx(file);
      if (FileIsLocked || FileIsTemp)
        return false;
    }
  }
  filePropNds = null;
  
  return ThereAreFiles; //because all rules are checked inside loop above
}

Aras.prototype.uiIsCopyFilePossible = function Aras_uiIsCopyFilePossible(itemNd, ItemTypeNd) {
/*
this function is for internal use *** only ***.
----------------------------------------------
*/
  
  var filePropNds = this.getPropertiesOfTypeFile(ItemTypeNd);
  
  var ThereAreFiles = false;
  for (var i=0; i<filePropNds.length; i++) {
    var propNm = this.getItemProperty(filePropNds[i], "name");
    var file = itemNd.selectSingleNode(propNm + "/Item");
    if (!file) {
      file = this.getItemProperty(itemNd, propNm);
      if (file) file = this.getItemById('File', file, 0);
    }
    
    if (file && !this.isTempEx(file))
      ThereAreFiles = true;
  }
  filePropNds = null;
  
  return ThereAreFiles; //because all rules are checked inside loop above
}

Aras.prototype.uiWriteObject = function Aras_uiWriteObject(doc, objectHTML)
{
  doc.write(objectHTML);
}

Aras.prototype.uiAddConfigLink2Doc4Assembly = function Aras_uiAddConfigLink2Doc4Assembly(doc, assemblyName)
{
  var hds = doc.getElementsByTagName("HEAD");
  if (hds.length<1) return false;
  var hd = hds[0];
  var newLink = doc.createElement("LINK");
  newLink.setAttribute("rel", "Configuration");
  newLink.setAttribute("href", this.getBaseURL()+"/cbin/" + assemblyName + ".dll.config.xml");
  hd.appendChild(newLink);

  var str = "function WriteUncommentedObject(objectId)" + 
            "{" +
              "var obj = document.getElementById(objectId);" +
              "if (top.WriteObjectToDocument) top.WriteObjectToDocument(document, obj.innerHTML);" +
              "else if (top.Aras_uiWriteObject) top.Aras_uiWriteObject(document, obj.innerHTML);" +
              "else document.write(obj.innerHTML);" +
            "}";

  doc.parentWindow.eval(str);

  return true;
}

Aras.prototype.uiGetFilteredObject4Grid = function Aras_uiGetFilteredObject4Grid( itemTypeID, filteredPropName, filterValue ) {
  var resObj = new Object();
  resObj.hasError = false;
  
  var itemTypeNd;
  try{
    itemTypeNd = this.getItemTypeDictionary(this.getItemTypeName(itemTypeID)).node;
  } catch (ex){}
  if (!itemTypeNd) {
    resObj.hasError = true;
    return resObj;
  }
  var fListNd = itemTypeNd.selectSingleNode("Relationships/Item[@type='Property' and name='"+filteredPropName+"']/data_source");
  var fListId = (fListNd) ? fListNd.text : null;
  if (!fListId){
    resObj.hasError = true;
    return resObj;
  }
  
  var _listVals = new Array();
  _listVals[0] = ' ';
  
  var _listLabels = new Array();
  _listLabels[0] = ' ';

  var optionNds = this.getListFilterValues(fListId);
  if (filterValue!="") optionNds = this.uiGetFilteredListEx(optionNds,"^"+filterValue+"$");
  
  for (i=0; i < optionNds.length; i++){
    _listVals[i+1] = this.getItemProperty(optionNds[i],"value");
    _listLabels[i+1] = this.getItemProperty(optionNds[i],"label");
  }
  _listVals   = _listVals.join('|');
  _listLabels = _listLabels.join('|');
  
  resObj.values = _listVals;
  resObj.labels = _listLabels;
  
  return resObj;
}
/* uiCheckKeyedName
*
*  Case unsensitive check whether exists such keyed_name in the ItemType
*  If exists one returns keyed_name with original case,
*  else returns false.
*/
Aras.prototype.uiGetItemByKeyedName = function Aras_uiGetItemByKeyedName(itemTypeName, keyed_name)
{
  var soapBody = '<Item type="' + itemTypeName + '" levels="0" action="get" select="keyed_name">';
  soapBody += '<keyed_name>' + keyed_name + '</keyed_name>';
  soapBody += '</Item>';  
  var statusId = this.showStatusMessage(0, '   Loading ' + itemTypeName + '...', '../images/Animated/ProgressSmall.gif');
  var res = this.soapSend('ApplyItem', soapBody);
  this.clearStatusMessage(statusId);
  
  if (res.getFaultCode() != 0)
  {
    return false;
  }
  var items = res.results.selectNodes(top.aras.XPathResult('/Item'));    
  if (items.length > 1)
  {  var msg = 'With keyed_name "' + keyed_name + '" exists several items, select from list appropriated one.';
     var param = new Object();
     param.buttons = new Object();
     param.buttons.btnOK = "OK";
     param.defaultButton  = "btnOK";
     param.message = 'Item cannot be defined uniquely.\n' +
'The first match is used.\n' +
'You may use search dialog (press F2) to define the item precisely';
     var res = window.showModalDialog(this.getScriptsURL()+"groupChgsDialog.html", param, "dialogHeight:150px;dialogWidth:300px;center:yes;resizable:no;status:no;help:no;");
  }
  return items(0);
}

Aras.prototype.uiEnableBalloonForPasswordField = function Aras_uiEnableBalloonForPasswordField(passwordField)
{
  if (!passwordField) return;
  
  var prefix = "sys_password_balloon$";
  var baloonProp  = prefix + "balloon";
  var hideBalloonFunc = prefix + "hideBalloon";
  var showBalloonIfCapsLockOnFunc = prefix + "showBalloonIfCapsLockOn";
  
  var hideBalloon = new Function("event",
    "var passwordField=event.srcElement;\n" +
    "passwordField." + baloonProp + ".HideBalloon();");
  
  var showBalloonIfCapsLockOn = new Function("event",
    "var passwordField = event.srcElement;\n" +
    "if (passwordField.style.visibility != 'hidden')\n" +
    "{\n" +
    "  var rect = top.aras.uiGetRectangleToShowWindowNearElement(passwordField);\n" +
    "  var balloon = passwordField." + baloonProp + ";\n" +
    "  var textWidth = top.aras.getFieldTextWidth(passwordField);\n" +
    "  if (textWidth > passwordField.clientWidth)\n" +
    "    textWidth = passwordField.clientWidth;\n" +
    "  else\n" +
    "    textWidth += 5;" +
    "  balloon.SetPosition(rect.left + textWidth, rect.top-5);\n" +
    "  balloon.DisplayIfCapsLockOn();\n" +
    "}");
      
  var onKeyUpHandler = new Function("event",
    "var passwordField=event.srcElement;\n" +
    "if (event.keyCode == 20)\n" + // CapsLock
    "  passwordField." + showBalloonIfCapsLockOnFunc + "(event);\n" +
    "else if (event.keyCode != 9)\n" + // Do not hide balloon if we come to input by tab.
    "  passwordField." + hideBalloonFunc + "(event);\n"
    );

  passwordField[baloonProp] = this.utils.GetBalloon();
  passwordField[hideBalloonFunc] = hideBalloon;
  passwordField[showBalloonIfCapsLockOnFunc] = showBalloonIfCapsLockOn;
  
  passwordField.attachEvent("onfocus", showBalloonIfCapsLockOn);
  passwordField.attachEvent("onfocusout", hideBalloon);
  passwordField.attachEvent("onkeyup", onKeyUpHandler);
}

// Retrieves window body size, the width and the height of the object including padding, 
// but not including margin, border, or scroll bar.
Aras.prototype.getDocumentBodySize = function Aras_GetDocumentBodySize(document)
{
  var res = this.newObject();
  res.width  = 0;
  res.height = 0;

  if (document)
  {
    res.width = document.body.clientWidth;
    res.height = document.body.clientHeight;
  }
  return res;
}

// Retrieves the width of the rectangle that bounds the text in the text field.
Aras.prototype.getFieldTextWidth = function Aras_getFieldTextWidth(field)
{
  if (field)
  {
    var r = field.createTextRange();
    if (r != null)
      return r.boundingWidth;
  }
  else
    return 0;
}

// Calculate html element coordinates on a parent window.
Aras.prototype.uiGetElementCoordinates = function Aras_uiGetElementCoordinates(oNode)
{
  var oCurrentNode = oNode;
  var iLeft = 0;
  var iTop = 0;
  
  while (oCurrentNode.tagName != "BODY")
  {
    iLeft += oCurrentNode.offsetLeft;
    iTop  += oCurrentNode.offsetTop;
    oCurrentNode=oCurrentNode.offsetParent;
  }
  
  //+++ IR-008672 (Date dialog is shown not near date field after scrolling)
  var readScroll;
  if (oNode.document.compatMode && oNode.document.compatMode == 'CSS1Compat') readScroll = oNode.document.documentElement;
  else readScroll = oNode.document.body;
  
  res = new Object();
  res.left = iLeft - (readScroll.scrollLeft - readScroll.clientLeft);
  res.top = iTop - (readScroll.scrollTop - readScroll.clientTop);
  //--- IR-008672 (Date dialog is shown not near date field after scrolling)
  
  return res;
}

// Calculate coordinates of window, that would be shown near element
Aras.prototype.uiGetRectangleToShowWindowNearElement = function Aras_uiGetRectangleToShowWindowNearElement(element, windowSize, rectangleInsideElement)
{
  if (element==undefined) throw new Error(1, "Parameter 'element' is not specified");
  
  var parentCoords = this.uiGetElementCoordinates(element);
  
  var dTop, dLeft, dHeight, dWidth;
  var boundHeight;
  
  element.focus();
  var ev = element.document.createEventObject('onclick');
  dTop = (ev.screenY-ev.clientY) + parentCoords.top;
  dLeft= (ev.screenX-ev.clientX) + parentCoords.left;
  
  if (rectangleInsideElement)
  {
    dTop += rectangleInsideElement.y + rectangleInsideElement.height;
    dLeft+= rectangleInsideElement.x;
    boundHeight = rectangleInsideElement.height;
  }
  else
    if (element.offsetHeight!=undefined)
    {
      dTop += element.offsetHeight;
      boundHeight = element.offsetHeight;
    }
  
  if (windowSize)
  {
    if (windowSize.height!=undefined) dHeight = windowSize.height;
    else dHeight  = 200;
    
    if (windowSize.width!=undefined) dWidth = windowSize.width;
    else dWidth  = 200;
    
    var dRight  = dLeft + dWidth;
    var dBottom = dTop + dHeight;
    
    var dx = screen.availWidth - dRight;
    var dy = screen.availHeight - dBottom;
    if (dx < 0) dLeft += dx;
    if (dy < 0) dTop -= dHeight + boundHeight;
  }
  
  wndRect = new Object();
  wndRect.top = dTop;
  wndRect.left = dLeft;
  wndRect.width = dWidth;
  wndRect.height = dHeight;
  
  return wndRect;
}

///<summary>
/// Show modal dialog from the specified URL using the specified dialog parameters, options
/// from "param" near element "child" of "parent" element
///</summary>
Aras.prototype.uiShowDialogNearElement = function Aras_uiShowDialogNearElement(element, dialogUrl, dialogParameters, dialogOptions, dialogSize, rectangleInsideElement)
{
  if (!element) throw new Error(1, "Parameter 'element' is not specified");
  if (dialogOptions === undefined) dialogOptions = "status:0; help:0; center:no;";
  if (dialogSize === undefined) dialogSize = {width:200, height:200};
  
  var wndRect = this.uiGetRectangleToShowWindowNearElement(element, dialogSize, rectangleInsideElement);
  var dialogPositionOptions =
    "dialogHeight:" + wndRect.height +
    "px; dialogWidth:" + wndRect.width +
    "px; dialogTop:" + wndRect.top +
    "px; dialogLeft:" + wndRect.left+
    "px; ";
  
  dialogOptions = dialogPositionOptions + dialogOptions;
  
  var wnd = window;
  if (element.document && element.document.parentWindow) wnd = element.document.parentWindow;
  
  var res = wnd.showModalDialog(dialogUrl, dialogParameters, dialogOptions);
  return res;
}

Aras.prototype.uiShowControlsApiReferenceCommand = function Aras_uiShowControlsApiReferenceCommand()
{
  var topHelpUrl = this.getTopHelpUrl();

  var re = /^(.*)[\\\/]([^\\\/]*)$/;//finds the last '\' or '/'
  if (!topHelpUrl || !re.test(topHelpUrl))
  {
    this.AlertError("Cannot determine TopHelpUrl");
    return;
  }
  
  topHelpUrl = RegExp.$1
  var controlsApiReferenceUrl = this.getBaseURL() + topHelpUrl + "/APIReference/WinHelp/InnovatorAPIReference.chm";
  top.aras.vault.DonwloadFileAndExecute(controlsApiReferenceUrl, this.getWorkingDir(true), true);
}