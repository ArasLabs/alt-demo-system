﻿// © Copyright by Aras Corporation, 2004-2007.

// Validate object
function Validate(parent) {
  this.parent = parent;
}

Validate.prototype.today = function() {
  var date = new Date();
  var today = date.getFullYear() + "-";
  if (date.getMonth() < 10) today += "0"
  today += date.getMonth() + "-";
  if (date.getDate() < 10) today += "0"
  today += date.getDate();
  return today;
}

Validate.prototype.name = function(str) {
  if (str.search(/[!@#$%^&*()]/) >= 0)
    return true;
  else
    return false;
}

Validate.prototype.text = function(str, limit) {
  if (str.length > limit) {
    top.aras.AlertError('The text that can be entered in this field is limited to ' + limit + ' characters. You have exceeded the limit.', "", "");
    return false;
  }
  return true;
}

Validate.prototype.date = function(date_field) {
  date = date_field.value.toUpperCase();

  if (date == "")
    return true;

  var months = new Array('JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC');

  if (date.search(/^(JAN|FEB|MAR|APR|MAT|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-\d{2}-\d{4}$/) < 0) {
    top.aras.AlertError( 'The format of the date you specified (' + date + ') is invalid. The valid date format is (MON-DD-YYYY).', "", "");
    date_field.focus();
    return false;
  }

  date_field.value = date;
  return true;
}

Validate.prototype.number = function(number) {
  if (isNaN(parseInt(number))) {
    top.aras.AlertError('This is not a valid integer: ' + number, "", "");
    return false;
  }
  return true;
}

Validate.prototype.floating = function(Float) {
  if (isNaN(parseFloat(Float))) {
    top.aras.AlertError('This is not a valid float number: ' + Float, "", "");
    return false;
  }
  return true;
}
