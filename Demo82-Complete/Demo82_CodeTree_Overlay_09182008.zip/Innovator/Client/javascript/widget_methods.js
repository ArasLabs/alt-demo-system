﻿// © Copyright by Aras Corporation, 2004-2007.

Aras.prototype.widgetOnLoad        = function(id) {this.evalEventMethod(id,'onload')}
Aras.prototype.widgetOnUnload      = function(id) {this.evalEventMethod(id,'onunload')}
Aras.prototype.widgetOnShow        = function(id) {this.evalEventMethod(id,'onshow')}
Aras.prototype.widgetOnChange      = function(id) {this.evalEventMethod(id,'onchange')}
Aras.prototype.widgetOnSelect      = function(id) {this.evalEventMethod(id,'onselect')}
Aras.prototype.widgetOnUnselect    = function(id) {this.evalEventMethod(id,'onunselect')}
Aras.prototype.widgetOnClick       = function(id) {this.evalEventMethod(id,'onclick')}
Aras.prototype.widgetOnDoubleClick = function(id) {this.evalEventMethod(id,'ondoubleclick')}
Aras.prototype.widgetOnOpenNode    = function(id) {this.evalEventMethod(id,'onopennode')}
Aras.prototype.widgetOnCloseNode   = function(id) {this.evalEventMethod(id,'onclosenode')}
