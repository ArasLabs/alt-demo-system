﻿// © Copyright by Aras Corporation, 2004-2007.

Aras.prototype.newField = function(fieldType) {
  with (this) {
    if (arguments.length == 1) {
      name = top.aras.prompt("Enter a field name:", "");
      if (name == null || name.search(/^$|^[ ]+$/) == 0) return;
    }

    var selectedFieldID = document.uniqueID;

    var xml = '<Item type="Field" action="add" id="' + selectedFieldID + '">' +
      '<name>' + name + '</name>' +
      '<field_type>' + fieldType + '</field_type>' +
      '<label_position>left</label_position>' +
      '<is_visible>1</is_visible>' +
      '<positioning>absolute</positioning>' +
      '<y>0</y>' +
      '<x>0</x>' +
      '<border_width>0</border_width>' +
      '<font_family>arial, helvetica, sans-serif</font_family>' +
      '<font_size>8pt</font_size>' +
      '<font_weight>bold</font_weight>' +
      '<font_align>right</font_align>' +
      '<font_color>#000000</font_color>' +
      '<html_code></html_code>' +
      '</Item>';

    var field = createXMLDocument();
    field.loadXML(xml);

    var html_code = '';

    if (fieldType.search(/^menubar$/) == 0) {
      setNodeElement(field, 'height', 26);
    }

    else if (fieldType.search(/^toolbar$/) == 0) {
      setNodeElement(field, 'height', 26);
    }

    else if (fieldType.search(/^tabbar$/) == 0) {
      setNodeElement(field, 'height', 25);
    }

    else if (fieldType.search(/^tree$/) == 0) {
      html_code = '<script>\n' +
        'function treeOnClickCheckbox(item,state) {alert(item,state)}\n' +
        'function treeOnClickMenu(item,menu_item) {alert(item,menu_item)}\n' +
        'function treeOnBeforeOpenMenu(item,menu) {alert(item,menu)}\n' +
        '</script>\n';
      setNodeElement(field, 'width',  200);
      setNodeElement(field, 'height', 400);
    }

    else if (fieldType.search(/^treegrid$/) == 0) {
      html_code = '<script>\n' +
        'function treegridOnLoad()   {with(top.aras){widgetOnLoad(getDomFieldByName("' + name + '","' + formName + '").getAttribute("id"))}}\n' +
        'function treegridOnUnload() {with(top.aras){widgetOnUnload(getDomFieldByName("' + name + '","' + formName + '").getAttribute("id"))}}\n' +
        'function treegridOnClick(id)       {top.aras.widgetOnClick(id)}\n' +
        'function treegridOnDoubleClick(id) {top.aras.widgetOnClick(id)}\n' +
        'function treegridOnOpenNode(id)    {top.aras.widgetOnClick(id)}\n' +
        'function treegridOnCloseNode(id)   {top.aras.widgetOnClick(id)}\n' +
        'function treegridOnBeforeOpenMenu(row,col)  {alert(row,col)}\n' +
        'function treegridOnClickMenu(item,row,col)  {alert(item,row,col)}\n' +
        'function treegridOnClickCheckbox(row,state) {alert(row,state)}\n' +
        'function treegridOnBeforeEditCell(row,col)  {alert(row,col)}\n' +
        'function treegridOnChangeEditCell(row,col)  {alert(row,col)}\n' +
        'function treegridOnLeaveEditCell(row,col)   {alert(row,col)}\n' +
        'function treegridOnBeforeSelect(row,multi)  {alert(row,multi)}\n' +
        'function treegridOnEditCell(event,row,col)  {\n' +
        '  if      (event==1) treegridOnBeforeEditCell(row,col);\n' +
        '  else if (event==2) treegridOnChangeEditCell(row,col);\n' +
        '  else if (event==3) treegridOnLeaveEditCell(row,col);\n' +
        '}\n' +
        '</script>\n' +
        '<object width="100%" height="100%" id="' + name + '" ' +
        'classid="../cbin/TreeTable.dll#Aras.Client.Controls.TreeGridContainer">\n' +
        '<param name="icon0"         value="icons/item_root1.gif">\n' +
        '<param name="icon1"         value="icons/item_open1.gif">\n' +
        '<param name="icon2"         value="icons/item_closed.gif">\n' +
        '<param name="icon3"         value="icons/item_node.gif">\n' +
        '<param name="icon4"         value="icons/item_node.gif">\n' +
        '<param name="eval"          value="treegridOnClick">\n' +
        '<param name="ondoubleclick" value="treegridOnDoubleClick">\n' +
        '<param name="onopennode"    value="treegridOnOpenNode">\n' +
        '<param name="onclosenode"   value="treegridOnCloseNode">\n' +
        '<param name="onstart"       value="treegridOnLoad">\n' +
        '<param name="onstop"        value="treegridOnUnload">\n' +
        '<param name="menu_init"     value="treegridOnBeforeOpenMenu">\n' +
        '<param name="menu_action"   value="treegridOnClickMenu">\n' +
        '<param name="oncheckbox"    value="treegridOnClickCheckbox">\n' +
        '<param name="oneditcell"    value="treegridOnEditCell">\n' +
        '<param name="onselectrow"   value="treegridOnBeforeSelect">\n' +
        '<param name="hide_on_start" value="1">\n' +
        '<param name="sort_up"       value="icons/up.gif">\n' +
        '<param name="sort_down"     value="icons/down.gif">\n' +
        '<param name="expandroot"    value="1">\n' +
        '</applet>';
      setNodeElement(field, 'height', 200);
    }

    else if (fieldType.search(/^grid$/) == 0) {
      html_code = '<script>\n' +
        'function gridOnLoad()   {with(top.aras){widgetOnLoad(getDomFieldByName("' + name + '","' + formName + '").getAttribute("id"))}}\n' +
        'function gridOnUnload() {with(top.aras){widgetOnUnload(getDomFieldByName("' + name + '","' + formName + '").getAttribute("id"))}}\n' +
        'function gridOnClick(id)       {top.aras.widgetOnClick(id)}\n' +
        'function gridOnDoubleClick(id) {top.aras.widgetOnClick(id)}\n' +
        'function gridOnBeforeSelect(row,multi) {alert(row,multi)}\n' +
        'function gridOnBeforeOpenMenu(row,col) {alert(row,col)}\n' +
        'function gridOnClickMenu(item,row,col) {alert(item,row,col)}\n' +
        'function gridOnBeforeEditCell(row,col) {alert(row,col)}\n' +
        'function gridOnChangeEditCell(row,col) {alert(row,col)}\n' +
        'function gridOnLeaveEditCell(row,col)  {alert(row,col)}\n' +
        'function gridOnEditCell(event,row,col) {\n' +
        '  if      (event==1) gridOnBeforeEditCell(row,col);\n' +
        '  else if (event==2) gridOnChangeEditCell(row,col);\n' +
        '  else if (event==3) gridOnLeaveEditCell(row,col);\n' +
        '}\n' +
        '</script>\n' +
        '<object width="100%" height="100%" id="' + name + '" ' +
        'classid="../cbin/TreeTable.dll#Aras.Client.Controls.GridContainer">\n' +
        '<param name="eval"          value="gridOnClick">\n' +
        '<param name="ondoubleclick" value="gidOnDoubleClick">\n' +
        '<param name="onstart"       value="gridOnLoad">\n' +
        '<param name="onstop"        value="gridOnUnload">\n' +
        '<param name="oncheckbox"    value="gridOnClickCheckbox">\n' +
        '<param name="oneditcell"    value="gridOnEditCell">\n' +
        '<param name="onselectrow"   value="gridOnBeforeSelect">\n' +
        '<param name="menu_init"     value="gridOnBeforeOpenMenu">\n' +
        '<param name="menu_action"   value="gridOnClickMenu">\n' +
        '<param name="hide_on_start" value="1">\n' +
        '<param name="sort_up"       value="icons/up.gif">\n' +
        '<param name="sort_down"     value="icons/down.gif">\n' +
        '</object>';
      setNodeElement(field, 'height', 200);
    }

    else if (fieldType.search(/^nested form$/) == 0) {
      setNodeElement(field,'default_value','Form Template');
      setNodeElement(field,'source_id',getDomFormByName('Form Template').getAttribute('id'));
    }

    else if (fieldType.search(/^image$/) == 0)  html_code = '<img src="images/1x1.gif">';
    else if (fieldType.search(/^HTML$/) == 0)   html_code = '<p>Some HTML goes here</p>';
    else if (fieldType.search(/^script$/) == 0) html_code = '<script></script>';

    if (html_code) setNodeElement(field,'html_code',html_code);

    var items = dom.selectSingleNode('/Innovator/Items');
    items.appendChild(field.documentElement);

    field = items.selectSingleNode('Item[@id="' + selectedFieldID + '"]');
    return field;
  }
}
