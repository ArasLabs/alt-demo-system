﻿// © Copyright by Aras Corporation, 2004-2007.

function BrowserCheck() {
	var b = navigator.appName
	if (b=="Netscape") this.b = "ns"
	else if (b=="Microsoft Internet Explorer") this.b = "ie"
	else this.b = b
	this.v   = parseInt(navigator.appVersion)
	this.ns  = (this.b=="ns" && this.v>=4)
	this.ns4 = (this.b=="ns" && (this.v==4 || this.v==5))
	this.ns5 = (this.b=="ns" && this.v==5)
	this.ie  = (this.b=="ie" && this.v>=4)
	this.ie4 = (navigator.userAgent.indexOf('MSIE 4')>0)
	this.ie5 = (navigator.userAgent.indexOf('MSIE 5')>0)
	if (this.ie5) this.v = 5
	this.min = (this.ns||this.ie)
}

var is = new BrowserCheck();
var fieldGrabbed = null;
var deltaX = 0;
var deltaY = 0;
var prevPosition = '';
var highlightedSpanShortID = '';

//Current moving element.
var sourceElement = null;
//Table id for current element.
var moveElementID = "currentTable";
//Timer id.
var timerID;
//Interval for moving element.
var movingInterval = 20;
//Change x coordinate when moving.
var movingDX = 3;
//Change y coordinate when moving.
var movingDY = 3;
var mouseDX;
//Saving mouse x coordinate.
var mouseX;
var mouseDY;
//Saving mouse y coordinate.
var mouseY;


function inSpan(obj) {
	if (obj.tagName == 'SPAN' && obj.id.search(/^[a-zA-Z0-9]{32}span/)==0) return obj;
	
	var res = null;
	
	if (is.ie) {
		if (obj.parentElement) res = inSpan(obj.parentElement);
	}
	else if (is.ns5) {
		if (obj.parentNode) res = inSpan(obj.parentNode);
	}
	
	if (!res) return null;
	else return res;
}

function getSpanID(elm) {
	var spanElem = inSpan(elm);
	if (!spanElem) return '';
	else return spanElem.id;
}

function getSpan(elm) {
	var spanElem = inSpan(elm);
	if (!spanElem) return null;
	else return spanElem;
}

var formtool_mouseOverStatusId;
attachEvent ('onunload', clearStatusMessage);

function clearStatusMessage() {
	if (formtool_mouseOverStatusId) top.aras.clearStatusMessage(formtool_mouseOverStatusId);
}

//Moving current element on the form.
function moveElement()
{
  if (fieldGrabbed.style.posLeft + fieldGrabbed.offsetWidth - document.body.scrollLeft + 5 >= document.body.clientWidth)
  {
    var realX = document.body.scrollLeft + mouseX;
    var dx = realX - fieldGrabbed.offsetLeft;

    if (dx < mouseDX - 5)
	  {
	    if (Math.abs(fieldGrabbed.style.posLeft + fieldGrabbed.offsetWidth - document.body.scrollWidth) < 5)
	    {
        mouseX -= movingDX;
        fieldGrabbed.style.posLeft -= movingDX;
        scrollBy(-movingDX, 0);
      }
    }
    else if (dx > mouseDX)
    {
      mouseX += movingDX;
      fieldGrabbed.style.posLeft += movingDX;
      scrollBy(movingDX, 0);
    }
  }
  else if ((fieldGrabbed.style.posLeft - document.body.scrollLeft - 2 <= 0)&&(document.body.clientWidth < document.body.scrollWidth))
  {
    if (fieldGrabbed.style.posLeft - movingDX < 0)
    {
      fieldGrabbed.style.posLeft = 0;
    }
    else
    {
      fieldGrabbed.style.posLeft -= movingDX;
    }
    scrollBy(-movingDX, 0);
  }
  
  if (fieldGrabbed.style.posTop + fieldGrabbed.offsetHeight - document.body.scrollTop + 5 >= document.body.clientHeight)
  {
    var realY = document.body.scrollTop + mouseY;
    var dy = realY - fieldGrabbed.offsetTop;
    
    if (dy < mouseDY - 5)
    {
      if (Math.abs(fieldGrabbed.style.posTop + fieldGrabbed.offsetHeight - document.body.scrollHeight) < 5)
      {
        mouseY -= movingDY;
        fieldGrabbed.style.posTop -= movingDY;
        scrollBy(0, -movingDY);
      }
    }
    else if (dy > mouseDY)
    {
      mouseY += movingDY;
      fieldGrabbed.style.posTop += movingDY;
      scrollBy(0, movingDY);
    }
  }
  else if ((fieldGrabbed.style.posTop - document.body.scrollTop - 5 <= 0))
  {
    if (fieldGrabbed.style.posTop - movingDY < 0)
    {
      fieldGrabbed.style.posTop = 0;
    }
    else
    {
      fieldGrabbed.style.posTop -= movingDY;
    }
    scrollBy(0, -movingDY);
  }
}

// Remove element from the form by element id.
function removeElement(elementID)
{
  var element = document.getElementById(elementID);
  if (element != null)
  {
    document.forms[0].removeChild(element);
  }
}

//Add table for current element.
function addTable(currentElement)
{
  var tableTag = document.createElement("TABLE");
  var tbodyTag = document.createElement("TBODY");
  var rowTag = document.createElement("TR");
  var cellTag = document.createElement("TD");

  rowTag.appendChild(cellTag);
  tableTag.appendChild(tbodyTag);
  tbodyTag.appendChild(rowTag);
  
  tableTag.setAttribute("id", moveElementID, false);
  tableTag.setAttribute("border", "1", false);
  tableTag.style.borderStyle = "dashed";
  tableTag.style.borderColor = "black";
  tableTag.setAttribute("width", currentElement.offsetWidth, false);
  tableTag.setAttribute("height", currentElement.offsetHeight, false);
  tableTag.style.position = "absolute";
  tableTag.style.top = currentElement.offsetTop;
  tableTag.style.left = currentElement.offsetLeft;
  
  document.forms[0].appendChild(tableTag);
}

document.onmouseover = function() {
	var elm = event.srcElement;
	if (!elm) return false;
	
	if (elm.tagName == 'SELECT') elm.disabled = true;
	
	if (fieldGrabbed) return false;
	if (event.button % 2 == 1) return false;
	
	var spanElem = getSpan(elm);
	if (!spanElem) {
		elm.style.cursor = 'default';
		return false;
	}
	else {
		var spanElemID = spanElem.id;
		spanElemID = spanElemID.substring(0, spanElemID.lastIndexOf('span'));
		if (highlightedSpanShortID != spanElemID) {
			with (parent.frames['fields']) {
				if (highlightedSpanShortID && currFldID!=highlightedSpanShortID) unSelectField(highlightedSpanShortID);
				
				highlightedSpanShortID = spanElemID;
				if (currFldID!=highlightedSpanShortID) selectField(highlightedSpanShortID, 'blue');
				else selectField(highlightedSpanShortID, 'black');
			}
		}
		
		if (event.altKey) elm.style.cursor = 'se-resize';
		else elm.style.cursor = 'hand';
		
		if (formtool_mouseOverStatusId) top.aras.clearStatusMessage (formtool_mouseOverStatusId);
    formtool_mouseOverStatusId = top.aras.showStatusMessage(0, spanElem.name, '');
	}
	
	return false;
}

document.onmouseout = function() {
	var elm = event.srcElement;
	if (!elm) return false;
	
	if (elm.tagName == 'SELECT')  elm.disabled = false;
	
	elm.style.cursor = 'default';
}

document.onmousedown = function() {
	var spanElem = getSpan(event.srcElement);
	if (!spanElem) return false;	
	
	sourceElement = spanElem;
	
	var fieldID = spanElem.id.substr(0, 32);
	
	with (parent.frames['fields']) {
		gridApplet.setSelectedRow(fieldID, false, true);
		onSelectGridRow(fieldID, 1, false);
	}

	fieldGrabbed = spanElem;
	prevPosition = spanElem.style.position;
	spanElem.style.position = 'absolute';
	var realX = document.body.scrollLeft+event.clientX;
	var realY = document.body.scrollTop+event.clientY;
	
	deltaX = realX - spanElem.offsetLeft;
	deltaY = realY - spanElem.offsetTop;
	
	mouseX = event.x;
	mouseDX = realX - spanElem.offsetLeft;
	mouseY = event.Y;
	mouseDY = realY - spanElem.offsetTop;
			
	clearInterval(timerID);
	timerID = setInterval("moveElement();", movingInterval);
	
	removeElement(moveElementID);	
  addTable(spanElem);
	
	return false;
}

document.onmouseup = function() {
	if (!fieldGrabbed) return false;
	
	var e = event;
	var elm = e.srcElement;
	if (!elm) return false;
	
	var spanElem = sourceElement;//getSpan(elm);
	if (!spanElem) return false;
	
	fieldGrabbed = null;
	
	elm.style.cursor = 'hand';
	spanElem.style.position = prevPosition;
	
	var fieldWasChanged = false;
	
	with (parent.frames['fields']) {
		if (e.altKey) {
			var oldWidth  = top.aras.getNodeElement(currFldNode, 'width' );
			var oldHeight = top.aras.getNodeElement(currFldNode, 'height');
			var newWidth  = spanElem.style.posWidth-2;
			var newHeight = spanElem.style.posHeight-2;
			
			fieldWasChanged = (newWidth!=oldWidth || newHeight!=oldHeight);
			
			if (fieldWasChanged) {
				top.aras.setNodeElement(currFldNode, 'width',  newWidth );
				top.aras.setNodeElement(currFldNode, 'height', newHeight);
			}
		}
		else {
			var oldX = top.aras.getNodeElement(currFldNode, 'x' );
			var oldY = top.aras.getNodeElement(currFldNode, 'y');
			var newX = spanElem.style.posLeft;
			var newY = spanElem.style.posTop;
			
			// +1 is used because of function selectField has code: spanElem.style.posLeft -= 1; spanElem.style.posTop -= 1;
			fieldWasChanged = (oldX!=newX+1 || oldY!=newY+1);
			
			if (fieldWasChanged) {
				top.aras.setNodeElement(currFldNode, 'x', newX);
				top.aras.setNodeElement(currFldNode, 'y', newY);
			}
		}
		
		if (fieldWasChanged) {
			if ((currFldNode.getAttribute('action')!='add')&& (currFldNode.getAttribute('action')!='create')) currFldNode.setAttribute('action', 'update');
			
			var currTabID = parent.frames['tabs'].currTabID;
			if (currTabID.search(/^field/)==0 && currTabID!=top.aras.getRelationshipTypeId('Field Event'))
				with (parent.frames['properties'].document)
					top.aras.uiPopulateFormWithItemEx(forms.MainDataForm, currFldNode, itemType, parent.isEditMode);
		}
	}
	if (fieldWasChanged && parent.currFormNd.getAttribute('action')!='add' && parent.currFormNd.getAttribute('action')!='create') parent.currFormNd.setAttribute('action', 'update');

	clearInterval(timerID);

	removeElement(moveElementID);
	
	return false;
}

document.onkeypress = function() {
	if (!fieldGrabbed) return false;
	
	if (event.keyCode == 27) {
		event.srcElement.style.cursor = "se-resize";
		var fieldNd = parent.frames['fields'].currFldNode;
		var fieldID = parent.frames['fields'].currFldID;
		var propNd  = null;
		if (parent.itemType) propNd = parent.itemType.selectSingleNode('Relationships/Item[@id="'+top.aras.getNodeElement(fieldNd, 'propertytype_id')+'" and @type="Property"]');
		
		fieldGrabbed.outerHTML = top.aras.uiDrawFieldEx(fieldNd, propNd, 'edit_form');
		fieldGrabbed = null;
		parent.frames['fields'].selectField(fieldID);
	}
	
	return false;
}

document.onmousemove = function() {
	if (!fieldGrabbed) return false;
	
	var elm = event.srcElement;
	if (!elm) return false;
	
	if (event.altKey) {
		elm.style.cursor = "se-resize";
		fieldGrabbed.style.posWidth  = event.x - fieldGrabbed.offsetLeft;
		fieldGrabbed.style.posHeight = event.y - fieldGrabbed.offsetTop;
	}
	else {
		elm.style.cursor = 'move';
		var realX = document.body.scrollLeft+event.x;
		var realY = document.body.scrollTop+event.y;	
		
		var posLeft = realX - deltaX;
		var posTop = realY - deltaY;
		
		mouseX = event.x;
		mouseY = event.y;
		
	  if ((posLeft + fieldGrabbed.offsetWidth - document.body.scrollLeft >= document.body.clientWidth) ||
	  (posLeft - document.body.scrollLeft <= 0))
	  {	   
	    realX = fieldGrabbed.style.posLeft + deltaX;  	
	  } 
	  if ( (posTop + fieldGrabbed.offsetHeight - document.body.scrollTop >= document.body.clientHeight) ||
	  (posTop - document.body.scrollTop <= 0))
	  {  
  	  realY = fieldGrabbed.style.posTop + deltaY;      
	  } 
	  	  
	  if (fieldGrabbed.style.posLeft + fieldGrabbed.offsetWidth - document.body.scrollLeft + 5 >= document.body.clientWidth)
	  {	
	    var realMouseX = document.body.scrollLeft + mouseX;	
	    var dx = realMouseX - fieldGrabbed.offsetLeft;
  		
	    if (dx < mouseDX)
	    { 
	      if (Math.abs(fieldGrabbed.style.posLeft + fieldGrabbed.offsetWidth - document.body.scrollWidth) < 5)
	      {	      
	        realX = fieldGrabbed.style.posLeft + deltaX;  
	      }
	    }	    
	  }
	  
	  if (fieldGrabbed.style.posTop + fieldGrabbed.offsetHeight - document.body.scrollTop + 5 >= document.body.clientHeight)
	  {
	  
	    var realMouseY = document.body.scrollTop + mouseY;	
	    var dy = realMouseY - fieldGrabbed.offsetTop;
  		
	    if (dy < mouseDY)
	    { 
	      if (Math.abs(fieldGrabbed.style.posTop + fieldGrabbed.offsetHeight - document.body.scrollHeight) < 5)
	      {	      
	        realY = fieldGrabbed.style.posTop + deltaY;  
	      }
	    }	    
	  }
	  
	    	   	 
	  if (realX - deltaX < 0)
	  {  
	    fieldGrabbed.style.posLeft = 0;
	  } 
	  else
	  {
	    fieldGrabbed.style.posLeft = realX - deltaX; 
	  }
  	 
	  if (realY - deltaY < 0)
	  {  
	    fieldGrabbed.style.posTop = 0;
	  } 
	  else
	  {
	    fieldGrabbed.style.posTop = realY - deltaY; 
	  }
  		
	 }
	
	return false;
}

document.body.onscroll = function() {
	return false;
}

document.onbeforeeditfocus = function(){
	return false;
}

document.onselectstart = function() {
	return false;
}

document.onclick = function() {
	return false;
}

document.ondblclick = function() {
	return false;
}

document.oncontextmenu = function() {
	return false;
}

