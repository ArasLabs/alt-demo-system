﻿//Written because of Microsoft patch KB912812
function WriteUncommentedObject(objectId)
{
  var obj = document.getElementById(objectId);
  WriteObject(obj.innerHTML);
}

function WriteObject(objectHTML)
{
  document.write(objectHTML);
}

function WriteObjectToDocument(document, objectHTML)
{
  document.write(objectHTML);
}

function UncommentObject(document, objectId)
{
  document.getElementById(objectId).outerHTML = document.getElementById(objectId).innerHTML;
}

function AddConfigurationLink() {
  var i = document.scripts.length - 1;
  if (i < 0) return;
  
  var ThisScript = document.scripts[i];
  if (!ThisScript) return;
  
  var BaseUrl;
  var flag = true;
  if (top.aras && top.aras.getBaseURL) {
    try {
      BaseUrl = top.aras.getBaseURL();
      flag = false;
    }
    catch (e) {}
  }
  if (flag) {
    BaseUrl = location.href.replace(/[\/\\](Solutions|scripts)[\/\\].*$/i, "");
  }
  if (!BaseUrl) return;
  
  var AssemblyList = ThisScript.innerHTML.split(";");
  for (var i=0; i<AssemblyList.length; i++) {
    var AssemblyName = AssemblyList[i];
    if (!AssemblyName) continue;
    document.write("<link rel=\"Configuration\" href=\"" + BaseUrl + "/cbin/" + AssemblyName + ".dll.config.xml\">");
  }
  /* This next element is for the benefit of software qa test automation */
document.write("<FORM id=\"evalhook\" style=\"display:none;\"><input id=\"evalhookINPUT\" name=\"INPUT\" type=\"hidden\" size=\"80\" value=\"\" /><input id=\"evalhookEVALCOUNT\" name=\"EVALCOUNT\" type=\"hidden\" size=\"80\" value=\"0\"/><input id=\"evalhookOUTPUT\" name=\"OUTPUT\" type=\"hidden\" size=\"80\"/><input id=\"evalhookERRORNUMBER\" name=\"ERRORNUMBER\" type=\"hidden\" size=\"80\"/><input id=\"evalhookERRORDESC\" name=\"ERRORDESC\" type=\"hidden\" size=\"80\"/><input id=\"evalhookTRIGGER\" name=\"TRIGGER\" type=\"hidden\" value=\"0\" onpropertychange='{var __INPUT = this.parentElement.INPUT.value;var __COUNT = parseInt(this.parentElement.EVALCOUNT.value);var __OUTPUT = \"\";var __EXCEPT_NUMBER = \"\";var __EXCEPT_DESC = \"\";try {__OUTPUT = eval(__INPUT);} catch (excep) { __EXCEPT_NUMBER = excep.number;__EXCEPT_DESC = excep.description;} this.parentElement.OUTPUT.value = __OUTPUT; this.parentElement.ERRORNUMBER.value = __EXCEPT_NUMBER; this.parentElement.ERRORDESC.value = __EXCEPT_DESC; this.parentElement.EVALCOUNT.value = __COUNT + 1;return(null);}' /></FORM>");
}

AddConfigurationLink();