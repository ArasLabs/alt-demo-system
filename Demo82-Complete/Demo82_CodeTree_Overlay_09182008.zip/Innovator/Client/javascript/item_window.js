﻿// (c) Copyright by Aras Corporation, 2004-2007.
var isItemWindow = true;

var menuFrame = (isTearOff ? document.frames['tearoff_menu'] : top.main.menu);

var isVersionableIT  = (top.aras.getItemProperty(itemType, 'is_versionable')=='1');
var isDependentIT    = (top.aras.getItemProperty(itemType, 'is_dependent')=='1');
var isRelationshipIT = (top.aras.getItemProperty(itemType, 'is_relationship')=='1');
var use_src_accessIT = (top.aras.getItemProperty(itemType, 'use_src_access')=='1');

var itemTypeID = top.aras.getItemTypeId(itemTypeName);
var can_addFlg = !isDependentIT && top.aras.getPermissions('can_add', itemTypeID) &&
                (!isRelationshipIT || itemTypeName == "RelationshipType" ||
                 (isRelationshipIT && !use_src_accessIT));

var filePropNms = new Array();
var fileItemTypeId = top.aras.getFileItemTypeID();
var filePropNds = itemType.selectNodes('Relationships/Item[@type="Property" and '+
  '(not(is_hidden) or is_hidden=0) and data_type="item" and data_source="'+fileItemTypeId+'"]');

for (var i=0; i<filePropNds.length; i++)
  filePropNms[i] = top.aras.getItemProperty(filePropNds[i], 'name');

var commandEventHandlers = new Object();

function findInstanceFrame() {
  var instance = null;
  if (frames['instance'])
  {
   instance = frames['instance'];
 }
  else
  {
   if (viewMode == 'tree view')
    for (var i = 0; i<frames['work'].frames.length; i++)
     if (frames['work'].frames[i].document.itemID == itemID) {
      instance = frames['work'].frames[i];
      break;
     }
   }
  return instance;
}

function updateInstanceFrame() {
  var instance = document.frames['instance'];
  if (!document.frames['instance']) return false;
  var form = instance.document.forms.MainDataForm;
  if (!form) return false;

  top.aras.uiPopulateFormWithItemEx(form, item, itemType, isEditMode);
  return true;
}

/*
addRowToItemsGrid is used in User defined Methods
*/
function addRowToItemsGrid (item) {
  try {
    if (!opener.main.work.isItemsGrid) return false;
  }
  catch (excep) { return false; }

  if (!item || !window.isTearOff) return false;

  if (opener.main.work.itemTypeName!=itemTypeName) return false;

  opener.main.work.updateRow(item);

  return true;
}

function updateItemsGrid (updatedItem, del_OR_add_Row_ifIDchanged) {
  if (del_OR_add_Row_ifIDchanged === undefined) del_OR_add_Row_ifIDchanged = true;

  if (!updatedItem || !window.isTearOff) return false;
  var updatedID = updatedItem.getAttribute("id");

  try {
    if (!opener.main.work.isItemsGrid) return false;
  }
  catch (excep) { return false; }

  if (itemTypeName == "ItemType") {
    if (itemID == opener.main.work.itemTypeID) {
      top.aras.makeItemsGridBlank();
      return true;
    }
  }

  if (opener.main.work.itemTypeName!=itemTypeName) return false;

  var gridApplet = opener.main.work.gridContainer;
  if (gridApplet.getRowIndex(itemID) == -1 ) return true;

  if (!del_OR_add_Row_ifIDchanged &&
      gridApplet.getRowIndex(updatedItem.getAttribute("id")) == -1) {
    return true;
  }

  var wasSelected = (gridApplet.getSelectedItemIds(";").search(itemID) > -1);

  if (del_OR_add_Row_ifIDchanged && updatedID != itemID) {
    opener.main.work.deleteRow(item);
  }
  opener.main.work.updateRow(updatedItem);

  if (wasSelected) {
    if (updatedID == itemID) opener.main.work.onSelectItem(itemID);
    else {
      var currSel = gridApplet.getSelectedId();
      //if (currSel)
      opener.main.work.onSelectItem(currSel);
    }
  }//if (wasSelected)

  return true;
}

function deleteRowFromItemsGrid(rowID) {
  try {
    if (!opener.main.work.isItemsGrid) return false;
  }
  catch (excep) { return false; }
  if (window.isTearOff
    && opener.main && opener.main.work && opener.main.work.isItemsGrid
    && opener.main.work.itemTypeName==itemTypeName)
  {
	  var gridApplet = opener.main.work.gridContainer;
    var selID = gridApplet.getSelectedItemIds(";");
    if (selID == rowID) {
      var prevSelRow = gridApplet.getRowIndex(selID);
      gridApplet.deleteRow(selID);
      var rowsInGrid = gridApplet.getRowsNum();
      if (rowsInGrid > 0 && prevSelRow>-1) {
        if (prevSelRow < rowsInGrid)  selID = gridApplet.getRowId(prevSelRow);
        else selID = gridApplet.getRowId(rowsInGrid-1);

        gridApplet.setSelectedRow(selID, false, true);
        opener.main.work.onSelectItem(selID);
      }//if(rowsInGrid>0)
      else opener.main.work.setupGrid(false);
    }
    else if (gridApplet.getRowIndex(rowID)!=-1) {
      gridApplet.deleteRow(rowID);
      var selID = gridApplet.getSelectedItemIds(";").split(";")[0];
      if (selID) opener.main.work.onSelectItem(selID);
    }
  }
}



var updateMenuState_tmt = 0;
function updateMenuState() {
  clearTimeout(updateMenuState_tmt);

  if (!menuFrame.menuFrameReady) {
    updateMenuState_tmt = setTimeout('updateMenuState()', 100);
    return;
  }
  var val = (top.aras.getVariable('ShowLabels') == 'true');
  menuFrame.setControlState('show_text', val);
  menuFrame.toolbarApplet.showLabels(val);

  var isTemp   = top.aras.isTempEx(item);
  var isDirty  = top.aras.isDirtyEx(item);
  var locked_by= top.aras.getItemProperty(item, 'locked_by_id');
  var ItemCanBeLockedByUser = top.aras.uiItemCanBeLockedByUser(item, isRelationshipIT, use_src_accessIT);
  var ItemIsLockedByUser = top.aras.isLockedByUser(item);
  
  var newFlg  = can_addFlg;
  var openFlg = (!isTemp && itemTypeName=='File');
  var saveFlg = ((isTemp && !isDependentIT) || (locked_by==top.aras.getCurrentUserID()));
  var saveAsFlg =  !isTemp;
  var purgeFlg= (locked_by=='');
  var lockFlg = ItemCanBeLockedByUser;
  var unlockFlg = ItemIsLockedByUser;
  var undoFlg = (!isTemp && isDirty);
  var revisionFlg = (!isTemp && isVersionableIT);

  var checkoutFlg     = top.aras.uiIsCheckOutPossible(item, ItemCanBeLockedByUser, ItemIsLockedByUser, itemType);
  var checkinFlg      = (ItemIsLockedByUser && filePropNms.length != 0);

  var copy2clipboardFlg = top.aras.getItemProperty(itemType, "is_relationship") == "1" &&
                          top.aras.getItemProperty(itemType, "is_dependent") != "1";
  var pasteFlg = !top.aras.clipboard.isEmpty() && (isTemp || ItemIsLockedByUser);
  if (pasteFlg) pasteFlg = top.aras.isLCNCompatibleWithIT(itemTypeID);
  var pasteSpecialFlg = !top.aras.clipboard.isEmpty() && (isTemp || ItemIsLockedByUser);
  var showClipboardFlg = !top.aras.clipboard.isEmpty();

  for (var i=0; i<filePropNms.length; i++) {
    var propNm = filePropNms[i];
    var file = item.selectSingleNode(propNm+'/Item');
    if (!file) {
      file = top.aras.getItemProperty(item, propNm);
      if (file) file = top.aras.getItemById('File', file, 0);
    }

    if (file) {
      var isLockedFile = top.aras.isLockedByUser(file);
      var isTempFile   = top.aras.isTempEx(file);
      checkinFlg  = checkinFlg && (!isTempFile && isLockedFile);
    }
  }
  var promoteFlg=lockFlg && !(isFunctionDisabled(itemTypeName,'Promote'));
  var noTabsFlg = !(isFunctionDisabled(itemTypeName,'No Tabs'));
  
  with (menuFrame) {
    setControlEnabled('new',       newFlg);
    setControlEnabled('open',      openFlg);
    setControlEnabled('download',  openFlg);
    setControlEnabled('view',      false);
    setControlEnabled('edit',      false);
    setControlEnabled('save',      saveFlg);
    setControlEnabled('saveAs',      saveAsFlg);
    setControlEnabled('save_unlock_close',saveFlg);
    setControlEnabled('purge',     purgeFlg);
    setControlEnabled('delete',    purgeFlg);
    setControlEnabled('print',     true);
    setControlEnabled('lock',      lockFlg);
    setControlEnabled('unlock',    unlockFlg);
    setControlEnabled('undo',      undoFlg);
    setControlEnabled('promote',   promoteFlg);
    setControlEnabled('revisions', revisionFlg);
    setControlEnabled('tabView',  true);
    setControlEnabled('no_tabs',   noTabsFlg);
    setControlEnabled('treeView', true);
    setControlEnabled('checkin',   checkinFlg);
    setControlEnabled('checkout',  checkoutFlg);
    setControlEnabled('checkout_2dir',checkoutFlg);
    setControlEnabled('undo_checkout',checkinFlg);
    setControlEnabled('copy2clipboard', copy2clipboardFlg);
    setControlEnabled('paste', pasteFlg);
    setControlEnabled('paste_special', pasteSpecialFlg);
    setControlEnabled('show_clipboard', showClipboardFlg);
  }

  if (isTearOff) {
    if (viewMode=='tab view') with (menuFrame) {
      setControlState('tabView', true);
      setControlState('treeView', false);
    }
    else if (viewMode=='tree view') with (menuFrame) {
      setControlState('tabView', false);
      setControlState('treeView', true);
    }
    else with (menuFrame) {
      setControlState('tabView', false);
      setControlState('treeView', false);
    }

    if (window.hideTabs !== undefined) with (menuFrame) {
      setControlState('no_tabs', hideTabs);
    }

    menuFrame.setControlEnabled("saveANDexit", saveFlg);
    menuFrame.setControlEnabled("close", true);
    menuFrame.setEnableAccessMenu(isEditMode);
  }
}

function registerCommandEventHandler( handlerOwnerWindow, handlerF, BeforeOrAfter, commandName) {
  if (!handlerOwnerWindow || !handlerF || !BeforeOrAfter || !commandName) return;
  if (BeforeOrAfter != "before" && BeforeOrAfter != "after") return;

  var key = BeforeOrAfter + commandName;
  var handlersInfoArr = commandEventHandlers[ key ];
  if (!handlersInfoArr) {
    handlersInfoArr = new Array();
    commandEventHandlers[ key ] = handlersInfoArr;
  }

  var len = handlersInfoArr.push (
    {
      window:handlerOwnerWindow,
      handler:handlerF
    }
  );

  key += ":" + String(len - 1);

  return key;
}

function unregisterCommandEventHandler( key ) {
  if (!key) return;

  var re = /^(.+):(\d+)$/;
  if ( !re.test(key) ) return;

  var k1 = RegExp.$1;
  var k2 = RegExp.$2;

  var handlersInfoArr = commandEventHandlers[ k1 ];
  if (!handlersInfoArr) return;

  delete handlersInfoArr[ k2 ];
}

if (!isTearOff) {
  //special code to set (un)registerCommandEventHandler on top frame
  function f (fNm) {
    fNm = fNm + "registerCommandEventHandler";
    if (top[fNm]) return;

    top[fNm] = window[fNm];
    function g() {
      top[fNm] = undefined;
    }

    window.attachEvent("onunload", g);
  }

  f( "" );
  f( "un" );
}

function executeUserCommandHandler( hId ) {
  var retValue = false; //indicates: no faults exist
  var handlersInfoArr = commandEventHandlers[ hId ];
  if (!handlersInfoArr) return retValue;

  for (var i=0; i<handlersInfoArr.length; i++) {
    var handlerInfo = handlersInfoArr[i];
    if (!handlerInfo) continue;

    var win = handlerInfo.window;
    var h   = handlerInfo.handler;
    if (!win || top.aras.isWindowClosed(win)) {
      handlersInfoArr[i] = null;
      continue;
    }

    try {
      retValue = h();
    }
    catch (excep) {retValue = "Exceprtion in handler " + hId + ", number " + i + ".";}
    
    if (retValue && typeof(retValue)=="string") break;
  }
  return retValue;
}

function onBeforeCommandRun( commandName ) {
  return executeUserCommandHandler( "before" + commandName );
}

function onAfterCommandRun( commandName ) {
  return executeUserCommandHandler( "after" + commandName );
}

function onNewCommand() {
  var newItm = top.aras.uiNewItemEx(itemTypeName);
  if (window.isTearOff && newItm && window.opener.top.main.work.isItemsGrid
   && window.opener.top.main.work.itemTypeName == itemTypeName)
    window.opener.top.main.work.insertRow(newItm);

  return true;
}

function onViewCommand() {
  return true;
}

function onEditCommand() {
  return true;
}

function onPurgeCommand(param) {
  return onPurgeDeleteCommand('purge', param);
}

function onDeleteCommand(param) {
  return onPurgeDeleteCommand('delete', param);
}

function onPurgeDeleteCommand(command, param)
{
  var silentMode = (false && param && param['delete_mode'] && param['delete_mode']=='silent');

  var delRes = false;
  var statusId;
  if (command == 'purge')
  {
    statusId = top.aras.showStatusMessage(0, 'purging...', '../images/Animated/ProgressSmall.gif');
    delRes = top.aras.purgeItemEx(item, silentMode);
  }
  else
  {
    statusId = top.aras.showStatusMessage(0, 'deleting...', '../images/Animated/ProgressSmall.gif');
    delRes = top.aras.deleteItemEx(item, silentMode);
  }
  top.aras.clearStatusMessage (statusId);

  if (delRes && opener.top.main)
  {
    if (!param)
      deleteRowFromItemsGrid(itemID);

    if (itemTypeName == 'ItemType')
    {
      if (window.isTearOff)
      {
        if (opener.top.main && opener.top.main.tree.updateTree)
          opener.top.main.tree.updateTree();
      }
      else if (top.main)
        top.main.tree.updateTree();
    }
    else if (itemTypeName=='Action')
    {
      if (window.isTearOff)
      {
        if (opener.top.main)
          opener.top.main.menu.updateGenericActions();
      }
      else if (top.main)
        top.main.menu.updateGenericActions();
    }
    else if (itemTypeName=='Report')
    {
      if (window.isTearOff)
      {
        if (opener.top.main)
          opener.top.main.menu.updateGenericReports();
      }
      else if (top.main)
        top.main.menu.updateGenericReports();
    }

    if (window.isTearOff) window.close();
    else top.main.work.location.replace('itemsGrid.html?itemtypeID='+window.itemType.getAttribute('id'));
  }

  if (param)
  {
    var res = top.aras.newObject();
    if (delRes) res['result'] = 'Deleted';
    else res['result'] = 'Canceled'; //deleting item canceled or failed
    return res;
  }
}

function onLockCommand() {
  var statusId = top.aras.showStatusMessage(0, 'locking...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.lockItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return true;

  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = true;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;
}

function onUnlockCommand() {
  
  var msg = onBeforeCommandRun( "unlock" );
  if (msg && typeof(msg)=="string") {top.aras.AlertError(msg); return false;}
  
  var statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
  
  var res = top.aras.unlockItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return false;
  onAfterCommandRun( "unlock" );

  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = false;
  top.aras.uiReShowItemEx(itemID, res, viewMode);

  return true;
}

function onUndoCommand() {
  if (!top.aras.isDirtyEx(item)) {
    top.aras.AlertError('Nothing to undo.');
    return true;
  }

  if (!confirm('Undo will discard your changes. Are you sure?')) return true;
  if (!top.aras.isTempEx(item)) {
    top.aras.removeFromCache(itemID);
    var res = top.aras.getItemById(itemTypeName, itemID, 0);
    if (!res) return true;
  }

  if (window.isTearOff) updateItemsGrid(res);
  top.aras.uiReShowItemEx(itemID, res, viewMode);

  return true;
}

function onSaveCommand()
{
  if (itemTypeName=='Report')
    clearJavascriptInReport(item);

  var msg = onBeforeCommandRun( "save" );
  if (msg && typeof(msg)=="string") {top.aras.AlertError(msg); return false;}

  var statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.saveItemEx(item);
  top.aras.clearStatusMessage (statusId);
  if (!res) return true;
  
  onAfterCommandRun( "save" );
  
  if (window.isTearOff) updateItemsGrid(res);
  if (opener.top.main != undefined)
  {
    if (itemTypeName == 'ItemType')
    {
      top.aras.getItemRelationships('ItemType', itemID, 'TOC Access');
      if (window.isTearOff) opener.top.main.tree.updateTree();
      else top.main.tree.updateTree();
    }
    else if (itemTypeName == 'Action')
    {
      if (window.isTearOff) opener.top.main.menu.updateGenericActions();
      else top.main.menu.updateGenericActions();
    }
    else if (itemTypeName=='Report')
    {
      if (window.isTearOff) opener.top.main.menu.updateGenericReports();
      else top.main.menu.updateGenericReports();
    }
  }  

  top.aras.uiReShowItemEx(itemID, res, viewMode);

  return true;
}

function onSaveUnlockAndExitCommand()
{
  // IR-003016 Run Report method fails
  if (itemTypeName=='Report')
    clearJavascriptInReport(item);

  var msg = onBeforeCommandRun( "save" );
  if (msg && typeof(msg)=="string") {top.aras.AlertError(msg); return false;}

  var SavedAttributes = new Object;
  function SaveItemAttributes(ItemNd)
  {
    //for now save only doGetItem attribute
    var attrNm = "doGetItem";
    SavedAttributes[attrNm] = ItemNd.getAttribute(attrNm);
  }
  
  function RestoreItemAttributes(ItemNd)
  {
    for (var attrNm in SavedAttributes)
    {
      var attrVal = SavedAttributes[attrNm];
      if (attrVal == null) ItemNd.removeAttribute(attrNm);
      else ItemNd.setAttribute(attrNm, attrVal);
    }
  }
  
  var statusId;
  statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
  SaveItemAttributes(item);
  //to improve perfomance of save operation, because results of "get" will be discarded by "unlock" below.
  item.setAttribute("doGetItem", "1");
  var res = top.aras.saveItemEx(item, false);
  top.aras.clearStatusMessage (statusId);
  if (!res)
  {
    RestoreItemAttributes(item);
    return true;
  }
  
  res.setAttribute("levels", "-1");//invalidates cached item because there was no "get"

  onAfterCommandRun( "save" );

  var resItemId = res.getAttribute("id");
  res = top.aras.getItemById$skipServerCache(itemTypeName, resItemId, 0, "locked_by_id");
  if (!res) return true;
  res.setAttribute("levels", "-1");//invalidates cached item because there was no "get"

  statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
  res = top.aras.unlockItemEx(res, false);
  top.aras.clearStatusMessage (statusId);
  if (!res) return true;

  if (window.isTearOff) updateItemsGrid(res);
  
  if (itemTypeName == 'ItemType')
  {
    top.aras.getItemRelationships('ItemType', itemID, 'TOC Access');
    if (window.isTearOff) opener.top.main.tree.updateTree();
    else top.main.tree.updateTree();
  }
  else if (itemTypeName == 'Action')
  {
    if (window.isTearOff) opener.top.main.menu.updateGenericActions();
    else top.main.menu.updateGenericActions();
  }
  else if (itemTypeName=='Report')
  {
    if (window.isTearOff) opener.top.main.menu.updateGenericReports();
    else top.main.menu.updateGenericReports();
  }

  if (window.isTearOff) window.close();
  return true;
}

// IR-003016 Run Report method fails
function clearJavascriptInReport(item) {
  var tmpDOM = top.aras.createXMLDocument();
  var xsl_stylesheet = top.aras.getItemProperty(item, "xsl_stylesheet");
  if (xsl_stylesheet != "") {
    tmpDOM.loadXML(xsl_stylesheet);
    var node = tmpDOM.selectSingleNode('//*[@implements-prefix="aras"]');
    var isModify = false;
    node = tmpDOM.selectSingleNode("//script[@userData='Tool Logic']")
    if (node) {
       node.parentNode.removeChild(node);
       isModify = true;
    }
    if (isModify) {
      top.aras.setItemProperty(item, "xsl_stylesheet", tmpDOM.xml);
    }
  }
}

function onRevisionsCommand()
{
  var param = new Object();
  param.aras = top.aras;
  param.itemID = itemID;
  param.itemTypeName = itemTypeName;
  
  var dlgWidth = "500px";
  var currItemType = top.aras.getItemTypeDictionary(itemTypeName);
  if (currItemType)
  {
    itemTypeID = top.aras.getItemProperty(currItemType.node, "id");
    instead_itemTypeID = itemTypeID + "_revisionsdlg";
    varName_colWidths= "IT_" + instead_itemTypeID + "_colWidths";
    var colWidths = top.aras.getVariable(varName_colWidths);
    if (colWidths)
    {
      dlgWidth = 0;
      var colWidthsArr = colWidths.split(";");
      for (var i = 0; i < colWidthsArr.length; i++)
        dlgWidth += parseInt(colWidthsArr[i]);
      
      if (dlgWidth < screen.availWidth)
        dlgWidth += "px";
    }
  }

  showModalDialog('revisionDialog.html', param,'dialogHeight:300px;dialogWidth:' + dlgWidth + ';status:0;help:0;resizable:1');
  return true;
}

function onPromoteCommand() {
  var param = new Object();
  param.item = item;
  param.aras = top.aras;

  var res = showModalDialog('promoteDialog.html', param, 'dialogHeight:300px;dialogWidth:400px;status:0;help:0;resizable:1;');
  if (typeof(res)=='string' && res=='null') {
    deleteRowFromItemsGrid(itemID);

    if (window.isTearOff) window.close();
    else top.main.work.location.replace('itemsGrid.html?itemtypeID='+window.itemType.getAttribute('id'));
    return true;
  }
  if (!res) return true;
  if (isVersionableIT) {
    var oldID = itemID;
    var result = top.aras.getItemLastVersion(itemTypeName, itemID);
    if (result) {
      itemID = result.getAttribute('id');
      if (oldID != itemID){
        deleteRowFromItemsGrid(oldID);
        addRowToItemsGrid (result);
        if (window.isTearOff) window.close();
        res = result;
      }
    }
  }

  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = false;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;
}

function onPrintCommand() {
  var frame = findInstanceFrame();
  if (frame && frame.document.body.onbeforeprint) {
    var f = frame.document.body.onbeforeprint;
    f();
  }
  top.aras.uiShowItemEx(item, 'print view', true);
  return true;
}

function onExport2OfficeCommand(targetAppType)
{
  var itm = item;
  if (itm)
  {
    var frm = (document.frames["relationships"]) ? document.frames["relationships"].frameElement : null
    var gridXml = "";
    if (frm)
    {
      try
      {
        frm = frm.contentWindow.iframesCollection[frm.contentWindow.currTabID];
        if (frm && frm.contentWindow.grid) gridXml = frm.contentWindow.grid.getXML();
      }
      catch (e){}
    }
    top.aras.export2Office(gridXml, targetAppType, itm); 
  }
}

function onOpenCommand() {
  top.aras.uiShowItemEx(item, 'openFile', true);
  return true;
}

function onDownloadCommand() {
  if (itemTypeName != 'File') return true;

  var workDir = top.aras.getWorkingDir(false, window);
  if (workDir == '') return true;

  with (top.aras) {
    var filename = getItemProperty(item, 'filename');
    var fileURL = getFileURLEx(item);
    if (fileURL == '') {
      top.aras.AlertError('Failed to download the file. The file URL is empty.');
      return false;
    }

    vault.setLocalFileName(filename);
    if ( !vault.downloadFile(fileURL) ) top.aras.AlertError("Failed to download the file.", "item_window: "+vault.getLastError(), "Client Side Error");
    else top.aras.AlertSuccess('The file "'+filename+'" has been successfuly downloaded into '+workDir+'.');
  }

  return true;
}

function onCheckInCommand() {
  var check_ok = true;
  if (isVersionableIT && top.aras.getItemProperty(item, 'new_version')!='1') {
    if (confirm(itemTypeName+' "'+top.aras.getKeyedNameEx(item)+'" needs to be saved. Save it ?')) {
      var newItemNd = top.aras.saveItemEx(item);
      if (isTearOff && newItemNd && itemTypeName==opener.top.main.work.itemTypeName)
        with (opener.top.main.work) {
          if (gridContainer.getRowIndex(itemID) > -1) {
            deleteRow(item);
            insertRow(newItemNd);
          }
        }
      if (newItemNd) top.aras.uiReShowItemEx(itemID, newItemNd, viewMode);
      if (isTearOff && newItemNd && itemTypeName==opener.top.main.work.itemTypeName) onCloseCommand();
      return true;
    }
  }
  else {
    for (var j=0; j<filePropNms.length; j++) {
      var propNm =filePropNms[j];
      var file = item.selectSingleNode(propNm+'/Item');
      if (!file) {
        file = top.aras.getItemProperty(item, propNm);
        if (file) {
           file = top.aras.getItemById('File', file, 0);
           item.selectSingleNode(propNm).text="";
           item.selectSingleNode(propNm).appendChild(file);
        }
      }

      if (file) {
         if (top.aras.checkinFile(file, window) == null)
           check_ok = false;
         if (window.opener)
           opener.main.work.updateRow(item);
      }
    }
  }

  var instance = findInstanceFrame();
  if (instance && instance.document.forms.MainDataForm)
   top.aras.uiPopulateFormWithItemEx(instance.document.forms.MainDataForm, item, itemType, isEditMode);
  if (updateMenuState) updateMenuState();

  if (check_ok)
  top.aras.AlertSuccess('Checkin completed.');
  else
  top.aras.AlertError('Checkin not completed.');

  return true;
}

function onCheckOutCommand() {
  var statusId = top.aras.showStatusMessage(0, 'checking out...', '../images/Animated/ProgressSmall.gif');
  var res;
  if (top.aras.isLocked(item))  {
    res = top.aras.checkoutFiles(item, top.aras.getWorkingDir(true, window));
    top.aras.clearStatusMessage (statusId);
    if (res) top.aras.AlertSuccess('CheckOut Completed')
    else top.aras.AlertError('CheckOut not completed')

    res = false;
  }
  else {
    res = top.aras.lockItemEx(item, top.aras.getWorkingDir(true, window), false);
  }
  top.aras.clearStatusMessage  (statusId);

  //--------  if (!updateInstanceFrame || !updateInstanceFrame()) if (updateMenuState) updateMenuState(); --------
  if (window.opener)
  {
    window.opener.main.work.updateRow(item);
  }

  var instance = findInstanceFrame();
  if (instance && instance.document.forms.MainDataForm)
  {
   top.aras.uiPopulateFormWithItemEx(instance.document.forms.MainDataForm, item, itemType, isEditMode);
  }

  if (updateMenuState) updateMenuState();

  if (!res) return true;
  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = true;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;
}

function onCheckOut2DirCommand()
{
  var checkout_path = top.aras.vault.selectFolder();
  if (!checkout_path) return true;

  var  statusId = top.aras.showStatusMessage(0, 'locking...', '../images/Animated/ProgressSmall.gif');
  var res;
  if (top.aras.isLocked(item))
  {
    if (top.aras.checkoutFiles(item, checkout_path)) 
      top.aras.AlertSuccess('Checkout completed');
    top.aras.clearStatusMessage(statusId);
    return true;
  }
  else
  {
    res = top.aras.lockItemEx(item, checkout_path, false);
    top.aras.clearStatusMessage(statusId);
  }

  if (!res) return true;
  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = true;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;
}

function onUndoCheckOutCommand() {
  top.aras.undoCheckOut(item);
  if (!updateInstanceFrame()) updateMenuState();
  top.aras.AlertError('Ready');
  return true;
}

function onTabViewCommand() {
  var activeToolbar = menuFrame.activeToolbar;
  var currentState = activeToolbar.getElement("tabView").getState();

  menuFrame.setControlState("tabView", true);
  menuFrame.setControlState("treeView", false);

  if (currentState == false && viewMode == "tab view") return true;

  if (!isTearOff) top.aras.setVariable("ViewMode", "tab view");

  var no_tabs = activeToolbar.getElement("no_tabs").getState();
  top.aras.uiTabViewItemEx(window, item, no_tabs);

  return true;
}

function onTreeViewCommand() {
  var activeToolbar = menuFrame.activeToolbar;
  var currentState = activeToolbar.getElement("tabView").getState();

  menuFrame.setControlState("tabView", false);
  menuFrame.setControlState("treeView", true);

  if (currentState == false && viewMode == "tree view") return true;

  if (!isTearOff) top.aras.setVariable("ViewMode", "tree view");

  top.aras.uiTreeViewItemEx(window, item);

  return true;
}

if (itemTypeName == "Report" || itemTypeName == "Method") {
  window.onTabViewCommand = undefined;//to fix IR-003526 and IR-003587
  window.onTreeViewCommand = undefined;//to fix IR-003526 and IR-003587
}

function onWhereusedViewCommand() {
}

var __tabsShowStr  = '';
function showRelationshipsFrame(b) {
  window.hideTabs = !b;

  if (viewMode=='tab view' && frames['relationships']) {
    if (b) {
      document.all("tabViewFrameset").rows = __tabsShowStr;
      document.frames["relationships"].frameElement.noResize = false;
    }
    else {
      __tabsShowStr = document.all("tabViewFrameset").rows;
      var newValStr;
      if (window.isTearOff) newValStr = __tabsShowStr.substr(0, __tabsShowStr.indexOf(',')+1)+'*,0px,20px';
      else newValStr = '*, 0px,20px';
      document.frames["tabViewFrameset"].attributes("rows").nodeValue = newValStr;
      document.frames["relationships"].frameElement.noResize = true;
    }

    if (!menuFrame.menuFrameReady || !menuFrame.activeToolbar || !menuFrame.activeToolbar.getElement('no_tabs')) {
      setTimeout('showRelationshipsFrame('+b+')', 100);
    }
    else {
      menuFrame.activeToolbar.getElement('no_tabs').setState(!b);
    }
  }
}

function onNoTabsCommand() {
  if (viewMode=='tab view') {
    var activeToolbar = menuFrame.activeToolbar;
    var hideTabs = (activeToolbar.getElement('no_tabs').getState()==true);

    menuFrame.setControlState('no_tabs', hideTabs);    
    
    if (frames['relationships'])  showRelationshipsFrame(!hideTabs);
    else setTimeout("top.aras.uiTabViewItemEx(window, item, "+(hideTabs==true ? "true" : "false")+")",1);
  }

  return true;
}

function onCloseCommand() {
  if (window.isTearOff) window.close();
  return true;
}

function onRefresh() {
  if('tree view'==viewMode)
  {
    document.frames["tree"].updateCache();
  }
  top.aras.uiReShowItemEx(itemID, item, viewMode);
}

function updateMenu() {
  if (menuFrame.populateAccessMenu) menuFrame.populateAccessMenu();
}

function onCopy2clipboardCommand() {
  if (this.menu && this.menu.copyTreeNode) {
    this.menu.copyTreeNode();
    return;
  }
  var itemArr = new Array();
  var itemID = item.getAttribute("id");
  var itemTypeName = item.getAttribute("type");
  var clItem = top.aras.copyRelationship(itemTypeName, itemID);
  itemArr.push(clItem);

  top.aras.clipboard.copy(itemArr);
  updateMenuState();
}

function onPasteCommand()
{
  if (this.menu && this.menu.pasteTreeNode)
  {
    this.menu.pasteTreeNode();
    return;
  }
  var itemArr = top.aras.clipboard.paste();
  if (itemArr.length == 0) return;

  for (var j = 0; j < itemArr.length; j++)
  {
    var clipboardItem = itemArr[j];
    var RelType_Nm = clipboardItem.relationship_itemtype;
    var RelType_Nd = top.aras.getItemFromServerByName("RelationshipType", RelType_Nm, 'copy_permissions,create_related').node;
    var as_is  = top.aras.getItemProperty(RelType_Nd, 'copy_permissions') == "1";
    var as_new = top.aras.getItemProperty(RelType_Nd, 'create_related') == "1";
    var relNd  = top.aras.pasteRelationship(item, clipboardItem, as_is, as_new, RelType_Nm);

    if (!relNd)
    {
      top.aras.AlertError("Pasting failed.");
      return;
    }
  }
  top.aras.AlertSuccess("Pasting completed successfully.");
  onRefresh();
  updateItemsGrid(item);
}

function onPaste_specialCommand(targetRelationshipTN, targetRelatedTN) {
  if (this.menu && this.menu.pasteSpecialTreeNode) {
    this.menu.pasteSpecialTreeNode();
    return;
  }
  var arguments = new Object();
  arguments.aras = top.aras;
  var itemsArr = new Array();
  itemsArr.push(window.item);
  arguments.itemsArr = itemsArr;
  arguments.srcItemTypeId = itemTypeID;
  arguments.targetRelationshipTN = targetRelationshipTN;
  arguments.targetRelatedTN = targetRelatedTN;

  var res = showModalDialog(top.aras.getScriptsURL()+'ClipboardManager.html', arguments, 'dialogHeight: 450px; dialogWidth: 700px; status:0; help:0; resizable:0');
  if (res && res.ids)
  {
    var clipboardItems = top.aras.clipboard.clItems;
    for (var i = 0; i < res.ids.length; i++) {
      for (var j = 0; j < itemsArr.length; j++) {
        var item = itemsArr[j];
        var clipboardItem = clipboardItems[res.ids[i]];

        if (!top.aras.pasteRelationship(item, clipboardItem, res.as_is, res.as_new, targetRelationshipTN, targetRelatedTN)) {
          top.aras.AlertError("Pasting failed");
          return;
        }
      }
    }
    top.aras.AlertSuccess("Pasting completed successfully.");

    onRefresh();
    updateItemsGrid(item);
  }
}

function onShow_clipboardCommand() {
  var arguments = new Object();
  arguments.aras = top.aras;
  arguments.srcItemTypeId = itemTypeID;
  var res = showModalDialog(top.aras.getScriptsURL()+'ClipboardManager.html', arguments, 'dialogHeight: 450px; dialogWidth: 700px; status:0; help:0; resizable:0');
  if (res) {
    onRefresh();
    if (top.main && top.main.menu) top.main.menu.setControlEnabled("show_clipboard", !top.aras.clipboard.isEmpty());
  }
}

var windowReady = true;
updateMenuState();