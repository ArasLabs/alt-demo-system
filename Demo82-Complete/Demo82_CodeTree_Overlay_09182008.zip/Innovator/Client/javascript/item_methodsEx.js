﻿// © Copyright by Aras Corporation, 2004-2007.

/*
 *   The item extended methods extension for the Aras Object.
 *   methods in this file use xml nodes as parameters
 */

Aras.prototype.isTempEx = function(itemNd) {
  if (itemNd == undefined) return undefined;

  return (itemNd.getAttribute('isTemp')=='1');
}

Aras.prototype.isDirtyEx = function(itemNd) {
  if (itemNd == undefined) return undefined;

  return (itemNd.selectSingleNode('descendant-or-self::Item[@isDirty="1"]')!=null);
}

Aras.prototype.isLocked = function Aras_isLocked(itemNd) {
  if (this.isTempEx(itemNd)) return false;

  var locked_by_id = this.getItemProperty(itemNd, 'locked_by_id');
  return (locked_by_id!='');
}

Aras.prototype.isLockedByUser = function Aras_isLockedByUser(itemNd) {
  if (this.isTempEx(itemNd)) return false;

  var locked_by_id = this.getItemProperty(itemNd, 'locked_by_id');
  return (locked_by_id==this.getCurrentUserID());
}

/*-- copyItemEx
 *
 *   Method to copy an item
 *   itemNd = item to be cloned
 *
 */
Aras.prototype.copyItemEx = function(itemNd, action, do_add) {
  if (!itemNd) return false;
  if (!action) action = "copyAsNew";
  if (do_add == undefined) do_add = true;
  if (do_add == null) do_add = true;

  var itemTypeName = itemNd.getAttribute('type');
  var bodyStr = '<Item type="'+itemTypeName+'" id="'+itemNd.getAttribute('id')+'" ';
  if (itemTypeName.search(/^ItemType$|^RelationshipType$|^User$/) == 0) bodyStr += ' action="copy" ';
  else bodyStr += ' action="' + action + '" ';
  if (!do_add) bodyStr += ' do_add="0" ';
  bodyStr += ' />';

  var res = null;

  with (this) {
    var statusId = showStatusMessage(0, '   Copying Item ...', system_progressbar1_gif);
    res = soapSend('ApplyItem', bodyStr);
    clearStatusMessage(statusId);
  }

  if (res.getFaultCode()!=0) {
    top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
    return null;
  }

  var itemCopy = res.results.selectSingleNode('//Item');
  if (itemCopy) itemCopy = this.dom.selectSingleNode('/Innovator/Items').appendChild(itemCopy);

  return itemCopy;
}


/*-- getListValuesEx
 *
 *   Get List values in one request from server using server getListValues method
 *   listID = id of list
 *   listName = name of list (optional)
 *   filterValue = (optional)
 *
 */
Aras.prototype.getListValuesEx = function(listID, listName, filterValue) {
  if (!listID && !listName) return false;
  var bodyStr = '<Item ';
  if (listID) bodyStr += ' listID="'+listID+'" ';
  if (listName) bodyStr += ' listName="'+listName+'" ';
  if (filterValue) bodyStr += ' filterValue="'+filterValue+'" ';
  bodyStr += ' action="getListValues" ';
  bodyStr += '/>';
  var res = null;

  with (this) {
    var statusId = showStatusMessage(0, '   Getting List Values Item ...', system_progressbar1_gif);
    res = soapSend('ApplyItem', bodyStr);
    clearStatusMessage(statusId);
  }

  if (res.getFaultCode()!=0) {
    top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
    return null;
  }
  return res.results.selectNodes('//Values/Value');
}



//+++++ saving item +++++
Aras.prototype.checkItemType = function(itemNd, win)
{
  with (this)
  {
    var name = getItemProperty(itemNd, 'name');
    var errMsg = "The name for ItemType is not valid.\nSpecify a different name, please.";

    if (name == '')
    {
      top.aras.AlertError("The name of the ItemType cannot be left blank.", "", "", win);
      return false;
    }

    var re = /^[a-zA-Z](\w|\s)*$/;
    if (!re.test(name))
    {
      top.aras.AlertError("The name of the ItemType can contain only letters and underscores.", "", "", win);
      return;
    }
    
    var properties = itemNd.selectNodes('Relationships/Item[@type="Property" and (not(@action) or (@action!="delete" and @action!="purge"))]');
    var property, propDt, propDs, tmpStoredLength, storedLength, pattern;
    for (var i = 0; i < properties.length; i++)
    {
      property = properties(i);
      propDt = getItemProperty(property, 'data_type');

      if (propDt == 'string')
      {
        tmpStoredLength = getItemProperty(property, 'stored_length');
        storedLength = parseInt(tmpStoredLength);

        if (isNaN(storedLength))
        {
          top.aras.AlertError('The length of the <b>"' + getKeyedNameEx(property) + '"</b> property is not specified.', "", "", win);
          return false;
        }
        else if (storedLength <= 0)
        {
          top.aras.AlertError('The length of the <b>"' + getKeyedNameEx(property) + '"</b> property is invalid: '+tmpStoredLength, "", "", win);
          return false;
        }
      }
      else if (propDt == 'item' || propDt == 'list' || propDt == 'filter list' || propDt == 'color list' || propDt == 'sequence' || propDt == 'foreign')
      {
        propDs = getItemProperty(property, 'data_source');
        if (!propDs && (!property.selectSingleNode("name") || property.selectSingleNode("name").text != "related_id" && property.selectSingleNode("name").text != "source_id"))
        {
          top.aras.AlertError('The data_source of the <b>"' + getKeyedNameEx(property) + '"</b> property is not specified.', "", "", win);
          return false;
        }
      }
      else if (propDt == 'filter list')
      {
        pattern = getItemProperty(property, 'pattern');
        if (!pattern)
        {
          top.aras.AlertError('The property '+getKeyedNameEx(property)+' is of type Filter List and has to have a pattern specified.', "", "", win);
          return false;
        }

        var tmpNd_1 = itemNd.selectSingleNode('Relationships/Item[@type="Property" and name="'+pattern+'" and (not(@action) or (@action!="delete" and @action!="purge"))]');
        if (!tmpNd_1)
        {
          top.aras.AlertError('Filter list property "'+getKeyedNameEx(property)+'" has wrong pattern !!!\n'+
            'There is no such property "'+pattern+'" in the ItemType.',win);
          return false;
        }
        else if (getItemProperty(tmpNd_1, 'name')==getItemProperty(property, 'name'))
        {
          top.aras.AlertError('The property specified for the pattern of the '+getKeyedNameEx(property)+' property cannot be the '+getKeyedNameEx(property)+' property itself.', "", "", win);
          return false;
        }
      }
    }
  }
  return true;
}


/* getPropertyLabel, used only in checkItem */

Aras.prototype.getPropertyLabel = function Aras_getPropertyLabel(reqId) {

  if(!reqId) return "";
  
  var xml = "<Item type='Property' action='get' id='" + reqId + "' select='label,keyed_name'/>";

  var res = this.soapSend("getItem",xml);
  if(!res || res.getFaultCode() != 0) return "";
  
  var item = res.getResult().selectSingleNode("Item");
  if(!item) return "";

  var label = this.getItemProperty(item,"label");
  if(!label) label = this.getItemProperty(item,"keyed_name");
  if(!label) return "";
  return label;
}

Aras.prototype.checkItem = function Aras_checkItem(itemNd,win,exclusion) {
  with(this)
  {
    var itemType, requrequiremens, requirement, reqId, reqName, reqDataType, itemPropVal, defVal;
    if (itemNd.getAttribute('type')) {
      itemType = getItemTypeDictionary(itemNd.getAttribute('type'));
      requirements = itemType.node.selectNodes('Relationships/Item[@type="Property"]');
    }

    if (itemType && requirements) {
    for(var i = 0;i<requirements.length;i++)
    {
      requirement = requirements[i];
      reqId   = requirement.getAttribute('id');
      reqName = getItemProperty(requirement,'name');
      reqDataType = getItemProperty(requirement,'data_type')
      
      if (exclusion && (reqName == exclusion)) continue;
      if(reqName)
      {
        itemPropVal = getItemProperty(itemNd,reqName);

        if((itemPropVal=='')&&(reqName=='id'||reqName=='type'||reqName=='typeId'))
        {
          itemPropVal = itemNd.getAttribute(reqName);
        }

        if((getItemProperty(requirement,'is_required')=='1')&&(itemPropVal==''))
        {
          defVal = getItemProperty(requirement,'default_value');
          if(defVal)
          {
            var msg = 'The "'+ this.getPropertyLabel(reqId) + '" field is required.\nYou must provide ' + 
                      'a value for this field before saving.\nDefault "' + defVal + '" will be used.';
            var ask = win.confirm(msg);

            if(!ask)return false;

            setItemProperty(itemNd,reqName,defVal);
            continue;
          }
          else if(!isPropFilledOnServer(reqName))
          {
            var doWarn = true;
            if (reqDataType == 'md5')
            {
              if (itemNd.getAttribute('action') != 'add')
              {
                if (!itemNd.selectSingleNode(reqName)) doWarn = false;
              }
            }
            if (doWarn)
            {
              var label = this.getPropertyLabel(reqId);
              this.AlertError('The "<b>' + label + '</b>" field is required. You must provide a value for this field before saving.', win);
              return false;
            }
          }
        }

        if(reqDataType == 'string')
        {
          var storedLength = parseInt(getItemProperty(requirement,'stored_length'));
          if(!isNaN(storedLength)&&itemPropVal.length-storedLength>0)
          {
            var msg = 'The maximum length for property "<b>' + this.getPropertyLabel(reqId) + '</b>" is <b>' + storedLength + '</b> characters.<br>' +
                      'You\'ve entered <b>' + itemPropVal.length + '</b> characters.<br>Please,check your input.'
            this.AlertError(msg,win);
            return false;
          }
        }
      }
      else
      {
        var msg = 'ItemType ' + getItemProperty(itemType.node,'label') +
                  ' has a property with no name. Please provide a name and save again.'
        this.AlertError(msg,win);
        return false;
      }
    }
    }
  }
  return true;
}

Aras.prototype.checkFileProps = function Aras_checkFileProps(itemNd)
{
  var itemTypeName = itemNd.getAttribute('type');
  if(itemTypeName=='File' || itemTypeName=='Located') return ; // do not check Files to prevent recursion
  
  var itemType  = this.getItemTypeForClient(itemTypeName).node;
  var fileProps = this.getPropertiesOfTypeFile(itemType);
 
  if (fileProps.length == 0) 
  {
    return;  // If length=0, then return immediately to improve the performance of 'Save' and 'Unlock' operations
  }
  
  for(var i=0;i<fileProps.length; i++)
  {
    var propNm = this.getItemProperty(fileProps[i],'name');
    var prop   = itemNd.selectSingleNode(propNm+'[not(./Item) and .!=""]');

    if(prop)with(this)
    {
      var fileID = prop.text;
      var fileNd = getFromCache(fileID);

      if(fileNd&&isLockedByUser(fileNd))
      {
        var filename = getItemProperty(fileNd,'filename');
        var checkedout_path = getItemProperty(fileNd,'checkedout_path');
        if(!vault.setWorkingDir(checkedout_path)||!setFileNameInVaultWithPathCheck(checkedout_path, filename))
        {
          filename = vault.selectFile();
          if(!filename) continue;
          var pos = filename.lastIndexOf('\\');
          setItemProperty(fileNd,'filename',filename.substr(pos-(-1)));
          setItemProperty(fileNd,'checkedout_path',filename.substring(0,pos));
        }

        if(hasFileChanged(fileNd))
        {
          if(!fileNd.getAttribute('action'))
          {
            fileNd.setAttribute('action','update');
          }
          fileNd.setAttribute('isDirty','1');
          filename = getItemProperty(fileNd,'checkedout_path') + "\\" + getItemProperty(fileNd,'filename');
          setItemProperty(fileNd,'file_size',vault.getFileSize(filename));
          setItemProperty(fileNd,'checksum',vault.getFileCheckSum(filename));
        }

        prop.text = '';
        prop.appendChild(fileNd);
      }
    }
    else
    {
      with(this)
      {
        var fileNd = itemNd.selectSingleNode(propNm+'/Item');
        if(fileNd&&isLockedByUser(fileNd))
        {
          var filename = getItemProperty(fileNd,'filename');
          var checkedout_path = getItemProperty(fileNd,'checkedout_path');
          if(!vault.setWorkingDir(checkedout_path)||!setFileNameInVaultWithPathCheck(checkedout_path, filename))
          {
            filename = vault.selectFile();
            if(!filename)continue;var pos = filename.lastIndexOf('\\');
            setItemProperty(fileNd,'filename',filename.substr(pos-(-1)));
            setItemProperty(fileNd,'checkedout_path',filename.substring(0,pos));
          }

          if(hasFileChanged(fileNd))
          {
            if(!fileNd.getAttribute('action'))
            {
              fileNd.setAttribute('action','update');
            }
            fileNd.setAttribute('isDirty','1');
            filename = getItemProperty(fileNd,'checkedout_path') + "\\" + getItemProperty(fileNd,'filename');
            setItemProperty(fileNd,'file_size',vault.getFileSize(filename));
            setItemProperty(fileNd,'checksum',vault.getFileCheckSum(filename));
          }
        }
      }
    }
  }

  var items = itemNd.selectNodes('./*/Item[@type!="File"] | ./Relationships/*/Item[@type!="File"]');
  for(var i = 0;i<items.length;i++)
  {
    this.checkFileProps(items[i]);
  }
}

Aras.prototype.prepareItem4Save = function Aras_prepareItem4Save(itemNd)
{
  var itemTypeName = itemNd.getAttribute('type');
  var itemID, item, items, items2;
  var i, j, parentNd;

  itemID = itemNd.getAttribute('id');
  items  = itemNd.selectNodes('.//Item[@id="'+itemID+'"]');

  for (i=0; i<items.length; i++)
  {
    item = items[i];
    parentNd = item.parentNode;
    parentNd.removeChild(item);
    parentNd.text = itemID;
  }

  items = itemNd.selectNodes('.//Item[@action="delete"]');
  for (i = 0; i < items.length; i++)
  {
      item = items[i];
      var childs = item.selectNodes("*[count(descendant::Item[@action])=0]");
      for (var j = 0; j < childs.length; j++) {
        var childItem = childs[j];
        item.removeChild(childItem);
      }
  }

  items = itemNd.selectNodes('.//Item');
  for (i=0; i<items.length; i++)
  {
    item = items[i];
    itemID = item.getAttribute('id');
    items2 = itemNd.selectNodes('.//Item[@id="'+itemID+'"][@data_type != "foreign"]');
    for (j=1; j < items2.length; j++)
    {
      item = items2[j];
      parentNd = item.parentNode;
      parentNd.removeChild(item);
      parentNd.text = itemID;
    }
  }

  items = itemNd.selectNodes('.//Item[not(@action) and not(.//Item/@action)]');
  for (i=0; i<items.length; i++)
  {
    items[i].setAttribute('action', 'get');
  }

  items = itemNd.selectNodes('.//Item[@action="get" and (not(.//Item) or not(.//Item/@action!="get"))]');
  for (i=0; i<items.length; i++)
  {
    item = items[i];
    itemID = item.getAttribute('id');
    parentNd = item.parentNode;

    if (parentNd.nodeName=='Relationships')
    {
      parentNd.removeChild(item);
    }
    else
    {
      if (itemID)
      {
        parentNd.removeChild(item);
        parentNd.text = itemID;
      }
    }
  }

  items = itemNd.selectNodes('.//Item[@action="get"]');
  for (i=0; i<items.length; i++)
  {
    items[i].setAttribute('action', 'skip');
  }
}

Aras.prototype.calcMD5 = function(s)
{
 return calcMD5(s);
}

Aras.prototype.codeMd5Fields = function(itemNd)
{
  return false; // This return was already here - why?

  itemType = this.getItemTypeDictionary(itemNd.getAttribute('type'));
  if (!itemType) return false;

  var md5Props = itemType.node.selectNodes('Relationships/Item[@type="Property" and data_type="md5" and (not(@action) or (@action!="delete" and @action!="purge"))]');
  for (var i=0; i<md5Props.length; i++)
  {
    with (this)
    {
      var propNm = getItemProperty(md5Props[i], 'name');
      if (!itemNd.selectSingleNode(propNm)) continue;

      var propVal = getItemProperty(itemNd, propNm);
      propVal = calcMD5(propVal);
      setItemProperty(itemNd, propNm, propVal);
    }
  }

  var items = itemNd.selectNodes('.//Item');
  for (i=0; i<items.lentgh; i++)
  {
    codeMd5Fields(items[i]);
  }
}

Aras.prototype.sendFilesWithVaultApplet = function Aras_sendFilesWithVaultApplet(itemNd, statusMsg, XPath2ReturnedNd) {
/*----------------------------------------
 * sendFilesWithVaultApplet
 *
 * Purpose:
 * This function is for iternal use only. DO NOT use in User Methods
 * Checks physical files.
 * Sets headers and send physical files to Vault
 *
 * Arguments:
 * itemNd    - xml node to be processed
 * statusMsg - string to show in status bar while files being uploaded
 * XPath2ReturnedNd = xpath to select returned node. Default: top.aras.XPathResult('/Item')
 */

  var win = this.uiFindWindowEx2(itemNd);
  if (!XPath2ReturnedNd) XPath2ReturnedNd = top.aras.XPathResult('/Item');

  var vaultServerURL = this.getVaultServerURL();
  var vaultServerID  = this.getVaultServerID();
  if (vaultServerURL == '' || vaultServerID == "") {
    top.aras.AlertError('The Vault Server is not specified for You.', "", "", win);
    return null;
  }

  var vaultApplet = this.vault;
  vaultApplet.clearClientData();
  vaultApplet.clearFileList();

  vaultApplet.setClientData('SOAPACTION', 'ApplyItem');
  vaultApplet.setClientData('DATABASE', this.getDatabase());
  vaultApplet.setClientData('AUTHUSER', this.getLoginName());
  vaultApplet.setClientData('AUTHPASSWORD', this.getPassword());

  var fileNds = itemNd.selectNodes('descendant-or-self::Item[@type="File" and (@action="add" or @action="update")]');
  for (var i=0; i<fileNds.length; i++) {
    var fileNd = fileNds(i);
    var fileID = fileNd.getAttribute('id');
    
    if (fileID) {
      var fileRels = fileNd.selectSingleNode("Relationships");
      if (!fileRels) fileRels = fileNd.appendChild(this.dom.createElement("Relationships"));
      var fileLocated = fileRels.selectSingleNode("Item[@type='Located']");
      if (!fileLocated) {
        fileLocated = fileRels.appendChild(this.dom.createElement("Item"));
        fileLocated.setAttribute("type", "Located");
      }
      if (!fileLocated.getAttribute("action")) {
        var newLocatedAction = "";
        if (fileNd.getAttribute("action") == "add")
          newLocatedAction = "add";
        else
          newLocatedAction = "merge";
        fileLocated.setAttribute("action", newLocatedAction);
      }
      if (!fileLocated.getAttribute("id") && !fileLocated.getAttribute("where"))
        fileLocated.setAttribute("where", "1=1"/*"source_id='"+fileID+"'"*/);
      this.setItemProperty(fileLocated, "related_id", vaultServerID);
    }
    
    //code related to export/import functionality. server_id == donor_id.
    var server_id = this.getItemProperty(fileNd, 'server_id');
    if (server_id == '') {
      //this File is not exported thus check physical file.
      var checkedout_path = this.getItemProperty(fileNd, "checkedout_path");
      var filename = this.getItemProperty(fileNd, "filename");
      var FilePath;
      
      if (!checkedout_path || !vaultApplet.setWorkingDir(checkedout_path) ||
          !filename || !this.setFileNameInVaultWithPathCheck(checkedout_path, filename)) {
        FilePath = vaultApplet.selectFile();
        if (!FilePath) return null;
        
        var parts = FilePath.split("\\");
        filename  = parts[parts.length-1];
        this.setItemProperty(fileNd, "filename", filename);
      }
      else FilePath = checkedout_path + "\\" + filename;
      
      this.setItemProperty(fileNd, "checkedout_path", checkedout_path);
      this.setItemProperty(fileNd, "checksum",        vaultApplet.getFileCheckSum(FilePath.replace(/\\/g,"/")));
      this.setItemProperty(fileNd, "file_size",       vaultApplet.getFileSize(FilePath.replace(/\\/g,'/')));
      
      vaultApplet.addFileToList(fileID, FilePath);
    }
  }

  var statusId = this.showStatusMessage(0, statusMsg, system_progressbar1_gif);
  var XMLdata = SoapConstants.EnvelopeBodyStart + '<ApplyItem>' +
  itemNd.xml+'</ApplyItem>' + SoapConstants.EnvelopeBodyEnd;

  vaultApplet.setClientData('XMLdata', XMLdata);

  var boolRes = vaultApplet.sendFiles(vaultServerURL);
  this.clearStatusMessage(statusId);

  var resXML = vaultApplet.getResponse();
  if (!boolRes || !resXML) {
    top.aras.AlertError("Failed to upload the files.\n\nIs the specified Vault Server URL: " + vaultServerURL + " correct ?", "", "", win);
    if (!boolRes) resXML+=vaultApplet.getLastError();
    top.aras.AlertError("An internal error has occured.", boolRes + "\n" + resXML, "Client Side Error", win);
    return null;
  }

  var resDom = this.createXMLDocument();
  resDom.loadXML(resXML);

  if (resDom.parseError.errorCode != 0) {
    var param = new Object();
    param.errorText = resXML;

    var val = top.aras.soapErrorDialog(resXML,win);
    return null;
  }

  if (this.hasFault(resDom, true)) {//because user can has just add access and no get access
    top.aras.AlertError(this.getFaultDetails(resDom), this.getFaultString(resDom), this.getFaultActor(resDom), win);
    return null;
  }
  if (this.hasMessage(resDom)) {// check for message
    this.refreshWindows(this.getMessageNode(resDom),resDom);
  }
  return resDom.selectSingleNode(XPath2ReturnedNd);
}

Aras.prototype.removeFormFromClientCache = function Aras_removeFormFromClientCache(itemID)
{
  var c = this.getCacheObject();
  //remove the cached form metadata (xml, it was recieved from server)
  delete c.Forms[itemID];
  //remove the cached forms (htmls, they were generated on client)
  delete this.commonProperties.formsCacheById[itemID+'_default'];
  delete this.commonProperties.formsCacheById[itemID+'_view'];
  delete this.commonProperties.formsCacheById[itemID+'_edit'];
  delete this.commonProperties.formsCacheById[itemID+'_print'];
  delete this.commonProperties.formsCacheById[itemID+'_add'];
}

Aras.prototype.clearSpecialClientCaches = function Aras_clearSpecialClientCaches(configurationNd)
{
  /*
  clears all special client caches.
  What cache to clear depends on the specified item.
  */
  if (!configurationNd) return false;
  
  var self = this;
  
  function clearSpecialClientCachesInternal(itemTypeName, itemID)
  {
    switch (itemTypeName)
    {
      case "Form":
        self.removeFormFromClientCache(itemID);
        break;
      
      case "ItemType":
        var instead_itemID = itemID + "_revisions_dlg";
        delete self.items2gridXSL[itemID];
        delete self.items2gridXSL[instead_itemID];
    
        self.commonProperties.formsCacheById = self.newObject();
    
        var varName_colOrder = 'IT_' + itemID + '_colOrder';
        var varName_colWidths= 'IT_' + itemID + '_colWidths';
        var varName_searchVis= 'IT_' + itemID + '_searchVis';
    
        self.removeVariable(varName_colOrder);
        self.removeVariable(varName_colWidths);
        self.removeVariable(varName_searchVis);
    
        varName_colOrder = "IT_" + instead_itemID + "_colOrder";
        varName_colWidths= "IT_" + instead_itemID + "_colWidths";
        varName_searchVis= "IT_" + instead_itemID + "_searchVis";
    
        self.removeVariable(varName_colOrder);
        self.removeVariable(varName_colWidths);
        self.removeVariable(varName_searchVis);
        
        for(var relId in cache.RelationshipTypes)
        {
          var rel = cache.RelationshipTypes[relId];
          if (!rel) continue;
          
          rel = rel.node;
          if (self.getItemProperty(rel, "source_id") == itemID ||
            self.getItemProperty(rel,  "related_id") == itemID ||
            self.getItemProperty(rel, "relationship_id") == itemID)
          {
            delete cache.RelationshipTypes[relId];//to escape redundant clearSpecialClientCachesInternal calls.
            clearSpecialClientCachesInternal("RelationshipType", relId);
          }
        }
        delete cache.ItemTypes.Dictionary[cache.ItemTypes.Names[itemID]];
        break;

      case "List":
        delete cache.Lists[itemID];
        break;

      case "RelationshipType":
        delete self.items2gridXSL[itemID];
        
        self.commonProperties.formsCacheById = self.newObject();
        
        var varName_colOrder = "RT_" + itemID + "_colOrder";
        var varName_colWidths= "RT_" + itemID + "_colWidths";
        var varName_searchVis= "RT_" + itemID + "_searchVis";
        
        self.removeVariable(varName_colOrder);
        self.removeVariable(varName_colWidths);
        self.removeVariable(varName_searchVis);
        
        var rel = cache.RelationshipTypes[itemID];
        if (rel)
        {
          delete cache.RelationshipTypes[itemID];
          
          rel = rel.node;
          var source_id  = self.getItemProperty(rel, "source_id");
          var related_id = self.getItemProperty(rel, "related_id");
          var relationship_id = self.getItemProperty(rel, "relationship_id");
          
          if (source_id) clearSpecialClientCachesInternal("ItemType", source_id);
          else cache.ItemTypes = self.newObject();
          
          if (related_id) clearSpecialClientCachesInternal("ItemType", related_id);
          if (relationship_id) clearSpecialClientCachesInternal("ItemType", relationship_id);
        }
        
        break;
    }
  }

  var itemNds = configurationNd.selectNodes("descendant-or-self::Item[@id and (@type='Form' or @type='ItemType' or @type='List' or @type='RelationshipType')]");
  var cache = this.getCacheObject();
  
  for (var i=0; i<itemNds.length; i++)
  {
    var itemNd = itemNds[i];
    var itemTypeName = itemNd.getAttribute("type");
    var itemID       = itemNd.getAttribute("id");
    
    clearSpecialClientCachesInternal(itemTypeName, itemID);
  }
  
  return true;
}

/*-- saveItemEx
 *
 *   Method to save an item
 *   id = the id for the item to be saved
 *
 */
Aras.prototype.saveItemEx = function Aras_saveItemEx(itemNd, confirmSuccess, doVersion)
{
  if (!itemNd) return null;
  if (confirmSuccess == undefined) confirmSuccess = true;
  if (doVersion == undefined) doVersion = false;

  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var oldItemTypeName;
  if (itemTypeName == "ItemType" && !this.isTempEx(itemNd)) oldItemTypeName = this.getItemTypeName(itemID);

  var res, win;

  win = this.uiFindWindowEx2(itemNd);
  
  //special checks for the item of ItemType type
  if (itemTypeName=='ItemType') res = this.checkItemType(itemNd, win);
  else res = true;
  
  if (!res) return null;
  
  //general checks for the item to be saved: all required parameters should be set
  if (itemTypeName) res = this.checkItem(itemNd, win);
  else res = true;
  
  if (!res) return null;
  res = null;

  //special checks for relationships and related items
  var newRelNodes = itemNd.selectNodes("Relationships/Item[@isDirty='1' or @isTemp='1']");
  var iter;
  for (iter=0; iter < newRelNodes.length; iter++)
  {
    if (!this.checkItem(newRelNodes[iter],win,"source_id")) return null;
  }
  
  var newRelatedNodes = itemNd.selectNodes("Relationships/Item/related_id/Item[@isDirty='1' or @isTemp='1']");
  for (iter=0; iter < newRelatedNodes.length; iter++)
    if (!this.checkItem(newRelatedNodes[iter],win,"source_id"))
      return null;
  
  this.checkFileProps(itemNd);
  
  var backupCopy = itemNd;
  var oldParent = backupCopy.parentNode;
  itemNd = itemNd.cloneNode(true);
  this.prepareItem4Save(itemNd);
  this.codeMd5Fields(itemNd);
    
  var isTemp = this.isTempEx(itemNd);
  
  if (isTemp)
  {
    itemNd.setAttribute('action', 'add');
    this.setItemProperty(itemNd, 'locked_by_id', this.getCurrentUserID());
    
    if (itemTypeName == 'RelationshipType')
    {
      if (!itemNd.selectSingleNode('relationship_id/Item'))
      {
        var rsItemNode = itemNd.selectSingleNode('relationship_id');
        if (rsItemNode)
        {
          var rs = this.getItemById('', rsItemNode.text, 0);
          if (rs)
          {
            rsItemNode.text = '';
            rsItemNode.appendChild(rs.cloneNode(true));
          }
        }
      }
      
      var tmp001 = itemNd.selectSingleNode('relationship_id/Item');
      if (tmp001 && this.getItemProperty(tmp001, 'name')=='')
      {
        this.setItemProperty(tmp001, 'name', this.getItemProperty(itemNd, 'name'));
      }
    }
  }
  else if (doVersion)
    itemNd.setAttribute('action', 'version');
  else
    itemNd.setAttribute('action', 'update');
  
  var tempArray = new Array();
  this.doCacheUpdate(true, itemNd, tempArray);
  
  var statusMsg = "";
  if (isTemp) statusMsg = '   Adding '+itemTypeName+'...';
  else if (doVersion) statusMsg = '   Versioning '+itemTypeName+'...';
  else statusMsg = '   Updating '+itemTypeName+'...';
  
  var res = this.applyItemWithFilesCheck(itemNd, win, statusMsg, this.XPathResult('/Item'));
  
  if (!res) return null;
  res.setAttribute('levels', '0');
  
  var newID = res.getAttribute('id');
  
  this.clearSpecialClientCaches(backupCopy);
  this.updateInCacheEx(backupCopy, res);
  
  var Cache   = this.getCacheObject();
  
  if (itemTypeName == "Preference")
  {
    var coreGlobal = itemNd.selectNodes("Relationships/Item[@type='Core_GlobalLayout' and @action]");
    if (coreGlobal && this.varsStorage && this.varsStorage.global)
    {
      var globalPrefObj = this.getPreference("Core_GlobalLayout", "0");
      if (globalPrefObj)
      {
        if(globalPrefObj.prefType == 1) // Site
        {
          var globalPref = this.newItem("Core_GlobalLayout");
          var sitePref = globalPrefObj.itemNode;
          var props = sitePref.selectNodes("*");
          for(var i=0; i < props.length; i++)
            globalPref.appendChild(props[i]);
        }
        else
        {
          var globalPref = globalPrefObj.itemNode;
          if(!globalPref) globalPref = globalPrefObj.itemNodes[0];
        }
        
        var oNodeList = this.varsStorage.global.childNodes;
        for (var i = 0; i < oNodeList.length; i++)
          this.varsStorage.global.removeChild(oNodeList.item(i));
          
        this.varsStorage.global.appendChild(globalPref);
      }
    }
  }
  else if (itemTypeName == 'RelationshipType')
  {
    var relationship_id = this.getItemProperty(itemNd, 'relationship_id');
    if (relationship_id) this.removeFromCache(relationship_id);
  }
  else if (itemTypeName == 'ItemType')
  {
    var item_name = (oldItemTypeName) ? oldItemTypeName : this.getItemProperty(itemNd, 'name');
    delete this.sGridsSetups[item_name];
    delete Cache.ItemTypes.Dictionary[item_name];
    
    if (Cache.ItemTypes.Names[itemID])  Cache.ItemTypes.Names[itemID] = null;
    if (Cache.ItemTypes.Ids[item_name]) Cache.ItemTypes.Ids[item_name] = null;

    // remove cached items
    if (item_name)
    {
      var oldNodes = this.dom.selectNodes("//Item[@type='"+item_name+"']");
      for(var i = 0; i < oldNodes.length; i++)
      {
        var oldNode = oldNodes[i];
        //issue  IR-005701 
        //  Runtime error doing a Save, Unlock and Close
        //  some  time super user  can edit ItemType item
        //  this  block  of  code  surpress  to  remove item  itself
        var ItemType = oldNode.selectSingleNode("self::Item[name='ItemType']");
        if(ItemType!=null&&item_name=='ItemType')
          continue;
        oldNode.parentNode.removeChild(oldNode);
      }
    }
  }
  
  if (oldParent)
  {
    var tmpRes = oldParent.selectSingleNode('Item[@id="'+newID+'"]');
    if (tmpRes == null && newID != itemID && oldParent.selectSingleNode('Item[@id="'+itemID+'"]') != null)
    {
      //possible when related item is versionable and relationship behavior is fixed
      //when relationship still points to previous generation.
      tmpRes = this.getFromCache(newID);
      this.updateInCacheEx(tmpRes, res);
      res = this.getFromCache(newID);
    }
    else
      res = tmpRes;
  }
  else
    res = this.getFromCache(newID);

  if (!res) return null;
  
  this.doCacheUpdate(false,itemNd, tempArray);
  
  if (confirmSuccess) this.AlertSuccess('Item saved successfully.',win);
  
  var params = this.newObject();
  params.itemID = itemID;
  params.itemNd = res;
  this.fireEvent("ItemSave", params);
  
  return res;
}

Aras.prototype.doCacheUpdate = function Aras_doCacheUpdate(prepare, itemNd, tempArray) {
  var nodes;
  if (prepare) {
    nodes = itemNd.selectNodes("descendant-or-self::Item[@id and (@action=\"add\" or @action=\"create\")]");
    for (var i=0;i<nodes.length;i++) {
      tempArray.push(new Array(nodes[i].getAttribute("id"),nodes[i].getAttribute("type")));
    }
  } else {
    for (var i=0;i<tempArray.length;i++) {
      nodes = this.dom.selectNodes("/Innovator/Items//Item[@id=\""+tempArray[i][0]+"\" and (@action=\"add\" or @action=\"create\")]");
      for (var o=0;o<nodes.length;o++) {
        nodes[o].setAttribute("action","skip");
        nodes[o].removeAttribute("isTemp");
        nodes[o].removeAttribute("isDirty");
      }
      if (i==0) continue;
      var itemID = tempArray[i][0];
    }
  }
}

Aras.prototype.setFileNameInVaultWithPathCheck = function Aras_setFileNameInVaultWithPathCheck(download_path, filename, doAlert)
{
  if (!download_path || !filename) return null;
  if (download_path.length + filename.length > 260-2)
  {
    if (doAlert || doAlert === undefined) this.AlertError("The file cannot be saved to the current working directory, because the file path is greater than 260 characters.");
    return null;
  }
  var vault = this.vault;
  if (!vault) return null;
  return vault.setFileName(filename);
}

Aras.prototype.downloadPhysicalFile = function Aras_downloadPhysicalFile(fileNd, download_path, win) {
/*
this method is for internal use *** only ***
*/
  var filename = this.getItemProperty(fileNd, "filename");
  //if (!filename) filename = fileNd.getAttribute("keyed_name");
  
  var vault = this.vault;
  
  //check if file with such name already exist in directory <download_path>
  vault.setWorkingDir(download_path);
  var tmpRes = this.setFileNameInVaultWithPathCheck(download_path, filename);
  if (tmpRes)
  {
    var param = new Object();
    param.buttons = new Object();
    param.buttons.btnYes = "Yes";
    param.buttons.btnNo  = "No";
    param.defaultButton  = "btnNo";
    param.message = download_path + "\\" + filename + " already exists. Do you want to replace it?";
    
    var res = win.showModalDialog(this.getScriptsURL()+"groupChgsDialog.html", param, "dialogHeight:150px;dialogWidth:350px;center:yes;resizable:no;status:no;help:no;");
    if (res == "btnNo") return false
  }
  else if (tmpRes === null)
  {
    return false;
  }
  //---
  
  var fileURL = this.getFileURLEx(fileNd);
  if (fileURL == "") {
    this.AlertError("Failed to download the file. The file URL is empty.");
    return false;
  }
  
  vault.clearClientData();
  vault.clearFileList();
  
  vault.setClientData("SOAPACTION", "GetFile");
  vault.setClientData('DATABASE',this.getDatabase());
  vault.setClientData('AUTHUSER',this.getLoginName());
  vault.setClientData('AUTHPASSWORD',this.getPassword());
  
  vault.setWorkingDir(download_path);
  vault.setLocalFileName(filename);
  
  var res = vault.downloadFile(fileURL);
  if (!res) {
    this.AlertError("Failed to download the file \"" + filename + "\" into " + download_path, "", "", win);
    return false;
  }
  
  return res;
}

/*-- lockItemEx
 *
 *   Method to lock the item passing the item object
 *   itemNd = the item
 *
 */
Aras.prototype.lockItemEx = function Aras_lockItemEx(itemNd, checkedout_path, confirmCheckOut)
{
  if (confirmCheckOut == undefined) confirmCheckOut = true;
  var oldParent = itemNd.parentNode;
  var win = this.uiFindWindowEx2(itemNd);

  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');

  var itemType = this.getItemTypeDictionary(itemTypeName);
  var is_relationship = this.getItemProperty(itemType.node, "is_relationship");

  if ( is_relationship == "1" && this.isDirtyEx(itemNd))
  {
    var sourceNd = itemNd.selectSingleNode("../..");

    if (sourceNd && this.isDirtyEx(sourceNd))
    {
      var itLabel = this.getItemProperty(itemType.node, "label");
      if (itLabel == "") itLabel = this.getItemProperty(itemType.node, "name");

      var param = new Object();
      param.buttons = new Object();
      param.buttons.btnOK = "OK";
      param.buttons.btnCancel  = "Cancel";
      param.defaultButton  = "btnCancel";

      param.message =
      "Locking this " + itLabel + " will cause you<br>to lose your changes in the source item.<br><br>" +
      "Click OK to lock the item and lose your changes<br>or Cancel to leave the item unlocked.";

      var res = win.showModalDialog(this.getScriptsURL()+"groupChgsDialog.html", param, "dialogHeight:150px;dialogWidth:300px;center:yes;resizable:no;status:no;help:no;");

      if (res == "btnCancel") return null;
    }
  }

  var bodyStr;
  var statusId;
  
  with (this)
  {
    if (itemTypeName == 'File')
    {
      if (checkedout_path == undefined) checkedout_path = this.getWorkingDir(true, win);
      else if (!this.vault.setWorkingDir(checkedout_path))
      {
        this.AlertError('The path you specified for file check out invalid. Trying to use working directory instead.', "", "", win);
        checkedout_path = this.getWorkingDir(true, win);
      }
      
      var res = this.downloadPhysicalFile(itemNd, checkedout_path, win);
      if (!res) return null;
      
      statusId = this.showStatusMessage(0, '   Check File out to '+checkedout_path+' ...', system_progressbar1_gif);
      bodyStr = "<Item type='File' id='" + itemID + "' action='lock'><checkedout_path><![CDATA["+checkedout_path+"]]></checkedout_path></Item>";
    }
    else
    {
      statusId = showStatusMessage(0, '   Locking '+itemTypeName+' ...', system_progressbar1_gif);
      bodyStr = "<Item type='" + itemTypeName + "' id='" + itemID + "' action='lock' />";
    }
    
    var res = soapSend('ApplyItem', bodyStr);
    clearStatusMessage(statusId);

    if (res.getFaultCode() != 0)
    {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor(), win);
      return null;
    }

    var item2  = res.results.selectSingleNode(top.aras.XPathResult('/Item'));
    if (!item2)
    {
      top.aras.AlertError('Failed to get the '+itemTypeName+' ItemType from the Server.', "", "", win);
      return null;
    }
    
    if (itemTypeName == 'File')
    {
      if (checkedout_path.search(/\\$/)==-1) checkedout_path += '\\';
      
      var filename = this.getItemProperty(itemNd, 'filename');
    }

    updateInCacheEx(itemNd, item2);

    if (itemTypeName != "File")
    {
      var itemTypeName = item2.getAttribute('type');
      if(itemTypeName=='File') return null; // do not check Files to prevent recursion

      var itemType  = this.getItemTypeForClient(itemTypeName).node;
      var fileProps = this.getPropertiesOfTypeFile(itemType);

      var flg = false;
      if (fileProps.length > 0)
      {
        for (var i=0; i<fileProps.length; i++)
        {
          var propNm  = getItemProperty(fileProps[i], 'name');
          var propVal = getItemProperty(item2, propNm);
          if (propVal)
          {
            if (!confirmCheckOut)  flg = true;
            else
            {
              var param = new Object();
              param.buttons = new Object();
              param.buttons.btnYes = 'Yes';
              param.buttons.btnNo  = 'No';
              param.defaultButton  = 'btnYes';
              param.message = '<br>Do you want to checkout the files?';

              var res = win.showModalDialog(this.getScriptsURL()+'groupChgsDialog.html', param, 'dialogHeight:100px;dialogWidth:200px;center:yes;resizable:no;status:no;help:no;');
              if (res == 'btnYes') flg = true;
              break;
            }
          }
        }

        if (flg)
        {
          if (!checkoutFiles(item2, checkedout_path))
          top.aras.AlertError('Checkout not completed.');
          else top.aras.AlertSuccess('Checkout completed.');
        }
      }
    }

    if (oldParent)
    {
      itemNd = oldParent.selectSingleNode('Item[@id="'+itemID+'"]');
      if (!itemNd)
        itemNd = oldParent.selectSingleNode('Item');
    }
    else itemNd = getFromCache(itemID);

    var params = this.newObject();
    params.itemID = itemNd.getAttribute("id");
    params.itemNd = itemNd;
    params.newLockedValue = this.isLocked(itemNd);
    this.fireEvent("ItemLock", params);

    return itemNd;
  }//with (this)
}

/*-- unlockItemEx
 *
 *   Method to unlock the item passing the item object
 *   itemNd = the item
 *
 */
Aras.prototype.unlockItemEx = function Aras_unlockItemEx(itemNd, saveChanges) {
  with (this) {
    var itemID = itemNd.getAttribute('id');
    var itemTypeName = itemNd.getAttribute('type');
    var win = this.uiFindWindowEx2(itemNd);

    if (isTempEx(itemNd)) {
      top.aras.AlertError('Failed to unlock the '+itemTypeName+' ItemType.', "", "", win);
      return null;
    }    
    checkFileProps(itemNd);

    if (saveChanges == undefined) {
      var isDirty = isDirtyEx(itemNd);
      if (!isDirty && itemTypeName == 'File') isDirty = hasFileChanged(itemNd);
      if (isDirty) {
        var param = new Object();
        param.buttons = new Object();
        param.buttons.btnYes = 'Yes';
        param.buttons.btnSaveAndUnlock = 'Save First';
        param.buttons.btnCancel = 'Cancel';
        param.defaultButton = 'btnCancel';

        param.message = 'Unlocking '+itemTypeName+' "'+getKeyedNameEx(itemNd)+'" will discard all your changes.\n'+
        'Are you sure ?';
        var res = win.showModalDialog(this.getScriptsURL()+'groupChgsDialog.html', param,  'dialogHeight:200px;dialogWidth:400px;center:yes;resizable:no;status:no;help:no;');
        if (res == 'btnCancel') return null;
        else if (res == 'btnYes') saveChanges = false;
        else saveChanges = true;
      }
    }

    if (saveChanges) {
      itemNd = saveItemEx(itemNd);
      if (!itemNd) return null;
    }

    var statusId = showStatusMessage(0, '   Unlocking '+itemTypeName+' ...', system_progressbar1_gif);
    itemID = itemNd.getAttribute('id');
    var lockedById = itemNd.selectSingleNode('locked_by_id');
    var res;
    if (!lockedById) {
      res = soapSend('ApplyItem', "<Item type='" + itemTypeName + "' id='" + itemID + "' action='get' />");
    }
    else res = soapSend('ApplyItem', "<Item type='" + itemTypeName + "' id='" + itemID + "' action='unlock' />", '', saveChanges);
    clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor(), win);
      return null;
    }
    res = res.results.selectSingleNode(top.aras.XPathResult('/Item'));
    if (!res) {
      top.aras.AlertError('Failed to get the '+itemTypeName+' ItemType from the Server.', "", "", win);
      return null;
    }

    var oldParent = itemNd.parentNode;
    updateInCacheEx(itemNd, res);
    updateFilesInCache(res);

    var newRes = null;
    if (oldParent) newRes = oldParent.selectSingleNode('Item[@id="'+itemID+'"]');
    else newRes = getFromCache(itemID);

    if (newRes) res = newRes;

    var params = this.newObject();
    params.itemID = res.getAttribute("id");
    params.itemNd = res;
    params.newLockedValue = this.isLocked(res);
    this.fireEvent("ItemLock", params);

    return res;
  }//with (this)
}

Aras.prototype.updateFilesInCache = function Aras_updateFilesInCache(itemNd)
{

  var itemTypeName = itemNd.getAttribute('type');
  if(itemTypeName=='File') return; // do not check Files to prevent recursion
  var itemType  = this.getItemTypeForClient(itemTypeName).node;
  var fileProps = this.getPropertiesOfTypeFile(itemType);

  with(this)
  {
    for(var i = 0;i<fileProps.length;i++)
    {
      var propNm = getItemProperty(fileProps[i],'name');
      var fileID = getItemProperty(itemNd,propNm);

      if(fileID)
      {
        removeFromCache(fileID);

        var qry = new top.Item();
        qry.setType('File');
        qry.setAction('get');
        qry.setID(fileID);
        qry.setAttribute('select','filename,file_size,file_type,checkedout_path,comments,checksum,label,mimetype');

        var results = qry.apply();

        if(results.isEmpty())
        {
          return false;
        }

        if(results.isError())
        {
          top.aras.AlertError(results.getErrorDetail());
          return false;
        }

        var file = results.getItemByIndex(0).node;
        updateInCache(file);
      }
    }
  }
}

Aras.prototype.purgeItemEx = function Aras_purgeItemEx(itemNd, silentMode) {
/*-- purgeItem
 *
 *   Method to delete the latest version of the item (or the item if it's not versionable)
 *   itemNd - 
 *   silentMode - flag to know if user confirmation is NOT needed
 *
 */
  
  return this.PurgeAndDeleteItem_CommonPartEx(itemNd, silentMode, "purge");
}

Aras.prototype.deleteItemEx = function Aras_deleteItemEx(itemNd, silentMode) {
/*-- deleteItem
 *
 *   Method to delete all versions of the item
 *   itemNd - 
 *   silentMode - flag to know if user confirmation is NOT needed
 *
 */
  
  return this.PurgeAndDeleteItem_CommonPartEx(itemNd, silentMode, "delete");
}

Aras.prototype.PurgeAndDeleteItem_CommonPartEx = function Aras_PurgeAndDeleteItem_CommonPartEx(itemNd, silentMode, purgeORdelete) {
/*-- PurgeAndDeleteItem_CommonPartEx
 *
 *   This method is for ***internal purposes only***.
 *
 */
  
  if (silentMode === undefined) silentMode = false;
  
  var ItemId = itemNd.getAttribute("id");
  var ItemTypeName = itemNd.getAttribute("type");
  
  //prepare
  if ( !silentMode ) {
    if ( !this.Confirm_PurgeAndDeleteItem(ItemId, this.getKeyedNameEx(itemNd), purgeORdelete) ) return false;
  }
  
  var DeletedItemTypeName;
  var relationship_id;
  if ( !this.isTempEx(itemNd) ) {
    //save some information
    if (ItemTypeName == "ItemType") {
      if ( this.getItemProperty(itemNd, "is_relationship") == "1" ) {
        relationship_id = ItemId;
      }
      DeletedItemTypeName = this.getItemProperty(itemNd, "name");
    }
    else if (ItemTypeName == "RelationshipType") {
      relationship_id = this.getItemProperty(itemNd, "relationship_id");
      DeletedItemTypeName = this.getItemProperty(itemNd, "name");
    }
    
    //delete
    if ( !this.SendSoap_PurgeAndDeleteItem(ItemTypeName, ItemId, purgeORdelete) ) return false;
  }
  
  itemNd.setAttribute("action", "skip");
  
  //remove node from parent
  var tmpNd = itemNd.parentNode;
  if (tmpNd) tmpNd.removeChild(itemNd);
  
  //delete all dependent stuff
  this.RemoveGarbage_PurgeAndDeleteItem(ItemTypeName, ItemId, DeletedItemTypeName, relationship_id);
  
  return true;
}

Aras.prototype.getKeyedNameEx = function Aras_getKeyedNameEx(itemNd) {
/*----------------------------------------
 * getKeyedNameEx
 *
 * Purpose: build and return keyed name of an Item.
 *
 * Arguments:
 * itemNd - xml node of Item to get keyed name of.
 */

  with (this) {
    var res = '';
    if (itemNd.nodeName != "Item") return res;

    if ((!isDirtyEx(itemNd)) && (!isTempEx(itemNd))) {
      res = itemNd.getAttribute('keyed_name');
      if (res) return res;
      res = this.getItemProperty(itemNd, 'keyed_name');
      if (res!='') return res;
    }

    var itemTypeName = itemNd.getAttribute('type');
    res = itemNd.getAttribute('id');

    var itemType = getItemTypeDictionary(itemTypeName);
    if (!itemType) return res;

    var relationshipItems  = itemType.node.selectNodes('Relationships/Item[@type="Property"]');
    var tmpArr  = new Array();//pairs keyOrder -> propValue
    var counter = 0;
    for (var i=0; i<relationshipItems.length; i++) {
      var propNd   = relationshipItems[i];
      var propName = getItemProperty(propNd, 'name');
      if (propName == '') continue;

      var keyOrder = getItemProperty(propNd, 'keyed_name_order');
      if (keyOrder == '') continue;

      var node = itemNd.selectSingleNode(propName);
      if (!node || node.childNodes.length != 1) continue;

      var txt = "";
      if (node.firstChild.nodeType == 1) {//if nested Item
        txt = getKeyedNameEx(node.firstChild);
      }
      else txt = node.text;

      if (txt != '') {
        tmpArr[counter] = new Array(keyOrder, txt);
        counter++;
      }
    }

    if (tmpArr.length > 0) {
      tmpArr = tmpArr.sort( keyedNameSorter );
      res = tmpArr[0][1];
      for (var i = 1; i < tmpArr.length; i++) {
        res +=  ' ' + tmpArr[i][1];
      }
    }

    return res;
  } //with this
}

Aras.prototype.getKeyedNameAttribute = function(node, element) {
  if (! node) return;
  var value;
    var tmpNd = node.selectSingleNode(element);
    if (tmpNd) {
      value = tmpNd.getAttribute('keyed_name');
      if (!value) value = '';
    }
    else value = '';
  return value;
}

function keyedNameSorter(a, b) {
  var s1 = parseInt(a[0]);
  if (isNaN(s1)) return 1;
  var s2 = parseInt(b[0]);
  if (isNaN(s2)) return -1;

  if (s1<s2) return -1;
  else if (s1==s2) return 0;
  else return 1;
}

/*-- getItemRelationshipsEx
 *
 *   Method to
 *
 *
*/
Aras.prototype.getItemRelationshipsEx = function(itemNd, relsName, pageSize, page, body) {
  if ( !(itemNd && relsName) ) return null;
  if (pageSize == undefined) pagesize = '';
  if (page == undefined) page = '';
  if (body == undefined) body = '';

  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var res = null;
  with (this) {
    if ( pageSize == -1 || isTempID(itemID)
      || (itemNd.getAttribute('levels') && parseInt(itemNd.getAttribute('levels')) > 0) ) {
      if (!isNaN(parseInt(pageSize)) && parseInt(pageSize)>0 && !isNaN(parseInt(page)) && parseInt(page)>-1) {
        res = itemNd.selectNodes('Relationships/Item[@type="'+relsName+'" and @page="'+page+'"]');
        if (res && res.length==pageSize) return res;
      }
      else {
        res = itemNd.selectNodes('Relationships/Item[@type="'+relsName+'"]');
        if (res && res.length>0) return res;
      }
    }

    var bodyStr = '<Item type="'+itemTypeName+'" id="'+itemID+'" relName="'+relsName+'" action="getItemRelationships"';
    if (pageSize) bodyStr += ' pageSize="'+pageSize+'"';
    if (page)     bodyStr += ' page="'+page+'"';
    if (body=='') bodyStr += '/>';
    else bodyStr +='>'+body+'</Item>';

    var res = soapSend('ApplyItem', bodyStr);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return null;
    }

    if (!itemNd.selectSingleNode('Relationships')) itemNd.appendChild(dom.createElement('Relationships'));
    var rels = res.results.selectNodes(top.aras.XPathResult('/Item[@type="'+relsName+'"]'));
    var itemRels = itemNd.selectSingleNode('Relationships');
    var idsStr = '';
    for (var i=0; i<rels.length; i++) {
      var rel = rels[i].cloneNode(true);
      var relId = rel.getAttribute('id');
      if (i > 0) idsStr += ' or ';
      idsStr += '@id="'+relId+'"';
      var prevRel = itemRels.selectSingleNode('Item[@type="'+relsName+'" and @id="'+relId+'"]');
      if (prevRel) {
        var page_ = rel.getAttribute('page');
        var pagemax_= rel.getAttribute('pagemax');
        if (page_ != null) {
          if (page_ == '') page_ = '1';
          prevRel.setAttribute('page', page_);
        }
        else prevRel.removeAttribute('page');
        if (pagemax_ != null) {
          if (pagemax_ == '') pagemax_ = '1';
          prevRel.setAttribute('pagemax', pagemax_);
        }
        else prevRel.removeAttribute('pagemax');
        continue;
      }
      itemRels.appendChild(rel);
    }
    itemNd.setAttribute('levels', '0');
    if (idsStr=='') return null;
    res = itemRels.selectNodes('Item[@type="'+relsName+'" and ('+idsStr+')]');
  }//with (this)

  return res;
}

/*-- getItemLastVersionEx
 *
 *   Method to load the latest version for the item
 *   itemTypeName = the ItemType name
 *   itemId       = the id for the item
 *
 */
Aras.prototype.getItemLastVersionEx = function(itemNd) {
  with (this) {
    var res = soapSend('ApplyItem', '<Item type="'+itemNd.getAttribute('type')+'" id="' + itemNd.getAttribute('id') + '" action="getItemLastVersion" />');

    if (res.getFaultCode() != 0) return null;

    res = res.results.selectSingleNode(top.aras.XPathResult('/Item'));
    if (!res) return null;

    itemNd.parentNode.replaceChild(res, itemNd);

    return res;
  }
}//getItemLastVersionEx

Aras.prototype.checkinFile = function Aras_checkinFile(fileNd, win) {
/*
this method is for internal use *** only ***
*/
  if (this.isTempEx(fileNd)) return null;
  if (!this.isLockedByUser(fileNd)) return null;
  
  fileNd.setAttribute('action', 'update');
  fileNd.setAttribute('version', '0');
  
  var updatedFile = this.sendFilesWithVaultApplet(fileNd, '   Checking File in...');
  if (!updatedFile) return null;
  
  var oldParent = fileNd.parentNode;
  this.updateInCacheEx(fileNd, updatedFile);
  
  if (oldParent) {
    updatedFile = oldParent.selectSingleNode('Item[@id="'+updatedFile.getAttribute('id')+'"]');
    oldParent.setAttribute('keyed_name', this.getItemProperty(updatedFile, "keyed_name"));
  }
  else updatedFile = this.getFromCache(updatedFile.getAttribute('id'));
  
  return updatedFile;
}

Aras.prototype.checkoutFiles = function Aras_checkoutFiles(itemNd, checkedout_path) {
/*
this method is for internal use *** only ***
*/
  if (!itemNd) return false;
  
  var success = true;
  var win = this.uiFindWindowEx2(itemNd);
  
  var itemTypeName = itemNd.getAttribute('type');
  if (itemTypeName=='File') return; // do not check Files to prevent recursion
  var itemType  = this.getItemTypeForClient(itemTypeName).node;
  var fileProps = this.getPropertiesOfTypeFile(itemType);
  var vault = this.vault;
  
  for (var i=0; i<fileProps.length; i++) {
    var propNm = this.getItemProperty(fileProps[i],'name');
    var fileNode = itemNd.selectSingleNode(propNm);
    if (!fileNode) continue;
    
    var fileNd = itemNd.selectSingleNode(propNm+'/Item');
    if (!fileNd) {
      var fileID = this.getItemProperty(itemNd, propNm);
      if (!fileID) continue;
      
      fileNd = this.getItemById('File', fileID, 0);
      if (!fileNd) {
        success = false;
        continue;
      }
    }
    
    if (this.isLockedByUser(fileNd)) {
      var res = this.downloadPhysicalFile(fileNd, checkedout_path, win);
      
      if (!res) {
        success = false;
        continue;
      }
    }
    else if (!this.lockItemEx(fileNd, checkedout_path)) {
      success = false;
      continue;
    }
  }
  
  return success; //because of issue IR-004174
}

Aras.prototype.downloadItemFiles = function Aras_downloadItemFiles(itemNd, localPath) {
/*
this method is for internal use *** only ***
*/
  if(!itemNd) return false;

  var itemTypeName = itemNd.getAttribute('type');
  var itemType  = this.getItemTypeForClient(itemTypeName).node;
  var fileProps = this.getPropertiesOfTypeFile(itemType);
  
  for (var i=0; i<fileProps.length; i++) {
    var propNm = this.getItemProperty(fileProps[i],'name');
    var fileNd = itemNd.selectSingleNode(propNm+'/Item');
    if (!fileNd) {
      var fileID = this.getItemProperty(itemNd,propNm);
      if(!fileID) continue;
      
      fileNd = this.getItemFromServerWithRels('File',fileID,'filename',
                                           'Located','related_id(vault_url)').node;
    }
    
    if(!fileNd) continue;
    
    var res = this.downloadPhysicalFile(fileNd, localPath, window);
    
    if (!res) continue;
  }
  
  return true;
}

Aras.prototype.undoCheckOut = function Aras_undoCheckOut(itemNd) {
/*
this method is for internal use *** only ***
*/
  if (!itemNd) return false;
  
  var itemTypeName = itemNd.getAttribute('type');
  var itemType  = this.getItemTypeForClient(itemTypeName).node;
  var fileProps = this.getPropertiesOfTypeFile(itemType);
  
  var res;
  for (var i=0; i<fileProps.length; i++) {
    var propNm = this.getItemProperty(fileProps[i],'name');
    var fileNd = itemNd.selectSingleNode(propNm+'/Item');
    if (fileNd) {
      if (!this.isLockedByUser(fileNd)) continue;
      res = this.unlockItemEx(fileNd,false);
    }
    else {
      var fileID = this.getItemProperty(itemNd,propNm);
      if (!fileID) continue;
      
      fileNd = this.getItemById('File',fileID,0);
      if (!fileNd || !this.isLockedByUser(fileNd)) continue;
      res = this.unlockItemEx(fileNd,false);
    }
  }
  
  if (itemTypeName == "File") return res;//to fix "undo checkout" for related item if related item is File
}

Aras.prototype.promoteEx = function Aras_promoteEx(itemNd, stateName, comments, soapController)
{
  if (!itemNd) return null;
  
  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');

  var promoteParams =
    {
      typeName: itemTypeName,
      id: itemID,
      stateName: stateName,
      comments: comments
    };
  
  var res = this.promoteItem_implementation(promoteParams, soapController);
  if (!res) return null;
  
  var oldParent = itemNd.parentNode;
  this.updateInCacheEx(itemNd, res);
  
  if (oldParent) res = oldParent.selectSingleNode('Item[@id="'+itemID+'"]');
  else res = this.getFromCache(itemID);
  
  var params = this.newObject();
  params.itemID = res.getAttribute("id");
  params.itemNd = res;
  this.fireEvent("ItemSave", params);
  
  return res;
}

Aras.prototype.getFileURLEx = function Aras_getFileURLEx(itemNd) {
/*----------------------------------------
 * getFileURLEx
 *
 * Purpose:
 * get file URL using default User's Vault
 *
 * Arguments:
 * itemNd - xml node of the File to be downloaded
 *
 */
  this.getItemRelationshipsEx(itemNd, "Located");
  var locatedNd = itemNd.selectSingleNode('Relationships/Item[@type="Located"]');

  if (locatedNd == null) {
   this.AlertError("Failed to get the File: Vault could not be located.");
   return '';}

  var vaultNode = locatedNd.selectSingleNode('related_id/Item[@type="Vault"]');
  if (!vaultNode) {
  var related_id = locatedNd.selectSingleNode('related_id').text;
  vaultNode = this.getItemById('Vault', related_id, 0)
  }

  var vaultServerURL = vaultNode.selectSingleNode('vault_url').text;
  if (vaultServerURL == '') return '';

  vaultServerURL = top.aras.TransformVaultServerURL(vaultServerURL);

  var fileID  = itemNd.getAttribute('id');
  var fileName= this.getItemProperty(itemNd, 'filename');
  var fileURL = vaultServerURL + 
                '?dbName=' + escape(this.getDatabase()) +
                '&fileID=' + escape(fileID) +
                '&fileName=' + escape_fileName(fileName);

  return fileURL;
}
function escape_fileName(f)
{
  var r="";
  var l=f.length;
  for(var i=0; i<l; i++) {
    var c=f.charCodeAt(i);
    if(c<128) { 
      if (f.charAt(i) == "+") r+="%2B";
      else r+=escape(f.charAt(i));
    }
    else r+="%u"+bb2hex(c);
  }
  return r;
}
function bb2hex(c) // 2 bytes only
{
  var arr="0123456789ABCDEF"
  return arr.charAt(c>>12 & 0xF)+arr.charAt(c>>8 & 0xF)+arr.charAt(c>>4 & 0xF)+arr.charAt(c & 0xF);
}