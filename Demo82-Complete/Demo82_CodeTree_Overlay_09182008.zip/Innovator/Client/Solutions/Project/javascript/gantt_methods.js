﻿var GanttXml=null;
var GanttWnd=null;

//+++ PREFERENCES
var columns = []; // hash : [column index] -> [_column object], column order position starts from 0
// --- PREFERENCES

var fldToCol = {}; // hash : [colId] -> [column index]
var fld = {}; // hash : [column name] -> [column order in initXML, also is colId]
/* default values:
fld['tree_node'] = 0;
fld['n'] = 1;
fld['predecessor'] = 2;
fld['status'] = 3;
fld['leader'] = 4;
fld['plan_start'] = 5;
fld['plan_finish'] = 6;
fld['duration'] = 7;
fld['hours'] = 8;
fld['role'] = 9;
fld['attach'] = 10;
*/

var wbsRowType = "wbs";
var actRowType = "act";
var milRowType = "mil";
var stylesFileBase = top.aras.getScriptsURL() + "../Solutions/Project/styles/";
var xmlFileBase = top.aras.getScriptsURL() + "../Solutions/Project/xml/";

var uniCache = {identities:{},queryDom:null,xsltWbs:null,xsltWbsBranch:null};

function showGanttInternal(wbs, projectNumber)
{
  var cancelled = false;
  if(GanttWnd != null && !top.aras.isWindowClosed(GanttWnd))
  {
    GanttWnd.focus();
    cancelled = !GanttWnd.confirm("Do you want to close this chart window and open a new one?");
    if(!cancelled) GanttWnd.close();
  }

  GanttXml = generateGanttXml(wbs);

  if(!cancelled) GanttWnd = window.open(top.aras.getScriptsURL() + "../Solutions/Project/scripts/Gantt.html#"+projectNumber, "Gantt"+projectNumber, "width=800, height=400, resizable=yes", true);
}


function generateGanttXml(wbsNode)
{
  var xslFile=top.aras.getScriptsURL()+"../Solutions/Project/styles/gantt.xsl";
  var resultNode = top.aras.createXMLDocument();
  resultNode.loadXML(wbsNode.xml);
  fillNumAndPredecessor(resultNode);
  var xml=top.aras.applyXsltFile(resultNode, xslFile);

  resultNode.loadXML(xml);
  if (window.convertDateStr && window.getDatePropertyPattern)
  {
/*we know that resultNode contains the following xml:
<project>
  <input-date-format>MM/dd/yyyy</input-date-format>
  <xsl:template mode="getAct" match="Item[@type='Activity2']">
    <task>
      <start-date><xsl:value-of select="date_start_sched"/></start-date>
      <end-date><xsl:value-of select="date_due_sched"/></end-date>
    </task>
  </xsl:template>
</project>
we have to convert start-date and end-date values into input-date-format.
*/
    var type = "Activity2";
    var newDateFormat = resultNode.selectSingleNode("/project/input-date-format").text;
    var startDateFormat = getDatePropertyPattern(type, "date_start_sched");
    var startDateNds = resultNode.selectNodes("/project//task/start-date");
    for (var i=0; i<startDateNds.length; i++)
    {
      var startDateNd = startDateNds[i];
      startDateNd.text = convertDateStr(startDateNd.text, startDateFormat, newDateFormat);
    }
    
    var endDateFormat = getDatePropertyPattern(type, "date_due_sched");
    var endDateNds = resultNode.selectNodes("/project//task/end-date");
    for (var i=0; i<endDateNds.length; i++)
    {
      var endDateNd = endDateNds[i];
      endDateNd.text = convertDateStr(endDateNd.text, endDateFormat, newDateFormat);
    }
  }

  processPredecessors(resultNode.documentElement, "//wbs/task/predecessor[.!='']");

  var xsltString = uniCache.xsltWbs;
  
  if (!xsltString)
  {
    xsltString = generateXSLT("Project").xsltWbs;
    uniCache.xsltWbs = xsltString;
  }
  
  var treeNode = top.aras.createXMLDocument();
  treeNode.loadXML(wbsNode.xml);

  //Clean empty Relationships
  var emptyRels = treeNode.selectNodes("descendant::Relationships[not(*)]");
  for(var i=0; i < emptyRels.length; i++)
    emptyRels[i].parentNode.removeChild(emptyRels[i]);

  var xml2 = top.aras.applyXsltString(treeNode, xsltString);
  treeNode.loadXML(xml2);
  processPredecessors(treeNode.documentElement);
  processNfields(treeNode.documentElement);
  
  resultNode.documentElement.appendChild(treeNode.documentElement.cloneNode(true));  //appended to "project/table"

  // Remove input_row from tree xml.
  var tableNode = resultNode.selectSingleNode("/project/table");
  tableNode.setAttribute("editable", false);
  tableNode.removeChild(tableNode.selectSingleNode("inputrow"));
  tableNode.setAttribute("EXPANDALL", "true");

  return resultNode;
}

function fillNumAndPredecessor(node)
{
  var act = node.selectNodes('//Item[@type= "Activity2" and not(@action= "delete")]');
  for(var i=0; i<act.length; ++i)
  {
    var a = act(i);
    var id = a.getAttribute('id');
    a.setAttribute('num', getActNum(id));
    var pred = getPredecessors(id);
    if(pred && pred.length)
    {
      var p = "";
      for(var j=0; j<pred.length; ++j) p+= ", "+getActNum(pred[j]);
      a.setAttribute('predecessor',p.substring(1));
    }
    a = null;
  }
  act = null;
}

function getPredecessors(id,excludeIds)
{
  var excludeCond = "";
  if(excludeIds && excludeIds.length)
  {
    for(var i=0;i<excludeIds.length;i++)
    {
      excludeId = excludeIds[i];
      excludeCond += "[related_id!='" + excludeId + "']";
    }
  }

  var predsArr = new Array();
  var activity2 = wbs.selectSingleNode("descendant::Item[@type='WBS Activity2' and not(@action='delete')]/related_id/Item[@type='Activity2' and @id='" + id + "']");
  if(!activity2)
  {
    if(queryCache.links.to[id]) var res = queryCache.links.to[id];
    else
    {
      var queryXml = '<Item type= "Activity2" id= "' + id + '" select= "id" action= "get">'+
                     '  <Relationships>'+
                     '    <Item type= "Predecessor" select= "related_id" related_expand= "0"/>'+
                     '  </Relationships>'+
                     '</Item>';

      var qry = new top.Item();
      qry.loadAML(queryXml);
      var results = qry.apply();
      if(!results.isError()) var res = results.getItemByIndex(0).node;
      if(!res) { top.aras.AlertError("Error 777:\n\nCan not find Activity2 with ID='" + id + "'."); return; }
      queryCache.links.to[id] = res;
    }
    activity2 = res;
  }

  var preds = activity2.selectNodes("Relationships/Item[@type='Predecessor'][not(@action='delete')]" + excludeCond);
  for(var i=0;i<preds.length;i++)
  {
    var pred = preds[i];
    var related_id = top.aras.getItemProperty(pred, "related_id");
    predsArr.push(related_id);
  }

  return predsArr;
}

function initColumns2(RootITNm)
{
  var columns = [];
  var columnItems;
  
  if (RootITNm == "Project")
  {
    var xml = "" +
    "<Item type='PM_ProjectGridLayout' action='get' select='position,name,label,width,is_system'>" +
      "<Relationships>" +
        "<Item type='PM_ProjectColumnDescription' action='get' select='row_type,data_source' />" +
      "</Relationships>" +
    "</Item>";
  
    var resObj = top.aras.getPreference(null,null,xml,1);        
    columnItems = resObj.itemNodes;
  }
  else if (RootITNm == "Project Template")
  {
    var resDom = top.aras.createXMLDocument();
    resDom.load(xmlFileBase + "projectGridLayoutXML.xml");
    columnItems = resDom.selectNodes("//Item[@type='Preference']/Relationships/Item");        
  }
  var maxPosition = {num:0, colName:""};

  for(var i=0;i<columnItems.length;i++)
  {
    var columnItem = columnItems[i];
    var name = top.aras.getItemProperty(columnItem, "name");
    var label = top.aras.getItemProperty(columnItem, "label");
    var width = top.aras.getItemProperty(columnItem, "width");
    var position = parseInt(top.aras.getItemProperty(columnItem, "position"),10) - 1; // 1 - number positions begin from, ... - 1 applying, because we need indexes from 0 in columns
    var is_system = top.aras.getItemProperty(columnItem, "is_system") == "1" ? true : false;
    var descrItems = columnItem.selectNodes("Relationships/Item[@type='PM_ProjectColumnDescription']");
    var sources = {};
    for(var j=0;j<descrItems.length;j++)
    {
      var descrItem = descrItems[j];
      var type = top.aras.getItemProperty(descrItem, "row_type");
      var src = top.aras.getItemProperty(descrItem, "data_source");
      if(type == wbsRowType || type == actRowType || type == milRowType)
        sources[type] = {val:src,xpath:null};
    }
    
    if(position > maxPosition.num)
    {
      maxPosition.num = position;
      maxPosition.colName = name;
    }
    
    columns[position] = new _column(name,label,width,sources,is_system);
  }
  
  if(maxPosition.num != i - 1)
  {
    top.aras.AlertError("Error:332 Wrong columns initialization, bad column order: " + maxPosition.colName + " = " + maxPosition.num);
    columns = [];
    return;
  }
  
  return columns;
}

function _column(name, label, width, sources, is_system)
{
  this.name = name;
  this.label = label;
  this.width = width;
  if(typeof(sources) == "string") // properties, which are sources for the column, they are chosen depending on type of row
  {
    var sources_obj = {};
    var elems = sources.split("|");
    for(var i=0;i<elems.length;i++)
    {
      elem = elems[i];
      var val = elem.split(",");
      sources_obj[val[0]] = {val:val[1],xpath:null};
    }
    if(i>0) this.sources = sources_obj;
    else this.sources = null;
  }
  else this.sources = sources;
  this.is_system = is_system;
}

function generateXSLT(RootITNm, columns)
{
  var xsltWbsDom = top.aras.createXMLDocument();
  var xsltWbsBranchDom = top.aras.createXMLDocument();
  
  if (RootITNm == "Project")
  {
    xsltWbsDom.load(stylesFileBase + "wbs.xsl");
    xsltWbsBranchDom.load(stylesFileBase + "wbs_branch.xsl");
  }
  else if (RootITNm == "Project Template")
  {
    xsltWbsDom.load(stylesFileBase + "template.xsl");
    xsltWbsBranchDom.load(stylesFileBase + "wbs_branch_template.xsl");
  }

  // reorder system columns
  
  var thead = xsltWbsDom.selectSingleNode("//thead");
  var cols = xsltWbsDom.selectSingleNode("//columns");
  var inputrow = xsltWbsDom.selectSingleNode("//inputrow");
  
  var ths = thead.selectNodes("th");
  for(var i=0;i<ths.length;i++)
  {
    var th = ths[i];
    fld[th.text] = i;
  }
  
  var lastIndex = ths.length;
  
  if (!columns)
  {
    columns = initColumns2(RootITNm);
    for(var i=0; i<columns.length; i++)
    {
      var column = columns[i];
      for(src in column.sources)
      {
        var v = column.sources[src].val;
        column.sources[src].xpath = getXPathForColumnSource(src, v);
        column.sources[src].params = getParamsForColumnSource(v);
      }
    }
  }
  
  for(var i=0;i<columns.length;i++)
  {
    var column = columns[i];
    if(column.is_system)
    {
      var idx = fld[column.name] + 1;
      var col = cols.selectSingleNode("column[" + idx + "]");
      col.setAttribute("width",column.width);
      col.setAttribute("order",i);
      ths[idx - 1].text = column.label;
    }
    else
    {
      fld[column.name] = lastIndex++;
      
      addTds(xsltWbsDom);
      addTds(xsltWbsBranchDom);
      
      function addTds(dom)
      {
        var wbsSrc = column.sources[wbsRowType];
        var tr = dom.selectSingleNode("//tr[@type='" + getRowType(wbsRowType) + "']");
        var lastTd = tr.selectSingleNode("*[last() -1]");

        if(wbsSrc)
        {
          var wbsTd = getTd(wbsSrc.xpath, wbsSrc.params);
          addToTr(tr,lastTd,[{td:wbsTd}]);
        }
        else
        {
          addToTr(tr,lastTd,[{td:getTd()}]);
        }
        
        var actSrc = column.sources[actRowType];
        var milSrc = column.sources[milRowType];

        var tr = dom.selectSingleNode("//tr[@type='" + getRowType(actRowType) + "']");
        var lastTd = tr.selectSingleNode("*[last()]");
        
        var tds2add = new Array();
        if(actSrc)
        {
          var actTd = getTd(actSrc.xpath, actSrc.params);
          tds2add.push({td:actTd,cond:"not(is_milestone='1')"});
        }
        else
        {
          tds2add.push({td:getTd()});
        }
        if (milSrc)
        {
          var milTd = getTd(milSrc.xpath, milSrc.params);
          tds2add.push({td:milTd,cond:"is_milestone='1'"});
        }
        else
        {
          tds2add.push({td:getTd()});
        }
        addToTr(tr, lastTd, tds2add);
        
        function getTd(xpath, propParams)
        {
          var td = dom.createElement("td");
          if(xpath)
          {
            if (propParams && propParams.readonly=="1")
            {
              var attr = dom.createElement("xsl:attribute");
              attr.setAttribute("name", "editable");
              attr.text = "false";
              td.appendChild(attr);
            }
            var valueOf;
            var doCommonPart = true;
            var ft = (propParams && propParams.field_type) ? propParams.field_type : "";
            switch (ft)
            {
              case "checkbox" :
                valueOf = dom.createCDATASection('<checkbox state="');
                td.appendChild(valueOf);
                valueOf = dom.createElement("xsl:value-of");
                valueOf.setAttribute("select", xpath);
                td.appendChild(valueOf);
                valueOf = dom.createCDATASection('"/>');
                td.appendChild(valueOf);
                doCommonPart = false;
                break;
              case "item" :
                xpath += "/@keyed_name";
                break;
              case "color" :
                var attr = dom.createElement("xsl:attribute");
                attr.setAttribute("name", "bgColor");
                valueOf = dom.createElement("xsl:value-of");
                valueOf.setAttribute("select", xpath);
                attr.appendChild(valueOf);
                td.appendChild(attr);
                doCommonPart = false;
                break;
              case "image" :
                valueOf = dom.createCDATASection('<img src= "');
                td.appendChild(valueOf);
                valueOf = dom.createElement("xsl:value-of");
                valueOf.setAttribute("select", xpath);
                td.appendChild(valueOf);
                valueOf = dom.createCDATASection('"/>');
                td.appendChild(valueOf);
                doCommonPart = false;
                break;
            }
            if(doCommonPart)
            {
              valueOf = dom.createElement("xsl:value-of");
              valueOf.setAttribute("select", xpath);
              td.appendChild(valueOf);
            }
          }
          else
            td.text = " ";

          return td;
        }

        function addToTr(tr,lastTd,arr) // [{node:td node,cond:condition}]
        {
          if(arr.length > 0)
          {
            var insNode;
            if(arr.length == 1 && !arr[0].cond)
              insNode = arr[0].td;
            else // use xsl:choose
            {
              insNode = dom.createElement("xsl:choose");
              var otherwiseNode = dom.createElement("xsl:otherwise");
              otherwiseNode.appendChild(getTd());
              for(var k=0;k<arr.length;k++)
              {
                var whenNode = dom.createElement("xsl:when");
                var tmpCond = (arr[k].cond) ? arr[k].cond : "0";
                whenNode.setAttribute("test", tmpCond);
                whenNode.appendChild(arr[k].td);
                insNode.appendChild(whenNode);
              }
              insNode.appendChild(otherwiseNode);
            }
            tr.insertBefore(insNode,lastTd.nextSibling);
          }
        }
      }

      var th = xsltWbsDom.createElement("th");
      th.setAttribute("align", "center");
      th.text = column.label;
      
      var col = xsltWbsDom.createElement("column");
      col.setAttribute("order",i);
      col.setAttribute("width",column.width);

      thead.appendChild(th);
      cols.appendChild(col);
    }

    var inputTd = xsltWbsDom.createElement("td");
    inputTd.setAttribute("bgColor", "#BDDEF7");
    inputrow.appendChild(inputTd);
  }

  for(var i=0;i<columns.length;i++)
  {
    var column = columns[i];
    fldToCol[fld[column.name]] = i;
  }

  var res = {xsltWbs:null, xsltWbsBranch:null};
  
  res.xsltWbs = xsltWbsDom.xml;
  res.xsltWbsBranch = xsltWbsBranchDom.xml;
  
  return res;
}

function getRowType(cellDataType)
{
  var rowType;
  if(cellDataType == actRowType || cellDataType == milRowType)
  {
    rowType = "Activity2";
  }
  else if(cellDataType == wbsRowType)
  {
    rowType = "WBS Element";
  }
  else
  {
    top.aras.AlertError("Error 229 : Wrong row type = '" + cellDataType + "'");
    return;
  }
  return rowType;
}

// ++ actNums methods
var actNums;
function initActNums()
{
  actNums = top.aras.createXMLDocument();
  var result = top.aras.applyMethod("GetActivitiesNumbers","<rootWBS>" + wbsId + "</rootWBS>");
  actNums.loadXML(result);
  if(wbs.selectSingleNode("//Item[@action]")) mergeActNums();
}

function getActNum(id)
{
  var actNumNode = actNums.selectSingleNode("//a[@id='" + id + "']");
  if(!actNumNode)  { top.aras.AlertError("Error 790:\n\nNo activity number found with id='" + id + "'"); return; }
  return actNumNode.getAttribute("number");
}

function checkActNum(num)
{
  if(actNums.selectSingleNode("//a[@number='" + num + "']")) return true;
  return false;
}

function getActIdByNum(num)
{
  var actNumNode = actNums.selectSingleNode("//a[@number='" + num + "']");
  if(!actNumNode)  { top.aras.AlertError("Error 799:\n\nNo activity id found with num = '" + num + "'"); return; }
  return actNumNode.getAttribute("id");
}

function mergeActNums()
{
  var tmpActNums = top.aras.createXMLDocument();
  tmpActNums.loadXML("<Result><w id='" + wbsId + "' /></Result>");

  actNums = top.aras.createXMLDocument();

  var actNode = tmpActNums.selectSingleNode("//w[@id='" + wbsId + "']");

  recursiveAdd(wbs,actNode);

  var lastWs = tmpActNums.selectNodes("//w[not(*)]");

  for(var i=0;i<lastWs.length;i++)
  {
    var lastW = lastWs[i];
    var id = lastW.getAttribute("id");
    var actW = actNums.selectSingleNode("//w[@id='" + id + "']");
    if(actW && !wbs.selectSingleNode("descendant::Item[@type='WBS Element'][@id='" + id + "']/Relationships/Item[@type='WBS Activity2' or @type='Sub WBS']"))
    {
      lastW.parentNode.replaceChild(actW.cloneNode(true),lastW);
    }
    else
    {
      lastW.parentNode.removeChild(lastW);
    }
  }

  actNums.loadXML(tmpActNums.xml);

  function recursiveAdd(wbsNode,actNode)
  {
    var treeItems = wbsNode.selectNodes("Relationships/Item[not(@action='delete')]/related_id/Item[not(@action='delete')]");
    for(var i=0;i<treeItems.length;i++)
    {
      var treeItem = treeItems[i];
      var type = treeItem.getAttribute("type");
      var id = treeItem.getAttribute("id");
      if(type=="WBS Element")
      {
        var w = tmpActNums.createElement("w");
        w.setAttribute("id",id);
        actNode.appendChild(w);
        recursiveAdd(treeItem,w);
      }
      else if(type=="Activity2")
      {
        var a = tmpActNums.createElement("a");
        a.setAttribute("id",id);
        actNode.appendChild(a);
      }
    }
  }

  numberActsInOrder();
}

function numberActsInOrder()
{
  var aNodes = actNums.selectNodes("/descendant::a")
  for(var i=0;i<aNodes.length;i++)
  {
    var aNode = aNodes[i];
    aNode.setAttribute("number",i+1);
  }
}

// -- actNums methods

function sortItems(parentNode)
{
  var typeXP = "[@type='WBS Activity2' or @type='Sub WBS']";
  var relationshipsNode = parentNode.selectSingleNode("Relationships");
  if(relationshipsNode)
  {
    var nextItem = parentNode.selectSingleNode("Relationships/Item"+typeXP+"[not(@action='delete')]/related_id/Item[not(prev_item) or prev_item='']");
    var beforeRel = relationshipsNode.firstChild;
    while(nextItem)
    {
      var nextRel = nextItem.parentNode.parentNode;
      if(nextItem.getAttribute("type")== "WBS Element") sortItems(nextItem);
      prevRel = relationshipsNode.insertBefore(nextRel,beforeRel);
      beforeRel = prevRel.nextSibling;
      prevItem = prevRel.selectSingleNode("related_id/Item");
      prevId = prevItem.getAttribute("id");
      nextItem = parentNode.selectSingleNode("Relationships/Item"+typeXP+"/related_id/Item[prev_item='" + prevId + "']");
    }
  }
}

function processPredecessors(node, xpath)
{
  var predecessorTDs;
  if (xpath)
    predecessorTDs = node.selectNodes(xpath);
  else
    predecessorTDs = node.selectNodes("descendant::tr/td[@name='Predecessor' and .!='']");

  for(var i=0;i<predecessorTDs.length;i++)
  {
    var predTD = predecessorTDs[i];
    var predVal = predTD.text;

    var predecessors = predVal.split(",");
    predVal = "";
    for(var j=0;j<predecessors.length;j++)
    {
      var pred_content = predecessors[j].split("|"); //predecessor id | precedence type | lead lag
      var pred = pred_content[0];
      if(j!=0) predVal += ',';
      var precType = (pred_content[1]!==undefined) ? pred_content[1] : "";
      var leadLag = (pred_content[2]!==undefined) ? pred_content[2] : "";
      predVal += getActNum(pred) + precType + leadLag;
    }
    predTD.text = predVal;
  }
}

function processNfields(node)
{
  var nTDs = node.selectNodes("descendant::tr[@type='Activity2']/td[@name='N']");
  for(var i=0;i<nTDs.length;i++)
  {
    var nTD = nTDs[i];
    var nTR = nTD.parentNode;
    var nID = nTR.getAttribute("id");

    nTD.text = getActNum(nID);
  }
}

function initColumns(step)
{
  switch(step)
  {
    case 1:
      columns = initColumns2(RootITNm);
      break;
    case 2:
      for(var i=0; i<columns.length; i++)
      {
        var column = columns[i];
        for(src in column.sources)
        {
          var v = column.sources[src].val;
          column.sources[src].xpath = getXPathForColumnSource(src, v);
          column.sources[src].params = getParamsForColumnSource(v);
        }
      }
      break;
  }
}

// +++ ER

function getXPathForColumnSource(srcType,srcPath)
{
  var rowType = getRowType(srcType);
  var qryDom = uniCache.queryDom;
  if(!qryDom)
  {
    if (!wbs)
      return;
    else
      qryDom = wbs;
  }
  var splitPath = srcPath.split("/");
  
  var xPath = "";
  var nextNode = qryDom.selectSingleNode("//Item[@type='" + splitPath[0] + "']");
  if(nextNode)
  {
    var chk = nextNode.selectSingleNode("ancestor-or-self::Item[@type='" + rowType + "']");
    if(!chk)
    {
      top.aras.AlertError("Error 670 : Wrong rowType='" + rowType + "' for scrPath='" + srcPath + "' in getXPathForColumnSource function");
      return;
    }

    var unCycle = 100;
    
    while(nextNode.getAttribute("type") != rowType)
    {
      xPath = "/" + xPath;
      if(nextNode.tagName == "Item") xPath = "[@type='" + nextNode.getAttribute("type") + "'][not(@action='delete')]" + xPath;
      xPath = nextNode.tagName + xPath;
      nextNode = nextNode.parentNode;
      if(-- unCycle == 0)
      {
        top.aras.AlertError("Error 338: infinite computational loop");
        return;
      }
    }
  }
  else if(splitPath[0] == 'Deliverable')
  {
    if(rowType == "Activity2") xPath = "Relationships/Item[@type='Activity2 Deliverable'][not(@action='delete')]/related_id/Item[not(@action='delete')]/";
    else if(rowType == "WBS Element") xPath = "Relationships/Item[@type='WBS Deliverable'][not(@action='delete')]/related_id/Item[not(@action='delete')]/";
  }
  else if(splitPath[0] == 'Identity')
  {
    xPath = "managed_by_id";
  }
  else
  {
    top.aras.AlertError("Error 775 : Wrong rowType in function getXPathForColumnSource");
    return;
  }

  xPath += splitPath[1];

  return xPath;
}

/*
  returns new object hash: prop name -> prop value for some required properties of Item (type=Property) in item type from srcPath.
  srcPath - path to the column
*/
function getParamsForColumnSource(srcPath)
{
  var requiredPropNames = new Array("data_type", "data_source", "readonly", "default_value", "name");
  var retObj = {};
  var splitPath = srcPath.split("/");
  if(splitPath.length<2) return retObj;
  var propName = splitPath[splitPath.length-1];
  var itemTypeName = splitPath[splitPath.length-2];
  var itemType = top.aras.getItemTypeDictionary(itemTypeName).node;
  if(!itemType)
  {
    top.aras.AlertError("Error 776 : Wrong itemTypeName in function getParamsForColumnSource");
    return retObj;
  }
  try
  {
    var propNd = itemType.selectSingleNode("Relationships/Item[@type='Property' and name='" + propName + "']");
  }
  catch (e)
  {
    top.aras.AlertError("Error 777 : Wrong propName in function getParamsForColumnSource");
    return retObj;
  }
  if(!propNd) return retObj;
  for (var i=0; i<requiredPropNames.length; i++)
  {
    var cn = requiredPropNames[i];
    retObj[cn] = top.aras.getItemProperty(propNd, cn, null);
  }
  retObj["itemTypeName"] = itemTypeName;
  retObj["itemTypeId"] = itemType.getAttribute("id");
  retObj["field_type"] = top.aras.uiGetFieldType4Property(propNd);
  return retObj;
}