﻿// (c) Copyright by Aras Corporation, 2005-2007.

/*
This js uses global ProjectTree.htm variables:
---------
a
wbs
projectItem

and functions:
---------
seekInArray
getItemForEdit
*/

/*
This file provides the following public methods for ProjectTree.htm
scheduleContract1 - implementation of MILESTONE SCHEDULING (CONTRACT 1)
scheduleContract2 - implementation of NETWORK SCHEDULING (CONTRACT 2). Sheduling may be forward or backward.
*/

var ONEDAY = 24*60*60*1000;

var smGlobal = null;

function _smGlobal()
{
  this.waiting = [];
  this.firstActs = [];
  this.lastActs = [];
  this.checkArr = [];
  this.projDate = null;
}

var smCache = null; // sheduling_methods cache

function _smCache()
{
  this.links = new linksCache();
  this.act = [];
  this.modAct = []; // modified activity, to know that comparisson by compareDates is rightfull, for example date_lf was 11/07, and we compare with 12/07, we'll set 11/07, but this is wrong )
  
  this.addMod = function(id,prop)
  {
    if(!this.modAct[id]) this.modAct[id] = [];
    this.modAct[id][prop] = true;
  }
  
  this.isMod = function(id,prop)
  {
    if(this.modAct[id] && this.modAct[id][prop]) return true;
    else return false;
  }
  
  function linksCache()
  {
    this.from = [];
    this.to = [];
  }
}

function initSchedVars()
{
  smGlobal = new _smGlobal();
  smCache = new _smCache();
}

var businessCalendars = new Object();
//stores holidays and working days in a form:
//businessCalendars[year] = {working day number:date, working day number:date, ... }
//businessCalendars[2006] = {0:20060102, 1:20060103, ..., 4:20060106, 5:20060109}

function dateToYYYYMMDD(dt)
{
//returns int representation of date in a form of YYYYMMDD
  var month = dt.getUTCMonth() + 1;
  if (month < 10) month = "0" + month;
  
  var date = dt.getUTCDate();
  if (date < 10) date = "0" + date;
  
  var str = String(dt.getUTCFullYear()) + String(month) + String(date);
  return parseInt(str);
}

function YYYYMMDDToDate(yyyyMMDD)
{
//parse 8 digits integer number in a form YYYYMMDD and returns Date object
  var sYYYYMMDD = String(yyyyMMDD);
  var yyyy = parseInt(sYYYYMMDD.substr(0,4), 10);
  var mm   = parseInt(sYYYYMMDD.substr(4,2), 10) - 1;
  var dd   = parseInt(sYYYYMMDD.substr(6,2), 10);
  
  var res = new Date(Date.UTC(yyyy, mm, dd));
  return res;
}

var turnOffCalendarExcpetions = false;//this flag is for debug purposes only (to run unit tests independently from DB)
function getBusinessCalendarForYear(year)
{
//finds Business Calendar for the specified year
  var yearCalendar = businessCalendars[year];
  if (yearCalendar !== undefined) return yearCalendar;
  
  var res = null;
  
  var exceptionsInfo = new Object();
  var weekend_are_days_off = true;

  if (!turnOffCalendarExcpetions)
  {
    var xml =
    "<Item type=\"Business Calendar Year\" action=\"get\" select=\"weekend_days_off\" levels=\"1\">" +
      "<year>" + year + "</year>" +
      "<Relationships>" +
        "<Item type=\"Business Calendar Exception\" action=\"get\" select=\"day_off,day_date\"/>" +
      "</Relationships>" +
    "</Item>";
    var res = a.soapSend("ApplyItem", xml);

    if (res.getFaultCode() != 0) res = null;
    else
    {
      res = res.getResult();
      if (res)
      {
        res = res.selectSingleNode("Item");
        if (res)
        {
          var dateFormat = getDatePropertyPattern("Business Calendar Exception", "day_date");
          
          var exceptions = res.selectNodes("Relationships/Item");
          for (var i=0; i<exceptions.length; i++)
          {
            var dateInfo = exceptions[i];
            var isDayOff = (a.getItemProperty(dateInfo, "day_off") == "1");
            var str_day_date = a.getItemProperty(dateInfo, "day_date");
            str_day_date = convertDateStr(str_day_date, dateFormat, USDateFormat);
            
            exceptionsInfo[str_day_date] = isDayOff;
          }
          
          weekend_are_days_off = (a.getItemProperty(res, "weekend_days_off") == "1");
        }
      }
    }
  }
  
  yearCalendar = new Array();
  
  var dt = new Date(Date.UTC(year, 0, 1));
  for (var i=0; true; i++)
  {
    if (dt.getUTCFullYear() > year) break;
    
    var isDayOff = false;
    var strDate = parseFromDate(dt);
    
    isDayOff = exceptionsInfo[strDate];
    
    if (isDayOff === undefined)
    {
      var dayOfWeek = dt.getUTCDay();
      //Sunday = 0
      //Saturday = 6
      
      if (dayOfWeek == 0 || dayOfWeek == 6) isDayOff = weekend_are_days_off;
      else isDayOff = false;
    }
    
    if (!isDayOff) yearCalendar.push(dateToYYYYMMDD(dt));
    
    dt.setUTCDate(dt.getUTCDate() + 1);
  }
  
  businessCalendars[year] = yearCalendar;
  
  return yearCalendar;
}

function findDateIndex(year, dt, isForwardSearch)
{
//finds index(ordinal number among working days of the year) of the specified date
//year - integer. Full year number (e.g. 2006)
//dt   - instance of Date class.
//isForwardSearch - boolean. Defines search for nearest working day direction for a case when date is a day off
//------
//if year and the specified date year do not match then exception is thrown
//if no match was found (specified date is a day off) then index of the nearest working day is returned (depends on search direction)
//if the specified date is a day off and there are no more working days in this year them:
//  - if isForwardSearch then (number of working days in the year) is returned.
//  - if not isForwardSearch then (-1) is returned.

  var dt_year = dt.getUTCFullYear();
  if (dt_year != year) throw new Error(1, "findDateIndex: Years do no match");
  
  var workingDays = getBusinessCalendarForYear(year);
  var indexCandidate = Math.floor((workingDays.length * (dt.getUTCDate() + dt.getUTCMonth()*30)) / 365);
  
  var target = dateToYYYYMMDD(dt);
  var dateCandidate = workingDays[indexCandidate];
  
  if (target == dateCandidate)
  {
    return indexCandidate;
  }
  else if (target > dateCandidate)
  {
    if (isForwardSearch)
    {
      //try to find the nearest working date greater or equal than target date
      for (var i=indexCandidate+1; i<workingDays.length; i++)
      {
        if (workingDays[i] >= target) return i;
      }
      
      //no working day was found in the year
      return workingDays.length;
    }
    else
    {
      //try to find the nearest working date less or equal than target date
      for (var i=indexCandidate+1; i<workingDays.length; i++)
      {
        if (workingDays[i] > target) return (i-1);
      }
      
      //the last working day in the year
      return (workingDays.length-1);
    }
  }
  else//if (target < dateCandidate)
  {
    if (isForwardSearch)
    {
      //try to find the nearest working date greater or equal than target date
      for (var i=indexCandidate-1; i>=0; i--)
      {
        if (workingDays[i] < target) return (i+1);
        
        indexCandidate = i;
      }
      
      return indexCandidate;
    }
    else
    {
      //try to find the nearest working date less or equal than target date
      for (var i=indexCandidate-1; i>=0; i--)
      {
        if (workingDays[i] <= target) return i;
      }
      
      //there are no working days in the year before the target date.
      return -1;
    }
  }
}

/*****************
tests data (assumption: no day offs except weekends):
12/31/2005 - Saturday
01/01/2006 - Sunday
01/03/2006 - Tuesday
02/01/2006 - Wednesday
02/04/2006 - Saturday
02/05/2006 - Sunday
02/06/2006 - Monday
2006 year is not a leap-year
03/01/2006 - Wednesday
12/01/2006 - Friday
12/31/2006 - Sunday
01/01/2007 - Monday
working days in 2007 year: 23+20+22+21+23+21+22+23+20+23+22+21=261
01/01/2008 - Tuesday
2008 year is a leap-year
02/29/2008 - Friday
03/03/2008 - Monday
-----------------
/** /
alert("Important: Unit tests are turned ON.");
turnOffCalendarExcpetions = true;
var commonTestsData =
[
  {dt1:"12/29/2005", dt2:"12/30/2005", diff:1},
  {dt1:"02/01/2006", dt2:"02/01/2006", diff:0},
  {dt1:"02/01/2006", dt2:"02/02/2006", diff:1},
  {dt1:"02/01/2006", dt2:"02/03/2006", diff:2},
  {dt1:"02/01/2006", dt2:"02/06/2006", diff:3},
  {dt1:"02/01/2006", dt2:"02/07/2006", diff:4},
  {dt1:"02/01/2006", dt2:"02/15/2006", diff:10},
  {dt1:"02/01/2006", dt2:"03/01/2006", diff:20},
  {dt1:"12/01/2006", dt2:"01/01/2007", diff:21},
  {dt1:"12/29/2006", dt2:"01/01/2007", diff:1},
  {dt1:"01/01/2007", dt2:"01/01/2008", diff:261},
  {dt1:"12/01/2006", dt2:"01/01/2008", diff:282},
  {dt1:"02/01/2008", dt2:"03/03/2008", diff:21}
];
/*****************/

/*****************
tests for incDate:
/** /
var incDateTestsData =
[
  {dt1:"12/31/2005", dt2:"01/03/2006", diff:1}
];
incDateTestsData = commonTestsData.concat(incDateTestsData);

var incDateTestsResult = "";
for (var i=0; i<incDateTestsData.length; i++)
{
  var test = incDateTestsData[i];
  var testCode = 'incDate("' + test.dt1 + '",' + test.diff + ')=="' + test.dt2 + '"';
  incDateTestsResult += testCode + ": " + eval(testCode) + "\n";
}
alert("incDate Tests Results:\n" + incDateTestsResult);
/************************/
function incDate(sdate,sdays)
{
//adds specified number of working days to the specified date

  var days = Number(sdays);
  if (days == 0) return sdate;
  else if (days < 0) return decDate(sdate,-days);
  
  //variable days contains a number of working days which must be added to start date (sdate)
  
  var start_date     = parseToDate(sdate);
  var start_year     = start_date.getUTCFullYear();
  var startDateIndex = findDateIndex(start_year, start_date, true);
  
  var workingDays = getBusinessCalendarForYear(start_year);
  if (startDateIndex == workingDays.length)
  {
    //start_date is a day off and there are no more working days in the startYear year
    start_year++;
    workingDays = getBusinessCalendarForYear(start_year);
    startDateIndex = 0;
    start_date  = YYYYMMDDToDate( workingDays[startDateIndex] );
  }
  
  var endDateIndex;
  for (var end_year=start_year;;)
  {
    endDateIndex = startDateIndex + days;
    days -= workingDays.length - startDateIndex;//decrease required days number on a number of working days in the year after startDateIndex
    if (days < 0) break;//current year contains enough working days
    
    end_year++;
    workingDays = getBusinessCalendarForYear(end_year);
    startDateIndex = 0;
  }
  
  var end_date = YYYYMMDDToDate( workingDays[endDateIndex] );
  return parseFromDate(end_date);
}

/*****************
tests for decDate:
/** /
var decDateTestsData =
[
  {dt1:"12/29/2005", dt2:"01/01/2006", diff:1}
];
decDateTestsData = commonTestsData.concat(decDateTestsData);

var decDateTestsResult = "";
for (var i=0; i<decDateTestsData.length; i++)
{
  var test = decDateTestsData[i];
  var testCode = 'decDate("' + test.dt2 + '",' + test.diff + ')=="' + test.dt1 + '"';
  decDateTestsResult += testCode + ": " + eval(testCode) + "\n";
}
alert("decDate Tests Results:\n" + decDateTestsResult);
/************************/
function decDate(sdate,sdays)
{
  var days = Number(sdays);
  if (days == 0) return sdate;
  else if (days < 0) return incDate(sdate,-days);
  
  //variable days contains a number of working days which must be added to start date (sdate)
  
  var start_date     = parseToDate(sdate);
  var start_year     = start_date.getUTCFullYear();
  var startDateIndex = findDateIndex(start_year, start_date, false);
  
  var workingDays = getBusinessCalendarForYear(start_year);
  if (startDateIndex == -1)
  {
    //start_date is a day off and there are no working days in the startYear year before start_date
    start_year--;
    workingDays = getBusinessCalendarForYear(start_year);
    startDateIndex = workingDays.length - 1;
    start_date  = YYYYMMDDToDate( workingDays[startDateIndex] );
  }
  
  var endDateIndex;
  for (var end_year=start_year;;)
  {
    endDateIndex = startDateIndex - days;
    days -= startDateIndex + 1;//decrease required days number on a number of working days in the year before startDateIndex (including startDateIndex)
    if (days < 0) break;//current year contains enough working days
    
    end_year--;
    workingDays = getBusinessCalendarForYear(end_year);
    startDateIndex = workingDays.length - 1;
  }
  
  var end_date = YYYYMMDDToDate( workingDays[endDateIndex] );
  return parseFromDate(end_date);
}

function decDateToFirstWorking(date) 
{
  var test_date = incDate(decDate(date,1),1);
  if (compareDates(test_date, date) < 0) return test_date
  else return decDate(date,1);
}

function incDateToFirstWorking(date) 
{
  var test_date = decDate(incDate(date,1),1);
  if (compareDates(test_date, date) > 0) return test_date
  else return incDate(date,1);
}

/*****************
tests for diffDates:
/** /
var diffDatesTestsData =
[
  {dt1:"12/29/2005", dt2:"01/01/2006", diff:1},
  {dt1:"12/31/2005", dt2:"01/03/2006", diff:1},
  {dt1:"12/31/2005", dt2:"01/01/2006", diff:0}
];
diffDatesTestsData = commonTestsData.concat(diffDatesTestsData);

var diffDatesTestsResult = "";
for (var i=0; i<diffDatesTestsData.length; i++)
{
  var test = diffDatesTestsData[i];
  var testCode = 'diffDates("' + test.dt1 + '","' + test.dt2 + '")==' + test.diff;
  diffDatesTestsResult += testCode + ": " + eval(testCode) + "\n";
}
alert("diffDates Tests Results:\n" + diffDatesTestsResult);
/************************/
function diffDates(sdate1,sdate2)  // sdate1 < sdate2 return > 0
{
//returns differnce between sdate2 and sdate1 in working days.
//if sdate1 < sdate2 then return value is positive
//else return value is negative or zero.

  if (sdate1 == sdate2) return 0;
  
  var date1 = parseToDate(sdate1);
  var date2 = parseToDate(sdate2);
  
  var invert = date1 > date2;//if true then the result will be negative integer
  if (invert)
  {
    var tmp = date1;
    date1 = date2;
    date2 = tmp;
  }
  
  var year1 = date1.getUTCFullYear();
  var year2 = date2.getUTCFullYear();
  
  var i1 = findDateIndex(year1, date1, true);
  var i2 = findDateIndex(year2, date2, true);
  
  var res = 0;
  if (year1 == year2)
  {
    res = i2 - i1;
  }
  else
  {
    //we know that year1 < year2
    
    var year1_days_count = getBusinessCalendarForYear(year1).length;
    var no_working_days_in_year2 = (findDateIndex(year2, date2, false) == -1);
    if (no_working_days_in_year2)
      res--;
    
    if ((year1_days_count == i1) && no_working_days_in_year2)
    {
      //no working days after date1 and no working days before date2
      res = 0;
    }
    else
    {
      res += (year1_days_count - i1) + i2;
    }
    
    for (var year=year1+1; year<year2; year++)
      res += getBusinessCalendarForYear(year).length;
  }
  
  if (invert) res = -res;
  
  return res;
}

/*
* compareDates()
* params:
* sdate1,sdate2 - string properties of type 'Date'
* returns:
* 1  if sdate1 > sdate2
* -1 if sdate1 < sdate2
* 0  if sdate1 == sdate2
*/

function compareDates(sdate1,sdate2)
{
  var date1 = parseToDate(sdate1);
  var date2 = parseToDate(sdate2);
  if(date1 > date2) return 1;
  else if(date1 < date2) return -1;
  else return 0;
}

function parseToDate(si)
{
  // 'MM/dd/yyyy';
  if (!si) return null;
  var ar = si.split('/');
  if (ar.length != 3) return null;
  var dt = new Date(Date.UTC(parseInt(ar[2],10), parseInt(ar[0],10)-1, parseInt(ar[1],10)));
  return dt;
}

function parseFromDate(d)
{
  // 'MM/dd/yyyy';
  var month = d.getUTCMonth() + 1;
  var day = d.getUTCDate();
  var year = d.getUTCFullYear();
  var str = (month>=10?"":"0" ) + month + "/" + (day>=10?"":"0" ) + day + "/" + year;
  return str;
}
//--- Common functions ---

//+++ Contract 1, Milestone scheduling +++

/*
 *  scheduleContract1()
 */

function scheduleContract1()
{
  var statusId = a.showStatusMessage(0, 'Scheduling...', '../../../images/Animated/ProgressSmall.gif');

  initSchedVars();
  lockingAllActivities();

  var phases = wbs.selectNodes("Relationships/Item[@type='Sub WBS'][not(@action='delete')]/related_id/Item[@type='WBS Element'][not(@action='delete')]");
  var firstActsArr = [];
  var minDate = null;

  var projStart = a.getItemProperty(projectItem, 'date_start_target');
  var proj_start_sched;
  var proj_due_sched;
  var mArrEs = []; // holds the es date for each phase
  
  for(var i=0;i<phases.length;i++)
  {
    var phase = phases[i];
    var name = a.getItemProperty(phase,"name");
    var milestones = phase.selectNodes("descendant::Item[@type='WBS Activity2'][not(@action='delete')]/related_id/Item[@type='Activity2'][not(@action='delete')][is_milestone='1'][date_due_sched!='']");
    if(milestones.length == 0) { a.AlertError('Phase ' + name + ' has no milestones with Plan Finish'); return; }
    
    var mArr = [];
    
    for(var j=0;j<milestones.length;j++)
    {
      var milestone = milestones[j];
      var id = milestone.getAttribute("id");
      if(getNs(id).length == 0) mArr.push(id);
    }
    
    if(mArr.length == 0) { a.AlertError("For Milestone Scheduling there must be at least one milestone without a successor in Phase:'" + name + "'"); return; }
    
    var maxDate = null;
    for(var j=0;j<mArr.length;j++)
    {
      var id = mArr[j];
      var milestone = smCache.act[id];
      var finish = a.getItemProperty(milestone,"date_due_sched");
      if(!maxDate) maxDate = finish;
      else if(compareDates(maxDate,finish) == -1) maxDate = finish;
    }
    
    //+++ check for predecessors between activities in different phases
    
    smGlobal.firstActs = [];
    smGlobal.lastActs = [];
    
    var phaseActNodes = phase.selectNodes("descendant::Item[@type='WBS Activity2'][not(@action='delete')]/related_id/Item[@type='Activity2'][not(@action='delete')]");
    
    for(var j=0;j<phaseActNodes.length;j++)
    {
      var phaseActNode = phaseActNodes[j];
      var id = phaseActNode.getAttribute("id");
      var isPred = phaseActNode.selectSingleNode("self::node()[not(Relationships/Item[@type='Predecessor'][not(@action='delete')])]");
      if(isPred) smGlobal.firstActs.push(id);
      smGlobal.checkArr[id] = true;
    }
    
    var res = goToEndChk(smGlobal.firstActs);
    smGlobal.checkArr = [];

    if(res)
    {
      for(var j=i;j<phases.length;j++)
      {
        var linkPhase = phases[j];
        var act = linkPhase.selectSingleNode("descendant::Item[@type='WBS Activity2']/related_id/Item[@type='Activity2'][@id='" + res + "']");
        if(act)
        {
          var linkPhaseName = a.getItemProperty(linkPhase,"name");
          var actName = a.getItemProperty(act,"name");
          break;
        }
      }
      a.AlertError("Wrong network structure. There is link with Activity '" + actName + "',number=" + getActNum(res) + " between phase '" + name + "' and phase '" + linkPhaseName + "'.");
      return;
    }
    
    //--- check for predecessors between activities in different phases
    
    // Structure is good
    
    smGlobal.waiting = [];
    smGlobal.projDate = null;
    backwardPass(smGlobal.lastActs,maxDate,null);
    firstActsArr[i] = smGlobal.firstActs;
    minDate = projStart;
    if(compareDates(minDate,smGlobal.projDate) == 1) minDate = smGlobal.projDate;
    
    if(!proj_start_sched) proj_start_sched = minDate;
    else if(compareDates(proj_start_sched,minDate) == 1) proj_start_sched = minDate;

    if(!proj_due_sched) proj_due_sched = maxDate;
    else if(compareDates(proj_due_sched,maxDate) == -1) proj_due_sched = maxDate;
    
    if(compareDates(minDate,projStart) == 1) minDate = projStart;
    mArrEs.push(minDate);
    minDate=null;
  }

  for(var i=0;i<phases.length;i++)
  {
    smGlobal.waiting = [];
    smGlobal.projDate = null;
    var firstActs = firstActsArr[i];
    forwardPass(firstActs,mArrEs[i],null);
    
    if(compareDates(proj_due_sched,smGlobal.projDate) == -1) proj_due_sched = smGlobal.projDate;
  }
  
  a.setItemProperty(projectItem,"date_start_sched",proj_start_sched);
  a.setItemProperty(projectItem,"date_due_sched",proj_due_sched);
  
  setStartFinish();

  a.clearStatusMessage(statusId);
}

//--- Contract 1, Milestone scheduling ---

function lockingAllActivities()
{
  var statusId2 = a.showStatusMessage(0, 'Locking all activities...', '../../../images/Animated/ProgressSmall.gif');
  
  var acts = wbs.selectNodes("descendant::Item[@type='WBS Activity2'][not(@action='delete')]/related_id/Item[@type='Activity2']");
  for(var i=0;i<acts.length;i++)
  {
    var act = acts[i];
    act = getItemForEdit(act);
    var id = act.getAttribute('id');
    smCache.act[id] = act;
  }
  
  a.clearStatusMessage(statusId2);

}


//+++ Contract 2, Network scheduling +++

/*
 *  scheduleContract2()
 *  arguments:
 *    isForward - Boolean: true - forward; false - backward
 *  description:
 
 Forward scheduling
==================
These are the steps of the scheduling:

1. The *project start scheduled* date is set to *project start target*, because it is initial point for forward scheduling.
2. *forward pass* is applied with initial date = *project start target*
3. outer date from previuos step is used as *project finish scheduled*
4. *backward pass* is applied with initial date = just calculated *project finish scheduled*
5. standard procedure to calculate start and finish for all activities (appendix A)
  

Backward scheduling
===================
These are the steps of the scheduling:

1. The *project finish scheduled* date is set to *project finish target*, because it is initial point for backeard scheduling.
2. *backward pass* is applied with initial date = *project finish target*
3. outer date of previos step is used as *project start scheduled*
4. *forward pass* is applied with initial date = just calculated *project start scheduled*
5. standard procedure to calculate start and finish for all activities (appendix A)

So as we can see backward scheduling is just "reflection" of forward scheduling.
 */

function scheduleContract2(isForward)
{
  var statusId = a.showStatusMessage(0, 'Scheduling...', '../../../images/Animated/ProgressSmall.gif');
  
  initSchedVars();
  lockingAllActivities();
  
  var projStart = a.getItemProperty(projectItem, 'date_start_target');
  if (!projStart) { 
    a.AlertError("Error: Start date of the project is empty.");
    return false;
  }
  else
  {
    if (isForward) a.setItemProperty(projectItem, "date_start_sched", projStart);
  }
  
  var projFinish = a.getItemProperty(projectItem, 'date_due_target');
  if (!projFinish) { 
    a.AlertError("Error: End date of the project is empty.");
    return false;
  }
  else
  {
    if (!isForward) a.setItemProperty(projectItem, "date_due_sched", projFinish);
  }
  
  // searching smGlobal.lastActs
  
  var acts = wbs.selectNodes("descendant::Item[@type='WBS Activity2'][not(@action='delete')]/related_id/Item[@type='Activity2' and not(Relationships/Item[@type='Predecessor'][not(@action='delete')])][not(@action='delete')]");
  for(var i=0;i<acts.length;i++)
  {
    var act = acts[i];
    var id = act.getAttribute('id');
    smGlobal.firstActs.push(id);
  }
  
  // ---
  
  // go to end with filling of smGlobal.lastActs
  
  if (isForward)
  {
    forwardPass(smGlobal.firstActs,projStart,null);
    smGlobal.waiting = [];
    var tmp = smGlobal.projDate;
    tmp = compareDates(projFinish,tmp)==1 ? projFinish : tmp;
    a.setItemProperty(projectItem,"date_due_sched",tmp);
    smGlobal.projDate = null;
    backwardPass(smGlobal.lastActs,tmp,null);
  }
  else
  {
    goToEnd(smGlobal.firstActs);
    backwardPass(smGlobal.lastActs,projFinish,null);
    smGlobal.waiting = [];
    var tmp = smGlobal.projDate;
    tmp = compareDates(projStart,tmp)==1 ? tmp : projStart;    
    a.setItemProperty(projectItem,"date_start_sched",tmp);
    smGlobal.projDate = null;
    forwardPass(smGlobal.firstActs,tmp,null);
  }
  
  setStartFinish();

  a.clearStatusMessage(statusId);

  //-------------
  
}

function setStartFinish()
{
  var scheduling_type = a.getItemProperty(projectItem,"scheduling_type");
  
  bDirection = scheduling_type == "Forward" ? true : false;

  var acts = wbs.selectNodes("descendant::Item[@type='WBS Activity2'][not(@action='delete')]/related_id/Item[@type='Activity2'][not(@action='delete')]");
  for(var i=0;i<acts.length;i++)
  {
    var act = acts[i];
    var start = a.getItemProperty(act,"date_start_sched");
    if(!start) start = "";
    var finish = a.getItemProperty(act,"date_due_sched");
    if(!finish) finish = "";
    var es = a.getItemProperty(act,"date_es");
    var ef = a.getItemProperty(act,"date_ef");
    var ls = a.getItemProperty(act,"date_ls");
    var lf = a.getItemProperty(act,"date_lf");
    var d = parseInt(a.getItemProperty(act,'expected_duration'));
    d = isNaN(d) ? 0 : d;
    
    if(bDirection) // for forward
    {
      // start
      
      if(compareDates(start,es) == -1) start = es;
      else
      {
        finish = incDate(start,d);
        if(compareDates(finish,lf) == 1) start = decDate(lf,d);
        if(compareDates(start,ls) == 1) start = ls;
      }
      
      // finish
      
      if(compareDates(finish,ef) == -1) finish = ef;
      else if(compareDates(finish,lf) == 1) finish = lf;
    }
    else // for backward and milestone
    {
      // finish
      
      if(compareDates(finish,lf) == 1 || finish == "") finish = lf;
      else if(compareDates(finish,ef) == -1) finish = ef;

      // start
      
      if(compareDates(start,ls) == 1 || start == "") start = ls;
      else
      {
        start = decDate(finish,d);
        if(compareDates(start,es) == -1)
        {
          start = es
          finish = incDate(start,d);
        }
      }
    }
    

    a.setItemProperty(act,"date_start_sched",start,false);
    a.setItemProperty(act,"date_due_sched",finish,false);
  }
}

//--- Contract 2, Network scheduling ---

function goToEndChk(fromIds)
{
  for(var i=0;i<fromIds.length;i++)
  {
    var id = fromIds[i];
    if(!smGlobal.checkArr[id]) return id;
    var prevIds = getPs(id);
    for(var j=0;j<prevIds.length;j++) if(!smGlobal.checkArr[prevIds[j]]) return prevIds[j];
    var toIds = getNs(id);
    if(toIds.length == 0)
    {
      if(seekInArray(smGlobal.lastActs,id) == -1) smGlobal.lastActs.push(id);
    }
    else
    {
      var res =  goToEndChk(toIds);
      if(res) return res;
    }
  }
  return null;
}

function goToEnd(fromIds)
{
  for(var i=0;i<fromIds.length;i++)
  {
    var id = fromIds[i];
    var toIds = getNs(id);
    if(toIds.length==0)
    {
      if(seekInArray(smGlobal.lastActs,id)==-1) smGlobal.lastActs.push(id);
    }
    else goToEnd(toIds);
  }
}

/*
*  forwardPass()
*  arguments:
*    parIds - ids should be processed
*    parEs - es for that ids from previous step
*    fromId - id of activity from where we go
*  description:
*    sets es,ls and smGlobal.lastActs array for each activity
*/

function forwardPass(parIds,parEs,fromId)
{
  for(var i=0;i<parIds.length;i++)
  {
    var id = parIds[i];
  
    if(!smGlobal.waiting[id])
    {
      smGlobal.waiting[id] = getPs(id);
    }
    
    var es = getProp(id,'date_es');
    var firstEs = parEs;
    if(!smCache.isMod(id,'date_es') || compareDates(parEs,es) == 1)
    {
      setProp(id,'date_es',parEs);
    }
    else firstEs = es;
    
    if(smGlobal.waiting[id].length != 0)
    {
      smGlobal.waiting[id] = excludeFromArray(smGlobal.waiting[id],fromId); // exclude the one where from we came
    }

    if(smGlobal.waiting[id].length != 0)
    {
      continue;
    }

    var d = parseInt(getProp(id,'expected_duration'));
    d = isNaN(d) ? 0 : d;
    var ef = incDate(firstEs,d);
    setProp(id,'date_ef',ef);
    
    var ids = getNs(id);
    if(ids.length == 0)
    {
      if(smGlobal.projDate)
      {
        if(compareDates(ef,smGlobal.projDate)==1)
        smGlobal.projDate = ef;
      }
      else smGlobal.projDate = ef;
      if(seekInArray(smGlobal.lastActs,id) == -1) smGlobal.lastActs.push(id);
    }
    else forwardPass(ids,ef,id);
  }
}

/*
*  backwardPass()
*  arguments:
*    parIds - ids should be processed
*    parLf - lf for that ids from previous step
*    fromId - id of activity from where we go
*  description:
*    sets ef,lf and smGlobal.firstActs array for each activity
*/

function backwardPass(parIds,parLf,fromId)
{
  for(var i=0;i<parIds.length;i++)
  {
    var id = parIds[i];
    
    if(!smGlobal.waiting[id])
    {
      smGlobal.waiting[id] = getNs(id);
    }
    
    var lf = getProp(id,'date_lf');
    var lastLf = parLf;
    if(!smCache.isMod(id,'date_lf') || compareDates(parLf,lf) == -1)
    {
      setProp(id,'date_lf',parLf);
    }
    else lastLf = lf;
    
    if(smGlobal.waiting[id].length != 0)
    {
      smGlobal.waiting[id] = excludeFromArray(smGlobal.waiting[id],fromId); // exclude the one where from we came
    }
    
    if(smGlobal.waiting[id].length != 0)
    {
      continue;
    }

    var d = parseInt(getProp(id,'expected_duration'));
    d = isNaN(d) ? 0 : d;
    var ls = decDate(lastLf,d);
    setProp(id,'date_ls',ls);
    
    var ids = getPs(id);
    if(ids.length == 0)
    {
      if(smGlobal.projDate)
      {
        if(compareDates(ls,smGlobal.projDate)==-1)
        smGlobal.projDate = ls;
      }
      else smGlobal.projDate = ls;
    }
    else backwardPass(ids,ls,id);
  }
}

function excludeFromArray(arr,elem)
{
  var n = seekInArray(arr,elem);
  return arr.slice(0,n).concat(arr.slice(n+1,arr.length));
}

function getProp(id,name)
{
  var act = smCache.act[id];
  return a.getItemProperty(act,name);
}

function setProp(id,name,prop)
{
  var act = smCache.act[id];
  if (act)
  {
    a.setItemProperty(act,name,prop,false);
    smCache.addMod(id,name);
  }
}

/*
* getPs()
*
* arguments:
*   id - id of activity for which we want get all predecessor activities
* description:
*   gets all predecessor activities for activity
* returns:
*   array of ids
*/

function getPs(id)
{
  if(!smCache.links.to[id])
  {
    smCache.links.to[id] = getPredecessors(id,null,true);
  }
  return smCache.links.to[id];
}

/*
* getNs()
*
* arguments:
*   id - id of activity for which we want get all activities, which predecessor activities
* description:
*   gets all predecessor activities for activity
* returns:
*   array of ids
*/

function getNs(id)
{
  if(!smCache.links.from[id])
  {
    smCache.links.from[id] = getReferrers(id,null,true);
  }
  return smCache.links.from[id];
}

var USDateFormat = "MM/dd/yyyy";

function convertDateStr(dt, oldPattern, newPattern)
{
  if (!dt) return dt;
  
  var calendar;
  if (document.applets["calendar_hidden"] && document.applets["calendar_hidden"].object)
    calendar = document.applets["calendar_hidden"].object;
  else
    calendar = top.aras.calendar;
  calendar.FormatStr = oldPattern;
  calendar.SetDate(dt);
  calendar.FormatStr = newPattern;
  
  var res = calendar.GetDate();
  
  return res;
}

function getDatePropertyPattern(itemTypeName, propertyName)
{
  switch (propertyName)
  {
    case "plan_finish":
      if (itemTypeName == "WBS Element") propertyName = "rollup_date_sched_due";
      else propertyName = "date_due_sched";
      break;
    
    case "plan_start":
      if (itemTypeName == "WBS Element") propertyName = "rollup_date_sched_start";
      else propertyName = "date_start_sched";
      break;
  }

  var it = top.aras.getItemTypeForClient(itemTypeName).node;
  if (!it) return USDateFormat;
  
  var propNd = it.selectSingleNode("Relationships/Item[@type='Property' and name='" + propertyName + "']");
  if (!propNd) return USDateFormat;
  
  var res = top.aras.getItemProperty(propNd, "pattern");
  if (!res) return USDateFormat;
  
  return res;
}
