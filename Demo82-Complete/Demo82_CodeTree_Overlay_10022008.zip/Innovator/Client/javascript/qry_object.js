﻿// © Copyright by Aras Corporation, 2004-2007.

function QryItem(arasObj, itemTypeName) {
  this.arasObj   = arasObj;
  this.dom       = arasObj.createXMLDocument();
	if (itemTypeName) this.itemTypeName = itemTypeName;
	
	this.initQry(this.itemTypeName);
}

QryItem.prototype.dom  = null;
QryItem.prototype.item = null;
QryItem.prototype.itemTypeName = '';
QryItem.prototype.response = null;
QryItem.prototype.result   = null;

/*
*/
QryItem.prototype.initQry = function QryItem_initQry(itemTypeName, preservePrevResults) {
	if (preservePrevResults == undefined) preservePrevResults = false;
	
	this.itemTypeName = itemTypeName;
	this.dom.loadXML('<Item type="'+this.itemTypeName+'" action="get" />')
  this.item = this.dom.documentElement;
	
	if (!preservePrevResults) {
		this.response  = new top.SOAPResults(this.arasObj, SoapConstants.EnvelopeBodyStart + '<Result />' + SoapConstants.EnvelopeBodyEnd);
		this.result = this.response.getResult();
	}
}

QryItem.prototype.setItemType = function QryItem_setItemType(itemTypeName) {
	if (this.itemTypeName == itemTypeName) return;
	
	this.initQry(itemTypeName, false);
}

/*
*/
QryItem.prototype.setCriteria = function QryItem_setCriteria(propertyName,value,condition) {
	if (condition == undefined) condition = 'eq';
	
	var criteria  = this.item.selectSingleNode(propertyName);
	if (!criteria) {
		criteria = this.dom.createElement(propertyName);
		this.item.appendChild(criteria);
	}
	
	criteria.text = value;
	criteria.setAttribute('condition',condition);
}

QryItem.prototype.setPropertyCriteria = function QryItem_setPropertyCriteria(propertyName, critName, value, condition) {
	if (condition == undefined) condition = 'eq';
	
	var criteria  = this.item.selectSingleNode(propertyName);
	if (!criteria) {
		criteria = this.dom.createElement(propertyName);
		this.item.appendChild(criteria);
	}
	
	var itm = criteria.selectSingleNode('Item');
	if (!itm) {
		itm = this.dom.createElement('Item');
		criteria.text = '';
		criteria.appendChild(itm);
	}
	
	criteria = itm.selectSingleNode(critName);
	if (!criteria) {
		criteria = this.dom.createElement(critName);
		itm.appendChild(criteria);
	}
	
	criteria.text = value;
	criteria.setAttribute('condition',condition);
}

QryItem.prototype.setRelationshipCriteria = function QryItem_setRelationshipCriteria(relType, propertyName, value, condition) {
	if (condition == undefined) condition = 'eq';
	
	var rels = this.item.selectSingleNode('Relationships');
	if (!rels) {
		rels = this.dom.createElement('Relationships');
		this.item.appendChild(rels);
	}
	
	var itm = rels.selectSingleNode('Item[@type="'+relType+'"]');
	if (!itm) {
		itm = this.dom.createElement('Item');
		rels.appendChild(itm);
		itm.setAttribute('type', relType);
		itm.setAttribute('action', 'get');
	}
	
	var criteria  = itm.selectSingleNode(propertyName);
	if (!criteria) {
		criteria = this.dom.createElement(propertyName);
		itm.appendChild(criteria);
	}
	
	criteria.text = value;
	criteria.setAttribute('condition',condition);
}

QryItem.prototype.setRelationshipPropertyCriteria = function QryItem_setRelationshipPropertyCriteria(relType, propertyName, critName, value, condition) {
	if (condition == undefined) condition = 'eq';
	
	var rels = this.item.selectSingleNode('Relationships');
	if (!rels) {
		rels = this.dom.createElement('Relationships');
		this.item.appendChild(rels);
	}
	
	var itm = rels.selectSingleNode('Item[@type="'+relType+'"]');
	if (!itm) {
		itm = this.dom.createElement('Item');
		rels.appendChild(itm);
		itm.setAttribute('type', relType);
		itm.setAttribute('action', 'get');
	}
	
	var tmpCrit  = itm.selectSingleNode(propertyName);
	if (!tmpCrit) {
		tmpCrit = this.dom.createElement(propertyName);
		itm.appendChild(tmpCrit);
	}
	
	itm = tmpCrit.selectSingleNode('Item');
	if (!itm) {
		itm = this.dom.createElement('Item');
		tmpCrit.appendChild(itm);
	}
	
	var criteria  = itm.selectSingleNode(critName);
	if (!criteria) {
		criteria = this.dom.createElement(critName);
		itm.appendChild(criteria);
	}
	
	criteria.text = value;
	criteria.setAttribute('condition', condition);
}

QryItem.prototype.setRelationshipSearchOnly = function(relType) {
	var itm = this.item.selectSingleNode('Relationships/Item[@type="'+relType+'"]');
  if (itm) itm.setAttribute('search_only','yes');
}


QryItem.prototype.setOrderBy = function(orderBy) {
  this.item.setAttribute('order_by',orderBy);
}

QryItem.prototype.setMaxGeneration = function(maxGeneration) {
  var flag = (maxGeneration) ? "1" : "0";
  this.item.setAttribute('max_generation',flag);
}

QryItem.prototype.setLevels = function(levels) {
  this.item.setAttribute('levels',levels);
}

QryItem.prototype.setSelect = function(select) {
  this.item.setAttribute('select',select);
}

QryItem.prototype.setConfigPath = function(configPath) {
  this.item.setAttribute('config_path',configPath);
}

QryItem.prototype.setPage = function(page) {
  this.item.setAttribute('page',page);
}

QryItem.prototype.getPage = function(page) {
  var page = this.item.getAttribute('page');
	if (page == null) page = '';
	return page;
}

QryItem.prototype.setPageSize = function(pageSize) {
  this.item.setAttribute('pagesize',pageSize);
}

QryItem.prototype.setMaxRecords = function(maxRecords) {
  this.item.setAttribute('maxRecords', maxRecords);
}

QryItem.prototype.setItemID = function(id) {
  this.item.setAttribute('id',id);
}

QryItem.prototype.getResponse = function() {
	return this.response;
}

QryItem.prototype.getResponseDOM = function() {
	return this.response.results;
}

QryItem.prototype.getResult = function() {
	return this.result;
}

QryItem.prototype.getResultDOM = function() {
	return this.result.ownerDocument;
}

QryItem.prototype.removeCriteria = function QryItem_removeCriteria(propertyName) {
  if (!propertyName) return;
  
  var criteria = this.item.selectSingleNode(propertyName);
	if (criteria) criteria.parentNode.removeChild(criteria);
}

QryItem.prototype.removePropertyCriteria = function QryItem_removePropertyCriteria(propertyName, critName) {
  var criteria = this.item.selectSingleNode(propertyName+'/Item/'+critName);
	if (criteria) {
		var itm = criteria.parentNode;
		itm.removeChild(criteria);
		if (!itm.selectSingleNode('.//*[.!="Relationships"]')) {
			this.removeCriteria(propertyName);
		}
	}
	else {
		var itm = this.item.selectSingleNode(propertyName+'/Item');
		if (!itm || !itm.selectSingleNode('.//*[.!="Relationships"]'))
			this.removeCriteria(propertyName);
	}
}

QryItem.prototype.removeRelationshipCriteria = function QryItem_removeRelationshipCriteria(relType, propertyName) {
  var criteria = this.item.selectSingleNode('./Relationships/Item[@type="'+relType+'"]/'+propertyName);
	if (criteria) {
		var itm = criteria.parentNode;
		itm.removeChild(criteria);
		if (!itm.selectSingleNode('.//*[.!="Relationships"]'))
			itm.parentNode.removeChild(itm);
	}
}

QryItem.prototype.removeRelationshipPropertyCriteria = function QryItem_removeRelationshipPropertyCriteria(relType, propertyName, critName) {
  var criteria = this.item.selectSingleNode('./Relationships/Item[@type="'+relType+'"]/'+propertyName+'/Item/'+critName);
	if (criteria) {
		var itm = criteria.parentNode;
		itm.removeChild(criteria);
		if (!itm.selectSingleNode('.//*[.!="Relationships"]')) {
			var parentCrit = itm.parentNode;
			parentCrit.removeChild(itm);
			this.removeRelationshipCriteria(propertyName);
		}
	}
	else {
		var itm = this.item.selectSingleNode('./Relationships/Item[@type="'+relType+'"]/'+propertyName+'/Item');
		if (!itm || !itm.selectSingleNode('.//*[.!="Relationships"]'))
			this.removeRelationshipCriteria(relType, propertyName);
	}
}

QryItem.prototype.removeAllCriterias = function QryItem_removeAllCriterias() {
	this.dom.documentElement = this.item.cloneNode(false);
	this.item = this.dom.documentElement;
}

QryItem.prototype.execute = function QryItem_execute(savePrevResults, soapController)
{
  if (savePrevResults === undefined) savePrevResults = (this.arasObj.getVariable('AppendItems')=='true');
  this.savePrevResults = savePrevResults;
  
  var res = this.arasObj.soapSend('ApplyItem', this.dom.xml, undefined, undefined, soapController);
  if (soapController) return;
  
  this.setResponse(res);
  
  return this.result;
}

QryItem.prototype.setResponse = function QryItem_setResponse(res)
{
  if (res.getFaultCode()!=0)
  {
    this.arasObj.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
    this.result = undefined;
    return;
  }

  this.response = res;

  if (this.savePrevResults)
  {
    res = res.getResult();
    var fromServer = res.selectNodes('Item');
    for (var i=0; i<fromServer.length; i++)
    {
      var oldItm = this.result.selectSingleNode('Item[@id="'+fromServer[i].getAttribute('id')+'"]');
      if (oldItm) oldItm.parentNode.replaceChild(fromServer[i].cloneNode(true), oldItm);
      else this.result.appendChild(fromServer[i].cloneNode(true));
    }
  }
  else this.result = res.getResult();
}

QryItem.prototype.syncWithClient = function QryItem_syncWithClient() {
	var res = this.getResult();
	var prevResults = res.selectNodes('Item[@isTemp="1" or @isDirty="1"]');
	for (var i=0; i<prevResults.length; i++) res.removeChild(prevResults[i]);
	
	var clientItems = top.aras.dom.selectNodes('/Innovator/Items/Item[@type="' + this.itemTypeName + '"]');
  
	for (var i=0; i<clientItems.length; i++) {
    var clientItem = clientItems(i);
    var isTempOrDirty = ((clientItem.getAttribute("isTemp") == "1") || (clientItem.getAttribute("isDirty") == "1"));
    
    var fromServer = res.selectSingleNode('Item[@id="' + clientItem.getAttribute('id') + '"]');
    
    if (isTempOrDirty) {
  		if (fromServer) res.replaceChild(clientItem.cloneNode(true), fromServer);
  		else res.appendChild(clientItem.cloneNode(true));
    }
    else {
      //to resolve IR-002881: Erroneous caching of the lifecycle state
      if (fromServer) {
        if ( !top.aras.isLockedByUser(clientItem) ) clientItem.parentNode.removeChild(clientItem);
      }
    }
	}
}

QryItem.prototype.setConditionEverywhere = function(condition)
{
  var condition_tags = this.item.selectNodes("//*[@condition!='"+condition+"']");
  for(var i=0;i<condition_tags.length;i++)
  {
    condition_tags.item(i).setAttribute('condition',condition);
  }
}


QryItem.prototype.replaceConditionEverywhere = function(condition1, condition2)
{
  var condition_tags = this.item.selectNodes("//*[@condition='"+condition1+"']");
  for(var i=0;i<condition_tags.length;i++)
  {
    condition_tags.item(i).setAttribute('condition',condition2);
  }
}

/*
blockName - 'or' or 'and'
*/
/*
QryItem.prototype.createConditionBlock = function QryItem_createConditionBlock(blockName) {
	var b = this.dom.createElement(blockName);
	this.item.appendChild(b);
	return b;
}

QryItem.prototype.addCondition2Block = function QryItem_addCondition2Block(block, propertyName, value, condition) {
  var criteria  = block.selectSingleNode(propertyName);
	if (!criteria) {
		criteria = this.dom.createElement(propertyName);
		this.item.appendChild(criteria);
	}
	
  criteria.text = value;
  if (condition != undefined) criteria.setAttribute('condition',condition);
}
*/

QryItem.prototype.setItemAttribute = function QryItem_setItemAttribute(name, value) {
  this.item.setAttribute(name, value);
}

QryItem.prototype.removeItemAttribute = function QryItem_removeItemAttribute(name) {
  this.item.removeAttribute(name);
}