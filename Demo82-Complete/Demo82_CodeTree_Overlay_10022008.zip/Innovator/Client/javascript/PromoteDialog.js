﻿/*
This file contains logic common for all "promote dialogs":
PromoteDialog.html, LifeCycleDialog.html

Part 1. Initialization.
*/
returnValue = null;

var aras = dialogArguments.aras;
var item = dialogArguments.item;
var itemID = item.getAttribute('id');
var itemTypeName = item.getAttribute('type');

aras = new Aras(aras);//create new Aras object

document.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"../styles/default.css\">");

var getComments= new Array();
var soapController;

/*
handler for async promote request.
Called when promote is finished.
*/
function whenPromoteFinish(res)
{
  soapController = null;
  
  if (!res) returnValue = 'null';
  else
  {
    res = top.aras.soapSend("ApplyItem", "<Item type='" + itemTypeName + "' id='" + itemID + "' action='get' />");
    if (res)
    {
      res = res.getResult();
      if (res) res = res.selectSingleNode("Item");
    }
    returnValue = res;
  }
  
  window.close();
}

/*
Promotes item to the specified state with the specified comments
*/
function promoteWithComments(stateName, comments) {
  if (comments === null)
  {
    toolbar.getActiveToolbar().getElement("promote").setEnabled(true);
    return false;
  }
  
  soapController = new SoapController(whenPromoteFinish);
  aras.promoteEx(item, stateName, comments, soapController);
}


onbeforeunload = function onbeforeunload_handler()
{
  if (soapController)
  {
    return "Promote is not finished yet.\n" +
      "It is recommended that You wait untill promote is finished.";
  }
}

onunload = function onunload_handler()
{
  if (soapController) soapController.markInvalid();
}
