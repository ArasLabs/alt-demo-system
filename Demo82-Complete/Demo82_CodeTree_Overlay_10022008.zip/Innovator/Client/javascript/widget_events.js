﻿// © Copyright by Aras Corporation, 2004-2007.

function menubarOnClick(item)  {top.aras.widgetOnShow(item.getId())}
function menubarOnClick(item)  {top.aras.widgetOnClick(item.getId())}
function menubarOnChange(item) {top.aras.widgetOnChange(item.getId())}
function toolbarOnClick(item)  {top.aras.widgetOnClick(item.getId())}
function toolbarOnChange(item) {top.aras.widgetOnChange(item.getId())}
function tabbarOnSelect(id)    {top.aras.widgetOnSelect(id)}
function tabbarOnUnselect(id)  {top.aras.widgetOnUnselect(id)}
function treeOnClick(id)       {top.aras.widgetOnClick(id)}
function treeOnDoubleClick(id) {top.aras.widgetOnClick(id)}
function treeOnClickCheckbox(item,state) {alert(item,state)}
function treeOnClickMenu(item,menu_item) {alert(item,menu_item)}
function treeOnBeforeOpenMenu(item,menu) {alert(item,menu)}
