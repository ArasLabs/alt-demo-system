﻿// © Copyright by Aras Corporation, 2004-2007.

/*-- newWorkflowMap
 *
 *   Method to create a new workflow map
 *
 */
Aras.prototype.newWorkflowMap = function() {
  with (this) {
    var statusId = showStatusMessage(0, '   Creating new Workflow Map...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('ApplyItem', '<Item type="Method" action="New Workflow Map"/>');
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var item = res.results.selectSingleNode(top.aras.XPathResult('/Item'));
    item.setAttribute('levels', 2);
    item.setAttribute('loaded','1');
    item.setAttribute('isTemp','1');
    var itemID = item.getAttribute('id')
    var domNodes = dom.selectSingleNode('/Innovator/Items');
    item = domNodes.appendChild(item.cloneNode(true));
    return item;
  }
}


/*-- initiateWorkflow
 *
 *   Method to initiate a new workflow process
 *   workflowMapID   = the id for the Workflow Map to be used as a template
 *   item           = the item for which new workflow process should be created
 *
 */
Aras.prototype.initiateWorkflow = function(workflowMapID, item)
{
  with (this)
  {
    var statusId = showStatusMessage(0, '   Initiating Workflow...','../images/Animated/ProgressSmall.gif');

    var body = '<WorkflowMap>' + workflowMapID + '</WorkflowMap>' +
               '<Item type="' + item.getAttribute('type') +
               '" id="' + item.getAttribute('id') + '" />';

    var res = soapSend('InitiateWorkflow', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0)
    {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var process = res.results.selectSingleNode('//Item');
    process.setAttribute('levels','1');
    process.setAttribute('loaded','1');

    var workflow = newRelationship(getItemFromServerByName('RelationshipType','Workflow', 'id').getID(),item);
    var related_id = workflow.selectSingleNode('related_id');
    related_id.replaceChild(process.cloneNode(true),related_id.selectSingleNode('Item'));
    setNodeElement(workflow, 'source_type', getItemFromServerByName('ItemType',item.getAttribute('type'),'id').getID());
    return true;
  }
}


/*-- startWorkflow
 *
 *   Method to start the workflow process
 *   workflowProcess  = the workflow process that should be started
 *
 */
Aras.prototype.startWorkflow = function(workflowProcess) {
  with (this) {
    var statusId = showStatusMessage(0, '   Starting Workflow process...','../images/Animated/ProgressSmall.gif');
    var body = '<Item type="Workflow Process" id="'+workflowProcess.getAttribute('id')+'" action="StartWorkflow"/>';
    var res = soapSend('ApplyItem', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0)
    {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var result = res.results.selectSingleNode(top.aras.XPathResult());
    if (result.text != 'Ok') return false;
    else return true;
  }
}


/*-- stopWorkflow
 *
 *   Method to stop the workflow process
 *   workflowProcess  = the workflow process that should be stopped
 *
 */
Aras.prototype.stopWorkflow = function(workflowProcess) {
  with (this) {
    var statusId = showStatusMessage(0, '   Starting Workflow process...','../images/Animated/ProgressSmall.gif');
    var body = '<Item type="Workflow Process" id="' +
               workflowProcess.getAttribute('id') + '" action="StopWorkflow" />';
    var res = soapSend('ApplyItem', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var result = res.results.selectSingleNode(top.aras.XPathResult());
    if (result.text != 'Ok') return false;
    else return true;
  }
}


/*-- activateActivity
 *
 *   Method to activate the activity
 *   activity  = the activity to be activated
 *
 */
Aras.prototype.activateActivity = function(activity) {
  with (this) {
    var statusId = showStatusMessage(0, '   Activating activity...','../images/Animated/ProgressSmall.gif');
    var body = '<Item type="Activity" id="' +
               activity.getAttribute('id') + '" action="ActivateActivity" />';
    var res = soapSend('ApplyItem', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var result = res.results.selectSingleNode(top.aras.XPathResult());
    if (result.text != 'Ok') return false;
    else return true;
  }
}


/*-- evaluateActivity
 *
 *   Method to close the activity
 *   activity  = the activity to be closed
 *   path      = path that should be followed
 *
 */
Aras.prototype.evaluateActivity = function(body) {
  with (this) {
    var statusId = showStatusMessage(0, '   Closing activity...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('EvaluateActivity', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var result = res.results.selectSingleNode(top.aras.XPathResult());
    if (result.text != 'Ok') return false;
    else return true;
  }
}


/*-- getAssignedActivities
 *
 *   Returns the Active and Pending Activity items for the user.
 *   The users Activities are those assigned to an Identity for which the user is a Member
 *
 */
Aras.prototype.getAssignedActivities = function(inBasketViewMode) {
  with (this) {
    var body = '<inBasketViewMode>' + inBasketViewMode + '</inBasketViewMode>'
    var statusId = showStatusMessage(0, '   Getting user activities...','../images/Animated/ProgressSmall.gif');
    var res = soapSend('GetAssignedActivities', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

//    var items = res.results.selectNodes(top.aras.XPathResult('/Item'));
//    for (var i=0; i<items.length; ++i) {
//      var item = items(i);
//      item.setAttribute('levels', '0');
//      var itemID = item.getAttribute('id')
//      var xpath = '/Innovator/Items/Item[@id="' + itemID + '"]';
//      if (!dom.selectSingleNode(xpath)) {
//        var domNodes = dom.selectSingleNode('/Innovator/Items');
//        domNodes.appendChild(item.cloneNode(true));
//      }
//      else updateDOM(xpath, item.xml, 0);
//    }

   return res.results.selectNodes(top.aras.XPathResult('/Item'));

  }
}

/*-- loadProcessInstance
 *
 *   Returns an applet ready XML string ofthe running workflow instance.
 *
 */
Aras.prototype.loadProcessInstance = function Aras_loadProcessInstance(ProcessId,ActivityId) {
  var statusId = this.showStatusMessage(0, "   Loading process map...", "../images/Animated/ProgressSmall.gif");
  
  var body = "<Item type=\"Workflow Process\" pid=\"" + ProcessId + "\" aid=\"" + ActivityId + "\"  />";
  var res = this.soapSend("LoadProcessInstance", body);
  if (statusId != -1) this.clearStatusMessage(statusId);
  
  if (res.getFaultCode()!=0) {
    this.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
    return false;
  }
  
  return res.results;
}

/*-- BuildProcessReport
 *
 *   Returns an HTML string ofthe running workflow instance - sign-off History
 *
 */
Aras.prototype.BuildProcessReport = function(ProcessId) {
  with (this) {

    var statusId = showStatusMessage(0, '   Loading process statistics...','../images/Animated/ProgressSmall.gif');
    var body = '<Item type="Workflow Process" id="' + ProcessId + '" />';
    var res = soapSend('BuildProcessReport', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results;
  }
}


/*-- StartDefaultWorkflow
 *
 *   Finds the Default Workflow Map for the passed itemType and instance,   and
 *   creates an instance of that Workflow and starts it.
 *
 */
Aras.prototype.StartDefaultWorkflow = function(ItemId, ItemType, ItemTypeId) {
  with (this) {

    var statusId = showStatusMessage(0, '   Starting the Default Workflow...','../images/Animated/ProgressSmall.gif');
    var body = '<Item id="' + ItemId + '"  type="' + ItemType + '" typeId="' + ItemTypeId + '" />';
    var res = soapSend('StartDefaultWorkflow', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results;
  }
}


/*-- StartNamedWorkflow
 *
 *   Starts an instance of a Workflow for a specified item
 *   WorkflowMap ID and the Item ID must be passed as arguments
 *
 */
Aras.prototype.StartNamedWorkflow = function(ItemId, ItemType, ItemTypeId, WorkflowMapId) {
  with (this) {

    var statusId = showStatusMessage(0, '   Starting the named Workflow...','../images/Animated/ProgressSmall.gif');
    var body = '<Item id="' + ItemId + '"  type="' + ItemType + '" typeId="' + ItemTypeId + '" WorkflowMapId="' + WorkflowMapId + '" />';
    var res = soapSend('StartNamedWorkflow', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results;
  }
}

/*-- ReAssignActivity
 *
 *   ReAssigns an Activity to a new Identity
 *   Activity ID and the Identity ID must be passed as arguments
 *
 */
Aras.prototype.ReAssignActivity= function(ActivityId, IdentityId) {
  with (this) {

    var statusId = showStatusMessage(0, '   ReAssigning the Activity...','../images/Animated/ProgressSmall.gif');
    var body = '<Item ActivityId="' + ActivityId + '"  IdentityId="' + IdentityId + '" />';
    var res = soapSend('ReAssignActivity', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results;
  }
}

/*-- ValidateVote
 *
 *   checks either the Password or E-Signature for a user
 *   Arguments are:  MD5 encrypted string +  "password" or esignature"
 *     returns      pass   or     fail
 */
Aras.prototype.ValidateVote= function(incoming, mode) {
  with (this) {

    var statusId = showStatusMessage(0, '   Validating your authentication...','../images/Animated/ProgressSmall.gif');
    var body = '<Item incoming="' + incoming + '" mode="' + mode + '" />';
    var res = soapSend('ValidateVote', body);
    if (statusId != -1) clearStatusMessage(statusId);

    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results;
  }
}
