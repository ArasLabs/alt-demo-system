﻿// (c) Copyright by Aras Corporation, 2007.

/// <summary>
/// Implements <see cref="IServerConnection"/>
/// </summary>
function InnovatorServerConnector(parentArasObj)
{
  this.parentArasObj = parentArasObj;
  if (!this.parentArasObj) this.parentArasObj = top.aras;
}

/// <summary>
/// Call the specified action on Innovator Server.
/// </summary>
/// <param name="actionName">
/// Action name.
/// </param>
/// <param name="inDOM">
/// <see cref="ArasXmlDocument"/> containing AML to send to Innovator Server.
/// </param>
/// <param name="outDOM">
/// <see cref="ArasXmlDocument"/> containing AML response from Innovator Server.
/// </param>
InnovatorServerConnector.prototype.CallAction = function InnovatorServerConnector_CallAction(action, inDom, outDom)
{
  var cachedItem = null;
  var tmpNd = inDom.documentElement;
  
  if (tmpNd.baseName == "Item")
  {
    var curAction = tmpNd.getAttribute("action");
    if (curAction == "purge" || curAction == "delete" || curAction == "update" || curAction == "version" || curAction == "add")
    {
      var iomCache = new IOMCache(this.parentArasObj);
      cachedItem = iomCache.apply(tmpNd);
    }
  }
  
  if (cachedItem != null)
  {
    outDom.loadXML("<Result>" + cachedItem.xml + "</Result>");
  }
  else
  {
    var res = this.parentArasObj.soapSend(action, inDom.xml);
    outDom.loadXML(res.getResponseText());
  }
}

/// <summary>
/// 
/// </summary>
/// <param name="reason"></param>
/// <param name="msg"></param>
InnovatorServerConnector.prototype.DebugLog = function InnovatorServerConnector_DebugLog(reason, msg)
{
  throw new Error(1, "Method DebugLog is not implemented");
}

/// <summary>
/// 
/// </summary>
/// <returns></returns>
InnovatorServerConnector.prototype.DebugLogP = function InnovatorServerConnector_DebugLogP()
{
  throw new Error(1, "Method DebugLogP is not implemented");
}

/// <summary>
/// Returns name of the current database in use.
/// </summary>
/// <returns></returns>
InnovatorServerConnector.prototype.GetDatabaseName = function InnovatorServerConnector_GetDatabaseName()
{
  return this.parentArasObj.getDatabase();
}

/// <summary>
/// 
/// </summary>
/// <param name="key"></param>
/// <returns></returns>
InnovatorServerConnector.prototype.GetFromCache = function InnovatorServerConnector_GetFromCache(key)
{
  throw new Error(1, "Method GetFromCache is not implemented");
}

/// <summary>
/// 
/// </summary>
/// <param name="name"></param>
/// <param name="defaultvalue"></param>
/// <returns></returns>
InnovatorServerConnector.prototype.GetOperatingParameter = function InnovatorServerConnector_GetOperatingParameter(name, defaultvalue)
{
  throw new Error(1, "Method GetOperatingParameter is not implemented");
}

/// <summary>
/// Returns id of current logged in Innovator user. Throws exception if there is no logged in user.
/// </summary>
/// <returns></returns>
InnovatorServerConnector.prototype.GetUserId = function InnovatorServerConnector_GetUserId()
{
  return this.parentArasObj.getUserID();
}

/// <summary>
/// 
/// </summary>
/// <returns></returns>
InnovatorServerConnector.prototype.GetSrvContext = function InnovatorServerConnector_GetSrvContext()
{
  throw new Error(1, "Method GetSrvContext is not implemented");
}

/// <summary>
/// 
/// </summary>
/// <param name="key"></param>
/// <param name="value"></param>
/// <param name="path"></param>
InnovatorServerConnector.prototype.InsertIntoCache = function InnovatorServerConnector_InsertIntoCache(key, value, path)
{
  throw new Error(1, "Method InsertIntoCache is not implemented");
}


function IOMCache(parentArasObj)
{
  this.arasObj = parentArasObj;
}


IOMCache.prototype.apply = function IOMCache_apply(itemNd)
{
  if (!itemNd) return null;
  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var itemAction = itemNd.getAttribute('action');
  if (itemAction == null) itemAction = '';
  
  var win = this.arasObj.uiFindWindowEx2(itemNd);
  
  //special checks for the item of ItemType type
  // <name> tag in itemNd required for next call
  var res;
  if (itemTypeName=='ItemType') res = this.arasObj.checkItemType(itemNd, win);
  else res = true;
  
  if (!res) return null;
  
  if (itemTypeName)
  {
    if (itemAction == 'delete')
    {
      this.arasObj.deleteItem(itemTypeName, itemID, true);
      return null;
    }
    else if (itemAction == 'purge')
    {
      this.arasObj.purgeItem(itemTypeName, itemID, true);
      return null;
    }
  }
  
  //general checks for the item to be saved: all required parameters should be set
  if (itemTypeName) res = this.arasObj.checkItem(itemNd, win);
  else res = true;
  
  if (!res) return null;
  
  res = null;
  
  //14.02.2004 - SNNicky: removed from prepareItem4Save because should modify node before backup
  // (adds Files nodes into the Item node)
  this.arasObj.checkFileProps(itemNd);
  
  var backupCopy = itemNd;
  var oldParent = backupCopy.parentNode;
  itemNd = itemNd.cloneNode(true);
  this.arasObj.prepareItem4Save(itemNd);
  this.arasObj.codeMd5Fields(itemNd);
  
  var isTemp = this.arasObj.isTempEx(itemNd);
    
  if (itemNd.getAttribute('action') == 'add')
  {
    if (itemTypeName == 'RelationshipType')
    {
      if (!itemNd.selectSingleNode('relationship_id/Item'))
      {
        var rsItemNode = itemNd.selectSingleNode('relationship_id');
        if (rsItemNode)
        {
          var rs = this.arasObj.getItemById('', rsItemNode.text, 0);
          if (rs)
          {
            rsItemNode.text = '';
            rsItemNode.appendChild(rs.cloneNode(true));
          }
        }
      }
      var tmp001 = itemNd.selectSingleNode('relationship_id/Item');
      if (tmp001 && this.arasObj.getItemProperty(tmp001, 'name')=='')
        this.arasObj.setItemProperty(tmp001, 'name', this.arasObj.getItemProperty(itemNd, 'name'));
    }
  }
    
  var files = itemNd.selectNodes('descendant-or-self::Item[@type="File" and (@action="add" or @action="update")]');

  if (files.length == 0)
  {
    res = this.arasObj.soapSend('ApplyItem', itemNd.xml);
    if (res.getFaultCode()!=0)
    {
      return null;
    }
    res = res.results.selectSingleNode(this.arasObj.XPathResult('/Item'));
  }
  else
  {
    res = this.arasObj.sendFilesWithVaultApplet(itemNd, 'Sending of File to Vault...');
  }//else if (files.length==0)
  
  if (!res) return null;
  res.setAttribute('levels', '0');
  
  var newID = res.getAttribute('id');
  this.arasObj.updateInCacheEx(backupCopy, res);
  
  if (itemTypeName == 'RelationshipType')
  {
    var relationship_id = this.arasObj.getItemProperty(itemNd, 'relationship_id');
    if (relationship_id) this.arasObj.removeFromCache(relationship_id);
    this.arasObj.commonProperties.formsCacheById = newObject();
  }
  else if (itemTypeName == 'ItemType')
  {
    var item_name = this.arasObj.getItemProperty(itemNd, 'name');
    delete this.arasObj.sGridsSetups[item_name];
    delete this.arasObj.items2gridXSL[itemID];
    this.arasObj.commonProperties.formsCacheById = newObject();

//      var _itemTypeName_ = item_name.replace(/\s/g, '_');
    var varName_pagesize = 'IT_' + itemID + '_pageSize';
    var varName_colOrder = 'IT_' + itemID + '_colOrder';
    var varName_colWidths= 'IT_' + itemID + '_colWidths';
    var varName_search   = 'IT_' + itemID + '_search';
    var varName_searchVis= 'IT_' + itemID + '_searchVis';
    var varName_searchMode='IT_' + itemID + '_searchMode';
    
    this.arasObj.removeVariable(varName_pagesize);
    this.arasObj.removeVariable(varName_colOrder);
    this.arasObj.removeVariable(varName_colWidths);
    this.arasObj.removeVariable(varName_search);
    this.arasObj.removeVariable(varName_searchVis);
    this.arasObj.removeVariable(varName_searchMode);
  }
  
  if (oldParent) res = oldParent.selectSingleNode('Item[@id="'+newID+'"]');
  else res = this.arasObj.getFromCache(newID);
  if (!res) return null;
  
  if (newID != itemID)
  {
    var itms = this.arasObj.getAffectedItems(itemNd.getAttribute('type'), newID);
    
    if (itms) for (var i=0; i<itms.length; i++)
    {
      var itm = itms[i];
      var itmID = itm.getAttribute('id');
      var affectedItm = this.arasObj.getItemById('', itmID, 0);
      if (affectedItm)
      {
        if (affectedItm.getAttribute('levels')==null) affectedItm.setAttribute('levels', 1);
        var tmpRes = this.arasObj.loadItems(itm.getAttribute('type'), 'id="' + itmID + '"', affectedItm.getAttribute('levels'));
        if (!tmpRes) continue;
        if (this.arasObj.uiFindWindowEx[itmID]) setTimeout("top.aras.uiReShowItem('"+itmID+"','"+itmID+"');", 100);
      }
    }
  }
  
  return res;
}

function Innovator() 
{
  return top.aras.newIOMInnovator();
}

function Item(itemTypeName, action, mode) 
{
  return top.aras.IomInnovator.newItem(itemTypeName, action);
}
