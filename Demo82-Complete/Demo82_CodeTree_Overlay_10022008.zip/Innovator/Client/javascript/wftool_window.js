﻿// (c) Copyright by Aras Corporation, 2004-2007.

function isTearOffMode() {
  if (top.isTearOff) return top.isTearOff;
  var isTearOff = (top.aras.getVariable('TearOff')=='true');
    var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  if( editor.currWFNode == undefined ) {
    editor = (!isTearOff ? document.frames['editor'] : top.main.work);
    if( editor.currWFNode != undefined ) return !isTearOff;
  }
  return isTearOff;
}

var menuFrame = (isTearOffMode() ? top.tearoff_menu : top.main.menu);

function updateItemsGrid (updatedItem) {
  var isTearOff = isTearOffMode();
  if (!updatedItem || !isTearOff) return false;
  var updatedID = updatedItem.getAttribute('id');

  with (top) {
    if (opener.main.work.isItemsGrid) {
      if (opener.main.work.itemTypeName==itemTypeName) {
        var gridApplet = opener.main.work.gridContainer;
        if (gridApplet.getRowIndex(itemID) > -1 ) {
          var wasSelected = (gridApplet.getSelectedItemIds(';').search(itemID) > -1);

          if (updatedID != itemID) opener.main.work.deleteRow(item);
          opener.main.work.updateRow(updatedItem);

          if (wasSelected) {
            if (updatedID == itemID) opener.main.work.onSelectItem(itemID);
            else {
              var currSel = gridApplet.getSelectedId();
              //if (currSel)
              opener.main.work.onSelectItem(currSel);
            }
          }//if (wasSelected)
        }
      }
    }//if (opener.main.work.isItemsGrid)
  }
}

function updateMenuState() {
  var isTearOff = isTearOffMode();
  if (isTearOff && document.frames['editor'] && document.frames['editor'].refreshMenuState) {
    document.frames['editor'].refreshMenuState();
  }
}

function onSaveAndCloseCommand() {
  return onSaveCommand();
}

function onSaveUnlockAndExitCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);

  var currWFNode = editor.currWFNode;
  update2Edit(currWFNode);

  var res = null;
  var currWFNode = editor.currWFNode;
  //replace all action="update" to "edit"
  var items = currWFNode.selectNodes("//Item[@action='update']");
  for (var i = 0; i < items.length; i++)
    if (items(i).getAttribute('type') != 'Workflow Map')
      items(i).setAttribute("action", "edit");

  with (editor) {
    var statusId;
    if (isTearOff) statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
    res = top.aras.saveItemEx(currWFNode, false);
    if (isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
    if (!res) return true;


    if (isTearOff) statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
    res = top.aras.unlockItemEx(res);
    if (isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
    if (!res) return true;
  }

  if (isTearOff) {
    updateItemsGrid(res);
    window.close();
  }

  return true;
}

/* replace all action="update" to "edit" */
function update2Edit(currWFNode) {
  var items = currWFNode.selectNodes("//Item[@action='update']");
  for (var i = 0; i < items.length; i++)
    if (items(i).getAttribute('type') != 'Workflow Map')
      items(i).setAttribute("action", "edit");
}

function onSaveCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);

  var currWFNode = editor.currWFNode;
  update2Edit(currWFNode);

  var statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
  var res = top.aras.saveItemEx(currWFNode);
  top.aras.clearStatusMessage(statusId);
  if (!res) return true;
  if (isTearOff) updateItemsGrid(res);
  unlockChildRelatedItems(res);

  window.system_res = res;
  window.setTimeout("top.aras.uiReShowItemEx("+(isTearOff ? "document.frames['editor']":"top.main.work")+".currWFNode.getAttribute(\"id\"), window.system_res,'');", 1);

  return true;
}

function unlockChildRelatedItems(currWorkflow)
{
  var workflowId = currWorkflow.getAttribute("id")
  var b = isEditMode;
  var q = new Item();
  q.loadAML(
    "<Item type='Workflow Map Activity' related_expand='0' select='related_id' action='get'>" +
      "<source_id>" + workflowId + "</source_id>" +
      "<related_id>" +
        "<Item type='Activity Template'>" +
          "<locked_by_id condition='is not null'/>" +
        "</Item>" +
      "</related_id>" +
    "</Item>");
  var r = q.apply();
  if ( !r.isError() )
  {
    var n = r.getItemCount();
    for (var i=0; i<n; i++)
    {
      var t = r.getItemByIndex(i);
      q.loadAML(
        "<Item type='Activity Template' id='" + t.getProperty("related_id") + "' " +
          "action='unlock' />");
      q.apply();
    }
  }
}


function updateRootItem(itemNd) {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  editor.currWFID = itemNd.getAttribute("id");
  editor.setEditMode();
}

function updateRootItem2(itemNd) {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  editor.currWFNode = itemNd;
}

function onUnlockCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);

  var currWFNode = editor.currWFNode;
  update2Edit(currWFNode);

  var res = top.aras.unlockItemEx(editor.currWFNode);
  if (res) {
    editor.setViewMode();
    if (isTearOff) updateItemsGrid(res);
  }

}

function onUndoCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);

  with (editor) {
    if (!top.aras.isDirtyEx(currWFNode)) {
      top.aras.AlertError('Nothing to undo.');
      return true;
    }

    if (!confirm('Undo will discard your changes. Are you sure?')) return true;

    unlockChildRelatedItems(currWFNode);
    top.aras.removeFromCache(currWFID);
    setEditMode();
  }

  return true;
}

function onLockCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  var res = top.aras.lockItemEx(editor.currWFNode);
  if (res) {
    editor.setEditMode();
    if (isTearOff) updateItemsGrid(res);
  }
}



var __frameShowStr = undefined;
function getNoTabsCorrectState() {
//returns current correct state
  return (__frameShowStr !== undefined);
}

function onNoTabsCommand() {
  var isTearOff = isTearOffMode();
  var activeToolbar = (isTearOff ? document.frames['tearoff_menu'] : top.main.menu).activeToolbar;
  var hideTabs = !getNoTabsCorrectState();
  menuFrame.setControlState("no_tabs", hideTabs);
  
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  var frameset = editor.document.getElementById("frameset");
  
  if (hideTabs) {
    __frameShowStr = frameset.attributes("rows").nodeValue;
    frameset.attributes("rows").nodeValue = __frameShowStr.replace(/,[^,]+,[^,]+$/, ",*,0");
  }
  else {
    frameset.attributes("rows").nodeValue = __frameShowStr;
    __frameShowStr = undefined;
  }
  
  editor.document.frames["tabs"].frameElement.noResize = hideTabs;
}


function onPurgeCommand() {
  return onPurgeDeleteCommand('purge');
}

function onDeleteCommand() {
  return onPurgeDeleteCommand('delete');
}

function onPurgeDeleteCommand(command)
{
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  var res = false;

  with (editor)
  {
    if (command == 'purge') res = top.aras.purgeItem('Workflow Map', currWFID, false);
    else res = top.aras.deleteItem('Workflow Map', currWFID, false);
  }

  if (res)
  {
    if (isTearOff)
    {
      window.close();
    }
    else
    {
      var wfIT = top.aras.getItemFromServerByName('ItemType', 'Workflow Map', 'id');
      if (wfIT) top.main.work.location.replace('itemsGrid.html?itemtypeID='+wfIT.getID());
      else top.main.work.location.replace('about:blank');
    }
  }

  if (isTearOff && opener.main.work.isItemsGrid && opener.main.work.itemTypeName==itemTypeName)
  {
    var gridApplet = opener.main.work.gridContainer;
    if (gridApplet.getRowIndex(itemID) > -1 ) gridApplet.deleteRow(itemID);
  }

  return true;
}

function onPrintCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  top.aras.uiShowItemEx(editor.currWFNode, 'print view', true);
  return true;
}

function onExport2OfficeCommand(targetAppType)
{
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  var itm = editor.currWFNode;
  if (itm)
  {
    top.aras.export2Office("", targetAppType, itm); 
  }
}

function onCloseCommand() {
  var isTearOff = isTearOffMode();
  var editor = (isTearOff ? document.frames['editor'] : top.main.work);
  var wfNd = editor.currWFNode;
  if (wfNd.selectSingleNode("//Item[@action='update' or @action='edit']") != null) {
    if (wfNd.getAttribute('isDirty')!='1') {
      wfNd.setAttribute('isDirty', '1');
      if ((wfNd.getAttribute('action') != 'add') && (wfNd.getAttribute('action') != 'create')) wfNd.setAttribute('action', 'edit');
    }
  }
  if (isTearOff) window.close();
  return true;
}

function onShowAccess() {
}

function onShowHistory() {
  var editmode = isEditMode ? 1 : 0;
  var url = 'historyGrid.html?ITName='+itemTypeName+'&itemID='+itemID+'&editMode=' + editmode + '&toolbar=1&where=dialog';
  var params = new Object;
  params.aras = top.aras;
  params.item = item;
  showModalDialog(url, params, 'dialogHeight:200px; dialogWidth:800px; status:0; help:0; resizable:yes; scroll:no;');
}

function onShowWhereUsed()
{
  var url = 'whereUsed.html?id=' + itemID + '&type_name=' + itemTypeName + '&curLy='+top.aras.getVariable("StructureLayout")+'&toolbar=1&where=dialog';
  var params = new Object;
  params.aras = top.aras;
  showModalDialog(url, params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0; resizable:yes; scroll:no;');
}

function onShowWorkflow()
{
  var editmode = isEditMode ? 1 : 0;
  var relTypeID = top.aras.getItemFromServerByName('RelationshipType', 'Workflow', 'id').getID();
  var url = 'relationships.html';
  var params = new Object;
  params.LocationSearch = '?db='+top.aras.getDatabase()+'&ITName='+itemTypeName+'&itemID='+itemID+'&relTypeID='+relTypeID+'&editMode='+editmode+'&tabbar=0&toolbar=1&where=dialog';
  params.aras = top.aras;
  params.item = item;
  showModalDialog(url, params, 'dialogHeight:500px; dialogWidth:750px; status:0; help:0; resizable:yes; scroll:no;');
}

function onShowLifeCycle()
{
  var url = 'LifeCycleDialog.html';
  var params = new Object;
  params.aras = top.aras;
  params.item = item;
  var res = showModalDialog(url, params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0; resizable:yes; scroll:no;');

  if (typeof(res)=='string' && res=='null')
  {
    deleteRowFromItemsGrid(itemID);

    window.close();
    return true;
  }
  if (!res) return true;

  if (isTearOff) updateItemsGrid(res);

  isEditMode = false;
  top.aras.uiReShowItemEx(itemID, res, '');
  return true;
}

var windowReady = true;

