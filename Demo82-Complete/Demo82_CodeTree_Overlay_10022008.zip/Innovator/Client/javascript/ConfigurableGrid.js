﻿/* Copyright by Aras Corporation, 2005-2007. */

/*
IMPORTANT NOTE: class methods and members not commented as "this is a public method" (member)
--------------  are not a part of public ConfigurableGrid API. Thus there is no guarantee
                that signature of such methods will not be changed in the future
                and even that such methods (members) will not be removed.
*/

// +++++ ConfigurableGrid prototype +++++
function ConfigurableGrid ( instanceName, cgridID, contextItemNd ) {
  this.isInitialized = false;
  
  if (!instanceName) return;
  if (!cgridID) return;
  if (!contextItemNd) return;
  
  // +++ constants
  this.inProgressImg = "../images/Animated/ProgressSmall.gif";
  // --- constants
  
  this.instanceName = instanceName;
  var msgId = top.aras.showStatusMessage(0, "Getting grid metadata...", this.inProgressImg);
  var res = top.aras.soapSend("GetConfigurableGridMetadata", "<Item type='Grid' id='" + cgridID+ "'/>");
  top.aras.clearStatusMessage(msgId);
  if (res.getFaultCode() > 0) {
    var resIOMError = (new Innovator()).newError( res.getFaultDetailsFull() );
    this.showError( resIOMError );
    return;
  }
  
  res = res.getResult();
  
  //+++setup grid definition
  var tmp = res.selectSingleNode("grid");
  res.removeChild(tmp);
  var r  = new Item();
  r.dom  = top.aras.createXMLDocument();
  r.node = r.dom.appendChild(tmp.selectSingleNode("Item"));
  //---setup grid definition
  
  //+++setup xslt
  tmp = res.selectSingleNode("xslt");
  res.removeChild(tmp);
  this.cachedXSLT = tmp.selectSingleNode("*").xml;
  //---setup xslt
  
  //+++setup columns xpaths and filter lists
  this.columnXPaths = new Array();
  this.cachedFilterLists = new Array();
  
  var lists = res.selectSingleNode("lists");
  
  tmp = res.selectSingleNode("columns");
  res.removeChild(tmp);
  tmp = tmp.selectNodes("column");
  this.columnNds = tmp;
  for (var i=0; i<tmp.length; i++) {
    var col = tmp.item(i);
    this.columnXPaths[i] = col.getAttribute("xpath");
    if (col.getAttribute("data_type") == "filter list") {
      var data_source = col.getAttribute("data_source");
      if (data_source) {
        var list = new Item();
        list.dom = lists.ownerDocument;
        list.node = lists.selectSingleNode("Item[@id='" + data_source + "']");
        this.cachedFilterLists[i] = list;
      }
    }
  }
  //---setup columns xpaths and filter lists
  
  this.gridDefinition = r;
  this.item_typeName = contextItemNd.getAttribute("type");
  this.item_id       = contextItemNd.getAttribute("id");
  this.auto_add_first_row  = top.aras.isTempEx(contextItemNd);
  this.isEditMode    = false;
  this.populateGridIsInProgress = false;
  this.cellValidationFailed = false;//this flag is used to return focus back (highlight) to edited cell
                                    //to indicate what cell value is invalid
                                    //this flag is reset to false in:
                                    // 1) on cell selection change (cell selection occurs inside onactivate also),
                                    // 2) during <Enter>, <Tab> and <Insert> processing
  this.preservedCellValue = "";
  this.lastEditableCellNum = undefined;
  
  this.predefinedEditResult = new Object();
  this.selectMethods    = new Object();
  
  this.copyByRefAttrNm = "copyByRef";
  
  this.cPropNmRE = /^(.*)\/([^\/]*)$/;//complex property name
  
  this.initHL_Cell();
  
  if (!this.item_typeName || !this.item_id) return;
  
  this.appletID = instanceName + "_" + cgridID;
  
  var nameSuffix = "$ConfigurableGrid$" + this.gridDefinition.getID() + "$" + this.instanceName;
  this.oncelledit_handler_name = "oncelledit" + nameSuffix;
  this.onkeypressed_handler_name = "onkeypressed" + nameSuffix;
  this.onselectcell_handler_name = "onselectcell" + nameSuffix;
  
  var oncelledit_handler   = new Function("mode", "id", "col",
                             "return " + this.instanceName + ".onCellEdit(mode, id, col);");
  var onkeypressed_handler = new Function("keyEvent",
                             "return " + this.instanceName + ".onKeyPressed(keyEvent);");
  var onselectcell_handler = new Function("cell",
                             "return " + this.instanceName + ".onSelectCell(cell);");
  
  window[this.oncelledit_handler_name]   = oncelledit_handler;
  window[this.onkeypressed_handler_name] = onkeypressed_handler;
  window[this.onselectcell_handler_name] = onselectcell_handler;
  
  // +++ finally setup topLeveleNode
  this.initTopLevelNode(contextItemNd);
  // --- finally setup topLeveleNode
}

ConfigurableGrid.prototype.initTopLevelNode = function ConfigurableGrid_initTopLevelNode(contextItemNd) {
  //this method is for internal purposes only.
  if (this.gridIsNotFunctional) return;
  
  var merge_path  = this.gridDefinition.getProperty("merge_path");
  var mergeInNode = contextItemNd;
  if (merge_path) {
    this.topLevelNode = mergeInNode.selectSingleNode(merge_path);
    if (!this.topLevelNode) {
      var doc = mergeInNode.ownerDocument;
      mergeInNode.appendChild(doc.createElement(merge_path));
    }
  }
  else {
    merge_path = "/AML";
    var storage = top.aras.createXMLDocument();
    storage.loadXML("<AML />");
    mergeInNode = storage;
  }
  
  this.topLevelNode = mergeInNode.selectSingleNode(merge_path);
}

ConfigurableGrid.prototype.start = function ConfigurableGrid_start() {
  //this method is for internal purposes only.
  var resHTML =
    "<object id=\"" + this.appletID + "\" style=\"width:100%; height:0px; visibility:hidden;\" " +
      "onbeforedeactivate=\"" + this.instanceName + ".saveInputtedData()\" " +
			"ondeactivate=\"" + this.instanceName + ".deactivateGrid()\" " +
			"onactivate=\"" + this.instanceName + ".activateGrid()\" " +
      "classId=\"../cbin/TreeTable.dll#Aras.Client.Controls.ExcelGrid\">" +
    "</object>" +
		"<script for=" + this.appletID + " event=GridStart(g)>" + this.instanceName + ".onGridAppletLoad();</script>"+
		"<script for=" + this.appletID + " event=GridKeyPress(k)>return " + this.instanceName + ".onKeyPressed(k);</script>"+
		"<script for=" + this.appletID + " event=GridXmlLoaded(b)>" + this.instanceName + ".onXmlLoaded();</script>"+
		"<script for=" + this.appletID + " event=GridEditCell(mode,id,col)>return " + this.instanceName + ".onCellEdit(mode,id,col);</script>"+
		"<script for=" + this.appletID + " event=GridSelectCell(c)>return " + this.instanceName + ".onSelectCell(c);</script>"+
""+
  "<object style=\"width:1px; height:1px;\" id=\"" + this.appletID + "_calendar\"  " +
    "classId=\"../cbin/calendar.dll#Aras.Client.Controls.Calendar\">" +
  "</object>";  
  document.write(resHTML);
  
  this.isInitialized = true;
}

ConfigurableGrid.prototype.initHL_Cell = function ConfigurableGrid_initHL_Cell() {
  //this method is for internal purposes only.
  this.hl_cell  = null;//highlighted cell
  this.hl_col   = -1;  //highlighted cell column index
  this.hl_rowId = null;//highlighted cell row id
}

ConfigurableGrid.prototype.onGridAppletLoad = function ConfigurableGrid_onGridAppletLoad() {
  //this method is for internal purposes only.
  this.isGridAppletLoaded = true;
}

// +++ just to fix IR-005000 "initial row should be created upon invoking new grid"
//         and for IR-005087 "Tab does nothing when at the last cell of a row in the grid"
function EmulateInsertPressed() {
  //this is for internal purposes only.
}

EmulateInsertPressed.prototype.getKeyCode = function EmulateInsertPressed_getKeyCode() {
  //this is for internal purposes only.
  var k_Insert = 45;
  
  return k_Insert;
}

EmulateInsertPressed.prototype.isShiftDown = function EmulateInsertPressed_isShiftDown() {
  //this is for internal purposes only.
  
  return false;
}
// --- just to fix IR-005000 "initial row should be created upon invoking new grid"
//         and for IR-005087 "Tab does nothing when at the last cell of a row in the grid"

ConfigurableGrid.prototype.onXmlLoaded = function ConfigurableGrid_onXmlLoaded () {
  //this method is for internal purposes only.
  this.onXmlLoaded2();
}

ConfigurableGrid.prototype.onXmlLoaded2 = function ConfigurableGrid_onXmlLoaded2 () {
  //this method is for internal purposes only.
  this.initHL_Cell();

  var a = this.getImplementationObject();
  if (!a) return;

  if (this.auto_add_first_row) {
    delete this.auto_add_first_row;
        
    if ( a.getRowsNum() == 0 ) {
      setTimeout(this.instanceName + ".addNewRootRow()", 1);
      this.populateGridIsInProgress = false;
      
      return;
    }
  }
  
  var c = (this.predefined_hl_cell === undefined) ? a.cells2(0, 0) : this.predefined_hl_cell;
  if (c) {
    this.predefined_hl_cell = null;
    
    if (this.lastEditableCellNum === undefined) {
      var lastColumnNum = a.getColumnCount() - 1;
      this.lastEditableCellNum = lastColumnNum;
      
      for (var i=lastColumnNum; i >= 0; i--) {
        var tmpCell = a.cells2(c.row, i);
        if (tmpCell && tmpCell.isEditable()) {
          this.lastEditableCellNum = i;
          break;
        }
        else if (i == 0) this.lastEditableCellNum = i;
      }
    }
    
    var cell = a.cells2(c.row, c.col);
    if (cell) {
      if (c.start_edit && !cell.isCheckbox())
      {
        try {a.editCellX(cell)} catch(e) {};
      }
      else {
        try {a.setCurCell(cell.getRowId(), cell.getColumnIndex())} catch (e) {};
      }
    }
  }

  this.populateGridIsInProgress = false;
}

ConfigurableGrid.prototype.handleGridEvent = function ConfigurableGrid_handleCellEvent(eventName, newValue)
{
  //this method is for internal purposes only.
  return this.handleEvent(eventName, "grid");
}

ConfigurableGrid.prototype.handleCellEvent = function ConfigurableGrid_handleCellEvent(eventName, newValue)
{
  //this method is for internal purposes only.
  var params = {};
  params.newValue = newValue;
  return this.handleEvent(eventName, "cell", params);
}

ConfigurableGrid.prototype.handleEvent = function ConfigurableGrid_handleEvent(eventName, eventType, params) {
  //this method is for internal purposes only.

  //params.newValue - is used only for onchangecell events
  
  var cellEventType = "cell";
  var gridEventType = "grid";
  if (eventType != cellEventType && eventType != gridEventType)
    return;
  
  var column = this.getColumnDefinition(this.selectedColumnNum);
  
  var nameSuffix = ((eventType == cellEventType) ? "$" + column.getAttribute("id") : "") + "$" + this.instanceName;
  var event_handler_name = eventName + nameSuffix;
  
  var HandlersQueue = window[event_handler_name];
  
  if (HandlersQueue === undefined) {//means that handleCellEvent is called first time for the column
    var supportedEvents;
    if (eventType == cellEventType)
      supportedEvents = new Array("oneditstart", "onchangecell", "oneditfinish");
    else if (eventType == gridEventType)
      supportedEvents = new Array("oncopy", "onpaste");
    
    for (var i=0; i<supportedEvents.length; i++) {
      var hn = supportedEvents[i] + nameSuffix;
      window[hn] = null;//to skip the below processing the next time 
    }
    
    var ces;
    if (eventType == cellEventType)
      ces = column.selectNodes("Relationships/Item[@type='Column Event']");
    else if (eventType == gridEventType)
      ces = this.gridDefinition.node.selectNodes("Relationships/Item[@type='Configurable Grid Event']");
    
    for (var i=0; i<ces.length; i++) {
      var ce = ces.item(i);
      var evName = top.aras.getItemProperty(ce, "grid_event");
      var evHandlerName = evName + nameSuffix;
      var method_code = top.aras.getItemProperty(ce, "related_id/Item/method_code");
      
      try {
        var h = new Function("item", "propertyName",
                             "newValue",
                             "grid",
                             method_code);
        
        if (!window[evHandlerName]) window[evHandlerName] = new Array();//initialize event handlers queue
        
        window[evHandlerName].push(h);//add event handler to the end of the queue.
        //we assume here that handlers order is defined by data model
      }
      catch (excep) {
        this.showError( (new Innovator()).newError(excep.description) );
        return false;
      }
    }
    
    HandlersQueue = window[event_handler_name];
  }
  
  var retValue = true;
  if (HandlersQueue) for (var i=0; i<HandlersQueue.length; i++) {
    var item = this.selectedItem;
    var propertyName = this.selectedProperty;
    //newValue is passed here as a parameter
    var newValue = (params && typeof(params)=="object") ? params.newValue : undefined;
    var grid = this;
    var handler = HandlersQueue[i];
    
    try {
      retValue = undefined;
      retValue = handler(item, propertyName,
                         newValue,
                         grid);
      //if return value is strictly false then break the loop
      if (retValue === false) break;
    }
    catch (excep) {
      this.showError( (new Innovator()).newError(excep.description), true );
      return false;
    }
    
    if ( retValue===undefined ) retValue = true;
  }
  
  if (this.userMethodRequiresRePopulating){
    this.rePopulateGridFewLater();
  }
  
  return retValue;
}

ConfigurableGrid.prototype.rePopulateGridFewLater = function ConfigurableGrid_rePopulateGridFewLater() {
  //this method is for internal purposes only.
  //to support repopulating in user methods
  setTimeout(this.instanceName + ".rePopulateGridFewLater_implementation()", 30);
}
ConfigurableGrid.prototype.rePopulateGridFewLater_implementation = function ConfigurableGrid_rePopulateGridFewLater_implementation() {
  //this method is for internal purposes only.
  //to support repopulating in user methods
  if (!this.userMethodRequiresRePopulating || this.populateGridIsInProgress) return;
  var a = this.getImplementationObject(); 
  if (!a) return; 
  try {  
   var cell = a.getCurCell(); 
   if (cell) {  
     this.predefined_hl_cell = { 
       start_edit: cell.isEdited(), 
       row : a.getRowIndex(cell.getRowId()),  
       col : cell.getColumnIndex()  
     }; 
   } 
  } catch (e){} 
  this.rePopulateGrid();
}

ConfigurableGrid.prototype.onSelectCell = function ConfigurableGrid_onSelectCell(cell) {
  //this method is for internal purposes only.
  if (!cell) return false;
  if (cell == this.hl_cell) return true;
  
  this.resetValidationFlag();
  
  var col = cell.getColumnIndex();
  
  this.hl_cell  = cell;
  this.hl_col   = col;
  this.hl_rowId = cell.getRowId();
  this.selectedColumnNum = col;
  
  var xpath = this.calculateXPathForColumn( col );
  var itms = (xpath) ? this.selectIOMItems(xpath) : undefined;
  itms = (itms && itms.getItemCount()>0) ? itms : undefined;
  
  this.selectedItem      = (itms && itms.getItemCount()==1) ? itms.getItemByIndex(0) : itms;
  this.selectedProperty  = this.calculatePropNmForColumn( col );
  
  //alert("cell.getRowId():" + cell.getRowId() + "\n\n" + "getParentId()" + this.getImplementationObject().getParentId());
  
  return true;
}

ConfigurableGrid.prototype.calculatePropNmForColumn = function ConfigurableGrid_calculatePropNmForColumn(col) {
  //this method is for internal purposes only.
  var column = this.getColumnDefinition(col);
  var propNm = top.aras.getItemProperty(column, "property");
  
  if ( this.cPropNmRE.test( propNm ) ) {
    propNm = RegExp.$2;
  }
  
  return propNm;
}

ConfigurableGrid.prototype.calculateXPathForColumn = function ConfigurableGrid_calculateXPathForColumn(col) {
  //this method is for internal purposes only.
  var a = this.getImplementationObject();
  if (!a) return;

  var xpath = a.getSelectedId();
  if (xpath == "") return ""; //xpath is empty if and only if item does not exist for the selected cell
  
  var column = this.getColumnDefinition( col );
  
  if (top.aras.getItemProperty(column, "starts_nested_row") == "1")
  {
    //do nothing
  }
  else {
    xpath += "/" + top.aras.getItemProperty(column, "xpath");
  }
  
  var property = top.aras.getItemProperty(column, "property");
  if ( this.cPropNmRE.test( property ) ) {
    var addXPath = RegExp.$1;
    xpath += "/" + addXPath;
  }
  
  return xpath;
}

ConfigurableGrid.prototype.isTopLevelNode = function ConfigurableGrid_isTopLevelNode(nd) {
  //this method is for internal purposes only.
  
  //this function determines if passed node is a "top level node" for the current grid
  
  return (nd && nd == this.topLevelNode);
}

ConfigurableGrid.prototype.calculateXPathForNode = function ConfigurableGrid_calculateXPathForNode( nd ) {
  //this method is for internal purposes only.
  
  var res = "";
  if (!nd) return res;
  
  while (nd) {
    var tagName = nd.nodeName;
    
    if ( this.isTopLevelNode(nd) ) break;
    
    var x = tagName;
    if (tagName == "Item") {
      x += "[@type='" + nd.getAttribute("type") + "']";
      x += "[@id='"   + nd.getAttribute("id")   + "']";
    }
    if (res != "") x += "/";
    
    res = x + res;
    
    nd = nd.parentNode;
  }
  
  return res;
}

ConfigurableGrid.prototype.getRootItemTypeName = function ConfigurableGrid_getRootItemTypeName() {
  //this method is for internal purposes only.
  return this.getRootItemTypeName_res;
}

ConfigurableGrid.prototype.clearPath2RootItem = function ConfigurableGrid_clearPath2RootItem( xpath ) {
  //this method is for internal purposes only.
  
  //removes the very first node from the xpath and all @id criterias
  return xpath.replace(/^[^\/]+\/(.+)$/, "$1").replace(/\[@id='[^\']*'\]/g, "");
}

ConfigurableGrid.prototype.createItemByXPathIfPossible = function ConfigurableGrid_createItemByXPathIfPossible(templateXPath, parentXPath, sibling, where) {
  if (sibling && sibling.isCollection()){
    return null;
  }else{
    return this.createItemByXPath(templateXPath, parentXPath, sibling, where);
  }
}

ConfigurableGrid.prototype.setAttributesOnNewItem = function ConfigurableGrid_setAttributesOnNewItem(itemNd) {
  //this method is for internal purposes only.
  
  itemNd.setAttribute("id", top.aras.generateNewGUID());
  itemNd.setAttribute("isNew", "1");
  itemNd.setAttribute("action", "add");
  itemNd.setAttribute("doGetItem", "0");
}

ConfigurableGrid.prototype.createItemByXPath = function ConfigurableGrid_createItemByXPath(templateXPath, parentXPath, sibling, where) {
  //this method is for internal purposes only.
  //templateXPath should not contain path to root items (direct descendants of node defined by merge_path)
  
  if (this.newItemCreationDisabled) return null;
  
  var dom = this.topLevelNode.ownerDocument;
  var self = this;
  var notDeletedFilter = "[not(@action='delete' or @action='purge')]";
  
  function f ( tagNm, flag, currNd, itType ) {
    var r = dom.createElement(tagNm);
    var t = null;
    
    if (flag && sibling) {
      var nd = sibling.node;
      
      if (nd && nd.parentNode == currNd) {
        if (where == "before") nd = nd;
        else if (where == "after") {
          do {
            nd = nd.nextSibling;
          } while (nd && nd.nodeType != 1);
        }
        else nd = null;
      }
      else nd = null;
      
      t = currNd.insertBefore( r, nd );
    }
    else{
      t = currNd.appendChild( r );
    }
    
    if (tagNm == "Item") {
      if (itType)
      {
        t.setAttribute("type", itType);
        for (var k = 0; k < self.columnNds.length; k++)
        {
          var clmn = self.columnNds[k];
          if (clmn.getAttribute("source_it_name") == itType)
          {
            var nm = clmn.getAttribute("name");
            var d_v = clmn.getAttribute("default_value");
            if (d_v && nm)
            {
              var nd = t.ownerDocument.createElement(nm);
              nd = t.appendChild(nd);
              nd.text = d_v;
            }
          }
        }
      }
      
      self.setAttributesOnNewItem(t);
      
      var parentNm = currNd.nodeName;
      if (parentNm != "Relationships" && !self.isTopLevelNode(currNd)) {
        var parentNd = currNd.parentNode;
        if ( parentNd && parentNd.nodeName == "Item" && !parentNd.getAttribute("action") ) {
          parentNd.setAttribute("action", "edit");
          parentNd.setAttribute("doGetItem", "0");
        }
      }
      else {
        var const_min_value = 0;
        var const_max_value = 2147483647;//2,147,483,647 is the max value for Integer data_type
        
        var min_value = const_min_value;
        var max_value = const_max_value;
        
        var sibling_criteria = "Item";
        if (itType) sibling_criteria += "[@type='" + itType + "']";
        sibling_criteria += notDeletedFilter;
        
        var prev_sibling = t.selectSingleNode("preceding-sibling::" + sibling_criteria + "[1]");
        var next_sibling = t.selectSingleNode("following-sibling::" + sibling_criteria + "[1]");
        
        var tmp_min_value = "";
        var tmp_max_value = "";
        if (prev_sibling != null) tmp_min_value = top.aras.getItemProperty(prev_sibling, "sort_order");
        if (next_sibling != null) tmp_max_value = top.aras.getItemProperty(next_sibling, "sort_order");
        
        tmp_min_value = parseInt(tmp_min_value);
        tmp_max_value = parseInt(tmp_max_value);
        
        var DoubleStep = 256;//the step will be 128 = 256 / 2. see below
        
        //after tmp_min_value and tmp_max_value processing min_value and max_value must contain values
        //which limit the range of possible sort_order values not including border values
        //so, finally the following must be true: min_value < sort_order < max_value
        if (!isNaN(tmp_min_value)) {
          min_value = tmp_min_value;
          if (!isNaN(tmp_max_value)) max_value = tmp_max_value;
          else {
            max_value = min_value + DoubleStep;
            if (max_value > const_max_value) max_value = const_max_value + 1;
          }
        }
        else if (!isNaN(tmp_max_value)) {
          max_value = tmp_max_value;
          min_value = max_value - DoubleStep;
          if (min_value < const_min_value) min_value = const_min_value - 1;
        }
        else {
          min_value = const_min_value - 1;
          max_value = const_max_value + 1;
        }
        
        var EnumerateAllFlag = ((max_value-min_value) <= 1);
        if (!EnumerateAllFlag) {
          var step_size = parseInt(( max_value - min_value ) / 2);//this just strips .5 part
          var sort_order = min_value + step_size;
          
          if (sort_order < const_min_value) sort_order = const_min_value;
          else if (sort_order > const_max_value) sort_order = const_max_value;
          
          var sort_orderNd = t.appendChild(dom.createElement("sort_order"));
          sort_orderNd.text = sort_order;
        }
        else {
          var Relationships = currNd.selectNodes(sibling_criteria);
          var SiblingsNumber = Relationships.length;//should never be 0;
          if (SiblingsNumber == 0) throw new Error(1, "ConfigurableGrid.createItemByXPath: Relationships number cannot be 0.");
          
          var step_size = parseInt((1 + const_max_value - const_min_value) / SiblingsNumber);
          var normal_step = parseInt(DoubleStep / 2);
          if (step_size > normal_step) step_size = normal_step;
          if (step_size < 1) step_size = 1;
          
          var TotalWidth = (SiblingsNumber - 1) * step_size + 1;
          var Start_sort_order = parseInt((const_max_value - TotalWidth) / 2);
          if (Start_sort_order < const_min_value) Start_sort_order = const_min_value;
          
          var sort_order = Start_sort_order - step_size;
          for (var i=0; i<SiblingsNumber; i++) {
            var relationship = Relationships[i];
            var sort_orderNd = relationship.selectSingleNode("sort_order");
            if (!sort_orderNd) sort_orderNd = relationship.appendChild(dom.createElement("sort_order"));
            
            sort_order += step_size;
            if (sort_order > const_max_value) {
              //check for an overflow just for a case
              sort_order = const_max_value;
              step_size = 0;
            }
            
            if (sort_orderNd.text != sort_order.toString()) {
              sort_orderNd.text = sort_order;
              
              var siblingAction = relationship.getAttribute("action");
              if (!siblingAction || siblingAction == "skip") {
                relationship.setAttribute("action", "edit");
                relationship.setAttribute("doGetItem", "0");
              }
            }
          }
        }
      }
    }
    
    return t;
  }
  
  if (!parentXPath) {
    var type = this.getRootItemTypeName();
    if (!type) {
      alert("Type of root item cannot be determined. Please check Your grid defintion.");
      return false;
    }
    
    nd = f ( "Item", true, this.topLevelNode, type );
    
    var source_id = nd.appendChild( dom.createElement("source_id") );
    source_id.text = this.item_id;
    
    parentXPath = "Item[@type='" + type + "'][@id='" + nd.getAttribute("id") + "']";
  }
  
  var re = /^Item\[@type='[\w ]+'\]\[@id='[^\']+'\]$/;
  var px = "";
  if ( re.test(parentXPath) ) {
    px = "";
  }
  else {
    px = this.clearPath2RootItem(parentXPath);
    px += "/";
  }
  
  if ( templateXPath.indexOf(px) != 0 ) {
    //alert("Column xpath is\n" + templateXPath + "\n\nbut parent xpath is\n" + px);
    return false;
  }
  var rx = templateXPath.replace(px, "");
  
  var parentNd = this.topLevelNode.selectSingleNode(parentXPath);
  if (!parentNd) {
    //alert("Very strange");
    return false;
  }
  
  var currNd = parentNd;
  var arr = this.parseXPath(rx);
  var lastItemPos = -1;
  
  for (var i=arr.length-1; i>-1; i--) {
    if (arr[i].tag == "Item") {
      lastItemPos = i;
      break;
    }
  }
  
  for (var i=0; i<arr.length; i++) {
    var tagInfo = arr[i];
    var tagNm  = tagInfo.tag;
    var itType = (tagNm == "Item" && tagInfo.attributes && tagInfo.attributes.type ? tagInfo.attributes.type : "");
    
    var x = tagNm;
    if (itType) x += "[@type='" + itType + "']";
    if (tagNm == "Item") x += notDeletedFilter;
    
    var t = currNd.selectSingleNode( x );
    var currNdName = currNd.nodeName;
    //only 2 Relationships and AML tags may contain several child nodes
    var allowsMultipleEntry = (currNdName == "Relationships" || currNdName == "AML");
    if (!t || (i==lastItemPos && allowsMultipleEntry)) t = f( tagNm, t, currNd, itType );
    
    currNd = t;
  }
  
  return currNd;
}

ConfigurableGrid.prototype.createItemForColumn = function ConfigurableGrid_createItemForColumn(col, parentXPath, sibling, where) {
  //this method is for internal purposes only.
  var colXPath = this.columnXPaths[col];
  
  return this.createItemByXPathIfPossible(colXPath, parentXPath, sibling, where);
}

ConfigurableGrid.prototype.selectIOMItems = function ConfigurableGrid_selectIOMItems(xpath) {
  //this method is for internal purposes only.
  
  var item = new Item(undefined, undefined, "simple");
  item.dom = this.topLevelNode.ownerDocument;
  item.node = undefined;
  item.nodeList = this.topLevelNode.selectNodes(xpath);
  return item;
}

ConfigurableGrid.prototype.onCellEditFinish = function ConfigurableGrid_onCellEditFinish( col ) {
  //this method is for internal purposes only.
  var a = this.getImplementationObject();
  if (!a) return false;
  
  this.handleCellEvent("oneditfinish");
  this.selectedCell = null;
}

ConfigurableGrid.prototype.recordLastTabTime = function ConfigurableGrid_recordLastTabTime() {
  //this method is for internal purposes only.
  this.timeStampForMouseClick = (new Date()).valueOf();
}

ConfigurableGrid.prototype.longTimePassedFromLastTab = function ConfigurableGrid_longTimePassedFromLastTab() {
  //this method is for internal purposes only.
  var t = (new Date()).valueOf();
  return (this.timeStampForMouseClick === undefined || t-this.timeStampForMouseClick-300 > 0);
}

ConfigurableGrid.prototype.validateCurrentCell = function ConfigurableGrid_validateCurrentCell() {
  //this method is for internal purposes only.
  this.resetValidationFlag();
  this.saveInputtedData();
  
  return !this.cellValidationFailed;
}

ConfigurableGrid.prototype.resetValidationFlag = function ConfigurableGrid_resetValidationFlag() {
  //this method is for internal purposes only.
  this.cellValidationFailed = false;
}

ConfigurableGrid.prototype.onCellEdit = function ConfigurableGrid_onCellEdit(mode, rowId, col, skipModifiedCheck)
{
  //this method is for internal purposes only.
  var a = this.getImplementationObject();
  if (!a) return false;
  
  if (mode == 10)
  {
    //we don't want to process <tab> event here
    this.recordLastTabTime();
    return true;
  }
  
  var __LongTimePassedFromLastTab = this.longTimePassedFromLastTab();
  
  //+++ to support repopulating from user methods
  if (this.userMethodRequiresRePopulating)
  {
    this.isRedundantEditOfCell = true;
    return true;
  }
  
  if (this.isRedundantEditOfCell)
  {
    if (mode=="2") this.isRedundantEditOfCell = false;
    return true;
  }
  //--- to support repopulating from user methods
  
  col = parseInt(col);
  
  function restoreCheckBoxValue(cell)
  {
    cell.setChecked( cell.isChecked() ? 0 : 1 );
  }
  
  //+++ pre-checks. logical constraints
  if (mode == 1)
  {
    var cell = a.cells(rowId, col);
    if (!cell.isCheckbox()) return true;
    
    if ( !this.isEditMode )
    {
      restoreCheckBoxValue(cell);
      return false;
    }
  }
  
  if (!this.isEditMode) return false;
  //--- pre-checks. logical constraints
  
  var self = this;
  
  var xpath = this.calculateXPathForColumn( col );
  if (xpath === undefined) return false;
  
  function createRequiredItem( parentXPath )
  {
    var start_edit_val = true;
    if ( ! __LongTimePassedFromLastTab )
    {
      if (datatype == "default")
      {
        var property  = self.columnNds.item(col);
        var data_type = property.getAttribute("data_type");
        if (data_type == "image") start_edit_val = false;
      }
      else if (datatype == "bound_multi")
        start_edit_val = false;

      if (!start_edit_val) return false;//if dialog will not be opened then there is no reason to generate underlying xml
    }
    
    var res = self.createItemForColumn(col, parentXPath);
    if ( !res ) return false;
    
    var newRowId = self.calculateXPathForNode( res );
    self.predefined_hl_cell = {
                                start_edit: start_edit_val,
                                row : a.getRowIndex(rowId),
                                col : col
                              };
    
    self.rePopulateGrid();
    return true;
  }
  
  var column  = this.getColumnDefinition( col );
  var columns = this.gridDefinition.node.selectNodes("Relationships/Item[@type='Grid Column']");
  var datatype = top.aras.getItemProperty(column, "datatype");
  var item   = null;
  var propNm = "";

  if (xpath == "")
  {
    createRequiredItem( a.getParentId() );
    return false;
  }

  function saveSelectedCellInfo()
  {
    self.selectedItem      = item;
    self.selectedProperty  = propNm;
    self.selectedColumnNum = col;
    self.selectedRowId     = rowId;
    self.selectedCell      = a.cells(rowId, col);
  }
  
  //+++ common code for modes 0, 1 and 2
  if (mode == 0 || mode == 1 || mode == 2)
  {
    propNm = this.calculatePropNmForColumn( col );
    
    var items = this.selectIOMItems(xpath);
    var c = items.getItemCount();
    if (c == 0)
    {
      createRequiredItem( rowId );
      return false;
    }
    else if (c > 1)
    {
      if (datatype == "bound_multi" || datatype == "unbound_multi")
        item = items;
      else
        return false;
    }
    else
      item = items.getItemByIndex(0);

    saveSelectedCellInfo();
  }
  //--- common code for modes 0, 1 and 2
  
  function beforeEditStart()
  {
    var r = self.lockItemBeforeEditStart(item);
    if (r===false) return r;
    
    if ( !self.handleCellEvent("oneditstart") ) return false;
    
    return true;
  }
  
  if (mode == 0)
  {
    var predefinedResult = this.predefinedEditResult;
    
    if (predefinedResult[col] !== undefined)
      return predefinedResult[col];
    
    function createCombo( vals, comboType )
    {
      var listLabels = new Array();
      var listVals   = new Array();
      listLabels.push(" ");
      listVals.push(" ");
      
      for (var i=0; i<vals.getItemCount(); i++)
      {
        var val = vals.getItemByIndex(i);
        
        var l = val.getProperty("label");
        var v = val.getProperty("value");
        if (l === undefined || l === "") l = v;
        
        listLabels.push( l );
        listVals.push( v );
      }
      
      listLabels = listLabels.join("|");
      listVals   = listVals.join("|");
      
      var ct = (comboType) ? parseInt(comboType) : 0;
      
      a.setComboList("", col);
      a.setColumnProperties("type=COMBO,combo_type=" + ct + ",list=" + col, col);
      self.selectedCell.setCombo(listLabels, listVals);
    }

    if (datatype == "default")
    {
      var property    = this.columnNds.item(col);
      var data_type   = property.getAttribute("data_type");
      
      if ( !beforeEditStart() ) return false;
      
      if (data_type == "boolean")
      {
        return false;
      }
      else if ( data_type == "color" )
        this.preservedCellValue = this.selectedCell.getValue();
      else if ( data_type == "color list" || data_type == "list" ) 
      {
        //nothing special      
      }
      else if ( data_type == "filter list" )
      {
        var list = this.cachedFilterLists[col];
        var isFiltered = false;
        var vals;
        
        var filterName = property.getAttribute("pattern");
        if (filterName)
        {
          var filterVal = item.getProperty(filterName);
          if (filterVal)
          {
            filterVal = this.escapeXMLAttribute(filterVal);
            vals = list.getItemsByXPath("Relationships/Item[@type='Filter Value' and filter='" + filterVal + "']");
            isFiltered = true;
          }
        }
        
        if (!isFiltered) vals = list.getItemsByXPath("Relationships/Item[@type='Filter Value']");
        
        createCombo( vals );
      }
      else if ( data_type == "date" )
        this.preservedCellValue = this.selectedCell.getValue();
      else if ( data_type == "decimal" || data_type == "float" || data_type == "integer" || data_type == "string" )
      {
        //nothing special
      }
      else if ( data_type == "formatted text" ) {}
      else if ( data_type == "image" )
      {
        if (__LongTimePassedFromLastTab)
        {
          this.disableUserInput();
          this.showImageDialog();
        }
        return false;
      }
      else if ( data_type == "item" )
        this.preservedCellValue = this.selectedCell.getValue();
      else if ( data_type == "md5" ) {
        //nothing special here. but mode 2 handler is special
      }
      else if ( data_type == "text" ) {}
      else
        return false;
      
      return true;
    }
    
    if ( !beforeEditStart() ) return false;
    
    //alert(datatype);
    
    if (datatype == "text")
      return true;
    else if (datatype == "dependent")
    {
      var res = false;
      
      for (var i=col-1; i>-1; i--)
      {
        var columnItem = columns[i];
        if (top.aras.getItemProperty(columnItem, "starts_nested_row") == "1")
        {
          var dt = top.aras.getItemProperty(columnItem, "datatype");
          res = (dt == "unbound_select" || dt == "unbound_multi");
          break;
        }
      }
      
      predefinedResult[col] = res;
      return res;
    }
    else if (datatype == "bound_select")
    {
      var vals = this.applyColumnQueryOrMethod();
      if (!vals) return false;
      
      this.xBoundSelectCache = vals;
      
      createCombo( vals );
      return true;
    }
    else if (datatype == "unbound_select")
    {
      var vals = this.applyColumnQueryOrMethod();
      if (!vals) return false;
      
      this.xBoundSelectCache = vals;
      
      createCombo( vals, 1 );
      return true;
    }
    else if (datatype == "bound_multi")
    {
      if (__LongTimePassedFromLastTab)
      {
        this.disableUserInput();
        this.showBoundMultiSelectDialog();
      }
      return false;
    }
    
    return true;
  }
  else if (mode == 1)
  {
    var cell = this.selectedCell;
    if (cell.isCheckbox())
    {
      if (!beforeEditStart())
      {
        restoreCheckBoxValue( cell );
        return false;
      }
      
      var v = (cell.isChecked() ? "1" : "0");
      this.saveValueToDom( v );
      this.selectedCell = null;
    }
  }
  else if (mode == 2)
  {
    var cell = this.selectedCell;
        
    if (!cell.wasChanged() && !skipModifiedCheck)
    {
      this.onCellEditFinish( col );
      return true;
    }
    
    var v = cell.getValue();
    
    if (datatype == "default")
    {
      var property = this.columnNds.item(col);
      if (!property) return false;
      
      var data_type = property.getAttribute("data_type");
      var pattern   = property.getAttribute("pattern");
      if (!pattern)
        if (data_type == "date") pattern = "MM/dd/yyyy";
      
      //+++ convert user input to property value
      if (data_type == "md5")
      {
        v = top.aras.calcMD5( v );
        cell.setValue("***");
      }
      else if (data_type == "item")
      {
        if (v)
        {
          var r = top.aras.uiGetItemByKeyedName(property.getAttribute("type"), v)
		  
          if (!r)
          {
            var skipWarningAndRollbackValue = this.F2KeyIsProcessed;
            if (skipWarningAndRollbackValue)
            {
              cell.setValue(this.preservedCellValue);
              return true;
            }
            else
            {
              if (!this.showInvalidValueAlert(cell, "Value \"" + v + "\" is invalid for " + top.aras.getItemProperty(column, "label") + ". Use F2 to invoke Search Dialog."))
              {
                cell.setValue(this.preservedCellValue);
                this.selectedCell = null;
                return true;
              }
              else
                return false;
            }
          }
          else
          {
            this.selectedItem.setPropertyAttribute( this.selectedProperty, "keyed_name", top.aras.getItemProperty(r, "keyed_name") );
            this.selectedItem.setPropertyAttribute( this.selectedProperty, "type", r.getAttribute("type"));
            v = r.getAttribute("id");
          }
        }
      }
      
      //+++ validate property value
      var propertyDef =
        {
          data_type: data_type,
          pattern  : pattern,
          is_required: (property.getAttribute("is_required") == "1"),
          stored_length: parseInt(property.getAttribute("stored_length"))
        };
        
      var isPropertyValueValid = top.aras.isPropertyValueValid(propertyDef, v);
      var validationMsg = top.aras.ValidationMsg;
      if (data_type == "date" && v != "")
      {
        //not empty dates are not validated by top.aras.isPropertyValueValid yet
        isPropertyValueValid = document.applets[this.appletID+"_calendar"].parseDate(v, pattern);
        validationMsg = "Value \"" + v + "\" is invalid for " + top.aras.getItemProperty(column, "label") + ".";
      }
      
      if (!isPropertyValueValid)
      {
        var skipWarningAndRollbackValue = this.F2KeyIsProcessed;
        
        var errMsg = validationMsg;
        if (data_type == "color")
          errMsg += " Use F2 to invoke Color Dialog.";
        else if (data_type == "date")
          errMsg += " Use F2 to invoke Date Dialog.";
        
        if (skipWarningAndRollbackValue)
        {
          cell.setValue(this.preservedCellValue);
          return true;
        }
        else
        {
          if (!this.showInvalidValueAlert(cell, errMsg))
          {
            cell.setValue(this.preservedCellValue);
            this.selectedCell = null;
            return true;
          }
          else
            return false;
        }
      }
      
      if (data_type == "color" || data_type == "color list")
      {
        var aColor = v;
        if (!aColor) aColor = "#ffffff";
        
        try {
          if (this.hl_cell_color) this.hl_cell_color = aColor;
          cell.setBgColor(aColor);
        }
        catch (e) {}
      }
      else if (data_type == "image") {
        if (v) {
          cell.setValue("<img src=\"" + v.replace(/\"/g, "&quot;") + "\">");
      }
    }
    }
    else if (datatype == "bound_select" || datatype == "unbound_select") {
      if (top.aras.getItemProperty(column, "starts_nested_row") == "1") {
        var vals = this.xBoundSelectCache;
        
        var valItem = null;
        
        for (var i=0; i<vals.getItemCount(); i++) {
          var val = vals.getItemByIndex(i);
          if (val.getProperty("value") == v) {
            valItem = val;
            break;
          }
        }
        
        if (valItem || datatype == "unbound_select") {
          for (var i=col+1; i<columns.length; i++) {
            var columnItem = columns[i];
            if (top.aras.getItemProperty(columnItem, "starts_nested_row") == "1") break;
            
            if (top.aras.getItemProperty(columnItem, "datatype") == "dependent")
            {
              var xp = top.aras.getItemProperty(columnItem, "xpath");
              var p  = top.aras.getItemProperty(columnItem, "property");
              
              var ni = item.getItemsByXPath(xp);
              if (ni.getItemCount() == 1) {
                ni = ni.getItemByIndex(0);
                
                var nv = (valItem ? valItem.getProperty(p) : "");
                ni.setProperty(p, nv);
                a.cells(rowId, i).setValue(nv);
              }
            }
          }
        }
        
        this.xBoundSelectCache = null;
      }
    }
     
    this.saveValueToDom( v );
    
    this.onCellEditFinish( col );
  }
  else if (mode == 21) {//<enter> was pressed
    if ( !this.validateCurrentCell() ) {//to save data and validate user input
      this.resetValidationFlag();
      return false;
    }
  }
  
  return true;
}//onCellEdit


ConfigurableGrid.prototype.lockItemBeforeEditStart = function ConfigurableGrid_lockItemBeforeEditStart( iomItem )
  //this method is for internal purposes only.
{
  var item = iomItem;
  var notCollectionNotNew = !item.isCollection() && !item.isNew() && (item.getAttribute("action") != "add");
  var f = false;//flag which means that item is locked (and thus editable) by current user
  
  if (notCollectionNotNew) {
    var lockedBy = item.isLocked();
    var preservedAction = item.node.getAttribute("action");
    if (lockedBy == 2) {
      var r = item.unlockItem();//for now return value is not checked here
      lockedBy = item.isLocked();
    }
    
    f = (lockedBy==1);
    if (!f) {
      var r = item.lockItem();
      f = !r.isError();
      if (f) {
        if (preservedAction) item.node.setAttribute("action", preservedAction);
        else item.node.removeAttribute("action");
        
        item.setProperty("locked_by_id", top.aras.getUserID());
      }
    }
    else
    {
      item.setProperty("locked_by_id", top.aras.getUserID());
    }
  }
  
  if (notCollectionNotNew && !f) {
    alert("This " + item.getType() + " is not editable");
    return false;
  }
  
  return true;
}

ConfigurableGrid.prototype.getColumnDefinition = function ConfigurableGrid_getColumnDefinition( col ) {
  //this method is for internal purposes only.
  var column = this.gridDefinition.node.selectSingleNode("Relationships/Item[@type='Grid Column'][" + (++col) + "]");
  if (!column)
  {
    this.showError((new Innovator()).newError("There is no column with index " + col + " in Grid definition"));
    return null;
  }
  
  return column;
}

ConfigurableGrid.prototype.getColumnDataType = function ConfigurableGrid_getColumnDataType() {
  var datatype = "";
  if (this.hl_cell) {
    var col = parseInt(this.selectedColumnNum);
    var column  = this.getColumnDefinition( col );
    var datatype = top.aras.getItemProperty(column, "datatype");
    if (datatype == "default") {
      if ( isNaN(col) ) return false;
      var property = this.columnNds.item(col);
      datatype = property.getAttribute("data_type");
    }
  }
  return datatype;
}

ConfigurableGrid.prototype.disableKeybord = function ConfigurableGrid_disableKeybord() {
  //this method is for internal purposes only.
  
  this.disableKeyboardFlag = true;
}

ConfigurableGrid.prototype.enableKeybord = function ConfigurableGrid_enableKeybord() {
  //this method is for internal purposes only.
  
  this.disableKeyboardFlag = false;
}

ConfigurableGrid.prototype.disableUserInput = function ConfigurableGrid_disableUserInput() {
  //this method is for internal purposes only.

  //disables keybord input and makes underlying grid applet "read only" to partially disable mouse input
  this.disableKeybord();
  
  var a = this.getImplementationObject();
  if (!a) return false;
  a.setEditable(false);
}

ConfigurableGrid.prototype.enableUserInput = function ConfigurableGrid_enableUserInput() {
  //this method is for internal purposes only.
  
  //enables keybord input and makes underlying grid applet "read/write"
  this.enableKeybord();
  
  var a = this.getImplementationObject();
  if (!a) return false;
  a.setEditable(true);
}

ConfigurableGrid.prototype.onKeyPressed = function ConfigurableGrid_onKeyPressed( keyEvent ) {
  //this method is for internal purposes only.

  if (this.disableKeyboardFlag || this.populateGridIsInProgress) return false;
  
  // +++ key codes
  var k_Tab    = 9;
  var k_Enter  = 13;
  var k_F      = 70;
  var k_F2     = 113;
  var k_Delete = 46;
  var k_Insert = 45;
  var k_C      = 67;
  var k_V      = 86;
  // --- key codes
  var keyCode = keyEvent.getKeyCode();
  
  if (keyCode == k_Tab) {
    var MinTimeDiff = 400;
    var TimeStamp = (new Date()).valueOf();
    
    if (this.LastKeyPressed === undefined) {}
    else if (TimeStamp - this.LastKeyPressed - MinTimeDiff < 0) {
      return false;
    }
    
    this.LastKeyPressed = TimeStamp;
  }
  
  if (keyCode == k_F2) {
    var columnDataType = this.getColumnDataType();

    if (this.selectedCell)
    {
      if (columnDataType == "item")
      {
        if (!this.selectedItem || !this.selectedProperty) return false;
      }
      
      if (columnDataType == "color" || columnDataType == "formatted text" || columnDataType == "text" ||
          columnDataType == "item" || columnDataType == "unbound_multi" || columnDataType == "bound_select" ||
          columnDataType == "unbound_select" || columnDataType == "date")
      {
        this.F2KeyIsProcessed = true;
        try
        {
          this.saveInputtedData();
        }
        catch (excep)
        {
          throw excep;
        }
        finally
        {
          this.F2KeyIsProcessed = false;
        }
        
        this.disableKeybord();
        
        if (columnDataType == "color") this.showColorDialog();
        else if (columnDataType == "formatted text") this.showFormattedTextDialog();
        else if (columnDataType == "text") this.showTextDialog();
        else if (columnDataType == "item") this.showItemDialog();
        else if (columnDataType == "unbound_multi") this.showUnboundMultiSelectDialog();
        else if (columnDataType == "bound_select") this.showBoundSelectDialog();
        else if (columnDataType == "unbound_select") this.showUnboundSelectDialog();
        else if (columnDataType == "date") this.showDateDialog();
      }
    }
  }
  else if (!this.selectedCell && keyCode == k_Delete) {
    if (!this.isEditMode) return true;
    
    var col = parseInt(this.hl_col);
    if ( isNaN(col) ) return false;
    
    if (col == -1) return true;//no column is selected
    
    var xpath = this.calculateXPathForColumn( col );
    if (!xpath) return false;
    
    var a = this.getImplementationObject();
    if (!a) return false;
    var cell = a.getCurCell();
    if (!cell.isEditable()) return true;//read-only cells should not allow the delete operation
    
    var item = null;
    var items = this.selectIOMItems(xpath);
    var c = items.getItemCount();
    
    if (c == 0) item = null;
    else if (c == 1) item = items.getItemByIndex(0);
    else item = items;
    
    if (!item || (item.node && item.node.tagName != "Item")) return true;
    
    var self = this;
    
    function d (item) {
      var itemNd = item.node;
      var parentNd = itemNd.parentNode;
      var parentNm = parentNd.nodeName;
      
      var applyAction = "delete";
      if (parentNm == "Relationships") {
        //this relationship is deleted
      }
      else if (self.isTopLevelNode(parentNd)) {
        //item is deleted because the parent node is a "top level" node
      }
      else {
        var levelUpNd = itemNd.selectSingleNode("../../..");
        parentNm = "";
        if (levelUpNd) parentNm = levelUpNd.nodeName;
        if (parentNm == "Relationships" || self.isTopLevelNode(levelUpNd)) {
          //delete one level up relationship instead of current item. If current item is dependent then
          //it will be deleted by standard delete logic
          itemNd = itemNd.selectSingleNode("../..");
        }
        else {
          //for now if current item is not a relationship and "parent" instance is not
          //a relationship also then we just erase a reference to current item from parent instance.
          applyAction = "null reference";
        }
      }
      
      var msg;
      if (applyAction == "delete") {
        msg = "Deleting " + itemNd.getAttribute("type") + 
              " \"" + top.aras.getKeyedNameEx(itemNd) + "\". Are you sure?";
      }
      else {
        msg = "Remove " + itemNd.getAttribute("type") + 
              " \"" + top.aras.getKeyedNameEx(itemNd) + "\" from configuration. Are you sure?";
      }
      
      var isConfirmed = window.confirm(msg);
      self.returnFocusToGrid();
      if ( !isConfirmed ) return false;//nothing was changed
      
      parentNd = itemNd.parentNode;
      var act = itemNd.getAttribute("action");
      if (act == "add") {
        //it doesn't matter what is applyAction
        parentNd.removeChild(itemNd);
      }
      else {
        if (applyAction == "delete") {
          itemNd.setAttribute("action", "delete");
        }
        else {
          //null reference
          parentNd.text = "";
          parentNd = parentNd.parentNode;
          if ( !parentNd.getAttribute("action") ) {
            parentNd.setAttribute("action", "edit");
          }
        }
      }
      
      return true;//something was changed
    }
    
    var statusId = top.aras.showStatusMessage(0, 'deleting...', '../images/Animated/ProgressSmall.gif');
    var f = false;
    if ( item.isCollection() ) {
      for (var i=0; i<item.getItemCount(); i++) {
        var ci = item.getItemByIndex(i);
        f = d( ci ) || f;//f is true if at least something was changed
      }
    }
    else f = d( item );
    
    if (f) this.rePopulateGrid();
    top.aras.clearStatusMessage (statusId);
  }
  else if (keyCode == k_Insert) {
    if (!this.isEditMode) return true;
    
    var where = (keyEvent.isShiftDown() ? "before" : "after");
    
    this.onInsertRowCommand(where);
    return false;
  }
  else if (keyCode == k_F) {
    if (!keyEvent.isControlDown()) return true;//only Ctrl+F matters
    
    setTimeout(this.instanceName + ".startFindAndReplace()", 10);
  }
  else if (keyCode == k_Tab) {
    if (!this.isEditMode) return true;
    
    var a = this.getImplementationObject();
    if (!a) return false;
    
    var c = a.getCurCell();
    
    if ( !this.validateCurrentCell() ) {//to save data is being inputted
      this.resetValidationFlag();
      return false;
    }
    
    if (keyEvent.isShiftDown()) return true;
    
    if (!c) return true;
    
    var cN = c.getColumnIndex();
    var rN = a.getRowIndex( c.getRowId() );

    if ( rN==a.getRowsNum()-1 && cN >= this.lastEditableCellNum) {
      this.addNewRootRow();
      return false;
    }
  }
  else if (!this.selectedCell && keyCode == k_C) {
    if (!this.isEditMode) return true;
    if (!keyEvent.isControlDown()) return true;//only Ctrl+C
    
    this.onCopyCommand();
    return false;
  }
  else if (!this.selectedCell && keyCode == k_V) {
    if (!this.isEditMode) return true;
    if (!keyEvent.isControlDown()) return true;//only Ctrl+V
    
    this.onPasteCommand();
    return false;
  }
}

ConfigurableGrid.prototype.getNearestStartsNestedColumn = function ConfigurableGrid_getNearestStartsNestedColumn(col) {
  //this method is for internal purposes only.
  var NearestStartsNested = col;
  for (; NearestStartsNested > -1; NearestStartsNested--) {
    var tmpColumnDef = this.getColumnDefinition( NearestStartsNested );
    if (top.aras.getItemProperty(tmpColumnDef, "starts_nested_row") == "1") break;
  }
  
  return NearestStartsNested;
}

ConfigurableGrid.prototype.onInsertRowCommand = function ConfigurableGrid_onInsertRowCommand(where, beforeRefreshCallback) {
  //this method is for internal purposes only.
  var col = parseInt(this.hl_col);
  if ( isNaN(col) ) return false;
  
  if ( !this.validateCurrentCell() ) {//to save data and validate user input
    this.resetValidationFlag();
    return false;
  }
  
  if (col == -1) col = 0;//no column is selected default to first
  
  var column  = this.getColumnDefinition( col );
  if (!(column)) return false; //no column is found
  var datatype = top.aras.getItemProperty(column, "datatype");
  if (datatype == "federated") {
    alert("Insert is ignored because this is federated column");
    return true;
  }
  
  var xpath = this.calculateXPathForColumn( col );
  if (xpath === undefined) return false;
  
  var item = null;
  if (xpath == "") {
    item = null;
  }
  else {
    var items = this.selectIOMItems(xpath);
    var c = items.getItemCount();
    
    if (c == 0) item = null;
    else if (c == 1) item = items.getItemByIndex(0);
    else item = items;
  }
  
  var a = this.getImplementationObject();
  if (!a) return false;
  
  var parentXPath = a.getParentId();
  var sibling     = item;
  
  //determine how far is the nearest starts_nested column
  var NearestStartsNested = this.getNearestStartsNestedColumn(col);
  
  var StayOnTheSameRow = (where != "after");
  if (sibling) {
    var self = this;
    function createNearestParent() {
      var nd  = sibling.node;
      var pNd = nd.parentNode;
      if (pNd.tagName == "Relationships") {
        //nothing to do here
        return self.calculateXPathForNode(pNd);
      }
      else {
        sibling = null;//there is no sibling because parent tag is not Relationships
        
        while (pNd.tagName != "Relationships" && pNd.tagName != "AML") {
          nd  = pNd;
          pNd = pNd.parentNode;
        }
        
        var parentXPath  = self.calculateXPathForNode(pNd);
        var tXPath   = self.calculateXPathForNode(nd);
        var tSibling = self.selectIOMItems(tXPath);
        tSibling     = tSibling.getItemByIndex(0);
        
        var templateXPath = "";
        if (parentXPath) {
          templateXPath = self.clearPath2RootItem(parentXPath) +
                          "/Item[@type='" + tSibling.getType() + "']";
        }
        
        nd = self.createItemByXPathIfPossible(templateXPath, parentXPath, tSibling, where);
        
        return self.calculateXPathForNode(nd);
      }
    }
    
    // --- we don't allow grid to paste several items in one cell.
    //if there is a need to do this - use special datatype ([un]bound_multi)
    //which has ability to show special Form. Or use special method.
    //-----------------------
    //if item for cell exists already we need to "go one level up" to generate a new row
    //instead of just generating one more sibling (to handle multiple items in 1 cell user should use corresponding dialog)
    
    if (NearestStartsNested < col) {
      //also we have to check that it's possible to get "several items in 1 cell" here
      //this means xpath for column should contain "Relationships"
      var severalItemsArePossible = false;
      var xpath4Test = top.aras.getItemProperty(column, "xpath") + "/" + top.aras.getItemProperty(column, "property");
      var tmpArr = this.parseXPath(xpath4Test);
      for (var i=0; i<tmpArr.length; i++) {
        if (tmpArr[i].tag == "Relationships") {
          severalItemsArePossible = true;
          break;
        }
      }
      
      if (severalItemsArePossible) {
        var FirstColumnOfItem = NearestStartsNested+1;
        var NearestParentXPath = a.getItemId(this.hl_rowId, FirstColumnOfItem);
        var NearestParentItem = this.selectIOMItems(NearestParentXPath);
        if (NearestParentItem.getItemCount() != 1) return false;
        
        sibling = NearestParentItem.getItemByIndex(0);
        
        parentXPath = createNearestParent();
        XPathIsEnough = true;
      }
    }
    // --- we don't allow grid to paste several items in one cell.
    
    if (sibling && !sibling.isCollection()) {
      parentXPath = createNearestParent();
    }
  }
  else {//if there is no sibling
    if (datatype == "bound_multi" || datatype == "unbound_multi") {
      StayOnTheSameRow = true;
    }
    
    if (StayOnTheSameRow) {
      var tmpXPath = a.getSelectedId();
      if (tmpXPath) parentXPath = tmpXPath;
    }
  }
  
  var res = this.createItemForColumn(col, parentXPath, sibling, where);
  if ( !res ) return false;

  var rowN = 0;
  var colN = 0;
  
  var c = a.getCurCell();
  if (!c) {
    rowN = a.getRowsNum();
    colN = 0;
  }
  else {
    rowN = a.getRowIndex( c.getRowId() );
    colN = col;
    
    if (!StayOnTheSameRow) {
      var cr = a.getSelectedId();
      if (!cr) {
        cr = a.getParentId();
        if (cr) rowN -= 1;
      }
      
      rowN += c.getRowSpan();
    }
  }
  
  this.predefined_hl_cell = {
                               start_edit: true,
                               row : rowN,
                               col : col
                            };
  
  if (beforeRefreshCallback) {
    var TopGeneratedNodeXPath = "";
    if (NearestStartsNested > -1) TopGeneratedNodeXPath = this.columnXPaths[NearestStartsNested];
    
    var tmpXPath = this.clearPath2RootItem(this.calculateXPathForNode(res));
    var levelsDiffStr = tmpXPath.replace(TopGeneratedNodeXPath, "");
    if (levelsDiffStr.indexOf("/") == 0) levelsDiffStr = levelsDiffStr.substr(1);
    var levelsDiffArr = this.parseXPath(levelsDiffStr);
    var levelsDiff = levelsDiffArr.length;
    
    var TopGeneratedNode = res;
    if (levelsDiff > 0) {
      tmpXPath = "..";
      for (var i=1; i<levelsDiff; i++) tmpXPath += "/..";
      TopGeneratedNode = TopGeneratedNode.selectSingleNode(tmpXPath);
    }
    
    beforeRefreshCallback(TopGeneratedNode);
  }
  
  this.rePopulateGrid();
}

ConfigurableGrid.prototype.onCopyCommand = function ConfigurableGrid_onCopyCommand() {
  //this method is for internal purposes only.

  this.clipboardData = null;
  
  var a = this.getImplementationObject();
  if (!a) return false;
  
  var cell = a.getCurCell();
  if (!cell) return false;
  
  var col   = cell.getColumnIndex();
  var xpath = a.getItemId(cell.getRowId(), col);
  if (!xpath) return false;
  
  var nodeToCopy = this.topLevelNode.selectSingleNode(xpath);
  if (!nodeToCopy) return false;
  
  var statusId = top.aras.showStatusMessage(0, 'copying...', '../images/Animated/ProgressSmall.gif');
  
  var nds2RemoveAttr = this.topLevelNode.selectNodes(".//Item[@"+this.copyByRefAttrNm+"]");
  for (var i=0; i<nds2RemoveAttr.length; i++)
    nds2RemoveAttr[i].removeAttribute(this.copyByRefAttrNm);
  
  var evRes = this.handleGridEvent("oncopy");
  if (evRes === false)
  {
    top.aras.clearStatusMessage (statusId);
    return false;
  }
  
  nodeToCopy = nodeToCopy.cloneNode(true);
  var deletedNodes = nodeToCopy.selectNodes(".//Item[@action='delete' or @action='purge']");
  for (var i=0; i<deletedNodes.length; i++) {
    var deletedNd = deletedNodes[i];
    var pNd = deletedNd.parentNode;
    if (pNd) pNd.removeChild(deletedNd);
  }
  
  this.clipboardData = {
    nodeToCopy: nodeToCopy,
    baseColumn: this.getNearestStartsNestedColumn(col)
  };
  
  top.aras.clearStatusMessage (statusId);
}

ConfigurableGrid.prototype.onPasteCommand = function ConfigurableGrid_onPasteCommand() {
  //this method is for internal purposes only.

  if (!this.clipboardData) {
    top.aras.AlertError("You must first copy a row in this document before using the Paste function.");
    return false;
  }
  
  var a = this.getImplementationObject();
  if (!a) return false;
  
  var cell = a.getCurCell();
  if (!cell) return false;
  
  var col = cell.getColumnIndex();
  var baseColumn = this.getNearestStartsNestedColumn(col);
  if (baseColumn != this.clipboardData.baseColumn) {
    top.aras.AlertError("You must select a cell that is from the same level from which you initiated the copy.");
    return false;
  }
  
  var statusId = top.aras.showStatusMessage(0, 'pasting...', '../images/Animated/ProgressSmall.gif');
  
  var evRes = this.handleGridEvent("onpaste");
  if (evRes === false)
  {
    top.aras.clearStatusMessage (statusId);
    return false;
  }

  var nodeToPaste = this.clipboardData.nodeToCopy.cloneNode(true);
  var itemNds = nodeToPaste.selectNodes("descendant-or-self::Item");
  for (var i=0; i<itemNds.length; i++) {
    var itemNd = itemNds[i];
    if (itemNd.getAttribute(this.copyByRefAttrNm)=="1")
    {
      itemNd.setAttribute("action", "get");
      itemNd.removeAttribute(this.copyByRefAttrNm);
    }
    else
      this.setAttributesOnNewItem(itemNd);
  }
  
  var res = true;
  var self = this;
  
  function beforeRefreshCallback(itemNd) {
    if (!itemNd) {
      res = false;
      return;
    }
    
    //change source_id
    var source_idNd = itemNd.selectSingleNode("source_id");
    if (source_idNd != null) {
      var source_id_pasteNd = nodeToPaste.selectSingleNode("source_id");
      if (source_id_pasteNd == null) nodeToPaste.appendChild(source_idNd);
      else nodeToPaste.replaceChild(source_idNd, source_id_pasteNd);
    }
    
    //shange sort_order
    var sort_orderNd = itemNd.selectSingleNode("sort_order");
    if (sort_orderNd != null) {
      var sort_order_pasteNd = nodeToPaste.selectSingleNode("sort_order");
      if (sort_order_pasteNd == null) nodeToPaste.appendChild(sort_orderNd);
      else nodeToPaste.replaceChild(sort_orderNd, sort_order_pasteNd);
    }
    
    itemNd.parentNode.replaceChild(nodeToPaste, itemNd);
    
    self.predefined_hl_cell.start_edit = false;
  }
  
  this.onInsertRowCommand("after", beforeRefreshCallback);
  top.aras.clearStatusMessage (statusId);
  
  return res;
}

ConfigurableGrid.prototype.saveInputtedData = function ConfigurableGrid_saveInputtedData() {
  //this method is for internal purposes only.
  if (this.selectedCell) {
    var a = this.getImplementationObject();
    if (!a) return false;
    
    a.turnEditOff();//to save data is being inputted
  }
}

ConfigurableGrid.prototype.deactivateGrid = function ConfigurableGrid_deactivateGrid() {
  //this method is for internal purposes only.
  if (this.hl_cell) {
    var a = this.getImplementationObject();
    if (!a) return false;
    a.clearCurCell();//to unselect highlighted cell
  }
}

ConfigurableGrid.prototype.activateGrid = function ConfigurableGrid_activateGrid() {
  //this method is for internal purposes only.
  var a = this.getImplementationObject();
  if (!a) return;
  
  var cell = this.hl_cell;
  if (cell) {
    //cellValidationFailed will be reset to false inside onSelectCell
    a.setCurCell(cell.getRowId(), cell.getColumnIndex());
  }
}

ConfigurableGrid.prototype.unselectHLCell = function ConfigurableGrid_unselectHLCell() {
  //this method is for internal purposes only.
  if (this.hl_cell) {
    this.initHL_Cell();//reset hl_cell stored values
    
    var a = this.getImplementationObject();
    if (!a) return false;
    a.clearCurCell();//to unselect highlighted cell
  }
}

ConfigurableGrid.prototype.addNewRootRow = function ConfigurableGrid_addNewRootRow() {
  //this method is for internal purposes only.
  this.saveInputtedData();
  
  this.unselectHLCell();
  
  var o = new EmulateInsertPressed();
  this.onKeyPressed( o );
}

ConfigurableGrid.prototype.startFindAndReplace = function ConfigurableGrid_startFindAndReplace() {
  //this method is for internal purposes only.
  
  this.saveInputtedData();
  
  var params = new Object();
  params.findNext   = new Function("f_what", "match_case", "dlg", "return " + this.instanceName + ".findNext(f_what, match_case, dlg);");
  params.replace    = new Function("r_what", "r_with", "match_case", "dlg", "return " + this.instanceName + ".replace(r_what, r_with, match_case, dlg);");
  params.replaceAll = new Function("r_what", "r_with", "match_case", "dlg", "return " + this.instanceName + ".replaceAll(r_what, r_with, match_case, dlg);");
  
  showModalDialog("FindAndReplaceDialog.html", params, "dialogHeight:180px;dialogWidth:360px;center:yes;help:yes;resizable:no;scroll:no;status:no;");
}

ConfigurableGrid.prototype.escapeSpecialREChars = function ConfigurableGrid_escapeSpecialREChars( str ) {
  //this method is for internal purposes only.
  var specialCharsArr = new Array("\\", "$", "(", ")", "*", "+", ".", "[", "?", "^", "{", "|");
  
  var old = str;
  for (var i=0; i<specialCharsArr.length; i++) {
    var ch = specialCharsArr[i];
    var re = new RegExp("\\" + specialCharsArr[i], "g");
    str = str.replace(re, "\\" + ch);
  }
  
  return str;
}

ConfigurableGrid.prototype.escapeXMLAttribute = function ConfigurableGrid_escapeXMLAttribute( attrVal ) {
  //this method is for internal purposes only.
  attrVal = attrVal.replace(/&/g,      "&amp;");
  attrVal = attrVal.replace(/</g,      "&lt;");
  attrVal = attrVal.replace(/>/g,      "&gt;");
  attrVal = attrVal.replace(/"/g, "&quot;");
  attrVal = attrVal.replace(/'/g, "&apos;");
  
  return attrVal;
}

ConfigurableGrid.prototype.findNext = function ConfigurableGrid_findNext(f_what, match_case, dlg) {
  //this method is for internal purposes only.
  
  if (!f_what) return false;
  
  var a = this.getImplementationObject();
  if (!a) return false;
  
  function alertNoMatchFound() {
    alert("No match found");
  }
  
  var currCell = this.hl_cell;
  var rN = a.getRowsNum();
  var cN = a.getColumnCount();
  
  var currRowNum;
  var currColNum;
  
  if (!currCell) {
    if (rN < 1) return true;
    currCell = a.cells2(0, 0);
    if (!currCell) {
      alertNoMatchFound();
      return false;
    }
    currRowNum = 0;
    currColNum = 0;
  }
  else {
    currRowNum = a.getRowIndex( currCell.getRowId() );
    currColNum = currCell.getColumnIndex() + 1;//+1 because we want to find "next"
  }
  
  f_what = this.escapeSpecialREChars(f_what);
  
  var re = new RegExp(f_what, (match_case?"":"i"));
  
  for (var r=currRowNum; r<rN; r++) {
    for (var c=currColNum; c<cN; c++) {
      currCell = a.cells2(r, c);
      if ( re.test(currCell.getValue()) ) {
        a.setCurCell(currCell.getRowId(), currCell.getColumnIndex());
        return true;
      }
    }
    currColNum = 0;
  }
  
  this.unselectHLCell();//to unselect highlighted cell
  
  alertNoMatchFound();
  return false;
}

ConfigurableGrid.prototype.replace = function ConfigurableGrid_replace(r_what, r_with, match_case, dlg) {
  //this method is for internal purposes only.
  var currCell = this.hl_cell;
  if (!currCell) return false;
  
  r_what = this.escapeSpecialREChars(r_what);
  var re = new RegExp(r_what, (match_case?"":"i"));
  
  var a = this.getImplementationObject();
  if (!a) return false;
  
  var newVal = this.replace_implementation(a, currCell, re, r_with);
  
  return re.test(newVal);
}

ConfigurableGrid.prototype.replace_implementation = function ConfigurableGrid_replace_implementation(a, currCell, re, r_with, silentErrors) {
  //this method is for internal purposes only.
  var oldVal = currCell.getValue();
  
  if (!currCell.isEditable()) {
    if (!silentErrors) alert("The field is read-only");
    return oldVal;
  }
  
  var col = currCell.getColumnIndex();
  var column   = this.getColumnDefinition( col );
  var datatype = top.aras.getItemProperty(column, "datatype");
  var data_type= "";
  if (datatype == "default") data_type = this.columnNds.item(col).getAttribute("data_type");
  
  if ( datatype != "text" && data_type != "string") {
    if (!silentErrors) alert("Replace is not allowed here");
    return oldVal;
  }
  
  var a = this.getImplementationObject();
  if (!a) return oldVal;
  a.setCurCell(currCell.getRowId(), currCell.getColumnIndex());
  var xpath = this.calculateXPathForColumn( currCell.getColumnIndex() );
  if (!xpath) return oldVal;
  
  var items = this.selectIOMItems(xpath);
  var c = items.getItemCount();
  if (c!=1) {
    if (!silentErrors) alert("An item cannot be uniquely defined");
    return oldVal;
  }
  
  var newVal = oldVal.replace( re, r_with );
  //+++ emulate cell edit:
  var r = this.onCellEdit(0, currCell.getRowId(), currCell.getColumnIndex());
  if (!r) return oldVal;
  currCell.setValue( newVal );
  this.onCellEdit(2, currCell.getRowId(), currCell.getColumnIndex(), true);
  //--- emulate cell edit
  
  return newVal;
}

ConfigurableGrid.prototype.replaceAll = function ConfigurableGrid_replaceAll(r_what, r_with, match_case, dlg) {
  //this method is for internal purposes only.
  var a = this.getImplementationObject();
  if (!a) return false;
  
  r_what = this.escapeSpecialREChars(r_what);
  var re      = new RegExp(r_what, "g"+(match_case?"":"i"));
  var re4test = new RegExp(r_what, (match_case?"":"i"));//g option is removed because of JScript bug/feature
  
  var rN = a.getRowsNum();
  var cN = a.getColumnCount();
  
  for (var r=0; r<rN; r++) {
    for (var c=0; c<cN; c++) {
      var currCell = a.cells2(r, c);
      if ( re4test.test(currCell.getValue()) ) {
        this.replace_implementation(a, currCell, re, r_with, true);
      }
    }
  }
  
  this.rePopulateGrid();
}

ConfigurableGrid.prototype.saveValueToDom = function ConfigurableGrid_saveValueToDom(propVal) {
  //this method is for internal purposes only.
  
  //this method is to serve cell value changes only
  //this.selectedItem must be set correcty
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  
  var items  = this.selectedItem;
  var propNm = this.selectedProperty;
  
  function saveItemChanges( item ) {
    var itemNd = item.node;
    top.aras.setItemProperty(itemNd, propNm, propVal);
    
    var act = item.getAction();
    var re  = /^update$|^edit$|^create$|^add$|^version$/;
    
    if ( !re.test(act) ) {
      var newAct = (itemNd.selectSingleNode("locked_by_id")) ? "update" : "edit";
      item.setAction(newAct);
      var doGetItem = item.getAttribute("doGetItem");
      if (doGetItem == null) item.setAttribute("doGetItem", "0");
    }
  }
  
  if (!items.isCollection()) {
    var item    = items;
    var prevVal = item.getProperty(propNm);
    
    if (prevVal != propVal) this.handleCellEvent("onchangecell", propVal);
    
    saveItemChanges( item );
  }
  else {
    for (var i=0; i<items.getItemCount(); i++) {
      saveItemChanges( items.getItemByIndex(i) );
    }
  }
}

ConfigurableGrid.prototype.returnFocusToGrid = function ConfigurableGrid_returnFocusToGrid() {
  //this method is for internal purposes only.

  var a = document.applets[this.appletID];
  if (a) a.requestFocus();
}

ConfigurableGrid.prototype.returnFocusToGridAndEnableUserInput = function ConfigurableGrid_returnFocusToGridAndEnableUserInput() {
  //this method is for internal purposes only.
  this.returnFocusToGrid();
  this.enableUserInput();
}

//+++ standard Dialogs
ConfigurableGrid.prototype.onAfterStandardDialog = function ConfigurableGrid_onAfterStandardDialog( dialogRes, acceptEmptyString, specialCellValue ) {
  //this method is for internal purposes only.
  this.returnFocusToGridAndEnableUserInput();
  
  var self = this;
  function f() {
    self.selectedCell = null;
  }
  
  if ( !this.isEditMode ||
       (acceptEmptyString && (dialogRes == undefined || dialogRes == null)
        || (!acceptEmptyString) && (!dialogRes)) ) {
    f();
    return true;
  }
  
  if (!this.selectedCell && this.selectedRowId) {//this is possible after F2 is pressed
    var col = parseInt(this.selectedColumnNum);
    if ( !isNaN(col) ) {
      var a = this.getImplementationObject();
      if (a) {
        this.selectedCell = a.cells(this.selectedRowId, col);
      }
    }
  }
  
  if (!this.selectedItem || !this.selectedProperty || !this.selectedCell) {
    f();
    return false;
  }
  
  var v = dialogRes;
  if (specialCellValue !== undefined) v = specialCellValue;
  this.selectedCell.setValue( v );//update cell value
  
  this.saveValueToDom(dialogRes);
  
  this.handleCellEvent("oneditfinish");
  
  f();
  return true;
}

ConfigurableGrid.prototype.showTextDialog = function ConfigurableGrid_showTextDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;

  var param = new Object();
  param.isEditMode = this.isEditMode;
  var cont = this.selectedItem.getProperty(this.selectedProperty);
  if (cont !== undefined)
    param.content = cont;
  else
    param.content = "";
  
  var res = showModalDialog("textDialog.html", param, "resizable:yes;status:no;help:no;dialogWidth:600px;dialogHeight:450px;");

  this.onAfterStandardDialog(res, true);
}

ConfigurableGrid.prototype.showDateDialog  = function ConfigurableGrid_showDateDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  var cell = null;
  if (this.selectedCell){
    cell = this.selectedCell;
  } else {
    cell = this.hl_cell;
  }
  if (!cell) return false;
  var col = parseInt(this.selectedColumnNum);
  if ( isNaN(col) ) return false;
  if (!this.columnNds.item(col)) return false;
  
  var param = new Object();
  param.date = this.selectedItem.getProperty(this.selectedProperty);
  param.format = this.columnNds.item(col).getAttribute("pattern");
  
  var res = top.aras.uiShowDialogNearElement(document.applets[this.appletID], top.aras.getScriptsURL() + 'dateDialog.html', param, undefined, undefined, cell.getBounds());

  this.onAfterStandardDialog(res, true);
}

ConfigurableGrid.prototype.showImageDialog = function ConfigurableGrid_showImageDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  var cell = this.selectedCell;
  if (!cell) {
    cell = this.hl_cell;
    if (!cell) return false;
  }
    
  var params = new Object();
  params.aras = top.aras;
  params.image = this.selectedItem.getProperty(this.selectedProperty);
  var res = showModalDialog('ImageBrowser/imageBrowser.html', params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0'); 
  
  var specialValue = undefined;
  if (res) {
    if (res == "set_nothing") res = "";
    specialValue = "<img src=\"" + res.replace(/\"/g, "&quot;") + "\">";
  }
  
  this.onAfterStandardDialog(res, true, specialValue);
}

ConfigurableGrid.prototype.showColorDialog = function ConfigurableGrid_showColorDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  
  var oldColor = this.selectedItem.getProperty(this.selectedProperty);
  if (!oldColor) oldColor = "#ffffff";
  
  var frm = (top.tearoff_menu ? top.tearoff_menu : top);
  var res = frm.document.colorApplet.getColor(oldColor);
    
  if (res) {
    this.hl_cell_color = res;
    if (!this.selectedCell)
      this.selectedCell = this.hl_cell;
    this.selectedCell.setBgColor(res);    
  }
  
  this.onAfterStandardDialog(res, false);
}

ConfigurableGrid.prototype.showFormattedTextDialog =  function ConfigurableGrid_showFormattedTextDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  
  var content = this.selectedItem.getProperty(this.selectedProperty);
  var res;
  
  if (this.isEditMode) {
    var param = new Object();
    param.sHTML = content;
    param.aras = top.aras;
    
    res = showModalDialog('HTMLEditorDialog.html', param, 'status:0; help:0');
  }
  else {
    content = content.replace(/\\/g, "\\\\");
    content = content.replace(/\\n/g, "\n");
    content = content.replace(/'/g, "\\\'");
    showModalDialog("javascript: '" + content + "'", "", "status:0; help:0");
  }
  
  this.onAfterStandardDialog(res, true);
}

ConfigurableGrid.prototype.showItemDialog = function ConfigurableGrid_showItemDialog() {
  //this method is for internal purposes only.
  if (!this.selectedItem) return false;
  if (!this.selectedProperty) return false;
  var col = parseInt(this.selectedColumnNum);
  if ( isNaN(col) ) return false;
  var property = this.columnNds.item(col);
  if (!property) return false;
  
  var data_source_name = property.getAttribute("type");
  var sourceItemTypeName = (this.selectedItem.node) ? this.selectedItem.node.getAttribute("type") : "";
  var params = {aras:window.top.aras, itemtypeName:data_source_name, itemContext:undefined, itemSelectedID:undefined, sourceItemTypeName:sourceItemTypeName, sourcePropertyName:this.selectedProperty};
  
  var dlgRes = showModalDialog("searchDialog.html", params, "dialogHeight:450px; dialogWidth:700px; status:0; help:0; resizable:1");

  var res = (dlgRes ? dlgRes.itemID : dlgRes);
  var kn  = (dlgRes ? dlgRes.keyed_name : dlgRes);
  
  this.onAfterStandardDialog(res, true, kn);
    
  if (dlgRes != undefined) 
    this.selectedItem.setPropertyAttribute( this.selectedProperty, "keyed_name", kn );
}
//--- standard Dialogs

// +++ other Dialogs +++
ConfigurableGrid.prototype.selectDialog_CommonPart = function ConfigurableGrid_selectDialog_CommonPart( title ) {
  //this method is for internal purposes only.
  var rowId = this.selectedRowId;
  if (!rowId) return false;
  var col = parseInt(this.selectedColumnNum);
  if ( isNaN(col) ) return false;
  
  var a = this.getImplementationObject();
  if (!a) return;
  
  var column = this.getColumnDefinition(col);
  var source_form = top.aras.getItemProperty(column, "source_form");
  
  if (!source_form){
    this.returnFocusToGridAndEnableUserInput();
    return false;
  }
  
  var param = new Object();
  param.title  = title;
  param.formId = source_form;
  param.aras   = top.aras;
  param.item   = this.applyColumnQueryOrMethod();
  param.selectedItem   = this.selectedItem;
  
  var q = new Item("Form", "get");
  q.setAttribute("select", "width,height");
  q.setProperty("id", source_form);
  
  var r = q.apply();
  if ( r.isError() ) {
    this.showError( r );
    return false;
  }
  
  var width  = r.getProperty("width");
  var height = r.getProperty("height");
  if (!width)  width  = 450;
  if (!height) height = 700;
  
  var res = showModalDialog("ShowFormAsADialog.html", param,
              "dialogHeight:" + height + "px; dialogWidth:" + width + "px; " +
              "status:0; help:0; resizable:1; scroll:0;");
  

  this.returnFocusToGridAndEnableUserInput();
  
  this.handleCellEvent("oneditfinish");
  this.selectedCell = null;
  
  if (res) {
    var a = document.applets[this.appletID];
    if (a) {
      var cell = a.getCurCell();
      if (cell) {
        this.predefined_hl_cell = {
                                    start_edit: false,
                                    row : a.getRowIndex(cell.getRowId()),
                                    col : col
                                  };
      }
    }
    
    this.rePopulateGrid();
  }
  
  return true;
}

ConfigurableGrid.prototype.showBoundMultiSelectDialog = function ConfigurableGrid_showBoundMultiSelectDialog() {
  //this method is for internal purposes only.
  
  return this.selectDialog_CommonPart("Bound Multi-Select");
}

ConfigurableGrid.prototype.showUnboundMultiSelectDialog = function ConfigurableGrid_showUnboundMultiSelectDialog() {
  //this method is for internal purposes only.
  
  return this.selectDialog_CommonPart("Unbound Multi-Select");
}

ConfigurableGrid.prototype.showBoundSelectDialog = function ConfigurableGrid_showBoundSelectDialog() {
  //this method is for internal purposes only.
  
  return this.selectDialog_CommonPart("Bound Select");
}

ConfigurableGrid.prototype.showUnboundSelectDialog = function ConfigurableGrid_showUnboundSelectDialog() {
  //this method is for internal purposes only.
  
  return this.selectDialog_CommonPart("Unbound Select");
}
// --- other Dialogs ---

ConfigurableGrid.prototype.applyColumnQueryOrMethod = function ConfigurableGrid_applyColumnQueryOrMethod() {
  //this method is for internal purposes only.
  var col = parseInt(this.selectedColumnNum);
  if ( isNaN(col) ) return null;
  
  var column = this.getColumnDefinition(col);
  var select_query  = top.aras.getItemProperty(column, "select_query");
  var select_method = top.aras.getItemProperty(column, "select_method");
  
  var r = null;
  
  var item = this.selectedItem;
  
  if (select_query) {
    var q = new Item();
    if (item) {
      select_query = select_query.replace(/\{itemtype\}/g, item.getType()).replace(/\{id\}/g, item.getID());
    }
    
    q.loadAML(select_query);
    
    r = q.apply();
  }
  else if (select_method) {
    var f = this.selectMethods[select_method];
    if (!f) {
      var q = new Item("Method", "get");
      q.setAttribute("select", "method_code");
      q.setProperty("method_type", "JavaScript", "eq");
      q.setProperty("id", select_method, "eq");
      
      var m = q.apply();
      if ( m.isError() ) {
        this.showError( m );
        return null;
      }
      
      try {
        f = new Function("item", m.getProperty("method_code"));
      }
      catch (excep) {
        this.showError( (new Innovator()).newError(excep.description) );
        return null;
      }
      
      this.selectMethods[select_method] = f;
    }
    
    r = f(item);
  }
  else {
    return null;
  }
  
  if ( r.isError() ) {
    this.showError( r );
    return null;
  }
  
  return r;
}

ConfigurableGrid.prototype.showNothing = function ConfigurableGrid_showNothing() {
  //this method is for internal purposes only.
  var a = document.applets[this.appletID];
  if (!a) return;
  
  a.style.display = "none";
}

ConfigurableGrid.prototype.showError = function ConfigurableGrid_showError( err, showGrid ) {
  //this method is for internal purposes only.
  this.gridIsNotFunctional = true;
  
  if (showGrid != true) {
    this.showNothing();
    
    var btn;

    var a = document.applets[this.appletID];
    
    if (a) {
      btn = document.createElement("<input type=\"button\" value=\"Error Loading grid\" >");
      btn = a.parentNode.appendChild(btn);
    }
    else {
      btn = document.createElement("<input type=\"button\" value=\"Error Loading grid\" >");
      document.write("<input id=\"" + btn.uniqueID + "\" type=\"button\" value=\"Error Loading grid\" >");
      btn = document.getElementById(btn.uniqueID);
    }
    
    btn.onclick = function getErrDetails() {
      alert(err.getErrorDetail()); // ??? getErrorString is better
    }
  }
  else
    alert(err.getErrorDetail());
}

ConfigurableGrid.prototype.parseXPath = function ConfigurableGrid_parseXPath( xpath ) {
  //this method is for internal purposes only.
  
  var resArr = new Array();
  if (!xpath) return resArr;
  
  var arr = xpath.split("/");
  var re  = /Item(?:\[[^\[\]]*\])*\[@type=['"]([\w ]+)["']\](?:\[[^\[\]]*\])*/;//Item tag with @type criteria
  var re2 = /([^\[\]]+)(?:\[[^\[\]]*\])*(?:\[[^\[\]]*\])*/;//tag name with criteria
  
  for (var i=0; i<arr.length; i++) {
    var t = arr[i];
    if (t == ".") continue;
    if (t == "..") {
      resArr.pop();
      continue;
    }
    
    var e = new Object();
    if ( re.test(t) ) {
      e.tag = "Item";
      e.attributes = new Object();
      e.attributes.type = RegExp.$1;
    }
    else if ( re2.test(t) ) {
      e.tag = RegExp.$1;
    }
    else {
      e.tag = t;
    }
    
    resArr.push(e);
  }
  
  return resArr;
}

ConfigurableGrid.prototype.export2HTML = function ConfigurableGrid_export2HTML() {
  //this method is for internal purposes only.
  if (this.gridIsNotFunctional) return "";
  if (!this.isInitialized) return "";
  
  var self = this;
  
  var columns = self.gridDefinition.getRelationships("Grid Column");
  
  function buildXSLT() {
    if (self.export2HTML_cachedXSLT) return self.export2HTML_cachedXSLT;
    
    var n = columns.getItemCount();
    
    var resXSLT =
    "<xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\">" +
      "<xsl:output method=\"html\" encoding=\"UTF-8\" indent=\"no\"/>" +
        
        "<xsl:template name=\"calcRowspan\">" +
          "<xsl:param name=\"pid\"/>" +
          "<xsl:variable name=\"str\">" +
            "<xsl:call-template name=\"buildStr\">" +
              "<xsl:with-param name=\"pid\" select=\"$pid\"/>" +
            "</xsl:call-template>" +
          "</xsl:variable>" +
          "<xsl:value-of select=\"string-length($str)\"/>" +
        "</xsl:template>" +
        
        "<xsl:template name=\"buildStr\">" +
          "<xsl:param name=\"pid\"/>" +
          "<xsl:variable name=\"chs\" select=\"/Items/Item[@pid=$pid]\"/>" +
          "<xsl:choose>" +
            "<xsl:when test=\"count($chs)=0\">c</xsl:when>" +
            "<xsl:otherwise>" +
              "<xsl:for-each select=\"$chs\">" +
                "<xsl:call-template name=\"buildStr\">" +
                  "<xsl:with-param name=\"pid\" select=\"@id\"/>" +
                "</xsl:call-template>" +
              "</xsl:for-each>" +
            "</xsl:otherwise>" +
          "</xsl:choose>" +
        "</xsl:template>" +
        
        "<xsl:template match=\"/\">" +
          "<html xmlns:x=\"urn:schemas-microsoft-com:office:excel\">" +
            "<head>" +
              "<base href=\"" + top.aras.getScriptsURL() + "\"/>" +
              "<style type=\"text/css\">" +
              "<xsl:comment>" +
              "table {table-layout:fixed;}" +
              "th {background-color:buttonface;}" +
              "td {mso-number-format:General; vertical-align:top;}" +
              "pre {white-space:normal; word-wrap:break-word;}" +
              "br {mso-data-placement:same-cell;}" +
              "</xsl:comment>" +
              "</style>" +
            "</head>" +
            "<body>" +
              "<table x:str=\"\" border=\"1\" cellpadding=\"0\" cellspacing=\"0\" cols=\"" + columns.getItemCount() + "\">" +
                "<xsl:for-each select=\"/Items/@*[starts-with(local-name(),'width')]\">" +
                    "<col width=\"{.}\">" +
                      "<xsl:if test=\". = 0\">" +
                        "<xsl:attribute name=\"style\">display:none</xsl:attribute>" +
                      "</xsl:if>" +
                    "</col>" +
                "</xsl:for-each>" +
                "<thead>" +
                  "<tr>";
    
    for (var i=0; i<n; i++) {
      resXSLT +=
                    "<th>" + columns.getItemByIndex(i).getProperty("label") + "</th>";
    }
    
    resXSLT +=
                  "</tr>" +
                "</thead>" +
                "<tbody>" +
                  "<xsl:apply-templates select=\"/Items/Item[not(@pid)]\" mode=\"generateTR\"/>" +
                "</tbody>" +
              "</table>" +
            "</body>" +
          "</html>" +
        "</xsl:template>" +
        
        "<xsl:template match=\"Item\" mode=\"generateTR\">" +
          "<xsl:variable name=\"id\" select=\"@id\"/>" +
          "<xsl:variable name=\"rowspan\">" +
            "<xsl:call-template name=\"calcRowspan\">" +
              "<xsl:with-param name=\"pid\" select=\"$id\"/>" +
            "</xsl:call-template>" +
          "</xsl:variable>" +
          "<xsl:variable name=\"firstchild\" select=\"/Items/Item[@pid=$id][position() = 1]\"/>" +
          "<xsl:variable name=\"firstchildID\" select=\"$firstchild/@id\"/>" +
          "<tr>" +
            "<xsl:apply-templates select=\"prop\">" +
              "<xsl:with-param name=\"rowspan\" select=\"$rowspan\"/>" +
            "</xsl:apply-templates>" +
            "<xsl:apply-templates select=\"$firstchild\"/>" +
          "</tr>" +
          "<xsl:apply-templates mode=\"generateNestedRows\" select=\".\"/>" +
        "</xsl:template>" +
        
        "<xsl:template match=\"Item\" mode=\"generateNestedRows\">" +
          "<xsl:variable name=\"id\" select=\"@id\"/>" +
          "<xsl:apply-templates select=\"/Items/Item[@pid=$id][position() = 1]\" mode=\"generateNestedRows\"/>" +
          "<xsl:apply-templates select=\"/Items/Item[@pid=$id][position() &gt; 1]\" mode=\"generateTR\"/>" +
        "</xsl:template>" +

        "<xsl:template match=\"Item\">" +
          "<xsl:variable name=\"id\" select=\"@id\"/>" +
          "<xsl:variable name=\"rowspan\">" +
            "<xsl:call-template name=\"calcRowspan\">" +
              "<xsl:with-param name=\"pid\" select=\"$id\"/>" +
            "</xsl:call-template>" +
          "</xsl:variable>" +
          "<xsl:apply-templates select=\"prop\">" +
            "<xsl:with-param name=\"rowspan\" select=\"$rowspan\"/>" +
          "</xsl:apply-templates>" +
          "<xsl:apply-templates select=\"/Items/Item[@pid=$id][position() = 1]\"/>" +
        "</xsl:template>" +
        
        "<xsl:template match=\"prop\">" +
          "<xsl:param name=\"rowspan\"/>"+
          "<td rowspan=\"{$rowspan}\">" +
            "<xsl:variable name=\"ch\" select=\"*[1]\"></xsl:variable>" +
            "<xsl:choose>" +
              "<xsl:when test=\"not($ch)\"><pre><xsl:value-of select=\".\"/></pre></xsl:when>" +
              "<xsl:when test=\"local-name($ch)='checkbox'\">" +
                "<input type=\"checkbox\">" +
                  "<xsl:if test=\"$ch/@state='1'\">" +
                    "<xsl:attribute name=\"checked\"/>" +
                  "</xsl:if>" +
                "</input>" +
              "</xsl:when>" +
              "<xsl:otherwise>" +
                "<xsl:copy-of select=\"$ch\"/>" +
              "</xsl:otherwise>" +
            "</xsl:choose>" +
          "</td>" +
        "</xsl:template>" +
      "</xsl:stylesheet>";
    
    self.export2HTML_cachedXSLT = resXSLT;
    return resXSLT;
  }
  
  var resXSLT = buildXSLT();
  if (!resXSLT) return;
  
  var a = this.getImplementationObject();
  if (!a) return;
  
  var i = new Item();
  i.loadAML( a.getXML() );
  
  var r = i.dom.documentElement;
  for (var j=0; j<columns.getItemCount(); j++) {
    r.setAttribute( "width"+j, a.getColWidth(j) );
  }
  
  var resHTML = i.applyStylesheet(resXSLT, "text");
  
  return resHTML;
}

ConfigurableGrid.prototype.applyIOMMethod = function ConfigurableGrid_applyIOMMethod(methodId, item) {
  //this method is for internal purposes only.
  var q = new Item("Method", "get");
  q.setProperty("id", methodId);
  q.setAttribute("select", "name,method_type,method_code");
  
  var m = q.apply();
  
  if (m.isError()) {
    this.showError( m );
    return;
  }
  
  var method_name = m.getProperty("name");
  var method_type = m.getProperty("method_type");
  var res;
  var loc = (method_type == "JavaScript") ? "client" : "server";
  if (loc == "server")
  {
    var i = new Innovator();
    res = i.applyMethod(method_name, item.dom.xml);
  }
  else
  {
    item.SetThisMethodImplementation( new Function(m.getProperty("method_code")) );
    res = item.ThisMethod(undefined);
    if (res === undefined) res = item;
  }
  
  return res;
}

ConfigurableGrid.prototype.rePopulateGrid = function ConfigurableGrid_rePopulateGrid() {
  //this method is for internal purposes only.

  return this.populateGrid(true);
}

ConfigurableGrid.prototype.populateGrid = function ConfigurableGrid_populateGrid(repopulate) {
  //this method is for internal purposes only.
  //parameter repopulate is ignored.
  
  var a = this.getImplementationObject();
  if (!a) return false;
  if (this.userMethodRequiresRePopulating){ //to support grid repopulating in user methods
    this.userMethodRequiresRePopulating = false;
  }
  
  this.populateGridIsInProgress = true;
  var rootItemTypeName = this.getRootItemTypeName();
  this.cachedXSLT = this.cachedXSLT.replace("{$RootItemTypeName}", rootItemTypeName);
  var xml = top.aras.applyXsltString(this.topLevelNode, this.cachedXSLT);
  a.ReloadData(xml);
  if (repopulate) this.setDirtyAttr4ParentItemIfNeed();
}

ConfigurableGrid.prototype.getDom = function ConfigurableGrid_getDom() {
  //this method is for internal purposes only.
  
  return this.topLevelNode;
}

ConfigurableGrid.prototype.getGridName = function ConfigurableGrid_getGridName() {
  //this method is for internal purposes only.
  if (!this.gridDefinition) return "";
  
  return this.gridDefinition.getProperty("name");
}


ConfigurableGrid.prototype.mergeItemRelationships = function ConfigurableGrid_mergeItemRelationships(oldItem, newItem) {
  //this method is for internal purposes only.
  
  var newRelationships = newItem.selectSingleNode("Relationships");
  if (newRelationships != null) {
    var oldRelationships = oldItem.selectSingleNode("Relationships");
    if (oldRelationships == null) {
      var oldDoc = oldItem.ownerDocument;
      oldRelationships = oldItem.appendChild(oldDoc.createElement("Relationships"));
    }
    
    this.mergeItemsSet(oldRelationships, newRelationships);
  }
}

ConfigurableGrid.prototype.mergeItem = function ConfigurableGrid_mergeItem(oldItem, newItem) {
  //this method is for internal purposes only.
  var allPropsXpath = "*[local-name()!='Relationships']";
  
  var oldAction = oldItem.getAttribute("action");
  if (!oldAction) oldAction = "skip";
  
  if (oldAction == "delete") {
    //do not merge newItem into oldSet
  }
  else if (oldAction == "add") {
    //this should never happen because getItem results cannot return not saved Item. do nothing here.
  }
  else if (oldAction == "update" || oldAction == "edit") {
    //we can add only missing properties here and merge relationships
    var newProps = newItem.selectNodes(allPropsXpath);
    for (var i=0; i<newProps.length; i++) {
      var newProp = newProps[i];
      
      var propNm  = newProp.baseName;
      var oldProp = oldItem.selectSingleNode(propNm);
      
      if (!oldProp) {
        oldItem.appendChild(newProp.cloneNode(true));
      }
      else {
        var oldPropItem = oldProp.selectSingleNode("Item");
        if (oldPropItem) {
          var newPropItem = newProp.selectSingleNode("Item");
          if (newPropItem) this.mergeItem(oldPropItem, newPropItem);
        }
      }
    }
    
    //merge relationships
    this.mergeItemRelationships(oldItem, newItem);
  }
  else if (oldAction == "skip") {
    //all properties not containing Items can be replaced here.
    
    //process oldItem properies with * NO * Item inside
    var oldProps = oldItem.selectNodes(allPropsXpath + "[not(Item)]");
    for (var i=0; i<oldProps.length; i++) {
      var oldProp = oldProps[i];
      
      var propNm  = oldProp.baseName;
      var newProp = newItem.selectSingleNode(propNm);
      
      if (newProp) oldItem.replaceChild(newProp.cloneNode(true), oldProp);
    }
    
    //process oldItem properies with Item inside
    var oldItemProps = oldItem.selectNodes(allPropsXpath + "[Item]");
    for (var i=0; i<oldItemProps.length; i++) {
      var oldProp = oldItemProps[i];
      
      var propNm  = oldProp.baseName;
      var newProp = newItem.selectSingleNode(propNm);
      
      if (newProp) {
        var oldPropItem = oldProp.selectSingleNode("Item");
        var newPropItem = newProp.selectSingleNode("Item");
        if (newPropItem) this.mergeItem(oldPropItem, newPropItem);
        else {
          var oldPropItemAction = oldPropItem.getAttribute("action");
          if (!oldPropItemAction) oldPropItemAction = "skip";
          
          if (oldPropItemAction == "skip") oldItem.replaceChild(newProp.cloneNode(true), oldProp);
        }
      }
    }
    
    //process all newItem properties which are missing in oldItem
    var newProps = newItem.selectNodes(allPropsXpath);
    for (var i=0; i<newProps.length; i++) {
      var newProp = newProps[i];
      
      var propNm  = newProp.baseName;
      var oldProp = oldItem.selectSingleNode(propNm);
      
      if (!oldProp) oldItem.appendChild(newProp.cloneNode(true));
    }
    
    //merge relationships
    this.mergeItemRelationships(oldItem, newItem);
  }
}

ConfigurableGrid.prototype.mergeItemsSet = function ConfigurableGrid_mergeItemsSet(oldSet, newSet) {
  //this method is for internal purposes only.
  
  //both oldSet and newSet are nodes with Items inside. (oldSet and newSet normally are AML or Relationships nodes)
  var oldDoc = oldSet.ownerDocument;
  
  //we don't expect action attribute specified on Items from newSet
  var newItems = newSet.selectNodes("Item[not(@action)]");
  for (var i=0; i<newItems.length; i++) {
    var newItem = newItems[i];
    var newId   = newItem.getAttribute("id");
    var newType = newItem.getAttribute("type");
    
    var oldItem = oldSet.selectSingleNode("Item[@id=\"" + newId + "\"][@type=\"" + newType + "\"]");
    if (!oldItem) {
      //
      oldItem = oldSet.appendChild(oldDoc.createElement("Item"));
      oldItem.setAttribute("id", newId);
      oldItem.setAttribute("type", newType);
    }
    
    this.mergeItem(oldItem, newItem);
  }
}

ConfigurableGrid.prototype.hasSeparateDom = function ConfigurableGrid_hasSeparateDom() {
  //this method is for internal purposes only.
  if (this.gridIsNotFunctional) return;
  
  return (this.topLevelNode.ownerDocument == this.topLevelNode.parentNode);
}

ConfigurableGrid.prototype.setDirtyAttr4ParentItemIfNeed = function ConfigurableGrid_setDirtyAttr4ParentItemIfNeed()
{
  //this method is for internal purposes only.
  var piNd = parent.item;
  if (!piNd || this.hasSeparateDom()) return;
  
  var actionExists = (piNd.selectSingleNode('descendant-or-self::Item[string(@action)!="" and @action!="get" and @action!="skip" or @isDirty="1"]')!=null);
  if (!actionExists) return;
  
  if (!piNd.getAttribute('action'))
    piNd.setAttribute('action', 'update');

  if (piNd.getAttribute('isDirty')!='1')
    piNd.setAttribute('isDirty', '1');

}

////////////////////////////   ++++ public methods ++++    ////////////////////////////
ConfigurableGrid.prototype.runQuery = function ConfigurableGrid_runQuery(doMerge) {
  //this is a public method
  if (this.gridIsNotFunctional) return;
  if (!this.isInitialized) return;
  
  if (doMerge === undefined) {
    doMerge = !this.hasSeparateDom();
  }
  
  if (!this.isGridAppletLoaded) {
    setTimeout(this.instanceName + ".runQuery(" + doMerge + ")", 100);
    return;
  }
  
  var qryRes = null;
  var query = this.gridDefinition.getProperty("query");
  if (query) {
    query = query.replace(/\{itemtype\}/g, this.item_typeName).replace(/\{id\}/g, this.item_id);
    
    var i = new Item();
    i.loadAML(query);
    
    var msgId = top.aras.showStatusMessage(0, "Running grid query...", this.inProgressImg);
    qryRes = i.apply();
    top.aras.clearStatusMessage(msgId);
  }
  else {
    var i = new Item(this.item_typeName);
    i.setID(this.item_id);
    qryRes = i;
  }
  
  if (qryRes.isError()) {
    if (qryRes.getErrorWho() == 0) {
      qryRes.loadAML("<AML/>");
    }
    else {
      this.showNothing();
      return;
    }
  }
  
  // +++ convert server resonse into <AML><Item id="1" /> ... <Item id="n" /></AML> form
  var xslt =
  "<xsl:stylesheet version='1.0' xmlns:xsl='http://www.w3.org/1999/XSL/Transform'>\n" +
	"<xsl:output omit-xml-declaration='yes' method='xml'/>\n" +
	
	"<xsl:template match='/'>\n" +
		"<AML>" +
		  "<xsl:apply-templates select='//Result' />\n" +
		"</AML>" +
	"</xsl:template>\n" +
	
	"<xsl:template match='Result'>\n" +
			"<xsl:apply-templates select='@* | node()' />" +
	"</xsl:template>\n" +
	
	"<xsl:template match='@* | node()'>\n" +
		"<xsl:copy>\n" +
			"<xsl:apply-templates select='@* | node()' />\n" +
		"</xsl:copy>\n" +
	"</xsl:template>\n" +
  "</xsl:stylesheet>";
  
  var aml = qryRes.applyStylesheet(xslt, "text");
  qryRes.loadAML( aml );
  // --- convert server resonse into <AML><Item id="1" /> ... <Item id="n" /></AML> form
  
  // +++ pass the AML into user-defined IOM method
  var method = this.gridDefinition.getProperty("method");
  if (method)
  {
    //it's up to user to return valid Item
    var msgId = top.aras.showStatusMessage(0, "Applying grid method...", this.inProgressImg);
    qryRes = this.applyIOMMethod(method, qryRes);
    top.aras.clearStatusMessage(msgId);
  }
  // --- pass the AML into user-defined IOM method
  
  // +++ initialize "root" ItemType name
  var RootItemTypeName = "";
  
  var nd = qryRes.dom.selectSingleNode("/AML/Item[@type]");//will use an existing node as a template
  if (nd)
  {
    RootItemTypeName = nd.getAttribute("type");
    
    if ( nd.getAttribute("CGridStub") == "1" ) nd.parentNode.removeChild( nd );
  }
  else {
    var query = this.gridDefinition.getProperty("query");
    if (query)
    {
      var i = new Item();
      i.loadAML(query);
      
      nd = i.dom.selectSingleNode("/Item[@type]");
      if (nd) RootItemTypeName = nd.getAttribute("type");
    }
  }
  
  this.getRootItemTypeName_res = RootItemTypeName;
  // --- initialize "root" ItemType name
  
  // +++ merge query results into topLevelNode
  var newSet = qryRes.dom.selectSingleNode("//AML");
  if (newSet)
  {
    if (!doMerge) this.topLevelNode.text = "";
    this.mergeItemsSet(this.topLevelNode, newSet);
  }
  // --- merge query results into topLevelNode
  
  this.populateGrid(false);
}

ConfigurableGrid.prototype.setVisible = function ConfigurableGrid_setVisible(b) {
  //this is a public method
  if (!this.isInitialized) return;
  
  var a = document.applets[this.appletID];
  if (!a) return;
  
  a.style.height = "100%";

  if (b)
    a.style.visibility = "visible";
  else
    a.style.visibility = "hidden";
}

ConfigurableGrid.prototype.setEditMode = function ConfigurableGrid_setEditMode( b ) {
  //this is a public method

  this.isEditMode = b;
}

ConfigurableGrid.prototype.getImplementationObject = function ConfigurableGrid_getImplementationObject() {
  //this is a public method.
  //However the type of returned object depends on implementation.
  //In current implementation an instance of JExcelGridApplet class is returned.
  
  if (!this.isInitialized) return null;
  
  var a = document.applets[this.appletID];
  if (!a) return null;
  
  return a.object;
}

ConfigurableGrid.prototype.getSelectedRowId = function ConfigurableGrid_getSelectedRowId() {
  //this is a public method
  return this.selectedRowId;
}

ConfigurableGrid.prototype.getSelectedColumn = function ConfigurableGrid_getSelectedColumn() {
  //this is a public method
  return this.selectedColumnNum;
}

ConfigurableGrid.prototype.invalidateContent = function ConfigurableGrid_invalidateContent() {
  //this is a public method
  this.userMethodRequiresRePopulating = true;
}

ConfigurableGrid.prototype.showInvalidValueAlert = function ConfigurableGrid_showInvalidValueAlert(cell, msg)
{
  //this is a public method
  if (msg === undefined) msg = "The value is invalid.";
  
  this.cellValidationFailed = true;
  
  var continueEdit = confirm(msg);
  setTimeout(this.instanceName + ".returnFocusToGrid()", 1);
  
  return continueEdit;
}

ConfigurableGrid.prototype.markItemToCopyByRef = function ConfigurableGrid_showInvalidValueAlert(itm)
{
  //this is a public method
  
  for (var i=0; i<itm.getItemCount(); i++)
  {
    var curItm = itm.getItemByIndex(i);
    var itms2NotGet = curItm.getItemsByXPath("descendant-or-self::Item[@action and @action!='get' and @action!='skip']");
    if (itms2NotGet.getItemCount()>0)
    {
      curItm = itms2NotGet.getItemByIndex(0)
      throw(new Error(1, "Item (type="+curItm.getAttribute("type")+", id="+curItm.getAttribute("id")+") cannot be copied by reference because of its action="+curItm.getAttribute("action")))
    }
    curItm.setAttribute(this.copyByRefAttrNm, "1");
  }
}

ConfigurableGrid.prototype.setNewItemCreationEnabled = function ConfigurableGrid_setNewItemCreationEnabled(isEnabled) 
{
  //this is a public method
  this.newItemCreationDisabled = (!isEnabled);
}

ConfigurableGrid.prototype.overrideMethod = function ConfigurableGrid_overrideMethod( methodName 
                                                                                    /*methodF, makeACopy*/
                                                                                    /* or */
                                                                                    /*argName0, argName1, ... argNameN, methodCode*/)
{
  //this is public method.
  /*
   * methodName - name of the method to override (base method will be available as this.base$<methodName>).
   * the rest of parameters may be different:
   * 1) Pass a funtion to override the method:
   * arguments[1] - (methodF) instance of class Function.
   * arguments[2] - (makeACopy) Boolean. make a copy of a function (context of original function becomes unavaliable).
   *                true by deafult.
   *
   * 2) Pass method code to override the method:
   * arguments[1]...arguments[N-2] - names of parameters for the new method.
   * arguments[N-1] - String. Method code. 
   */
  
  var baseMethodName = "base$" + methodName;
  var baseMethod = this[baseMethodName];
  if (!baseMethod)
  {
    baseMethod = this[methodName];
    if (!baseMethod)
    {
      throw new Error(1, "There is no method " + methodName + " in ConfigurableGrid");
    }
    
    this[baseMethodName] = baseMethod;
  }
  
  var method = null;
  var methodType = "function";
  var makeACopy = true;
  if (arguments.length > 1)
  {
    method = arguments[1];
    if (method)
    {
      methodType = typeof(method);
      if (methodType == "function")
      {
        makeACopy = arguments[2];
        if (makeACopy == undefined) makeACopy = true;
        
        //It's also possible to parse the string to get parameters list and method code.
        //Review what is better.
        if (makeACopy)
        {
          var functionStr = method.toString();
          //extract function arguments
          functionStr.search(/\(([^\)]*)\)/);//find "(...)"
          var args = RegExp.$1.replace(/\s/g, "").replace(/,/g, "\",\"");//remove all white spaces and replace [,] with [","]
          if (args.length > 0) args = "\"" + args + "\"";
          
          //extract function code
          functionStr.search(/\{([\W\w]*)\}$/);
          var methodCode = RegExp.$1;
          
          method = eval("new Function(" + args + ", methodCode)");
        }
      }
      else
      {
        var methodCode = arguments[arguments.length-1];
        var args = "";
        for (var i=1; i<arguments.length-1; i++)
        {
          args += "arguments[" + i + "],";
        }
        
        method = eval("new Function(" + args + " methodCode)");
      }
    }
  }
  
  var newMethod = method;
  if (!newMethod)
  {
    //restore original base method
    newMethod = baseMethod;
  }
  
  this[methodName] = newMethod;
}
////////////////////////////   ---- public methods ----    ////////////////////////////
// ----- ConfigurableGrid prototype -----
