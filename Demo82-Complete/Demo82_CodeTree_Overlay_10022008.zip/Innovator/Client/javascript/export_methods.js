﻿// © Copyright by Aras Corporation, 2004-2007.

/*
 *   The export methods extension for the Aras Object.
 *
 */

/*-- exportItemType
 *
 *   Method to export the ItemType
 *   name   = the ItemType name
 *   action = the action value for the exported item
 *   lifeCycleMapAction = the action value for the exported Life Cycle Map
 *   revisionsAction    = the action value for the exported Revisions property item
 *   formAction         = the action value for the exported Form
 *
 */
Aras.prototype.exportItemType = function(name,action,lifeCycleMapAction,revisionsAction,formAction) {
  with (this) {
    var res = soapSend('ApplyItem', '<Item type="ItemType" action="get" levels="1" '+
		  'config_path="Property|View" expand="1" export="'+action+'" file="'+name+'ItemType">'+
			'<name>'+name+'</name></Item>');
    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var itemType   = new ActiveXObject("Msxml2.DOMDocument.4.0");
    itemType.async = false;
		itemType.preserveWhiteSpace = true;
    itemType.loadXML(res.getResultsBody());

    if (lifeCycleMapAction == 'get') {
      var item = itemType.selectSingleNode('/Item/default_lifecycle/Item');
      item.setAttribute('id','');
      item.setAttribute('action','get');
      item.removeChild(item.selectSingleNode('description'));
      item.removeChild(item.selectSingleNode('start_state'));
    } else {
      var lifeCycleMapName = itemType.selectSingleNode('/Item/default_lifecycle/Item/name').text;
      var lifeCycleMap     = exportLifeCycleMap(lifeCycleMapName,lifeCycleMapAction);
      itemType.selectSingleNode('/Item/default_lifecycle').replaceChild(lifeCycleMap.documentElement,itemType.selectSingleNode('/Item/default_lifecycle/Item'));
    }

    if (formAction == 'get') {
      var item = itemType.selectSingleNode('//Item[@type="Form"]');
      item.setAttribute('id','');
      item.setAttribute('action','get');
    } else {
      var formName = itemType.selectSingleNode('//Item[@type="Form"]/name').text;
      var form     = exportForm(formName,formAction);
      var related_id = itemType.selectSingleNode('//Item[@type="Form"]').parentNode;
      related_id.replaceChild(form.documentElement,related_id.selectSingleNode('Item'));
    }

    if (revisionsAction == 'get') {
      var item = itemType.selectSingleNode('/Item/revisions/Item');
      item.setAttribute('id','');
      item.setAttribute('action','get');
      item.removeChild(item.selectSingleNode('revision'));
    }

    var nodes = itemType.selectNodes('/Item/Relationships/Item[@type="Property"]');
    for (var i=0; i<nodes.length; ++i) {
      var node = nodes.item(i);
      if (getNodeElement(node,'data_type') == 'item') {
        var data_source = node.selectSingleNode('data_source');
        var newNode = data_source.cloneNode(false);
        var item = itemType.createElement('Item');
        item.setAttribute('id','');
        item.setAttribute('action','get');
        item.setAttribute('type','ItemType');
        var name = data_source.selectSingleNode('Item/name').cloneNode(true)
        item.appendChild(name);
        newNode.appendChild(item);
        node.replaceChild(newNode,data_source);
      }
    }

    return itemType;
  }
}

/*-- exportItemTypeEx
 *
 *   Method to export the ItemType, uses new server side ExportItemType method.
 *   itemID   = the ItemType id
 *
 */
Aras.prototype.exportItemTypeEx = function(itemID) {
		var statusId = this.showStatusMessage(0, '   Exporting ItemType ...', '../images/Animated/ProgressSmall.gif');
    var res = soapSend('ApplyItem', 
      '<Item type="ItemType" action="exportItemType" save_to_files="1" id="'+itemID+'" />');
		this.clearStatusMessage(statusId);
    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    
    var itemType   = new ActiveXObject("Msxml2.DOMDocument.4.0");
    itemType.async = false;
		itemType.preserveWhiteSpace = true;
    itemType.loadXML(res.getResultsBody());
    return itemType;
}



/*-- exportForm
 *
 *   Method to export the Form
 *   name   = the Form name
 *   action = the action value for the exported item
 *
 */
Aras.prototype.exportForm = function(name,action) {
  with (this) {
    var res = soapSend('ApplyItem', '<Item type="Form" action="get" levels="3" '+
		  'config_path="Form Event|Body/Field/Field Event" expand="1" export="'+action+
			'" file="'+name+'Form"><name>'+name+'</name></Item>');
    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var form   = new ActiveXObject("Msxml2.DOMDocument.4.0");
    form.async = false;
		form.preserveWhiteSpace = true;
    form.loadXML(res.getResultsBody());

    var nodes = form.selectNodes('//propertytype_id');
    for (var i=0; i<nodes.length; ++i) {
      var node = nodes.item(i);

      var item = node.selectSingleNode('Item');
      var id   = item.getAttribute('id');
      node.removeChild(item);
      node.text = id;
    }

    return form;
  }
}

/*-- exportLifeCycleMap
 *
 *   Method to export the Life Cycle Map
 *   name   = the ItemType name
 *   action = the action value for the exported item
 *
 */
Aras.prototype.exportLifeCycleMap = function(name,action) {
  with (this) {
    var res = soapSend('ApplyItem', '<Item type="Life Cycle Map" action="get" levels="1" '+
		  'config_path="Life Cycle Transition|Life Cycle State" expand="1" export="'+action+
			'" file="'+name+'LifeCycleMap"><name>'+name+'</name></Item>');
    if (res.getFaultCode()!=0) {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }

    var lifeCycleMap   = new ActiveXObject("Msxml2.DOMDocument.4.0");
    lifeCycleMap.async = false;
		lifeCycleMap.preserveWhiteSpace = true;
    lifeCycleMap.loadXML(res.getResultsBody());
    if (!lifeCycleMap.selectSingleNode('/Item')) {
      top.aras.AlertError('The ExportItem result is empty.', "", "");
      return false;
    }

    var startState = lifeCycleMap.selectSingleNode('/Item/start_state/Item/@id');
    if (!startState) startState = lifeCycleMap.selectSingleNode('/Item/start_state');
    var duplicate  = lifeCycleMap.selectSingleNode('/Item/Relationships/Item[@id="' + startState.text + '"]');

    var item = lifeCycleMap.createElement('Item');
    item.setAttribute('type','Life Cycle State');
    item.setAttribute('action','get');
    item.appendChild(duplicate.selectSingleNode('name').cloneNode(true));

    duplicate.parentNode.insertBefore(item,duplicate);
    duplicate.parentNode.removeChild(duplicate);

    var nodes = lifeCycleMap.selectNodes('/Item/Relationships/Item[@type="Life Cycle Transition"]');
    for (var i=0; i<nodes.length; ++i) {
      var node = nodes.item(i);

      var fromState = node.selectSingleNode('from_state/Item');
      fromState.setAttribute('id','');
      fromState.setAttribute('action','get');

      var toState = node.selectSingleNode('to_state/Item');
      toState.setAttribute('id','');
      toState.setAttribute('action','get');
    }

    return lifeCycleMap;
  }
}

/*-- exportItem -- This is old and should be updated and was in item_methods.js
 *
 *   Method to export an item
 *   typeName = the ItemType name
 *   xpath    = the XPath to the item to export
 *   fName    = the filename to save the export
 *
 */
Aras.prototype.exportItem = function(typeName, xpath, fName) {
  with (this) {
    var statusId = showStatusMessage(0, '   Exporting item...','../images/Animated/ProgressSmall.gif');
    var typeAttr = (typeName.length>0) ? ('[@type="' + typeName + '"]') : '';
    var node = dom.selectSingleNode('/Innovator/Items/Item' + typeAttr + '[' + xpath + ']');
    if (!node) return false;
    var itemID = node.getAttribute('id');
    if (itemID.length>0 && typeName.length>0) {
      return exportItems(typeName, 'id="' + itemID + '"', fName);
    }
  }
}

/*-- exportItems -- This is old and should be updated and was in item_methods.js
 *
 *   Method to export an item
 *   typeName = the ItemType name
 *   xpath    = the XPath to the item to export
 *   fName    = the filename to save the export
 *
 */
Aras.prototype.exportItems = function(typeName, xpath, fName) {
  with (this) {
    var body = '', attrs = '';
    if (arguments.length > 1) {
      attrs = arguments[1];
      if (!(attrs.length > 0)) { 
        top.aras.AlertError ('The ID of the exported item is not set.', "", ""); 
        return false; 
      }
    }

    var soapBody = '<Item export="create" ' +
      'type="' + typeName + '" ' +
      'file="' + fName + '" ' +
      'levels="4" ' +
      attrs + ' action="get" />';
    var res = soapSend('GetItem', soapBody);
    clearStatusMessage(statusId);
		
    if (res.getFaultCode() != 0) return false;
    else return true;
  }
}

/*-- importItem -- This is old and should be updated and was in item_methods.js
 *              -- should be able to just use the ApplyItem or Apply AML
 *
 *   Method to import an item
 *   fName = the filename to import the item
 *
 */
Aras.prototype.importItem = function(fName) {
  with (this) {
    var statusId = showStatusMessage(0, '   Importing item...','../images/Animated/ProgressSmall.gif');

    var body = '';
    var soapBody = '<Item ' +
      'file="' + fName + '" />' 

    var res = soapSend('CreateItem', soapBody);
		
    if (res.getFaultCode() != 0) return false;

    return true;
  }
}

