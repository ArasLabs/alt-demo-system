﻿// (c) Copyright by Aras Corporation, 2004-2007.

Aras.prototype.uiRegWindowEx = function Aras_uiRegWindowEx(itemID, win) {
/*-- uiRegWindowEx
 *
 *  registers window as Innovator window.
 *  All Innovator windows get events notifications.
 *  All Innovator windows are closed when main window is closed.
 *
 */

  if (!itemID || !win) return false;

  var winName = this.mainWindowName + '_' + itemID;
  this.windowsByName[winName] = win;

  return true;
}

Aras.prototype.uiUnregWindowEx = function Aras_uiUnregWindowEx(itemID) {
/*-- uiUnregWindowEx
 *
 *  unregisters window as Innovator window (should be called when item window is closed).
 *  All Innovator windows get events notifications.
 *  All Innovator windows are closed when main window is closed.
 *
 */

  if (!itemID) return false;

  var winName = this.mainWindowName + '_' + itemID;
  delete this.windowsByName[winName];

  return true;
}

Aras.prototype.uiFindWindowEx = function Aras_uiFindWindowEx(itemID) {
/*-- uiUnregWindowEx
 *
 *  finds registered Innovator window.
 *
 */

  if (!itemID) return null;

  var winName = this.mainWindowName + '_' + itemID;
  var res = null;
  try {
    res = this.windowsByName[winName];
    if (res == undefined) res = null;
  } catch (excep) {}

  if (res && top.aras.isWindowClosed(res)) {
    this.uiUnregWindowEx(itemID);
    return null;
  }

  return res;
}

Aras.prototype.uiCheckExistedFile = function(fileNd) {
    var filename = fileNd.selectSingleNode("filename").text;
    var checkedout_path = top.aras.getWorkingDir(true, window);
    top.aras.vault.setWorkingDir(checkedout_path);
  if (top.aras.setFileNameInVaultWithPathCheck(checkedout_path, filename))
  {
      var param = new Object();
    param.buttons = new Object();
    param.buttons.btnYes = 'Yes';
    param.buttons.btnNo  = 'No';
    param.defaultButton  = 'btnNo';
    param.message = checkedout_path + '\\' +filename + ' already exists in target directory. Do you want to replace it?';
    var res = showModalDialog(this.getScriptsURL()+"groupChgsDialog.html", param, "dialogHeight:150px;dialogWidth:350px;center:yes;resizable:no;status:no;help:no;");
    if (res == "btnNo") {
            top.aras.AlertError('Checkout not completed.');
            return false;
        }
        return true;
  }
    return true;
}

Aras.prototype.uiFindWindowEx2 = function(itemNd) {
  var itemID = itemNd.getAttribute('id');
  var win = this.uiFindWindowEx(itemID);
  if (! win) try{
    var parentItemNd = itemNd.selectSingleNode("../../../..");
    if (parentItemNd && parentItemNd.nodeType!=9) {
      var pid = parentItemNd.getAttribute('id');
      win = this.uiFindWindowEx(pid);
    }
  }catch(exc1){}
  if (!win) win = window;
  return win;
}

Aras.prototype.uiOpenWindowEx = function Aras_uiOpenWindowEx(itemID, params)
{
  if (!itemID) return null;
  if (params==undefined) params='';

  var isMainWindow = (top.name == this.mainWindowName);

  if (!isMainWindow && top.opener && !top.aras.isWindowClosed(top.opener)) return top.opener.top.aras.uiOpenWindowEx(itemID, params);
  else {
    var winName = this.mainWindowName+'_'+itemID;
    var win = null;
    try {
      win = top.open('about:blank', winName, params);
    }
    catch (excep) {/* "No such interface supported" exception is possible here */}

    if (win) try {//substitute opener for the new window
      if (top.opener && !top.aras.isWindowClosed(top.opener) && top.opener.name == this.mainWindowName) {
        win.opener = top.opener;
      }
    }
    catch (excep) {/* security exception may occur */}

    var F5 = 116;
    if (win) this.utils.HideKeyboardInput(F5, true, 0, win);
    
    return win;
  }
}

Aras.prototype.uiShowPopupBlockerQuestion = function Aras_uiShowPopupBlockerQuestion()
{
  this.AlertError(
    "Innovator has failed to open a new window.<br><br>" +
    
    "The most common cause for this is the use of pop-up blocking software.<br>" +
    "Please, allow pop-ups for the Innovator web host.<br><br>" +
    
    "If you do not use pop-up blocking software, please ensure your browser software is up to date.", "", "");
}

Aras.prototype.uiCloseWindowEx = function(itemID)
{
  if (!itemID) return false;
  with (this) {
    var win = uiFindWindowEx(itemID);
    if (win) win.close();
  }
  return true;
}


/*
 * uiGetFormID4ItemEx - function to get id of form correspondent to the item (itemNd) and mode
 *                  (result depends on current user)
 *
 * parameters:
 * itemNd   - xml node of item to find correspondent form
 * formType - string, representing mode: 'add', 'view', 'edit' or 'print'
 */
Aras.prototype.uiGetFormID4ItemEx = function Aras_uiGetFormID4ItemEx(itemNd, formType)
{

  function getForms(arasObj, itemType, roles, formType, classification)
  {
    var returnNodes;
    if (typeof(roles)=="string")
    {
      var tmpRoles = roles;
      roles = new Array();
      roles.push(tmpRoles);
    }
    var strRoles = "(role='" + roles.join("' or role='") + "')";

    if (classification)
    {
      var xp = "Relationships/Item[@type='View' and " + strRoles + " and type='" + formType + "'][form_classification]/related_id/Item[@type='Form']";
      var formIds = new Array();
      var tmpNds = itemType.selectNodes( xp );
      var itemTypeNm = arasObj.getItemProperty(itemType, "name")
      if (tmpNds.length > 0)
      {
        for (var i = 0; i < tmpNds.length; i++)
        {
          var formClassification = tmpNds[i].parentNode.parentNode.selectSingleNode("form_classification").text;
          if (arasObj.areClassPathsEqual(formClassification, classification, itemTypeNm))
            formIds.push(tmpNds[i].getAttribute("id"));
        }
      }
      else
        returnNodes = null;
      
      if (formIds.length>0)
      {
        var additionalXp = "[@id='" + formIds.join("' or @id='") + "']";
        xp += additionalXp;
        returnNodes = itemType.selectNodes( xp );
      }
    }
    if (!(returnNodes && (returnNodes.length != 0)))
      returnNodes = itemType.selectNodes("Relationships/Item[@type='View' and string(form_classification)='' and " + strRoles + " and type='"+formType+"']/related_id/Item[@type='Form']");

    return returnNodes;
  }

  function findMaxPriorityFormID(arasObj, formNds)
  {
    if (formNds.length == 0) return "";

    var currForm = formNds[0];
    var currPriority = arasObj.getItemProperty(formNds[0].selectSingleNode("../.."), "display_priority");
    if (currPriority == "") currPriority = Number.POSITIVE_INFINITY;

    for (var i=1; i<formNds.length; i++)
    {
      var priority = arasObj.getItemProperty(formNds[i].selectSingleNode("../.."), "display_priority");
      if (priority == "") priority = Number.POSITIVE_INFINITY;

      if (currPriority > priority)
      {
        currPriority = priority;
        currForm = formNds[i];
      }
    }

    return currForm.getAttribute("id");
  }

  if (!itemNd) return "";
  if (!formType || formType.search(/^default$|^add$|^view$|^edit$|^print$|^search$/)==-1) return "";

  var userIdentities = this.getIdentityList().split(",");
  if (userIdentities.length == 0) return "";

  var userNd = null;
  var tmpUserID = this.getCurrentUserID();

  if (tmpUserID == this.getUserID())
  {
    userNd = this.getLoggedUserItem();
  }
  else
  {
    userNd = this.getItemFromServerWithRels('User',tmpUserID,'id','Alias','related_id(id)',true).node;
  }
  if (!userNd) return "";

  var identityNd = userNd.selectSingleNode("Relationships/Item[@type='Alias']/related_id/Item[@type='Identity']");
  if (!identityNd) return "";

  var identityId   = identityNd.getAttribute("id");
  var itemTypeID   = itemNd.getAttribute("typeId");
  var itemTypeName = itemNd.getAttribute("type");
  var itemTypeNd   = this.getItemTypeDictionary(itemTypeName).node;
  var classification;
  var classificationNode = itemNd.selectSingleNode("classification");
  if (classificationNode)
    classification = classificationNode.text;
  
  var formID = "";
  

  formID = findMaxPriorityFormID(this, getForms(this, itemTypeNd, identityId, formType, classification));
  if (formID) return formID;

  if (formType != "default")
  {
    formID = findMaxPriorityFormID(this, getForms(this, itemTypeNd, identityId, "default", classification));
    if (formID) return formID;
  }
  
  formID = findMaxPriorityFormID(this, getForms(this, itemTypeNd, userIdentities, formType, classification));
  if (formID) return formID;
  
  if (formType != "default")
  {
    formID = findMaxPriorityFormID(this, getForms(this, itemTypeNd, userIdentities, "default", classification));
    if (formID) return formID;
  }

  return "";
}

/*
 * uiGetRelationshipView4ItemTypeEx - function to get Relationship View of ItemType
 *                  (result depends on current user)
 *
 * parameters:
 * itemType   - xml node of ItemType
 */
Aras.prototype.uiGetRelationshipView4ItemTypeEx = function Aras_uiGetRelationshipView4ItemTypeEx(itemType)
{
  if (!itemType) return null;

  with (this)
  {
    var userIdentities = getIdentityList().split(',');
    if (userIdentities.length == 0) return null;

    var userNd = null;
    var tmpUserID = getCurrentUserID();

    if (tmpUserID == getUserID())
    {
      userNd = getLoggedUserItem();
    }
    else
    {
      userNd = this.getItemFromServerWithRels('User',tmpUserID,'id','Alias','related_id(id)',true).node;
    }
    if (!userNd) return null;

    var identityNd = userNd.selectSingleNode('Relationships/Item[@type="Alias"]/related_id/Item[@type="Identity"]');
    if (!identityNd) return null;

    var identityId = identityNd.getAttribute('id');

    var res = itemType.selectSingleNode('Relationships/Item[@type="Relationship View" and (related_id/Item/@id="'+identityId+'" or related_id="'+identityId+'")]');
    if (!res) for (var i=0; i<userIdentities.length; i++) {
      res = itemType.selectSingleNode('Relationships/Item[@type="Relationship View" and (related_id/Item/@id="'+userIdentities[i]+'" or related_id="'+userIdentities[i]+'")]');
      if (res) break;
    }

    return res;
  }
}

/*
 * uiGetTOCView4ItemTypeEx - function to get TOC View of ItemType
 *                  (result depends on current user)
 *
 * parameters:
 * itemType   - xml node of ItemType
 */
Aras.prototype.uiGetTOCView4ItemTypeEx = function Aras_uiGetTOCView4ItemTypeEx(itemType)
{
  if (!itemType) return null;

  with (this)
  {
    var userIdentities = getIdentityList().split(',');
    if (userIdentities.length == 0) return null;

    var userNd = null;
    var tmpUserID = getCurrentUserID();

    if (tmpUserID == getUserID())
    {
      userNd = getLoggedUserItem();
    }
    else
    {
      userNd = this.getItemFromServerWithRels('User',tmpUserID,'id','Alias','related_id(id)',true).node;
    }
    if (!userNd) return null;

    var identityNd = userNd.selectSingleNode('Relationships/Item[@type="Alias"]/related_id/Item[@type="Identity"]');
    if (!identityNd) return null;

    var identityId = identityNd.getAttribute('id');

    var res = itemType.selectSingleNode('Relationships/Item[@type="TOC View" and (related_id/Item/@id="'+identityId+'" or related_id="'+identityId+'")]');
    if (!res) for (var i=0; i<userIdentities.length; i++)
    {
      res = itemType.selectSingleNode('Relationships/Item[@type="TOC View" and (related_id/Item/@id="'+userIdentities[i]+'" or related_id="'+userIdentities[i]+'")]');
      if (res) break;
    }

    return res;
  }
}

/*
 * uiGetForm4ItemEx - function to get form xml node correspondent to the item (itemNd) and mode
 *                  (result depends on current user)
 *
 * parameters:
 * itemNd   - xml node of item to find correspondent form
 * formType - string, representing mode: 'add', 'view', 'edit' or 'print'
 */
Aras.prototype.uiGetForm4ItemEx = function(itemNd, formType)
{
  if (!itemNd) return null;
  if (!formType || formType.search(/^default$|^add$|^view$|^edit$|^print$|^search$/)==-1) return null;
  var formID = this.uiGetFormID4ItemEx(itemNd, formType);
  var formNd = this.getFormForDisplay(formID).node;
  return formNd;
}


Aras.prototype.getDefaultViewMode = function Arasa_getDefaultViewMode(itemTypeName)
{
  var res = '';

  var qry = new top.Item();
  qry.setType('ItemType');
  qry.setAction('get');
  qry.setProperty('name',itemTypeName);
  qry.setAttribute('select','structure_view');
  var result = qry.apply();
  if(!result.isError())
  {
    var itemType = result.getItemByIndex(0).node;
    if (itemType) res = this.getItemProperty(itemType, 'structure_view');
  }
  if (res == '') res = this.getVariable('ViewMode');

  return res;
}

/*
 * uiShowItemEx
 *
 * parameters:
 * 1) itemNd     - item to be shown
 * 2) viewMode   - 'tab view', 'tree view', 'print view', 'where used' or 'openFile'
 * 3) isTearOff  - true or false.
 */
Aras.prototype.uiShowItemEx = function Aras_uiShowItemEx(itemNd, viewMode, isTearOff)
{
  if (!itemNd) return false;
  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  if (viewMode == undefined )  
		viewMode = this.getDefaultViewMode(itemTypeName);
  if (viewMode == "tree view") 
		viewMode = "tab view";
  var isNew = false;
  if (viewMode == "new")
  {
    viewMode = "tab view";
    isNew = true;
  }

  if (itemTypeName.search(/^Form$|^Life Cycle Map$|^Workflow Map$/) == -1)
  {
    if (viewMode.search(/^tab view$|^tree view$|^print view$|^where used$|^openFile$/) == -1)
    {
      top.aras.AlertError("The specified view mode \"" + viewMode + "\" is invalid.\n\n" +
      "The supported view modes are:\n"+
      "\"tab view\", \"tree view\", \"print view\", \"where used\", \"openFile\""+
      ".", "", "");
      return false;
    }
  }

  if (viewMode.search(/^print view$|^where used$/) == 0) 
    isTearOff = true;
  
  if (isTearOff == undefined ) 
    isTearOff = (this.getVariable('TearOff')=='true');

  var isEditMode = (this.isTempEx(itemNd) || this.isLockedByUser(itemNd) ) ? true : false;

  if (itemTypeName=='File' && viewMode=='openFile')
  {
    var fileURL = this.getFileURLEx(itemNd);
    if (fileURL == '')
    {
      top.aras.AlertError('Failed to get the File.', "The file URL is invalid.", "Client Side Error");
      return false;
    }

    window.open(fileURL);
    return true;
  }
  else if ((viewMode == "tree view") && (itemTypeName == "Report" || itemTypeName == "Method"))
    viewMode = "tab view";

  var win = this.uiFindWindowEx(itemID);
  if (win && viewMode != 'print view')
	{
    if (win.opener == undefined)
    {
      this.uiUnregWindowEx(itemID);
      win = null;
    }
    else
    {
      win.focus();
      return true;
    }
  }

  if (viewMode.search(/^print view$|^where used$/) == -1)
  {
    if      (itemTypeName == 'Form')           return this.uiShowFormItemEx(itemNd, isTearOff);
    else if (itemTypeName == 'Life Cycle Map') return this.uiShowLifeCycleItemEx(itemNd, isTearOff);
    else if (itemTypeName == 'Workflow Map')   return this.uiShowWorkflowItemEx(itemNd, isTearOff);
  }

  var winH = 400;
  var winW = 800;
  if (isTearOff)
  {
    if (viewMode=='tab view')
    {
      var scrH = top.screen.availHeight;
      var scrW = top.screen.availWidth;
      var x = (scrW - winW) / 2; if (x<0) x=0;
      var y = (scrH - winH) / 2; if (y<0) y=0;

      var formID;
      if (isNew)
        formID = this.uiGetFormID4ItemEx(itemNd, 'add');
      else
        formID = this.uiGetFormID4ItemEx(itemNd, (isEditMode ? 'edit':'view'));

      var formNd = this.getFormForDisplay(formID).node;
      if (formNd)
      {
        var formH = this.getItemProperty(formNd, 'height');
        var formW = this.getItemProperty(formNd, 'width');
        if (formH == '') formH = 250;
        else if (formH < 50) formH = 50;
        if (formW == '') formW = 800;
        else if (formW < 50) formW = 50;

        winH = (formH > scrH) ? scrH : formH;
        winW = (formW > scrW) ? scrW : formW;
        
        winH = parseInt(winH) + 50 /*body height*/ + 50 /*menu*/ + 20 /*status bar*/;
        
        x = (scrW - winW) / 2;
        y = (scrH - winH) / 2;
      }
      
      win = this.uiOpenWindowEx(itemID, 'width=1,height=1,top='+y+',left='+x+',scrollbars=yes,resizable=yes,status=no');
      if (!win)
      {
        this.uiShowPopupBlockerQuestion();
        return false;
      }

      try
      {
        //win.moveTo(x, y);
        win.resizeTo(winW, winH);
      }
      catch (excep) {}
    }
    else if (viewMode=='print view')
    {
      var winPrint = this.uiFindWindowEx(itemID + 'print');
      if (winPrint)
      {
        this.uiPrintViewItemEx(winPrint, itemNd);
        winPrint.focus();
        return true;
      }
      else
      {
        var winName = this.mainWindowName+'_'+itemID+'print';
        win = top.open('about:blank', winName, 'scrollbars=no,resizable=yes,status=no');
      }
    }
    else
    {
      win = this.uiOpenWindowEx(itemID, 'scrollbars=no,resizable=yes,status=yes');
      if (!win)
      {
        this.uiShowPopupBlockerQuestion();
        return false;
      }
    }

    if (viewMode=='print view') this.uiRegWindowEx(itemID+'print', win);
    else this.uiRegWindowEx(itemID, win);
  }
  else
  {
    win = top.main.work;
    this.uiRegWindowEx(itemID, win);
  }

  if (win)
  {
    win.itemTypeName = itemTypeName;
    win.isEditMode = isEditMode;

    if      (viewMode=='tab view')   this.uiTabViewItemEx(win, itemNd, undefined, winH, formH);
    else if (viewMode=='tree view')  this.uiTreeViewItemEx(win, itemNd);
    else if (viewMode=='print view') this.uiPrintViewItemEx(win, itemNd);
    else if (viewMode=='where used') this.uiWhereusedViewItemEx(win, itemNd);
  }

  return true;
}

Aras.prototype.uiShowFormItemEx = function Aras_uiShowFormItemEx(formNd, isTearOff)
{
  if (!formNd || formNd.getAttribute('type')!='Form') return false;
  if (isTearOff==undefined) isTearOff = this.getVariable('TearOff')=='true';

  var formID = formNd.getAttribute('id');
  var win = this.uiFindWindowEx(formID);
  if (win)
  {
    win.focus();
    return true;
  }

  win = (isTearOff ? this.uiOpenWindowEx(formID, 'scrollbars=no,resizable=yes,status=no') : top.main.work);
  if (!win)
  {
    this.uiShowPopupBlockerQuestion();
    return false;
  }

  this.uiRegWindowEx(formID, win);
  win.aras = this;

  var url = 'FormTool/formtool.html?formID='+formID;

  if (isTearOff)
  {
    var isEditMode = (this.isTempEx(formNd) || this.isLockedByUser(formNd) ) ? true : false;
    var typeID     = formNd.getAttribute('typeId');
    var itemTypeNd = null;
    if (typeID)
    {
      itemTypeNd = this.getItemTypeDictionary(this.getItemTypeName(typeID)).node;
    }
    else
    {
      itemTypeNd = this.getItemTypeDictionary('Form').node;
    }

    var doc = win.document.open();
    win.aras = this;
    win.isTearOff = true;
    win.item      = formNd;
    win.itemID    = formID;
    win.itemTypeName = 'Form';
    win.itemType = itemTypeNd;
    win.viewMode = '';
    win.isEditMode = isEditMode;
    
    var itemTypeLabel = this.getItemProperty(itemTypeNd, "label");
    var keyed_name    = this.getKeyedNameEx(formNd);
    
    doc.write(
    '<html>\n' +
    '<head>\n' +
    '<title>'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+(isEditMode ? '':' (read only)')+'</title>\n' +
    '<base HREF="'+this.getScriptsURL()+'" />\n' +
    '</head>\n' +
    '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +
    '<SCRIPT ID="formtool_window_script"></SCRIPT>\n' +
    '<SCRIPT>\n' +
      'function updateRootItem(itemNd) {\n'+
      ' if (!itemNd) {top.aras.AlertError("Failed to get the "+window.itemTypeName, "", ""); return false;}\n'+
      ' if (itemNd.getAttribute("type")!=window.itemTypeName) {top.aras.AlertError("Invalid ItemType specified: ("+itemNd.getAttribute("type")+")."); return false;}\n'+
      ' itemID = itemNd.getAttribute("id");\n'+
      ' var wasLocked = (top.aras.isLockedByUser(item) || top.aras.isTempEx(item));\n'+
      ' item   = itemNd;\n'+
      ' itemID = itemNd.getAttribute("id");\n'+
      ' if (isEditMode) {\n'+
      '  isEditMode = wasLocked;\n'+
      '  setEditMode();\n'+
      ' }\n'+
      ' else {\n'+
      '  isEditMode = wasLocked;\n'+
      '  setViewMode();\n'+
      ' }\n'+
      '}\n'+
      'function setTitle(isEditMode) {\n' +
      ' document.title="'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - " + top.aras.getKeyedNameEx(item);\n' +
      '}\n' +
      'function setEditMode() {\n'+
      ' isEditMode = true;\n'+
      ' setTitle(true);\n'+
      ' document.frames.editor.setEditMode();\n'+
      '}\n'+
      'function setViewMode() {\n'+
      ' isEditMode = false;\n'+
      ' setTitle(false);\n'+
      ' document.frames.editor.setViewMode();\n'+
      '}\n'+
      'function turnWindowReadyOn() {\n'+
      //that script will set windowReady = true and cause menuUpdate
      ' document.scripts["formtool_window_script"].src = "' + this.getScriptsURL() + '../javascript/formtool_window.js";\n' +
      //clear onload handler on editor frame
      ' document.frames["editor"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
      '}\n'+
      'onload = function onload_handler() {\n'+
      ' setTimeout("onload_handler2();", 1);\n'+
      '}\n'+
      'function onload_handler2() {\n' +
      ' window.aras = new Aras(window.aras);\n' +
      ' var frmSet = document.createElement(commentedFrameset.innerHTML);\n'+
      ' var oldBody = document.body;\n'+
      ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n'+
      ' var frm = document.createElement(commentedFrame1.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("tearOffMenu.aspx?view=formtool");\n'+
      ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
      ' frm.attachEvent("onload", turnWindowReadyOn);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("'+url+'");\n'+
      ' frm = document.createElement(commentedFrame3.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("statusbar.html?xmlfile=tabview_statusbar.xml");\n'+
      '}\n' +
    '</SCRIPT>\n' +
    '<COMMENT id="commentedFrameset"><FRAMESET rows=\'50px,*,20px\'></FRAMESET></COMMENT>\n'+

    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame2"><frame name="editor" src="about:blank" style="border-top:2px groove;" frameborder="yes" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame3"><frame name="statusbar" src="about:blank" frameborder=0 scrolling=no noresize /></COMMENT>' +

    '<BODY></BODY>\n'
    );

    win.doc = doc;
    win.setTimeout("window.doc.close();window.doc = undefined;", 1);
  }
  else win.location.replace(url);
}


Aras.prototype.uiShowLifeCycleItemEx = function Aras_uiShowLifeCycleItemEx(lcNd, isTearOff) {
  if (!lcNd || lcNd.getAttribute('type')!='Life Cycle Map') return false;
  if (isTearOff==undefined) isTearOff = this.getVariable('TearOff')=='true';

  var lcID = lcNd.getAttribute('id');
  var win = this.uiFindWindowEx(lcID);
  if (win) {
    win.focus();
    return true;
  }

  win = (isTearOff ? this.uiOpenWindowEx(lcID, 'scrollbars=no,resizable=yes,status=no') : top.main.work);
  if (!win) {
    this.uiShowPopupBlockerQuestion();
    return false;
  }

  this.uiRegWindowEx(lcID, win);
  win.aras = this;
  win.currLCNode = lcNd;

  var url = 'LifeCycle/lifecycletool.html?id='+lcID;

  if (isTearOff)
  {
    var isEditMode = (this.isTempEx(lcNd) || this.isLockedByUser(lcNd) ) ? true : false;
    var typeID = lcNd.getAttribute('typeId');
    var itemTypeNd = null;
    if (typeID)
    {
      itemTypeNd = this.getItemTypeDictionary(this.getItemTypeName(typeID)).node;
    }
    else
    {
      itemTypeNd = this.getItemTypeDictionary('Life Cycle Map').node;
    }

    var doc = win.document.open();
    win.aras = this;
    win.currLCNode = lcNd;
    win.isTearOff = true;
    win.item      = lcNd;
    win.itemID    = lcID;
    win.itemTypeName = 'Life Cycle Map';
    win.itemType = itemTypeNd;
    win.viewMode = '';
    win.isEditMode = isEditMode;

    doc.write(
    '<html>\n' +
    '<head>\n' +
    '<title>Life Cycle Map - '+this.getKeyedNameEx(lcNd) + (isEditMode ? '' : ' (read only)')+'</title>\n'+
    '<base HREF="'+this.getScriptsURL()+'" />\n'+
    '</head>\n'+
    '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +

    '<SCRIPT ID="lctool_window_script"></SCRIPT>\n'+
    '<SCRIPT>\n'+
      'function setTitle(isEditMode) {\n' +
      '  document.title = "Life Cycle Map - '+this.getKeyedNameEx(lcNd) + '" +  (isEditMode ? "" : " (read only)");\n' + 
      '}\n' +
      'function turnWindowReadyOn() {\n'+
      //that script will set windowReady = true and cause menuUpdate
      ' document.scripts["lctool_window_script"].src = "' + this.getScriptsURL() + '../javascript/lctool_window.js";\n' +
      //clear onload handler on editor frame
      ' document.frames["editor"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
      '}\n'+
      'onload = function onload_handler() {\n'+
      ' setTimeout("onload_handler2();", 1);\n'+
      '}\n'+
      'function onload_handler2() {\n' +
      ' window.aras = new Aras(window.aras);\n' +
      ' var frmSet = document.createElement(commentedFrameset.innerHTML);\n'+
      ' var oldBody = document.body;\n'+
      ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n'+
      ' var frm = document.createElement(commentedFrame1.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("tearOffMenu.aspx?view=lifecycletool");\n'+
      ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
      ' frm.attachEvent("onload", turnWindowReadyOn);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("'+url+'");\n'+
      ' frm = document.createElement(commentedFrame3.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("statusbar.html?xmlfile=tabview_statusbar.xml");\n'+
      '}\n' +
    '</SCRIPT>\n'+
    '<COMMENT id="commentedFrameset"><FRAMESET rows=\'50px,*,20px\'></FRAMESET></COMMENT>\n'+

    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame2"><frame name="editor" src="about:blank" frameborder="yes" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame3"><frame name="statusbar" src="about:blank" frameborder=0 scrolling=no noresize /></COMMENT>' +

    '<BODY></BODY>\n'
    );

    win.doc = doc;
    win.setTimeout("window.doc.close();window.doc = undefined;", 1);
  }
  else
  {
    win.location.replace(url);
  }
}


Aras.prototype.uiShowWorkflowItemEx = function Aras_uiShowWorkflowItemEx(wfNd, isTearOff)
{
  if (!wfNd || wfNd.getAttribute('type')!='Workflow Map') return false;
  if (isTearOff==undefined) isTearOff = this.getVariable('TearOff')=='true';

  var wfID = wfNd.getAttribute('id');
  var win = this.uiFindWindowEx(wfID);
  if (win)
  {
    win.focus();
    return true;
  }

  win = (isTearOff ? this.uiOpenWindowEx(wfID, 'scrollbars=no,resizable=yes,status=no') : top.main.work);
  if (!win)
  {
    this.uiShowPopupBlockerQuestion();
    return false;
  }

  this.uiRegWindowEx(wfID, win);
  win.aras = this;
  win.currWFNode = wfNd;

  var url = 'Workflow/workflowtool.html?id='+wfID;

  if (isTearOff)
  {
    var isEditMode = (this.isTempEx(wfNd) || this.isLockedByUser(wfNd) ) ? true : false;
    var typeID     = wfNd.getAttribute('typeId');
    var itemTypeNd = null;
    if (typeID)
    {
      itemTypeNd = this.getItemTypeDictionary(this.getItemTypeName(typeID)).node;
    }
    else
    {
      itemTypeNd = this.getItemTypeDictionary('Workflow Map').node;
    }

    var doc = win.document.open();
    win.aras = this;
    win.currWFNode = wfNd;
    win.isTearOff = true;
    win.item      = wfNd;
    win.itemID    = wfID;
    win.itemTypeName = 'Workflow Map';
    win.itemType = itemTypeNd;
    win.viewMode = "";
    win.isEditMode = isEditMode;

    doc.write(
    '<html>\n' +
    '<head>\n' +
    '<title>Workflow Map - '+this.getKeyedNameEx(wfNd) + (isEditMode ? '' : ' (read only)')+'</title>\n' +
    '<base HREF="'+this.getScriptsURL()+'" />\n' +
    '</head>\n' +
    '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +

    '<SCRIPT ID="wftool_window_script"></SCRIPT>\n' +
    '<SCRIPT>\n' +
      'function setTitle(isEditMode) {\n' +
      '  document.title = "Workflow Map - '+this.getKeyedNameEx(wfNd) + '" +  (isEditMode ? "" : " (read only)");\n' + 
      '}\n' +
      'function turnWindowReadyOn() {\n'+
      //that script will set windowReady = true and cause menuUpdate
      ' document.scripts["wftool_window_script"].src = "' + this.getScriptsURL() + '../javascript/wftool_window.js";\n' +
      //clear onload handler on editor frame
      ' document.frames["editor"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
      '}\n'+
      'onload = function onload_handler() {\n'+
      ' setTimeout("onload_handler2();", 1);\n'+
      '}\n'+
      'function onload_handler2() {\n' +
      ' window.aras = new Aras(window.aras);\n' +
      ' var frmSet = document.createElement(commentedFrameset.innerHTML);\n'+
      ' var oldBody = document.body;\n'+
      ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n'+
      ' var frm = document.createElement(commentedFrame1.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("tearOffMenu.aspx?view=wokflowtool");\n'+
      ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
      ' frm.attachEvent("onload", turnWindowReadyOn);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("'+url+'");\n'+
      ' frm = document.createElement(commentedFrame3.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.contentWindow.location.replace("statusbar.html?xmlfile=tabview_statusbar.xml");\n'+
      '}\n' +
    '</SCRIPT>\n'+
    '<COMMENT id="commentedFrameset"><FRAMESET rows=\'50px,*,20px\'></FRAMESET></COMMENT>\n'+

    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame2"><frame name="editor" src="about:blank" frameborder="yes" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
    '<COMMENT id="commentedFrame3"><frame name="statusbar" src="about:blank" frameborder=0 scrolling=no noresize /></COMMENT>' +

    '<BODY></BODY>\n'
    );

    win.doc = doc;
    win.setTimeout("window.doc.close();window.doc = undefined;", 1);
  }
  else win.location.replace(url);
}

/*
* uiReShowItemEx
*
* parameters:
* 1) oldItemID- old id of item to be shown
* 2) itemNd   - item to be shown //usually itemId==oldItemId
* 3) viewMode - 'tab view', 'tree view', 'where used' or 'openFile'
*/
Aras.prototype.uiReShowItemEx = function(oldItemID, itemNd, viewMode)
{
  if (!oldItemID) return false;
  if (!itemNd) return false;
  if (viewMode == undefined) viewMode = this.getDefaultViewMode(itemTypeName);
  var win = this.uiFindWindowEx(oldItemID);
  if (!win || top.aras.isWindowClosed(win)) return this.uiShowItemEx(itemNd, viewMode);

  var itemID = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  if (itemTypeName=='File' && viewMode=='openFile') {
    var fileURL = this.getFileURLEx(itemNd);
    if (fileURL == '') {
      top.aras.AlertError('Failed to get the File.', "The file URL is invalid.", "Client Side Error");
      return false;
    }

    window.open(fileURL);
    return true;
  }
  if (oldItemID!=itemID || win.viewMode!=viewMode) {
    var wasTearOff = (win.opener!=undefined);

    var arasObj;
    if (this.parentArasObj){
      arasObj = this.parentArasObj;
    }
    else arasObj = this;

    if (win.name != 'work'){
      win.close();
    }

    this.uiUnregWindowEx(oldItemID);
    return arasObj.uiShowItemEx(itemNd, viewMode, wasTearOff);
  }

  if(viewMode=='tree view')
  itemNd = this.updateTreeViewItem(itemNd);

  if (win.updateRootItem) win.updateRootItem(itemNd);
  else top.aras.AlertError('The function updateRootItem is not implemented.', "", "", win);
  if (win.updateMenu) win.updateMenu();
}

/*
 * uiTabViewItemEx
 *
 * parameters:
 * 1) win    - window in wich item should be shown
 * 2) itemNd - item to be shown
 * 3) noTabs - true or false
 */
Aras.prototype.uiTabViewItemEx = function(win, itemNd, noTabs, winH, formH)
{
  if (!win || top.aras.isWindowClosed(win)) return false;
  if (!itemNd) return false;
  var itemID       = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var isEditMode   = win.isEditMode;
  var isTearOff    = (win.opener!=undefined);
  var isFile       = (itemTypeName=='File');
  var itemTypeNd   = null;
  var typeID       = itemNd.getAttribute('typeId');
  itemTypeNd       = this.getItemTypeDictionary(itemTypeName).node;
  
  var isNew = false;
  var action = itemNd.getAttribute('action');
  var isTemp = itemNd.getAttribute('isTemp');
  if ((action == "add") && (isTemp == "1"))
  	  isNew = true;

  if (!itemTypeNd)
  {
    top.aras.AlertError('ItemType "'+itemTypeName+'" not found.');
    return false;
  }

  if (noTabs == undefined)
  {
    var structureView = this.getItemProperty(itemTypeNd, 'structure_view');
    if (structureView == '') noTabs = true;
    else noTabs = (this.getVariable('NoTabsInTabView') == 'true');
  }

  var keyed_name    = this.getKeyedNameEx(itemNd);
  var itemTypeLabel = this.getItemProperty(itemTypeNd, 'label');

  if (isFile && !formH)
  {
    formH  = "60%";
  }
  else
  {
    var formID = this.uiGetFormID4ItemEx(itemNd, (isEditMode ? 'edit':'view'));
    var formNd = this.getFormForDisplay(formID).node;
    if (formNd)
    {
      formH = this.getItemProperty(formNd, 'height');
      var formW = this.getItemProperty(formNd, 'width');
      if (!formH) formH = 250;
      if (!formW) formW = 800;
      
      if (!noTabs)
      {
        try
        {
          win.resizeTo(parseInt(formW), parseInt(formH) + 50 /*body height*/ + 50 /*menu*/ + 100 /*minimal relationships*/);
        }
        catch (excep) {}
      }
    }
    else if (!isFile) formH = 50;
  }

  var menuURL = this.scriptsURL + "tearOffMenu.aspx?view=";
  if (itemTypeName == "Report") menuURL += "reporttool";
  else if (itemTypeName == "Method") menuURL += "methodeditor";
  else menuURL += "tab";

  var content =
  '<html>\n' +
  '<head>\n' +
  '<title>'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+(isEditMode ? '':' (read only)')+'</title>\n' +
  '<base HREF="'+this.getScriptsURL()+'" />\n' +
  '</head>\n' +
  '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +

  '<SCRIPT ID="item_window_script"></SCRIPT>'+
  '<SCRIPT>'+
    'var hideTabs = '+(noTabs!=false)+';\n'+
    'var LocationSearches = new Object();\n'+
    'function updateRootItem(itemNd) {\n'+
    ' if (!itemNd) {top.aras.AlertError("Failed to get the "+window.itemTypeName, "", ""); return false;}\n'+
    ' if (itemNd.getAttribute("type")!=window.itemTypeName) {top.aras.AlertError("Invalid ItemType specified: ("+itemNd.getAttribute("type")+")."); return false;}\n'+
    ' itemID = itemNd.getAttribute("id");\n'+
    ' var wasLocked = (top.aras.isLockedByUser(item) || top.aras.isTempEx(item));\n'+
    ' item   = itemNd;\n'+
    ' itemID = itemNd.getAttribute("id");\n'+
    ' if (isEditMode)\n' +
    ' {\n' +
    '   isEditMode = wasLocked;\n'+
    '   setEditMode();\n'+
    ' }\n'+
    ' else\n' +
    ' {\n' +
    '   isEditMode = wasLocked;\n' +
    '   setViewMode();\n' +
    ' }\n' +
    '}\n'+
    'function setEditMode()\n'+
    '{\n'+
    ' var prevMode = isEditMode;\n'+
    ' isEditMode = true;\n'+
    '  document.title="'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - " + top.aras.getKeyedNameEx(item);\n';
  if (isTearOff) content+=
    ' if (document.frames.tearoff_menu && document.frames.tearoff_menu.setEditMode)\n'+
    '   document.frames.tearoff_menu.setEditMode();\n';
  content+=
    ' var editFormID = top.aras.uiGetFormID4ItemEx(item,"edit");\n'+
    ' var viewFormID = top.aras.uiGetFormID4ItemEx(item,"view");\n'+
    ' var prevFormID = (document.frames.instance) ? document.frames.instance.document.formID : "";\n'+
    ' if (item.getAttribute("action") == "add")\n'+
    ' {\n'+
    '   if (document.frames.instance)\n'+
    '     top.aras.uiShowItemInFrameEx(document.frames.instance, item, "add", 0);\n'+
    ' }\n'+
    ' else if ((prevMode != isEditMode && editFormID != viewFormID) || editFormID != prevFormID)\n'+
    ' {\n'+
    '   if (document.frames.instance)\n'+
    '     top.aras.uiShowItemInFrameEx(document.frames.instance, item, "edit", 0);\n'+
    ' }\n'+
    ' else if (document.frames.instance && document.frames.instance.document.forms.MainDataForm)\n'+
    '   top.aras.uiPopulateFormWithItemEx(document.frames.instance.document.forms.MainDataForm, item, itemType, true);\n'+
    ' if (document.frames.relationships && document.frames.relationships.setEditMode)\n'+
    '   document.frames.relationships.setEditMode();\n'+
    '}\n'+
    'function setViewMode() {\n'+
    ' var prevMode = isEditMode;\n'+
    ' isEditMode = false;\n'+
    '  document.title="'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - " + top.aras.getKeyedNameEx(item) + " (read only)";\n';
  if (isTearOff) content+=
    ' if (document.frames.tearoff_menu && document.frames.tearoff_menu.setViewMode) document.frames.tearoff_menu.setViewMode();\n';
  content+=
    ' var editFormID = top.aras.uiGetFormID4ItemEx(item,"edit");\n'+
    ' var viewFormID = top.aras.uiGetFormID4ItemEx(item,"view");\n'+
    ' var prevFormID = (document.frames.instance) ? document.frames.instance.document.formID : ""\n'+
    ' if ((prevMode!=isEditMode && editFormID!=viewFormID) || viewFormID!=prevFormID) {\n'+
    '   if (document.frames.instance) top.aras.uiShowItemInFrameEx(document.frames.instance,item,"view",0);'+
    ' }\n'+
    ' else if (document.frames.instance && document.frames.instance.document.forms.MainDataForm) {\n'+
    '   top.aras.uiPopulateFormWithItemEx(document.frames.instance.document.forms.MainDataForm, item, itemType, false);\n'+
    ' }\n'+
    ' if (document.frames.relationships && document.frames.relationships.setViewMode) {'+
    '   document.frames.relationships.setViewMode();\n'+
    ' }'+
    '}\n'+
    'function turnWindowReadyOn() {\n'+
    //that script will set windowReady = true and cause menuUpdate
    ' document.scripts["item_window_script"].src = "' + this.getScriptsURL() + '../javascript/item_window.js";\n' +
    //clear onload handler on tearoff_menu frame
    ' document.frames["'+ (isTearOff ? 'tearoff_menu' : 'statusbar') + '"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
    '}\n'+
    'onload = function onload_handler() {\n'+
    ' setTimeout("onload_handler2();", 1);\n'+
    '}\n'+
    'function onload_handler2() {\n' +
    (isTearOff ?
      ' while(window.aras.parentArasObj) window.aras = window.aras.parentArasObj;\n'+
      ' window.aras = new Aras(window.aras);\n'
      : ''
    ) +
    ' var frmSet = document.createElement(commentedFrameset.innerHTML);\n'+
    ' var oldBody = document.body;\n' +
    ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n' +
    ' var frm;\n'+
    (isTearOff ?
      ' frm = document.createElement(commentedFrame1.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'
      : ''
    ) +
    ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
    ' frmSet.appendChild(frm);\n'+
    (!noTabs ?
      ' frm = document.createElement(commentedFrame3.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n' +
      ' frm.attachEvent("onload", onload_handler3);\n' +
      ' LocationSearches["relationships"] = "?db='+this.getDatabase()+'&ITName='+itemTypeName+'&itemID='+itemID+'&editMode='+(isEditMode ? 1:0)+'&tabbar=1&toolbar=1&where=tabview";\n' +
      ' frm.contentWindow.location.replace("'+this.getScriptsURL()+'relationships.html");\n'
      : ' setTimeout(\'onload_handler3()\', 1);\n'
    ) +
    ' frm = document.createElement(commentedFrame4.innerHTML);\n'+
    ' frmSet.appendChild(frm);\n' +
    '}\n' +
    'function onload_handler3(){\n' +
    ' var frm;\n' +
    (!noTabs ?
      ' frm = document.frames["relationships"].frameElement;\n' +
      ' frm.detachEvent("onload", onload_handler3);\n'
      : ''
    ) +
    ' frm = document.frames["instance"];\n' +
    ' frm.frameElement.attachEvent("onload", onload_handler4);\n' +
    (isNew? ' top.aras.uiShowItemInFrameEx(frm, item, "add",0);\n' :  ' top.aras.uiShowItemInFrameEx(frm, item, "'+(isEditMode ? 'edit':'view')+'",0);\n') +
    '}\n' +
    'function onload_handler4(){\n' +
    ' var frm = document.frames["instance"].frameElement;\n' +
    ' frm.detachEvent("onload", onload_handler4);\n' +
    ' frm = document.frames["statusbar"].frameElement;\n' +
    ' frm.attachEvent("onload", ' + (isTearOff ? 'onload_handler5' : 'turnWindowReadyOn') +');\n' +
    ' frm.contentWindow.location.replace("'+this.scriptsURL+'statusbar.html?xmlfile=tabview_statusbar.xml");\n' +
    '}\n' +
    'function onload_handler5(){\n' +
    ' var frm = document.frames["statusbar"].frameElement;\n' +
    ' frm.detachEvent("onload", onload_handler5);\n' +
    ' frm = document.frames["tearoff_menu"].frameElement;\n' +
    ' frm.attachEvent("onload", turnWindowReadyOn);\n' +
    ' frm.contentWindow.location.replace("' + menuURL + '");\n' +
    '}\n'+
  '</SCRIPT>\n';
  
  if (isTearOff)
  {
    if (winH)
    {
      var dy = (winH - 50) /*body height*/ - 50 /*menu*/ - parseInt(formH) /*form*/ - 100 /*minimal relationships*/ - 20 /*status bar*/;
      if (dy < 0) formH = parseInt(formH) + dy;
    }
    content+=
    '<COMMENT id="commentedFrameset"><FRAMESET name="tabViewFrameset" rows="50px'+(noTabs ? '' : (','+formH+'px')) + ',*,20px" frameborder="yes" framespacing="2"></FRAMESET></COMMENT>\n'+
    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n';
  }
  else
  {
    content+=
    '<COMMENT id="commentedFrameset"><FRAMESET name="tabViewFrameset" rows="'+(noTabs ? '*' : (formH+'px,*'))+',20px" frameborder="yes" framespacing="2"></FRAMESET></COMMENT>\n';
  }

  content+=
  '<COMMENT id="commentedFrame2"><frame name="instance" src="about:blank" frameborder="yes" scrolling="auto" marginwidth="0" marginheight="0" /></COMMENT>\n';

  if (!noTabs)
  {
    content+=
    '<COMMENT id="commentedFrame3"><frame id="relationships" name="relationships" src="about:blank" frameborder="yes" scrolling=no marginwidth="0" marginheight="0" /></COMMENT>';
  }
  content+=
  '<COMMENT id="commentedFrame4"><frame name="statusbar" src="about:blank" frameborder=0 scrolling=no noresize /></COMMENT>\n' +
  '<BODY></BODY>\n';

  if (top.aras.isWindowClosed(win)) return false;

  var doc = win.document.open();
  win.item     = itemNd;
  win.itemID   = itemID;
  win.itemTypeName = itemTypeName;
  win.itemType = itemTypeNd;
  win.viewMode = 'tab view';
  win.isEditMode = isEditMode;
  win.isTearOff = isTearOff;
  if (isTearOff) win.aras = this;

  var purgeFlg = false;
  var delFlg = ( (this.getItemProperty(itemNd, 'locked_by_id')=='') && !isEditMode );

  if (!isTearOff) with (top.main.menu) {
    setControlEnabled('view',    false);
    setControlEnabled('edit',    false);
    setControlEnabled('save',    isEditMode);
    setControlEnabled('delete',  delFlg);
    setControlEnabled('purge',   purgeFlg);
    setControlEnabled('lock',    delFlg);
    setControlEnabled('unlock',  isEditMode);
    setControlEnabled('open',    isFile);
    setControlEnabled('download',isFile);
  }

  doc.write(content);
  win.doc = doc;
  win.setTimeout("window.doc.close();window.doc = undefined;", 1);
}

/*
 * updateTreeViewItem
 *
 * used in uiTreeViewItemEx and uiReShowItemEx to find or create
 * item in TreeViewItem after changes in this item, it's necessary,
 * because changed item lies in "items" node of cache
 *
 */
Aras.prototype.updateTreeViewItem = function(itemNd) {
  var itemID = itemNd.getAttribute("id");
  var itemsNd = this.dom.selectSingleNode("Innovator/Items");
  var treeViewItems = itemsNd.selectSingleNode("TreeViewItems");
  if (!treeViewItems) treeViewItems = itemsNd.appendChild(this.dom.createElement("TreeViewItems"));
  var oldTreeViewItem = treeViewItems.selectSingleNode("Item[@id='"+itemID+"']");
  if (!oldTreeViewItem || (oldTreeViewItem && oldTreeViewItem.xml != itemNd.xml)) {
    if (oldTreeViewItem) oldTreeViewItem.parentNode.removeChild(oldTreeViewItem);
    itemNd = treeViewItems.appendChild(itemNd.cloneNode(true));
    var relationshipsNd = itemNd.selectSingleNode("Relationships");
    if (relationshipsNd) {
      relationshipsNd.text = "";
    }
    var relatedNd = itemNd.selectSingleNode("related_id");
    if (relatedNd) {
      var relatedId = this.getItemProperty(relatedNd, "related_id");
      this.setItemProperty(relatedNd, "related_id", relatedId);
    }
  }
  else itemNd = oldTreeViewItem;
  itemNd.setAttribute("levels", "0");
  return itemNd;
}

/*
* uiTreeViewItemEx
*
* parameters:
* 1) win    - window in wich item should be shown
* 2) itemNd - item to be shown
*/
Aras.prototype.uiTreeViewItemEx = function(win, itemNd) {
  return this.uiTabViewItemEx(win, itemNd, undefined, undefined);

  if (!win || isWindowClosed(win)) return false;
  if (!itemNd) return false;

  var itemTypeName = itemNd.getAttribute("type");

  if ( this.isDirtyEx(itemNd) ) {
    var param = new Object();
    param.buttons = new Object();
    param.buttons.btnSave = 'Save';
    param.buttons.btnDontSave = 'Don\'t save';
    param.defaultButton = 'btnSave';
    param.message =
    "Tree View mode for " + itemTypeName + " " + this.getKeyedNameEx(itemNd) + " may discard all your changes. " +
    "Click Save button to save all your changes.";
    var res = win.showModalDialog(this.getScriptsURL()+'groupChgsDialog.html', param, 'dialogHeight:200px;dialogWidth:400px;center:yes;resizable:no;status:no;help:no;');
    if (res == "btnSave")
    {
      var resItm = this.saveItemEx(itemNd);
      if (!resItm) return false;
      itemNd = resItm;
    }
  }

  var itemID     = itemNd.getAttribute('id');
  itemTypeName   = itemNd.getAttribute("type");
  var isEditMode = win.isEditMode;
  var isTearOff  = (win.opener!=undefined);
  var typeID     = itemNd.getAttribute('typeId');
  itemTypeNd     = this.getItemTypeDictionary(itemTypeName).node;

  // copy itemNd from "Innovator/Items" to "Innovator/Items/TreeViewItems/"
  itemNd = this.updateTreeViewItem(itemNd);

  var keyed_name = this.getKeyedNameEx(itemNd);
  var itemTypeLabel = this.getItemProperty(itemTypeNd, 'label');
  var content =
  '<html>\n' +
  '<head>\n' +
  '<title>'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+(isEditMode ? '':' (read only)')+'</title>\n' +
  '<base HREF="'+this.getScriptsURL()+'" />\n' +
  '</head>\n' +
  '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +

  '<SCRIPT ID="item_window_script"></SCRIPT>\n' +
  '<SCRIPT>'+
    'function updateRootItem(itemNd) {\n'+
    ' if (!itemNd) {top.aras.AlertError("Failed to get the "+window.itemTypeName, "", ""); return false;}\n'+
    ' if (itemNd.getAttribute("type")!=window.itemTypeName) {top.aras.AlertError("Invalid ItemType specified: ("+itemNd.getAttribute("type")+")."); return false;}\n'+
    ' itemID = itemNd.getAttribute("id");\n'+
    ' var wasLocked = top.aras.isLockedByUser(item);\n'+
    ' item   = itemNd;\n'+
    ' itemID = itemNd.getAttribute("id");\n'+
    ' if (isEditMode) {\n'+
    '  isEditMode = wasLocked;\n'+
    '  setEditMode();\n'+
    ' }\n'+
    ' else {\n'+
    '  isEditMode = wasLocked;\n'+
    '  setViewMode();\n'+
    ' }\n'+
    ' document.frames["tree"].updateTreeView()' +
    '}\n'+

    'function setEditMode() {\n'+
    ' var prevMode = isEditMode;\n'+
    ' isEditMode = true;'+
    '  document.title="'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+'";\n'+
    ' item = top.aras.getItemById("'+itemTypeName+'", itemID, 0);\n'+
    ' item = top.aras.updateTreeViewItem(item);\n' +
    " updateMenuState();\n" +
    '}\n'+

    'function setViewMode() {\n'+
    ' var prevMode = isEditMode;\n'+
    ' isEditMode = false;'+
    '  document.title="'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+' (read only)";\n'+
    ' item = top.aras.getItemById("'+itemTypeName+'", itemID, 0);\n'+
    ' item = top.aras.updateTreeViewItem(item);\n' +
    " updateMenuState();\n" +
    '}\n'+

    'function turnWindowReadyOn() {\n'+
    //that script will set windowReady = true and cause menuUpdate
    ' document.scripts["item_window_script"].src = "' + this.getScriptsURL() + '../javascript/item_window.js";\n' +
    //clear onload handler on tree frame
    ' document.frames["tree"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
    '}\n'+
    'onload = function onload_handler() {\n'+
    ' setTimeout("onload_handler2();", 1);\n'+
    '}\n'+
    'function onload_handler2() {\n' +
    (isTearOff ?
      ' while(window.aras.parentArasObj) window.aras = window.aras.parentArasObj;\n'+
      ' window.aras = new Aras(window.aras);\n'
      : ''
    ) +
    ' var frmSet = document.createElement(commentedFrameset1.innerHTML);\n' +
    ' var oldBody = document.body;\n'+
    ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n'+
    ' var frm;\n' +
    (isTearOff ?
      ' frm = document.createElement(commentedFrame1.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'
      : ''
    ) +
    ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
    ' frmSet.appendChild(frm);\n'+
    ' var frmSet2 = document.createElement(commentedFrameset2.innerHTML);\n' +
    ' frmSet.appendChild(frmSet2);\n' +
    ' frm = document.createElement(commentedFrame3.innerHTML);\n'+
    ' frmSet2.appendChild(frm);\n'+
    ' frm = document.createElement(commentedFrame4.innerHTML);\n'+
    ' frmSet2.appendChild(frm);\n' +
    (isTearOff ?
      ' frm = document.createElement(commentedFrame5.innerHTML);\n'+
      ' frmSet.appendChild(frm);\n'+
      ' frm.attachEvent("onload", onload_handler3);\n' +
      ' frm.contentWindow.location.replace("statusbar.html?xmlfile=tabview_statusbar.xml");\n'
      : ' onload_handler3();\n'
    ) +
    '}\n' +
    'function onload_handler3() {\n' +
    ' var frm;\n' +
    (isTearOff ?
      ' frm = document.frames["statusbar"].frameElement;\n' +
      ' frm.detachEvent("onload", onload_handler3);\n' +
      ' frm = document.frames["tearoff_menu"];\n' +
      ' frm.frameElement.attachEvent("onload", onload_handler4);\n' +
      ' frm.location.replace("'+this.getScriptsURL()+'tearOffMenu.aspx?view=tree");\n'
    : ' onload_handler4();\n'
    ) +
    '}\n' +
    'function onload_handler4() {\n' +
    ' var frm;\n' +
    (isTearOff ?
      ' frm = document.frames["tearoff_menu"].frameElement;\n' +
      ' frm.detachEvent("onload", onload_handler4);\n'
    : ''
    ) +
    ' frm = document.frames["menu"];\n' +
    ' frm.frameElement.attachEvent("onload", onload_handler5);\n' +
    ' frm.location.replace("'+this.getScriptsURL()+'itemMenu.html?id='+itemID+'&tearOff='+tearOffFlg+'");\n' +
    '}\n' +
    'function onload_handler5() {\n' +
    ' var frm = document.frames["menu"].frameElement;\n' +
    ' frm.detachEvent("onload", onload_handler5);\n' +
    ' frm = document.frames["tree"];\n' +
    ' frm.frameElement.attachEvent("onload", turnWindowReadyOn);\n' +
    ' frm.location.replace("'+this.getScriptsURL()+'itemTree.html?itemID='+itemID+'&itemTypeName='+itemTypeName+'");\n' +
    '}\n' +
  '</SCRIPT>\n' +
  '';

  var tearOffFlg;
  if (isTearOff) {
    content +=
    '<COMMENT id="commentedFrameset1"><FRAMESET name="tabViewFrameset" rows="50px,28px,*,20px" frameborder="no" framespacing="0"></FRAMESET></COMMENT>\n'+
    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n';
    tearOffFlg = '1';
  }
  else {
    content +=
    '<COMMENT id="commentedFrameset1"><FRAMESET name="tabViewFrameset" rows="28px,*" scrolling="no" frameborder="no" framespacing="0"></FRAMESET></COMMENT>\n';
    tearOffFlg = '0';
  }

  content +=
  '<COMMENT id="commentedFrame2"><frame name="menu" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
  '<COMMENT id="commentedFrameset2"><FRAMESET name="tabViewFrameset" cols="200,*" frameborder="yes" framespacing="0"></FRAMESET></COMMENT>\n' +
  '<COMMENT id="commentedFrame3"><frame name="tree" src="about:blank" scrolling="no" marginwidth="0" marginheight="0" /></COMMENT>\n' +
  '<COMMENT id="commentedFrame4"><frame name="work" src="about:blank" scrolling="auto" marginwidth="0" marginheight="0" /></COMMENT>\n';
  if (isTearOff) {
    content += '<COMMENT id="commentedFrame5"><frame name="statusbar" src="about:blank" frameborder=0 scrolling="no" noresize /></COMMENT>';
  }
  content += '<BODY></BODY>';

  if (top.aras.isWindowClosed(win)) return false;
  var doc = win.document.open();
  win.item     = itemNd;
  win.itemID   = itemID;
  win.itemTypeName = itemTypeName;
  win.itemType = itemTypeNd;
  win.viewMode = 'tree view';
  win.isEditMode = isEditMode;
  win.isTearOff = isTearOff;
  if (isTearOff) win.aras = this;

  var isFile = (itemTypeName == 'File');
  var purgeFlg = false;
  var delFlg = ( (this.getItemProperty(itemNd, 'locked_by_id')=='') && !isEditMode );


  if (!isTearOff) with (top.main.menu) {
    setControlEnabled('view',    false);
    setControlEnabled('edit',    false);
    setControlEnabled('save',    isEditMode);
    setControlEnabled('delete',  delFlg);
    setControlEnabled('purge',   purgeFlg);
    setControlEnabled('lock',    delFlg);
    setControlEnabled('unlock',  isEditMode);
    setControlEnabled('open',    isFile);
    setControlEnabled('download',isFile);
  }


  doc.write(content);
  win.doc = doc;
  win.setTimeout("window.doc.close();window.doc = undefined;", 1);
}//uiTreeViewItemEx

/*
 * uiPrintViewItemEx
 *
 * parameters:
 * 1) win    - window in wich item should be shown
 * 2) itemNd - item to be shown
 */
Aras.prototype.uiPrintViewItemEx = function(win, itemNd)
{
  if (!win || top.aras.isWindowClosed(win)) return false;
  if (!itemNd) return false;

  var itemID       = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var isEditMode   = false;
  var itemTypeNd   = null;
  var typeID       = itemNd.getAttribute('typeId');
  itemTypeNd       = this.getItemTypeDictionary(itemTypeName).node;

  if (!itemTypeNd)
  {
    var doc = win.document.open();
    doc.write('uiPrintViewItemEx: ItemType "'+itemTypeName+'" not found !');
    doc.close();
    return false;
  }

  var isFile = (itemTypeName=='File');
  var keyed_name = this.getKeyedNameEx(itemNd);
  var itemTypeLabel = this.getItemProperty(itemTypeNd, 'label');
  var formNd = this.uiGetForm4ItemEx(itemNd, 'print');
  var formH;
  if (formNd)
  {
    formH = this.getItemProperty(formNd, 'height');
    if (formH == '') formH = '250';
  }
  else if (!isFile) formH = "50";

  var content =
  '<html>\n'+
  '<head>\n'+
  '<title>'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+' (print view)</title>\n'+
  '<base HREF="'+this.getScriptsURL()+'" />\n'+
  '</head>\n'+
  '<SCRIPT>\n'+
    'var cont = null;\n'+
    'function populateTables2() {\n'+
    ' if (cont) {\n'+
    '  var doc = document.frames["printBody"].document;\n'+
    '  doc.all("fr2").innerHTML = cont.text;\n'+
    ' }\n'+
    '}\n'+
    '\n'+

    'onload = function() {\n'+
    ' var doc = document.frames["printBody"].document.open();\n'+
    ' doc.write("<html>'+
      '<head>'+
        '<base href=\''+this.getScriptsURL()+'\' >'+
        '<link rel=\'stylesheet\' type=\'text/css\' href=\'../styles/default.css\'>'+
      '</head>'+
      '<body topmargin=0 leftmargin=0 rightmargin=0 bottommargin=0>'+
      '<iframe id=fr1 border=0 frameborder=no scrolling=no></iframe>'+
      '<br>'+
      '<span id=fr2 style=\'border-top:2px groove\'></span>'+
      '</body></html>");\n'+
    ' doc.close();\n'+
    ' top.aras.uiShowItemInFrameEx(doc.frames["fr1"], item, "print", 0);\n'+
    ' var bodyStr = "<table><itemID>'+itemID+'</itemID><type>'+itemTypeName+'</type></table>";\n'+
    ' cont = top.aras.populateRelationshipsTables(bodyStr);\n'+
    ' var b = doc.frames["fr1"].document.body;\n'+
    ' var st_ie = b.clientHeight;\n'+
    ' st_ie = b.clientWidth;\n'+
    ' doc.all("fr1").height = b.scrollHeight;\n'+
    ' doc.all("fr1").width = b.scrollWidth;\n'+
    ' if (cont) setTimeout("populateTables2()", 1);\n'+
    '}\n'+
  '</SCRIPT>\n' +
  '<frameset rows="29px,*" frameborder="yes" framespacing="2">'+
  ' <frame name="printview_menu" src="'+this.getScriptsURL()+'printviewMenu.html" scrolling="no" marginwidth="0" marginheight="0" noresize />'+
  ' <frame name="printBody" src="about:blank" frameborder="yes" scrolling="auto" marginwidth="0" marginheight="0" />'+
  '</frameset>\n'+
  '</html>';

  if (top.aras.isWindowClosed(win)) return false;
  var doc = win.document.open();
  win.item     = itemNd;
  win.itemID   = itemID;
  win.itemTypeName = itemTypeName;
  win.itemType = itemTypeNd;
  win.viewMode = 'print view';
  win.isEditMode = false;
  win.aras = this;

  doc.write(content);
  win.doc = doc;
  win.setTimeout("window.doc.close();window.doc = undefined;", 1);
}//uiPrintViewItemEx

Aras.prototype.uiWhereusedViewItemEx = function(win, itemNd)
{
  if (!win || top.aras.isWindowClosed(win)) return false;
  if (!itemNd) return false;

  var itemID       = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var isEditMode   = win.isEditMode;
  var isTearOff    = (win.opener!=undefined);
  var isFile       = (itemTypeName=='File');
  var itemTypeNd   = null;
  var typeID       = itemNd.getAttribute('typeId');
  itemTypeNd       = this.getItemTypeDictionary(itemTypeName).node;

  if (!itemTypeNd)
  {
    var doc = win.document.open();
    doc.write('uiWhereusedViewItemEx: ItemType "'+itemTypeName+'" not found !');
    doc.close();
    return false;
  }

  var itemTypeLabel = this.getItemProperty(itemTypeNd, 'label');
  var itemTypeName = this.getItemProperty(itemTypeNd, 'name');
  var keyed_name = this.getKeyedNameEx(itemNd);
  var content =
  '<html>\n' +
  '<head>\n' +
  '<title>'+(itemTypeLabel?itemTypeLabel:itemTypeName)+' - '+keyed_name+' (where used view)</title>\n'+
  '<base HREF="'+this.getScriptsURL()+'" />\n'+
  '</head>\n'+
  '<SCRIPT ID="ScriptSet1" SRC="' + this.getScriptsURL() + '../javascript/scriptset1.aspx"></SCRIPT>\n' +

  '<SCRIPT ID="item_window_script"></SCRIPT>' +
  '<SCRIPT>'+
      'function turnWindowReadyOn() {\n'+
      //that script will set windowReady = true and cause menuUpdate
      ' document.scripts["item_window_script"].src = "' + this.getScriptsURL() + '../javascript/item_window.js";\n' +
      //clear onload handler on whereused frame
      ' document.frames["whereused"].frameElement.detachEvent("onload", turnWindowReadyOn);\n'+
      '}\n'+
      'onload = function onload_handler() {\n'+
      ' setTimeout("onload_handler2();", 1);\n'+
      '}\n'+
      'function onload_handler2() {\n' +
      (isTearOff ? ' window.aras = new Aras(window.aras);\n' : '' ) +
      ' var frmSet = document.createElement(commentedFrameset.innerHTML);\n'+
      ' var oldBody = document.body;\n'+
      ' oldBody.parentNode.replaceChild(frmSet, oldBody);\n'+
      ' var frm;\n'+
      (isTearOff ?
        ' frm = document.createElement(commentedFrame1.innerHTML);\n'+
        ' frmSet.appendChild(frm);\n'
        : ''
      ) +
      ' frm = document.createElement(commentedFrame2.innerHTML);\n'+
      ' frm.attachEvent("onload", turnWindowReadyOn);\n'+
      ' frmSet.appendChild(frm);\n'+
      '}\n' +
  '</script>\n';

  if (isTearOff)
    content +=
    '<COMMENT id="commentedFrameset"><FRAMESET rows="50px,*" frameborder="yes" framespacing="2"></FRAMESET></COMMENT>\n'+
    '<COMMENT id="commentedFrame1"><frame name="tearoff_menu" src="'+this.getScriptsURL()+'tearOffMenu.aspx?view=whereused" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n';
  else {
    content +=
    '<COMMENT id="commentedFrameset"><FRAMESET rows="100%" frameborder="yes" framespacing="2"></FRAMESET></COMMENT>\n';
  }

  content +=
  '<COMMENT id="commentedFrame2"><frame name="whereused" src="'+this.getScriptsURL()+'whereUsed.html?id=' + itemID + '&type_name=' + itemTypeName + '&curLy=' +  this.getVariable("StructureLayout") + '" frameborder="yes" scrolling="no" marginwidth="0" marginheight="0" noresize /></COMMENT>\n' +
  '<BODY></BODY>\n';

  if (top.aras.isWindowClosed(win)) return false;
  var doc = win.document.open();
  win.item     = itemNd;
  win.itemID   = itemID;
  win.itemTypeName = itemTypeName;
  win.itemType = itemTypeNd;
  win.viewMode = 'where used';
  win.isEditMode = isEditMode;
  win.isTearOff = isTearOff;
  if (isTearOff) win.aras = this;

  var isFile = (itemTypeName == 'File');
  var purgeFlg = false;
  var delFlg = ( (this.getItemProperty(itemNd, 'locked_by_id')=='') && !isEditMode );

  doc.write(content);
  win.doc = doc;
  win.setTimeout("window.doc.close();window.doc = undefined;", 1);
}//uiWhereusedViewItemEx

/*
 * uiShowItemInFrameEx
 * frame
 * itemNd
 * formType - 'add', 'view', 'edit', 'print', 'default', 'edit_form' (also this parameter defines mode to open item)
 * formNd4Display - if specified then this form is used to display the item
 */
Aras.prototype.uiShowItemInFrameEx = function(frame, itemNd, formType, nestedLevel, formNd4Display)
{
  if (!frame) return false;
  if (!itemNd) return false;
  if (formType==undefined) formType = 'view';
  if (nestedLevel==undefined) nestedLevel = 0;
  

  var itemID       = itemNd.getAttribute('id');
  var itemTypeName = itemNd.getAttribute('type');
  var itemTypeID   = itemNd.getAttribute('typeId');
  var itemTypeNd   = null;
  var iomItem = new Item();
  iomItem.dom = itemNd.ownerDocument;
  iomItem.node = itemNd;

  itemTypeNd = this.getItemTypeDictionary(itemTypeName).node;
  itemTypeID = itemTypeNd.getAttribute('id');
  var doc = frame.document.open();
  doc.itemID   = itemID;
  doc.isTemp   = this.isTempID(itemID);
  doc.itemTypeName = itemTypeName;
  doc.item     = itemNd;
  doc.thisItem = iomItem;
  doc.isEditMode = (formType=='edit' || formType=='search' || formType=='add');
  doc.itemType = itemTypeNd;
  frame.nestedLevel = nestedLevel;

  with (this)
  {
    var formNd = (formNd4Display) ? formNd4Display : uiGetForm4ItemEx(itemNd, (formType!='edit_form' ? formType:'edit'));
    if (!formNd)
    {
      doc.write('<html><body><center>A "'+formType+'" form is not specified for you.</center></body></html>');
      doc.close();
      try
      {
        if (doc.parentWindow.parent.updateMenuState) doc.parentWindow.parent.updateMenuState();
      }
      catch (excep) {}
      return false;
    }

    doc.formID = formNd.getAttribute('id');
    if (nestedLevel <= maxNestedLevel)
    {
      var content = uiDrawFormEx(formNd, formType, itemTypeNd);
      doc.writeln( content );

      if (frame.top.isTearOff)
      {
        doc.writeln(
        '<script>\n'+
        'function tearOffItemChangeHandler(propNm, propVal, notupdateMenu) {\n'+
        ' if ( top.opener && !top.aras.isWindowClosed(top.opener) && top.opener.top && ' + 
             ' top.opener.top.main && top.opener.top.main.work && top.opener.top.main.work.isItemsGrid && ' + 
             ' document.itemTypeName==top.opener.top.main.work.itemTypeName)\n'+
        '  top.opener.top.main.work.updateRow(document.item, notupdateMenu);\n'+
        '}\n'+
        'document.userChangeHandler = tearOffItemChangeHandler;'+
        '</script>');
      }

      if (doc.forms.MainDataForm) uiPopulateFormWithItemEx(doc.forms.MainDataForm, doc.item, itemTypeNd, (formType=='edit' ||formType=='search' ||formType=='add' ));
      doc.close();
    }
    else {
      doc.writeln('There is ' + itemTypeName+' "'+getKeyedNameEx(itemNd)+'" here.');
      doc.close();
    }
  }
}//uiShowItemInFrameEx


/*
* uiDrawFormEx
* doc
* formNd
* mode - (add, edit, view, print, view_form, edit_form,search)
*/
Aras.prototype.uiDrawFormEx = function(formNd, mode, itemTypeNd)
{
  if (!formNd) return '';
  if (!mode) return '';
  if (itemTypeNd==undefined) itemTypeNd = null;

  var formID = formNd.getAttribute('id');
  var cacheID= formID+'_'+mode;
  var content = this.commonProperties.formsCacheById[cacheID];

  if (content) return content;
  else content = '';

  content += '<html>\n<head>\n<base HREF="'+this.getScriptsURL()+'" />\n';

  var tmpVal = this.getItemProperty(formNd, 'stylesheet');
  if (tmpVal != '') content += '<link rel="stylesheet" type="text/css" href="'+tmpVal+'">\n';

  var bodyNd = formNd.selectSingleNode('Relationships/Item[@type="Body"]');
  var fieldNds, fieldNd;

  if (bodyNd) with (this)
  {
    //body style
    content += '<style type="text/css">body {\n';
    tmpVal = getItemProperty(bodyNd, 'bg_color');
    tmpVal = (tmpVal && tmpVal.substring(0,1)!='#') ? 'buttonface' : tmpVal;
    if (tmpVal != '') content += 'background-color:'+tmpVal+';\n';
    tmpVal = getItemProperty(bodyNd, 'bg_image');
    if (tmpVal != '') content += 'background-image:url('+tmpVal+');\n';
    tmpVal = getItemProperty(bodyNd, 'bg_repeat');
    if (tmpVal != '') content += 'background-repeat:'+tmpVal+';\n';
    tmpVal = getItemProperty(bodyNd, 'bg_attach');
    if (tmpVal != '') content += 'background-attachment:'+tmpVal+';\n';
    content += '}\n';

    fieldNds = bodyNd.selectNodes('Relationships/Item[@type="Field" and '+
      '(not(@action) or (@action!="delete" and @action!="purge"))]');
    for (var i=0; i<fieldNds.length; i++)
    {
      fieldNd = fieldNds[i];
      content += '.' + getItemProperty(fieldNd, 'name') + '{';

      var tmpVal;
      tmpVal = getItemProperty(fieldNd, 'bg_color');
      if (tmpVal!='') content += 'background-color:'+getItemProperty(fieldNd, 'bg_color') + ';';

      if (getItemProperty(fieldNd, 'field_type') == 'label')
      {
        tmpVal = getItemProperty(fieldNd, 'font_family');
        if (tmpVal!='') content += 'font-family:' + getItemProperty(fieldNd, 'font_family') + ';';

        tmpVal = getItemProperty(fieldNd, 'font_size');
        if (tmpVal!='') content += 'font-size:'   + getItemProperty(fieldNd, 'font_size')   + ';';

        tmpVal = getItemProperty(fieldNd, 'font_weight');
        if (tmpVal!='') content += 'font-weight:' + getItemProperty(fieldNd, 'font_weight') + ';';

        tmpVal = getItemProperty(fieldNd, 'font_color');
        if (tmpVal!='') content += 'color:'       + getItemProperty(fieldNd, 'font_color') + ';';
      }

      content += '}\n';
    }

    content += '</style>\n';

    //^^^^^ body style
    content += '</head>\n';

    content += '<script >\n';
    if (mode == "view_form" || mode == "edit_form")
      content += "onerror=function onerror_handler() {return true;}\n";
    
    content +=  'var  cbValue = new Array("", "0", "1");\n';
    content +=  '</script>';

    if (itemTypeNd) content += '<script>\n'+
      'if (document.itemType==undefined) {\n'+
      ' document.itemType=top.aras.getItemById("ItemType","'+itemTypeNd.getAttribute('id')+'",0);\n'+
      ' document.itemTypeName="'+getItemProperty(itemTypeNd, 'name')+'";\n'+
      '}\n'+
      '</script>\n';

    if (mode!='print' && mode!='view_form' && mode!='edit_form')
    {
      content += '<script defer="true" src="../javascript/widget_events.js"></script>\n';
      content += '<script defer="true" src="../javascript/scriptset5.aspx"></script>\n';
      if (mode != "search")
      {
        content += assignFormEventEx(formNd);
      }

      content += ''+
      '<script>\n'+
        'var inputsArray = new Array();\n' + 
        'document.isFormPopulated = false;\n'+
        'function handleItemChange(propNm, propVal) {\n'+
        ' if (!document.isFormPopulated) return true;\n'+
        ' if (!document.isEditMode) return true;\n'+
        ' if (!document.item) return true;\n'+
        ' var elem = document.getElementById(propNm+"_system");\n'+
        ' if (!elem) return false;\n'+
        ' var propVal2 = propVal;'+
        ' if (propVal2.xml != undefined) propVal2 = propVal.getAttribute("id");\n'+
        ' if (elem.value==propVal2) return true;\n'+
        ' var notupdateMenu = (document.item.getAttribute("isDirty") == "1");\n'+
        ' document.item.setAttribute("isDirty", "1");\n'+
        ' var applyChanges2All = document.applyChanges2All;\n'+
        ' top.aras.setItemProperty(document.item,propNm,propVal,applyChanges2All);\n'+
        ' elem.value=propVal2;\n'+
        ' if ((document.item.getAttribute("action")!="add") && (document.item.getAttribute("action")!="create")) document.item.setAttribute("action", "update");\n';

      if (mode != "search")
      {
        content += ' if(parent && parent.frames && parent.frames.tearoff_menu && parent.frames.tearoff_menu.setControlEnabled) parent.frames.tearoff_menu.setControlEnabled("undo", true);'+
                   ' else if(parent && parent.parent && parent.parent.frames && parent.parent.frames.menu && parent.frames.tearoff_menu.setControlEnabled) parent.parent.frames.menu.setControlEnabled("undo", true);'+
                   ' if (document.userChangeHandler) document.userChangeHandler(propNm, propVal, notupdateMenu);\n';
      }
      content += '}\n'+
      '</script>\n';
    }
    else if (mode=='edit_form' || mode=='view_form')
    {
      if ( isTempEx(formNd) || isLockedByUser(formNd) )
        content += '<script defer="true" src="../javascript/formtool_mouse.js"></script>\n';
    }

    content += '<script>var bFromSearch = false;</script>\n';
//
    content += '<body topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" '+
//    'onbeforeunload="if (window.dataUpdate_system) dataUpdate_system();" '+
    '>\n';
    content += '<form id="MainDataForm" onsubmit="return false;">\n';
    var i;
    if (itemTypeNd)
    {
      var propNds = itemTypeNd.selectNodes('Relationships/Item[@type="Property" and name!="" and '+
        '(not(@action) or (@action!="delete" and @action!="purge"))]');
      for (i=0; i<propNds.length; i++)
        content += '<textarea id="'+getItemProperty(propNds[i],'name')+'_system" style="display:none;"></textarea>\n';
      content += '\n\n\n';
    }
    var propID;
    var propNd = null;

    var reqListsArr = this.newArray();
    for (i=0; i<fieldNds.length; i++)
    {
      fieldNd = fieldNds[i];
      if (itemTypeNd)
      {
        propID = getItemProperty(fieldNd, 'propertytype_id');
        if (propID) propNd = itemTypeNd.selectSingleNode('Relationships/Item[@type="Property" and name!="" and '+
          '@id="'+propID+'" and (not(@action) or (@action!="delete" and @action!="purge"))]');
        else propNd = null;
      }

      //Get all required lists from server in one query
      var propDT = getItemProperty(propNd, 'data_type');
      if (propDT == 'filter list' || propDT == 'list')
      {
        var listID = getItemProperty(propNd, 'data_source');
        var relType = "Value";
        if (propDT == "filter list") 
          relType = "Filter Value";
        
        var listDescr = this.newObject();
        listDescr.id = listID;
        listDescr.relType = relType;
       
        reqListsArr.push(listDescr);
      }
    }
    if (reqListsArr.length > 0)
      this.getSeveralListsValues(reqListsArr);


    for (i=0; i<fieldNds.length; i++)
    {
      fieldNd = fieldNds[i];
      if (itemTypeNd)
      {
        propID = getItemProperty(fieldNd, 'propertytype_id');
        if (propID) propNd = itemTypeNd.selectSingleNode('Relationships/Item[@type="Property" and name!="" and '+
          '@id="'+propID+'" and (not(@action) or (@action!="delete" and @action!="purge"))]');
        else propNd = null;
      }
      content += uiDrawFieldEx(fieldNd, propNd, mode, itemTypeNd);
    }
    

    content += '</form>\n';
    content += '<script>\n';
    for (var i=0; i<functionsCount; i++)
    {
      content += allFieldsEventsfunctions[i];
    }
    var funcTmpNm = 'StopHookingMouseInputInScript_' + formID;
    content += 'function '+funcTmpNm+'()\n' +
               '{\n' + 
               '  if (window.inputsArray)\n' + //check for global variable existence
               '    for (var i=0; i<inputsArray.length; i++)\n' + 
               '      top.aras.utils.StopHookingMouseInputInScript(window, inputsArray[i]);\n ' +
               '}\n' + 
               'window.attachEvent("onunload", ' + funcTmpNm + ')\n' +
      '</script>\n' +
      /* to fix IE bug with external deferred scripts */
      '<script type="text/javascript">\n' +
      '/* to fix IE bug with external deferred scripts */\n' +
      'for(var i=0; i<document.scripts.length; i++)\n' +
      '{\n' +
      '  var myScript = document.scripts[i];\n' +
      '  if (myScript.defer && myScript.readyState !== "complete")\n' +
      '  {\n' +
      '    var scriptCode = "";\n' +
      '    var url = myScript.src;\n' +
      '    if (url)' +
      '    {\n' +
      '      myScript.src = "";\n' +
      '      var http = new ActiveXObject("Msxml2.XMLHTTP.3.0");\n' +
      '      http.open("GET", url, false);\n' +
      '      var success = true;\n' +
      '      try\n' +
      '      {\n' +
      '        http.send();\n' +
      '      }\n' +
      '      catch(excep)\n' +
      '      {\n' +
      '        continue;\n' +
      '      }\n' +
      '      scriptCode = http.responseText;\n' +
      '    }\n' +
      '    else\n' +
      '    {\n' +
      '      scriptCode = myScript.text;\n' +
      '      myScript.text = "";\n' +
      '    }\n' +
      '    if (!scriptCode) continue;\n' +
      '    var newScript = document.createElement("SCRIPT");\n' +
      '    newScript.text = scriptCode;\n' +
      '    myScript.parentNode.insertBefore(newScript, myScript);\n' +
      '  }\n' +
      '}\n' +
      '</script>\n' +
      '</body>\n';
  }
  else
  {
    content += '</head>\n';
    top.aras.AlertError('The body of the form is missing.', "", "");
  }

  content += '</html>';

  if (mode!='edit_form' && mode != 'view_form') this.commonProperties.formsCacheById[cacheID] = content;
  return content;
}


/*
  Returns string: field type 4 specified Property
*/
Aras.prototype.uiGetFieldType4Property = function Aras_uiGetFieldType4Property( propertyNd )
{
  var fieldtype = "text";

  if (!propertyNd) return fieldtype;

  var datatype = this.getItemProperty(propertyNd, "data_type");
  var propertyName = this.getItemProperty(propertyNd, "name");

  if (datatype == "string" || datatype == "integer" || datatype == "float" || datatype == "decimal" || datatype == "sequence")
  {
    fieldtype = "text"

    var stored_length = this.getItemProperty(propertyNd, "stored_length");
    stored_length = parseInt(stored_length);

    if ( !isNaN(stored_length) && stored_length > 64)
      fieldtype = "textarea"
  }
  else if (datatype == "item")
  {
    if (this.getItemProperty(propertyNd, "data_source") == top.aras.getItemTypeId("File"))
      fieldtype = "file item"
    else
      fieldtype = "item";
  }
  else if (datatype == "list" || datatype == "filter list" || datatype == "color list")    fieldtype = "dropdown";
  else if (datatype == "formatted text")fieldtype = "formatted text";
  else if (datatype == "boolean")       fieldtype = "checkbox";
  else if (datatype == "date")          fieldtype = "date";
  else if (datatype == "md5")           fieldtype = "password";
  else if (datatype == "text")          fieldtype = "textarea";
  else if (datatype == "HTML")         fieldtype = "html";
  else if (datatype == "color")         fieldtype = "color";
  else if (datatype == "image")         fieldtype = "image";
  else if (datatype == "federated")     fieldtype = "text";
  else if (datatype == "foreign")
  {
    var sourceProperty = this.getSourceOfForeignProperty( propertyNd );
    if (sourceProperty) fieldtype = this.uiGetFieldType4Property( sourceProperty );
  }
  else
    fieldtype = "text";
  if (datatype == "string" && propertyName == "classification")
    fieldtype = "class structure";

  return fieldtype;
}

Aras.prototype.uiMergeForeignPropertyWithSource = function Aras_uiMergeForeignPropertyWithSource( foreignProperty ) {
/*
returns modified version of specified foreignProperty with some properties get from source
Property
*/
  if (!foreignProperty) return null;

  var data_type = this.getItemProperty(foreignProperty, "data_type");
  if (data_type != "foreign") return null;

  var tmpRes = foreignProperty.cloneNode(true);

  var sourcePropNd;

  while (data_type == "foreign") {
    sourcePropNd = this.getSourceOfForeignProperty( foreignProperty );
    if (!sourcePropNd) return tmpRes;

    data_type = this.getItemProperty(sourcePropNd, "data_type");
    foreignProperty = sourcePropNd;
  }

  var self = this;

  function copyProperty(propNm) {
    var tmpVal = self.getItemProperty(sourcePropNd, propNm);
    self.setItemProperty(tmpRes, propNm, tmpVal, false);
  }

  copyProperty("data_type");
  copyProperty("data_source");

  function copyAttribute(propNm,attrNm)
  {
    var tmpAttr = self.getNodeElementAttribute(sourcePropNd,propNm,attrNm);
    if(tmpAttr) self.setNodeElementAttribute(tmpRes,propNm,attrNm,tmpAttr);
  }

  copyAttribute("data_source","keyed_name");
  copyAttribute("data_source","type");
  copyAttribute("data_source","name");

  this.setItemProperty(tmpRes, "readonly", "1", false);

  return tmpRes;
}

Aras.prototype.uiDrawFieldEx = function Aras_uiDrawFieldEx(fieldNd, propNd, mode, itemTypeNd) {
/*
* uiDrawFieldEx
*
*/
  if (!fieldNd) return false;
  if (propNd==undefined) propNd = null;
  if (propNd) {
    var prop_data_type = this.getItemProperty(propNd, "data_type");
    if (prop_data_type == "foreign") {
      propNd = this.uiMergeForeignPropertyWithSource( propNd );
    }
  }

  var content = '';
  var fieldID = fieldNd.getAttribute('id');
  var tmpVal;

  //border-style:solid; border-color:red; border-width:1px;
  content += '<span name="'+this.getItemProperty(fieldNd, 'name')+'" id="'+fieldID+'span" style="';

  with (this) {
    var fieldType = getItemProperty(fieldNd, 'field_type');
    if (fieldType == '') fieldType = 'text';

    // +++ field style applying
    tmpVal = getItemProperty(fieldNd, 'positioning');
    if (tmpVal == '') tmpVal = 'absolute';
    content += 'position:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'y');
    if (tmpVal == '') tmpVal = 0;
    content += 'top:'+tmpVal+'px; ';

    tmpVal = getItemProperty(fieldNd, 'x');
    if (tmpVal == '') tmpVal = 0;
    content += 'left:'+tmpVal+'px; ';

    var label_position = getItemProperty(fieldNd, 'label_position');
    if (label_position=='') label_position = 'left';

    tmpVal = getItemProperty(fieldNd, 'width');
    if (tmpVal != '') {
      if (tmpVal.search(/\d$/) != -1) tmpVal += 'px';
      content += 'width:'+tmpVal+'; ';
    } else content += 'width:0; ';

    tmpVal = getItemProperty(fieldNd, 'height');
    if (tmpVal != '') {
      if (tmpVal.search(/\d$/) != -1) tmpVal += 'px';
      content += 'height:'+tmpVal+'; ';
    } else content += 'height:0; ';

    tmpVal = getItemProperty(fieldNd, 'z_index');
    if (tmpVal == '') tmpVal = '0';
    content += 'z-index:'+tmpVal+'; ';

    if (getItemProperty(fieldNd, 'is_visible') == '0') content += 'visibility:hidden; ';
    // --- field style applying

    content += '"><fieldset style="';

    tmpVal = getItemProperty(fieldNd, 'border_width');
    if (tmpVal == '') tmpVal = '0';
    if (tmpVal.search(/\d$/) != -1) tmpVal += 'px';
    content += 'border-width:'+tmpVal+'; ';
    content += '">';

    tmpVal = getItemProperty(fieldNd, 'legend');
    if (tmpVal != '') content += '<legend>'+tmpVal+'</legend>';

    var valign;
    if (label_position.search(/^left$|^right$/)==0) valign = 'center';
    else valign = 'top';

    var align;
    if (label_position.search(/^left$|^right$/)==0) align = 'left';
    else align = 'center';

    var align_inputField = getItemProperty(fieldNd, 'text_align');

    content += '<table cellpadding="0" cellspacing="0">';
    content += '<tr><td valign="'+valign+'" align="'+align+'" nowrap="yes" >';

    var exclusion = (fieldType.search(/^button$|^label$/)==0);

    if (label_position=='left' && !exclusion) {
      content += uiDrawFieldPromptEx(fieldNd, propNd);
      content += '</td><td valign="center" align="left" nowrap="yes">';//width="100%"
    }
    else if (label_position=='top' && !exclusion) {
      content += uiDrawFieldPromptEx(fieldNd, propNd);
      content += '</td></tr><tr><td valign="top" align="'+align_inputField+'" nowrap="yes">';//height="100%"
    }


    if (mode=='add' && fieldType != 'class structure')
      mode = 'edit';
    if (fieldType == 'html')          content += uiDrawFieldHTMLEx    (fieldNd, propNd, mode);
    else if (fieldType == 'nested form')content+=uiDrawFieldNestedFormEx(fieldNd, propNd, mode);
    else if (fieldType == 'menubar')  content += uiDrawFieldMenubarEx (fieldNd, propNd, mode);
    else if (fieldType == 'toolbar')  content += uiDrawFieldToolbarEx (fieldNd, propNd, mode);
    else if (fieldType == 'tabbar')   content += uiDrawFieldTabbarEx  (fieldNd, propNd, mode);
    else if (fieldType == 'tree')     content += uiDrawFieldTreeEx    (fieldNd, propNd, mode);
    else if (fieldType == 'treegrid') content += uiDrawFieldTreeGridEx(fieldNd, propNd, mode);
    else if (fieldType == 'grid')     content += uiDrawFieldGridEx    (fieldNd, propNd, mode);
    else if (fieldType == 'label')    content += uiDrawFieldLabelEx   (fieldNd, propNd, mode);
    else if (fieldType == 'hidden')   content += uiDrawFieldHiddenEx  (fieldNd, propNd, mode);
    else if (fieldType == 'text')     content += uiDrawFieldTextEx    (fieldNd, propNd, mode);
    else if (fieldType == 'password') content += uiDrawFieldPasswordEx(fieldNd, propNd, mode);
    else if (fieldType == 'textarea') content += uiDrawFieldTextareaEx(fieldNd, propNd, mode);
    else if (fieldType.search(/^listbox|^dropdown$|^color list$/)==0)
                                      content += uiDrawFieldListboxEx (fieldNd, propNd, mode);
    else if (fieldType == 'button')   content += uiDrawFieldButtonEx  (fieldNd, propNd, mode);
    else if (fieldType == 'checkbox') content += uiDrawFieldCheckboxEx(fieldNd, propNd, mode);
    else if (fieldType == 'checkbox list')
                                      content += uiDrawFieldCheckboxListEx(fieldNd, propNd, mode);
    else if (fieldType == 'radio button list')
                                      content += uiDrawFieldRadiobuttonListEx(fieldNd, propNd, mode);
    else if (fieldType == 'date')     content += uiDrawFieldDateEx    (fieldNd, propNd, mode);
    else if (fieldType == 'item')     content += uiDrawFieldItemEx    (fieldNd, propNd, mode);
    else if (fieldType == 'image')    content += uiDrawFieldImageEx   (fieldNd, propNd, mode);
    else if (fieldType == 'color')    content += uiDrawFieldColorEx   (fieldNd, propNd, mode, itemTypeNd);
    else if (fieldType == 'file item')content += uiDrawFieldFileItemEx(fieldNd, propNd, mode);
    else if (fieldType == 'formatted text')
                                      content += uiDrawFieldFormattedTextEx(fieldNd, propNd, mode);
    else if (fieldType == 'class structure')
                                      content += uiDrawFieldClassStructureEx(fieldNd, propNd, mode, itemTypeNd);


    if (label_position=='right' && !exclusion) {
      content += '</td><td valign="center" align="left" nowrap="yes">';
      content += uiDrawFieldPromptEx(fieldNd, propNd);
    }
    else if (label_position=='bottom' && !exclusion) {
      content += '</td></tr><tr><td valign="top" align="center" nowrap="yes">';
      content += uiDrawFieldPromptEx(fieldNd, propNd);
    }

    content += '</td></tr>';
    content += '</table>';
  }//with (this)

  content += '</fieldset></span>';

  content += '\n\n\n';
  return content;
}


Aras.prototype.uiDrawFieldPromptEx = function(fieldNd, propNd) {
  var content = '';
  content += '<p style="text-transform:capitalize; ';

  with (this) {
    var tmpVal = getItemProperty(fieldNd, 'font_family');
    if (tmpVal != '') content += 'font-family:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'font_size');
    if (tmpVal != '') content += 'font-size:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'font_weight');
    if (tmpVal != '') content += 'font-weight:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'font_color');
    if (tmpVal != '') content += 'color:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'text_align');
    if (tmpVal == '') tmpVal = 'left';
    content += 'text-align:'+tmpVal+'; ';

    tmpVal = getItemProperty(fieldNd, 'label');
    content += '">'+ preserveTags(tmpVal) +'&nbsp;</p>';
  }

  return content;
}


Aras.prototype.uiDrawFieldHTMLEx = function (fieldNd, propNd, mode) {
  return this.getItemProperty(fieldNd, 'html_code');
}

Aras.prototype.uiDrawFieldNestedFormEx = function (fieldNd, propNd, mode) {
  var fieldID = fieldNd.getAttribute('id');
  var fieldNm = this.getItemProperty(fieldNd, 'name');

  var content = '';
  content += '<iframe id="'+fieldID+'" name="'+fieldNm+'" ';
  if (mode=='edit_form' || mode=='view_form') content += 'style="visibility:hidden;" ';
  content += 'src="about:blank" frameborder="0" ></iframe>\n';//height="100%" width="100%"

  if (propNd) with (this) {
    var dsID = getItemProperty(propNd, 'data_source');
    var dsIT = (dsID != '') ? getItemById('ItemType', dsID, 0) : null;
    var exprStr = '';
    if (dsIT) {
      var dsITNm = getItemProperty(dsIT, 'name');
      var propNm = getItemProperty(propNd,'name');
      var funcName = 'system_'+fieldID+'_src';

      content += '<script >\n'+
      'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var iframe = document.getElementById("'+fieldID+'");\n'+
        ' if (!iframe) return true;\n'+
        ' var frameElem=document.frames("'+fieldID+'");\n'+
        ' if (!frameElem) return true;\n'+
        ' if (iframe.value==ctrlElem.value) return true;\n'+
        ' var itemID=ctrlElem.value;\n'+
        ' iframe.value=itemID;\n'+
        ' if (itemID=="") {\n'+
        '  '+
        '  '+
        '  '+
        ' }\n'+
        ' var doc;\n'+
        ' var itm = document.item.selectSingleNode("'+propNm+'/Item");\n'+
        ' if (!itm) itm = top.aras.getItemById("'+dsITNm+'",itemID,0);\n'+
        ' if (!itm) {\n'+
        '  doc = frameElem.document.open();\n'+
        '  doc.write(\''+dsITNm+' with id "\'+itemID+\'" not found !\');\n'+
        '  doc.close();\n'+
        ' }'+
        ' else top.aras.uiShowItemInFrameEx(frameElem,itm,"default",window.nestedLevel-(-1));\n'+
        ' return true;\n'+
        '}\n';
      if (propNm)
        content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';
      content += '</script>\n';
    }
  }
  return content;
}

Aras.prototype.uiDrawMenubarEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawMenubarEx';
}

Aras.prototype.uiDrawFieldToolbarEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawFieldToolbarEx';
}

Aras.prototype.uiDrawFieldTabbarEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawFieldTabbarEx';
}

Aras.prototype.uiDrawFieldTreeEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawFieldTreeEx';
}

Aras.prototype.uiDrawFieldTreeGridEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawFieldTreeGridEx';
}

Aras.prototype.uiDrawFieldGridEx = function (fieldNd, propNd, mode)
{
  return 'uiDrawFieldGridEx';
}

Aras.prototype.uiDrawFieldLabelEx = function (fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');

    content +=
      '<span id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'">' +
      preserveTags(getItemProperty(fieldNd, 'label')) + '</span>';
  }

  return content;
}

Aras.prototype.uiDrawFieldHTPEx = function (type, fieldNd, propNd, mode)
{
  var content = '';
  var fieldID = fieldNd.getAttribute('id');
  var fieldNm = this.getItemProperty(fieldNd, 'name');
  var propNm  = '';
  if (propNd) propNm = this.getItemProperty(propNd, 'name');

  if (mode=='print') content += '<span ';
  else content += '<input type="'+type+'" ';

  if (type=='password') content += 'pwdChanged=0 value="***" ';

  content += 'id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';

  var tmpVal = this.getItemProperty(fieldNd, 'display_length');
  if (tmpVal=='') {/*
    tmpVal = '100%';
    if (getItemProperty(fieldNd, 'width') == '') tmpVal = '*';
    content += 'width:'+tmpVal+'; ';
    tmpVal = '100%';
    if (getItemProperty(fieldNd, 'height') == '') tmpVal = '*';
    content += 'height:'+tmpVal+'; ';*/
    content += ' ';
  }
  else content += ' size="'+tmpVal+'" ';
  
  var userOnBlur   = "";
  var userOnChange = "";
  var readOnlyProp = this.uiIsFieldReadOnly(fieldNd, propNd);
  
  if (mode == 'edit_form' || mode =='view_form') content += ' readOnly ';
  else if (mode != "print")
  {
    var skipUserHanders = "";
    if (propNd)
    {
      if (readOnlyProp)
      {
        if (mode != "search") content += 'disabled ';
      }
      else
      {
        readOnlyProp = (this.getItemProperty(propNd, 'data_type') == 'sequence' && mode != 'search');
        if (readOnlyProp) content += ' readOnly value="Server Assigned" ';
      }
      tmpVal = this.getItemProperty(propNd, 'stored_length');
      if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';

      var onchangeCode = this.generateOnChangeHandler(type, fieldNd, propNd, mode);
      content += ' onchange="' + onchangeCode.onChangeCode + '" onblur="' + onchangeCode.onBlurCode + '" ';
      userOnBlur   = onchangeCode.userOnBlurCode;
      userOnChange = onchangeCode.userOnChangeCode;
      skipUserHanders = "onchange,onblur";
    }
    if (mode != "search")
    {
      content += this.assignFieldEventEx(fieldNd, skipUserHanders);
    }
  }

  // for the foreign properties we should show the fields in read only mode.
  var dataType = this.getItemProperty(propNd,'data_type');
  if ((dataType == 'foreign') && mode != 'print')
    content += ' disabled ';

  tmpVal = this.getItemProperty(fieldNd, 'tab_stop');
  if (tmpVal == '1')
  {
    tmpVal = this.getItemProperty(fieldNd, 'tab_index');
    if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
  }
  else content += ' tabindex="-1"';

  if (mode=='print') content += '></span>\n';
  else content += '/>\n';

  if (mode != 'edit_form' && mode != 'view_form')
  {
    content += userOnChange + userOnBlur;

    var funcName = 'system_'+fieldID+'_value';
    content += '<script type="text/javascript">\n';
    content += 'function ' + funcName + '() {\n' +
      (type=='password' ? 'return true;\n' : '') +
      ' if (event.propertyName!="value") return true;\n'+
      ' var ctrlElem = event.srcElement;\n'+
      ' if (!ctrlElem) return true;\n'+
      ' var input=document.getElementById("'+fieldID+'");\n'+
      ' if (!input) return true;\n'+
      ' var val=ctrlElem.value;\n'+
      ' if (input.value==val) return true;\n';
    if (mode=='print')
    {
      content +=
      ' input.value=val;\n'+
      ' input.innerHTML=top.aras.preserveTags(val);\n';
    }
    else
    {
      content +=
      ' input.value=val;\n';
    }
    content +=        
      ' return true;\n' +
      '}\n';
    
    if (propNm)
      content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';

    content += 'document.getElementById("'+fieldID+'").propNm="'+propNm+'";\n';
    if (mode != 'print' && !readOnlyProp)
      content += 'document.getElementById("'+fieldID+'").setExpression("readOnly","!document.isEditMode");\n';
    content += '</script>\n';
  }

  return content;
}

Aras.prototype.uiDrawFieldHiddenEx = function (fieldNd, propNd, mode) {
  return this.uiDrawFieldHTPEx('hidden', fieldNd, propNd, mode);
}

Aras.prototype.uiDrawFieldTextEx = function (fieldNd, propNd, mode) {
  return this.uiDrawFieldHTPEx('text', fieldNd, propNd, mode);
}

Aras.prototype.uiDrawFieldPasswordEx = function (fieldNd, propNd, mode) {
  return this.uiDrawFieldHTPEx('password', fieldNd, propNd, mode);
}

Aras.prototype.uiDrawFieldTextareaEx = function Aras_uiDrawFieldTextareaEx(fieldNd, propNd, mode)
{
  var content = '';
  var fieldID = fieldNd.getAttribute('id');
  var fieldNm = this.getItemProperty(fieldNd, 'name');
  var propNm  = '';
  if (propNd) propNm = this.getItemProperty(propNd, 'name');

  if (mode=='print') content += '<table border="0" cellpadding="0" cellspacing="0" cols="1"><tr><td style="word-wrap:break-word;display:block;width:expression(this.parentNode.parentNode.all(\'template\').offsetWidth);cursor:hand;" ';
  else content += '<textarea ';
  
  content += 'id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';
  
  var tmpVal;
  var tmpY = this.getItemProperty(fieldNd, 'textarea_rows');
  var tmpX = this.getItemProperty(fieldNd, 'textarea_cols');
  
  if (mode!='print')
  {
    if (tmpY != '') content += 'rows="'+tmpY+'" ';
    if (tmpX != '') content += 'cols="'+tmpX+'" ';
  }
  
  var userOnBlur   = "";
  var userOnChange = "";
  var readOnlyProp = this.uiIsFieldReadOnly(fieldNd, propNd);
  
  if (mode == 'edit_form' || mode == 'view_form') content += ' readOnly ';
  else if (mode != "print")
  {
    var skipUserHanders = "";
    
    if (propNd)
    {
      if (readOnlyProp && mode != "search") content += ' DISABLED ';
      
      var onchangeCode = this.generateOnChangeHandler("textarea", fieldNd, propNd, mode);
      content += ' onchange="' + onchangeCode.onChangeCode + '" onblur="' + onchangeCode.onBlurCode + '" ';
      userOnBlur   = onchangeCode.userOnBlurCode;
      userOnChange = onchangeCode.userOnChangeCode;
      skipUserHanders = "onchange,onblur";
    }
    if (mode != "search")
    {
      content += this.assignFieldEventEx(fieldNd, skipUserHanders);
    }
  }
  
  tmpVal = this.getItemProperty(fieldNd, 'tab_stop');
  if (tmpVal == '1')
  {
    tmpVal = this.getItemProperty(fieldNd, 'tab_index');
    if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
  }
  else content += ' tabindex="-1"';
  content += '>';
  
  if (mode=='print')
  {
    content += '</td><td><textarea id="template" style="position:absolute;top:0px;left:0px;visibility:hidden;overflow:auto;" ';
    if (tmpY != '') content += 'rows="'+tmpY+'" ';
    if (tmpX != '') content += 'cols="'+tmpX+'" ';
    content += '></textarea></td></tr></table>';
  }
  else content += '</textarea>';
  
  if (mode != 'edit_form' && mode != 'view_form')
  {
    content += userOnChange + userOnBlur;
    
    var funcName = 'system_'+fieldID+'_value';
    content += '<script type="text/javascript">';
    content += 'function '+funcName+'() {\n'+
      ' if (event.propertyName!="value") return true;\n'+
      ' var ctrlElem = event.srcElement;\n'+
      ' if (!ctrlElem) return true;\n'+
      ' var textarea=document.getElementById("'+fieldID+'");\n'+
      ' if (!textarea) return true;\n'+
      ' if (textarea.value==ctrlElem.value) return true;\n'+
      ((mode!='print') ? ' textarea.value=ctrlElem.value;\n' : 'textarea.innerHTML=top.aras.preserveTags(ctrlElem.value);\n')+
      ' return true;\n'+
      '}';
    
    if (propNm)
    {
      content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
    }
    
    content += 'document.getElementById("'+fieldID+'").propNm="'+propNm+'";\n';
    if (mode != 'print' && !readOnlyProp)
      content += 'document.getElementById("'+fieldID+'").setExpression("readOnly","!document.isEditMode");';
    content += '</script>';
  }
  
  return content;
}

Aras.prototype.generateOnChangeHandler = function Aras_generateOnChangeHandler(fieldType, fieldNd, propNd, mode)
{
  //for internal use only
  //the function generates onchange handler for <input> and <textarea>
  //**
  // fieldType - text, password, textarea
  
  var fieldID = fieldNd.getAttribute("id");
  var data_type = this.getItemProperty(propNd, "data_type");
  var isRequired = this.getItemProperty(propNd, "is_required");
  var pattern = this.getItemProperty(propNd, "pattern");
  var stored_length = this.getItemProperty(propNd, "stored_length");
  var propNm = this.getItemProperty(propNd, "name");
  var DSName = "";
  if (propNd)
  {
    var DS = propNd.selectSingleNode("data_source");
    if (DS) DSName = DS.getAttribute("name");
  }
  
  if (fieldType == "item" && !DSName) fieldType = "";
  
  /*
The sequence of execution:
1. IE fires onchange
a) call user handler for onchange. if that returns false - stop onchange handling and return false.
b) run new value validation. If validation fails global variable top.aras.ValidationMsg is set to message text
   and global variable with auto generated name fieldValIsInvalid${fieldID} is set to true.

2. IE fires onblur
a) ensure this onblur is not called from the onblur handler (read IEbugWorkAround description below)
   This workaround makes impossible to call onblur recursively.
b) Check fieldValIsInvalid${fieldID} variable value. If that is true - ask user to modify the value or cancel the modification.
c) If user want to continue edit - return focus to the field.
   - If user tries to leave the field without any modifications there will be no onchange fired but we check fieldValIsInvalid${fieldID}
     again. And prevent this attempt.
   - If user modifies the value then onchange is fired and ... see point 1.
d) If user want to cancel edit - restore previous value of the field. Set value of fieldValIsInvalid${fieldID} to false.
   Call custom onchange handler.
  */
  
  var userOnChangeFunc = 'user$' + fieldID + '$onchange';
  var userOnBlurFunc   = 'user$' + fieldID + '$onblur';
  var IE6bugWorkAround = "IE6bug$" + fieldID; //IE6 goes into infinite loop if onchange handler does "alert(123); return false;" while onchange was caused by a click on .Net control.
  var IEbugWorkAround  = "IEbug$" + fieldID;  //IE (6 and 7) fires onblur twice for input if onblur was caused by a click on .Net control
  var fieldValueIsInvalid = "fieldValIsInvalid$" + fieldID;
  var userOnChangeCode =
    '<script type="text/javascript">\n' +
    'function ' + userOnChangeFunc + '()\n' +
    '{\n' +
      this.getEventHandlerCode(fieldNd, "onchange", false, "return true;") + '\n' +
    '}\n' +
    '</script>\n';
  var userOnBlurCode =
    '<script type="text/javascript">\n' +
    'var ' + fieldValueIsInvalid + ' = false;\n' +
    'var ' + IEbugWorkAround +' = false;\n' +
    'function ' + userOnBlurFunc + '()\n' +
    '{\n' +
      this.getEventHandlerCode(fieldNd, "onblur", false, "return true;") + '\n' +
    '}\n' +
    '</script>';
  
  var onChangeCode = 
    fieldValueIsInvalid + '=false;\n' +
    'var ures=' + userOnChangeFunc + '();\n' +
    'if (ures == false) return false;\n' +
    /* +++ some checks and variables for properties of type "item" */
    (fieldType == "item" ?
    'var dS = \'' + DSName + '\';\n' +
    'if (event.srcElement.tagName!=\'INPUT\' && !document.isEditMode) return ures;\n' +
    'if (bFromSearch) { bFromSearch = false; return true;}\n' : '') + //validation and call to handlePropertyChange is NOT required in this case
    /* --- some checks and variables for properties of type "item" */
    'var val=this.value;\n' +
    /* +++ encode value for MD5 fields */
    (data_type == 'md5' ? 'val=top.aras.calcMD5(val);\n' : '');
    /* --- encode value for MD5 fields */
  
  if (mode != "search")
  {
    var handleInvalidValueCode =
      '    ' + fieldValueIsInvalid + '=true;\n' +
      '    return true;\n'; //if we return false there will be no onblur
  
    onChangeCode +=
      /* +++ this code is required only for data type "item" */
      (fieldType == 'item'     ?
      'if (val)\n' +
      '{\n' +
      '  val=top.aras.uiGetItemByKeyedName(dS, val);\n' +
      '  if (!val)\n' +
      '  {\n' +
      '    top.aras.ValidationMsg = \'Value entered does not exist for item type \' + dS + \'. Edit again?\';\n' +
           handleInvalidValueCode +
      '  }\n' +
      '}\n': '') +
      /* --- this code is required only for data type "item" */
      /* +++ this is common code required for any data type */
      '  var propertyDef=\n'+
      '  {\n' +
      '    data_type  : \'' + data_type + '\',\n' +
      '    is_required: ' + (isRequired == "1") + '\n' +
      (pattern ?                        ',\n' +
      '    pattern    : \'' + pattern + '\'' : '') +
      (stored_length   ?                ',\n' +
      '    stored_length: parseInt(\'' + stored_length + '\')\n' : '') +
      '  };\n' +
      '  if (!top.aras.isPropertyValueValid(propertyDef, val))\n' +
      '  {\n' +
           handleInvalidValueCode +
      '  }\n';
      /* --- this is common code required for any data type */
  }//if (mode != "search")
  
  onChangeCode +=
    '  if (window.handleItemChange)\n' +
    '  {\n' +
    '    handleItemChange(\''+propNm+'\', val);\n' +
    '  }';
  
  var onBlurCode =
    'if (' + IEbugWorkAround + ') {return;}\n' + //to prevent second call. Read IEbugWorkAround description above.
    IEbugWorkAround + '=true;\n' +
    'setTimeout(\'' + IEbugWorkAround +'=false;\', 0);\n' +
    'if (' + fieldValueIsInvalid + ')\n' +
    '{\n' +
    '  var continueEdit = top.aras.showValidationMsg(window, false);\n' +
    '  if (continueEdit)\n' +
    '  {\n' +
    '    this.focus();\n' +
    '    return;\n' +
    '  }\n' +
    '  else\n' + //+++ return previous value of the input box
    '  {\n' +
    '    var valueIsRestored = false;\n' +
    '    if (document.item)\n' +
    '    {\n' +
    '      var oldValue = document.item.selectSingleNode(\'' + propNm + '/Item\');\n' +
    '      if (oldValue == null) oldValue = document.item.selectSingleNode(\'' + propNm + '\');\n' +
    '      if (oldValue == null)\n' +
    '      {\n' +
    '        this.value = \'' + (fieldType == 'password' ? '***' : '') + '\';\n' +
    '      }\n' +
    '      else if (oldValue.baseName == \'Item\')\n' +
    '      {\n' +
    '        this.value = top.aras.getKeyedNameEx(oldValue);\n' +
    '      }\n' +
    '      else if (oldValue.getAttribute(\'keyed_name\') != null)\n' +
    '      {\n' +
    '        this.value = oldValue.getAttribute(\'keyed_name\');\n' +
    '      }\n' +
    '      else\n' +
    '      {\n' +
    '        this.value = oldValue.text;\n' +
    '      }\n' +
    '      valueIsRestored = true;\n' +
    '    }\n' +
    '    ' + fieldValueIsInvalid + ' = false;\n' +
    '    if (valueIsRestored) ' + userOnChangeFunc + '();\n' +
    '  }\n' + //--- return previous value of the input box
    '}\n' + //--- if field value is invalid
    'var ures=' + userOnBlurFunc + '();\n' +
    'return ures;\n';
  
  var res = {
    userOnBlurCode: userOnBlurCode,
    userOnChangeCode: userOnChangeCode,
    onBlurCode: onBlurCode,
    onChangeCode: onChangeCode};
  
  return res;
}

Aras.prototype.uiGetFilteredListEx = function(fValueNds, filter) {
  if (!fValueNds) return null;
  if (filter==undefined) filter = '';

  if (filter == '') return fValueNds;

  var res = new Array();
  for (var i=0; i<fValueNds.length; i++)
    if (this.getItemProperty(fValueNds[i],'filter').search(filter) == 0) res[res.length] = fValueNds[i];

  this.applySortOrder(res);
  return res;
}

Aras.prototype.uiDrawFieldListboxEx = function(fieldNd, propNd, mode) {
  var content = '';

  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldType = getItemProperty(fieldNd, 'field_type');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    if (mode=='print') content += '<span ';
    else content += '<select test ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';
    if (fieldType == 'listbox multi select') content += ' multiple="yes" ';

    var tmpVal;

    if (fieldType == 'dropdown' ) tmpVal = '1';
    else {
      tmpVal = getItemProperty(fieldNd, 'listbox_size');
      if (tmpVal == '') tmpVal = '2';
    }
    content += ' size="'+tmpVal+'" ';
    content += ' style="color:#000000" ';

    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);
    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (propNd) {
        if (readOnlyProp && mode != "search") content += ' DISABLED ';
      }
      if (propNm) content += ' onpropertychange="if (event.propertyName==\'selectedIndex\' && this.selectedIndex!=-1) '+
        'if (window.handleItemChange) handleItemChange(\''+propNm+'\',this.options(this.selectedIndex).value)" ';
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, '');
      }
    }
    else if (mode == 'edit_form' || mode == 'view_form') content += ' disabled ';

    content += '>';

    var noBlank = (getItemProperty(fieldNd, 'list_no_blank') == '1');
    if (!noBlank && mode!='print') content += '<option></option>';

    var funcName;
    var propDT = '';
    if (propNd)  propDT = getItemProperty(propNd, 'data_type');

    if (mode != 'print' && propNd) {
      var listID = getItemProperty(propNd, 'data_source');
      if (listID) {
        var options;
        if (propDT == 'filter list') options = getListFilterValues(listID);
        else options = getListValues(listID);

        var i, val, lab, option;
        for (i=0; i<options.length; i++) {
          option = options[i];
          val = getItemProperty(option, 'value');
          lab = getItemProperty(option, 'label');
          if (lab=='') lab = val;
          content += '<option id="'+val+'" value="'+val+'" ';
          if (propDT == 'color list') content += 'style="background-color:'+val+'"';
          content += '>'+lab+'</option>';
        }
        content += '</select> \n';

        content += '<script> \n';
        content += 'document.getElementById("'+fieldID+'").selectedIndex = -1;\n';
        content += '</script>\n';

        if (mode != 'edit_form' && mode != 'view_form') {
          var pattern = getItemProperty(propNd, 'pattern');
          if (propDT == 'filter list' && pattern != '') {
            funcName = 'system_'+fieldID+'_options';
            content += '<script>';
            content += 'function '+funcName+'() {\n'+
            ' if (event.propertyName!="value") return true;\n'+
            ' var selectElem=document.getElementById("'+fieldID+'");\n'+
            ' if (!selectElem) return true;\n'+
            ' var oldVal="";\n'+
            ' if(selectElem.selectedIndex!=-1) oldVal=selectElem.options(selectElem.selectedIndex).value;\n'+
            ' selectElem.selectedIndex=-1;\n'+
            ' var i, val, lab, optionNd, option;\n'+
            ' for (i=selectElem.options.length-1; i>=0; i--) selectElem.options.remove(i);\n'+
            ' var filterVal=event.srcElement.value;\n'+
            ' var optionNds=top.aras.getListFilterValues("'+listID+'");\n'+
            ' if (filterVal!="") optionNds = top.aras.uiGetFilteredListEx(optionNds,"^"+filterVal+"$");\n'+
            ' var emptyOption = null; '+
            ((!noBlank) ? ' emptyOption=document.createElement("option");\n' +
            ' selectElem.options.add(emptyOption); emptyOption.selected=true;\n' : '')+
            ' for (var i=0; i<optionNds.length; i++) {\n'+
            '  optionNd = optionNds[i];\n'+
            '  option = document.createElement("option");\n'+
            '  selectElem.options.add(option);\n'+
            '  lab = top.aras.getItemProperty(optionNd,"label");\n'+
            '  val = top.aras.getItemProperty(optionNd,"value");\n'+
            '  if (lab=="") lab = val;\n'+
            '  option.id   = val;\n'+
            '  option.value= val;\n'+
            '  if (val==oldVal) {if(emptyOption && emptyOption.selected) emptyOption.selected=false; option.selected=true;}\n'+
            '  option.innerHTML=top.aras.preserveTags(lab);\n'+
            ((propDT == 'color list') ? '  option.style.backgroundColor=val;\n' : '')+
            ' }\n'+
            ((noBlank) ? ' var opts=selectElem.options;\n if (opts.selectedIndex==0 && opts[0].value!=oldVal) {opts.selectedIndex=-1; opts.selectedIndex=0;}\n' : '') +
            '}';

            content += 'document.getElementById("'+pattern+'_system").attachEvent("onpropertychange",'+funcName+');';
            content += '</script>';
          }
        }
      }
      else content += '</select>';
    }
    else if (mode == "print") {
      var objLabelsName = "labels" + fieldID;
      content += '</span><script>\n var ' + objLabelsName + ' = new Object();\n';
      var listID = getItemProperty(propNd, 'data_source');
      if (listID) {
        var options;
        if (propDT == 'filter list') options = getListFilterValues(listID);
        else options = getListValues(listID);

        var i, val, lab, option;
        var re = /(\\|")/g;
        for (i=0; i<options.length; i++) {
          option = options[i];
          val = getItemProperty(option, 'value');
          lab = getItemProperty(option, 'label');
          if (lab=='') lab = val;
          content += objLabelsName + '["'+val.replace(re, "\\$1")+'"]="'+lab.replace(re, "\\$1")+'";\n';
        }
      }
      content +='</script>';
    }

    if (mode != 'edit_form' && mode != 'view_form') {
      content += '<script>';
      funcName = 'system_'+fieldID+'_selectedIndex';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var select=document.getElementById("'+fieldID+'");\n'+
        ' if (!select) return true;\n'+
        ' if (select.i_value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' select.i_value=val;\n'+
        ' ' + ((mode=='print') ? ((propDT=='color list') ? 'select.style.backgroundColor=val;\n' : '')+'select.innerHTML=top.aras.preserveTags('+objLabelsName+'[val]);\n' : 'var opt = select.options(val);\n'+
        ' if (opt && opt.length) opt=opt(0);\n'+
        ' select.selectedIndex=(opt ? opt.index:-1);\n')+
        ' return true;\n'+
        '}';
      if (propNm)
        content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      if (mode != 'print' && !readOnlyProp)
        content += 'document.getElementById("'+fieldID+'").setExpression("disabled","!document.isEditMode");';
      content += '</script>';
    }
  }
  return content;
}//uiDrawFieldListboxEx

Aras.prototype.uiDrawFieldButtonEx = function (fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content += '<input type="button" ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';

    var tmpVal = getItemProperty(fieldNd, 'label');
    if (tmpVal != '') content += 'value="'+tmpVal+'" ';

    if (mode.search(/^print$|^edit_form$|^view_form$|^search$/)==-1) content += assignFieldEventEx(fieldNd, '');

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    content += '/>';
  }

  return content;
}

Aras.prototype.uiDrawFieldImageCheckboxEx = function (fieldNd, propNd) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content +=  '<img id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'"';
    content +=  ' src="../images/Other/12x12_checkboxblue0.gif" value = "0"';
    content +=  ' onclick=" this.value = (this.value + 1) % 3;  " ';
//    content +=  ' this.src = "../images/checkbox/" + cbImages[this.value];\' ';
//    content += '\'';

    if (propNm) content += ' onpropertychange=" '+
       'if (window.handleItemChange) handleItemChange(\''+propNm+'\', cbValue[this.value]);" ';


    var tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    content += '/>';


    content += '<script>';
    funcName = 'system_'+fieldID+'_checked';
    content += 'function '+funcName+'() {\n'+
      ' if (event.propertyName!="value") return true;\n'+
      ' var ctrlElem = event.srcElement;\n'+
      ' if (!ctrlElem) return true;\n'+
      ' var checkbox=document.getElementById("'+fieldID+'");\n'+
      ' if (!checkbox) return true;\n'+
      ' if (checkbox.i_value==ctrlElem.value) return true;\n'+
      ' var val=ctrlElem.value;\n'+
      ' checkbox.i_value=val;\n'+
      ' if (val == "0") { checkbox.src = "../images/Other/12x12_checkbox0.gif"; checkbox.value = 1;}\n'+
      ' else if (val == "1"){ checkbox.src = "../images/Other/12x12_checkbox1.gif"; checkbox.value = 2;}\n'+
      ' else {checkbox.src = "../images/Other/12x12_checkboxblue0.gif"; checkbox.value = 0;}\n'+
      ' return true;\n'+
      '}';
    if (propNm)
      content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
    content += '</script>';

  }

  return content;
}

Aras.prototype.uiDrawFieldCheckboxEx = function (fieldNd, propNd, mode) {
  if (mode == "search") return this.uiDrawFieldImageCheckboxEx(fieldNd, propNd);
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content += '<input type="checkbox"  ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';
    var tmpVal;

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      content += 'onpropertychange="';
      var method_code = getEventHandlerCode(fieldNd, "onchange", true);

      if (propNm) content += 'if (event.propertyName==\'checked\') '+
        'if (window.handleItemChange) handleItemChange(\''+propNm+'\',( (this.checked) ? \'1\':\'0\')); ';

      //field event "onChange" corresponds to checkbox event "onpropertychange"
      if (method_code != '') {
        content += "if (event.propertyName == &quot;checked&quot;)\n"+
                   "{\n"+ 
                    method_code + '\n' +
                   "}\n";
      }

      content += '"\n';
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onchange');
      }
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);
    if (mode != 'print') {
      if (propNd) {
        if (readOnlyProp && mode != "search" ) content += ' DISABLED ';
      }
    }
    else content += ' disabled ';

    content += '/>';

    if (mode != 'edit_form' && mode != 'view_form') {
      content += '<script>';
      funcName = 'system_'+fieldID+'_checked';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var checkbox=document.getElementById("'+fieldID+'");\n'+
        ' if (!checkbox) return true;\n'+
        ' if (checkbox.i_value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' checkbox.i_value=val;\n'+
        ' var checkbox_checked = (val=="1" ? true:false);\n'+
        ' if (checkbox_checked != checkbox.checked) checkbox.checked = checkbox_checked;\n'+
        ' return true;\n'+
        '}';
      if (propNm)
        content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      if (mode != 'print' && !readOnlyProp)
        content += 'document.getElementById("'+fieldID+'").setExpression("disabled","!document.isEditMode");';
      content += '</script>';
    }
  }

  return content;
}

Aras.prototype.uiDrawFieldImageRadListEx = function(type, fieldNd, propNd) {
  var imageDir = (type == 'radio') ? '../images/radio/' : '../images/checkbox/';
  var content = "";
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    var tabStop = (getItemProperty(fieldNd, 'tab_stop') == '1');
    var tabIndex = getItemProperty(fieldNd, 'tab_index');

    var funcName;
    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);
    if (propNd) {
      var listID = getItemProperty(propNd, 'data_source');
      if (listID) {
        var chboxes, propDT;
        propDT = getItemProperty(propNd, 'data_type');
        if (propDT == 'filter list') chboxes = getListFilterValues(listID);
        else chboxes = getListValues(listID);

        var i, val, lab, chbox;
        var vertOrient = (getItemProperty(fieldNd, 'orientation') == 'vertical');

        for (i=0; i<chboxes.length; i++) {
          chbox = chboxes[i];
          val = getItemProperty(chbox, 'value');
          lab = getItemProperty(chbox, 'label');
          if (lab == '') lab = val;
          content += '<span id="'+fieldID+'" name="'+val+'" style="';
          if (propDT == 'color list') content += ' background-color:'+val+'; ';

          if (vertOrient) content += 'float:left; clear:left;';
          else content += 'float:none; clear:none;';

/*          content += '"><input type="'+type+'" value="'+val+'" name="'+fieldID+'name"';
          if (!tabStop) content += ' tabindex="-1" ';

          if (propNm) content += 'onpropertychange="if (event.propertyName==\'checked\') '+
            'if (window.handleItemChange && this.checked) handleItemChange(\''+propNm+'\',this.value);" ';
          content += assignFieldEventEx(fieldNd, '');
*/
          content += '"><img value="'+val+'" name="'+fieldID+'name"';
          content += ' src = "../images/Other/12x12_'+type+'blue0.gif"';


          content += ' onclick = "this.checked = (this.checked) ? false : true; this.dumm = 1; "  \n';

          if (!tabStop) content += ' tabindex="-1" ';
          else if (tabIndex!='') content += ' tabindex="'+tabIndex+'" ';

          if (propNm) content += ' onpropertychange=" '+
            ' if (event.propertyName != \'dumm\') return true; if (window.handleItemChange) handleItemChange(\''+propNm+'\', (this.checked) ? this.value : \'\');" ';
          content += '/>'+lab+'</span>';
        }


        var pattern = getItemProperty(propNd, 'pattern');
        if (propDT == 'filter list' && pattern != '') {
          funcName = 'system_'+fieldID+'_chboxes';
          content += '<script>\n';
          content += 'function '+funcName+'() {\n'+
          ' if (event.propertyName!="value") return true;\n'+
          ' var chboxSpans=document.all("'+fieldID+'");\n'+
          ' if (!chboxSpans) return true;\n'+
          ' var i, j, val, chboxNd, chbox, goodSpans;\n'+
          ' if (chboxSpans.length==undefined) chboxSpans=new Array(chboxSpans);\n'+
          ' for (i=0; i<chboxSpans.length; i++) chboxSpans[i].style.display="none";\n'+
          ' var filterVal=event.srcElement.value;\n'+
          ' var chboxNds=top.aras.getListFilterValues("'+listID+'");\n'+
          ' if (filterVal!="") chboxNds = top.aras.uiGetFilteredListEx(chboxNds,"^"+filterVal+"$");\n'+
          ' for (var i=0; i<chboxNds.length; i++) {\n'+
          '  chboxNd = chboxNds[i];\n'+
          '  val = top.aras.getItemProperty(chboxNd,"value");\n'+
          '  if (chboxSpans.length>1) {\n'+
          '    for(z=0;z<chboxSpans.length;z++) if(chboxSpans[z].firstChild.value==val) chboxSpans[z].style.display="inline";\n'+
          '  }\n'+
          ' }\n'+
          '}\n';

          content += 'document.getElementById("'+pattern+'_system").attachEvent("onpropertychange",'+funcName+');\n';
          content += '</script>\n';
        }

      }
    }


    content += '<script>';
    funcName = 'system_'+fieldID+'_checked';
    content += 'function '+funcName+'() {\n'+
      ' if (event.propertyName!="value") return true;\n'+
      ' var ctrlElem = event.srcElement;\n'+
      ' if (!ctrlElem) return true;\n'+
      ' var chboxSpans=document.all("'+fieldID+'");\n'+
      ' if (!chboxSpans) return true;\n'+
      ' var val=ctrlElem.value;\n'+
      ' if (chboxSpans(0).i_value==val) return true;\n'+
      ' var checkbox;\n'+
      ' chboxSpans(0).i_value=val;\n'+
      ' for (var i=0; i<chboxSpans.length; i++) {'+
      '  checkbox=chboxSpans(i).all.tags("img")(0);\n'+
      '  checkbox.src =(val==checkbox.value) ? \'../images/Other/12x12_'+type+'blue1.gif\' : \'../images/Other/12x12_'+type+'blue0.gif\';\n'+
      '  checkbox.checked = (val==checkbox.value);'+
      ' }'+
      ' return true;\n'+
      '}';
    if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';

    content += '</script>';

  }
  return content;

}

Aras.prototype.uiDrawFieldChbRadListEx = function(type, fieldNd, propNd, mode) {
  if (mode == "search") return this.uiDrawFieldImageRadListEx(type, fieldNd, propNd);
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    var tabStop = (getItemProperty(fieldNd, 'tab_stop') == '1');
    var tabIndex = getItemProperty(fieldNd, 'tab_index');

    var funcName;
    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);
    if (propNd) {
      var listID = getItemProperty(propNd, 'data_source');
      if (listID) {
        var chboxes, propDT;
        propDT = getItemProperty(propNd, 'data_type');
        if (propDT == 'filter list') chboxes = getListFilterValues(listID);
        else chboxes = getListValues(listID);

        var i, val, lab, chbox;
        var vertOrient = (getItemProperty(fieldNd, 'orientation') == 'vertical');
        var res = new Array();
        for (var i=0; i<chboxes.length; i++)
          res[res.length] = chboxes[i];

        for (i=0; i<res.length; i++) {
          chbox = res[i];
          val = getItemProperty(chbox, 'value');
          lab = getItemProperty(chbox, 'label');
          if (lab == '') lab = val;
          content += '<span id="'+fieldID+'" name="'+val+'" style="';
          if (propDT == 'color list') content += 'background-color:'+val+'; ';

          if (vertOrient) content += 'float:left; clear:left;';
          else content += 'float:none; clear:none;';

          content += '"><input type="'+type+'" value="'+val+'" name="'+fieldID+'name"';
          if (readOnlyProp && mode != "search") content += ' disabled ';
          if (!tabStop) content += ' tabindex="-1" ';
          else if (tabIndex!='') content += ' tabindex="'+tabIndex+'" ';

          if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
            if (propNm) content += ' onpropertychange="if (event.propertyName==\'checked\') '+
            'if (window.handleItemChange) if(this.checked) handleItemChange(\''+propNm+'\',this.value);'+
            'else if(this.autoUncheck!=undefined && !this.autoUncheck) handleItemChange(\''+propNm+'\',\'\');" ';
            if (mode != "search")
            {
              content += assignFieldEventEx(fieldNd, 'onchange'); //onchange processes below
            }
          }
          else content += ' disabled ';
          content += '/>'+lab+'</span>';
        }

        if (mode != 'edit_form' && mode != 'view_form') {
          var pattern = getItemProperty(propNd, 'pattern');
          if (propDT == 'filter list' && pattern != '') {
            funcName = 'system_'+fieldID+'_chboxes';
            content += '<script>';
            content += 'function '+funcName+'() {\n'+
            ' if (event.propertyName!="value") return true;\n'+
            ' var chboxSpans=document.all("'+fieldID+'");\n'+
            ' if (!chboxSpans) return true;\n'+
            ' var i, j, val, chboxNd, chbox, goodSpans;\n'+
            ' if (chboxSpans.length==undefined) chboxSpans=new Array(chboxSpans);\n'+
            ' for (i=0; i<chboxSpans.length; i++) chboxSpans[i].style.display="none";\n'+
            ' var filterVal=event.srcElement.value;\n'+
            ' var chboxNds=top.aras.getListFilterValues("'+listID+'");\n'+
            ' if (filterVal!="") chboxNds = top.aras.uiGetFilteredListEx(chboxNds,"^"+filterVal+"$");\n'+
            ' for (var i=0; i<chboxNds.length; i++) {\n'+
            '  chboxNd = chboxNds[i];\n'+
            '  val = top.aras.getItemProperty(chboxNd,"value");\n'+
            '  if (chboxSpans.length>1) {\n'+
            '    for(z=0;z<chboxSpans.length;z++) if(chboxSpans[z].firstChild.value==val) chboxSpans[z].style.display="inline";\n'+
            '  }\n'+
            ' }\n'+
            '}';

            content += 'document.getElementById("'+pattern+'_system").attachEvent("onpropertychange",'+funcName+');';
            content += '</script>';
          }
        }
      }
    }

    if (mode != 'edit_form' && mode != 'view_form') {
      content += '<script>';
      funcName = 'system_'+fieldID+'_checked';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var chboxSpans=document.all("'+fieldID+'");\n'+
        ' if (!chboxSpans) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' if (chboxSpans(0).i_value==val) return true;\n'+
        ' var checkbox;\n'+
        ' chboxSpans(0).i_value=val;\n'+
        ' for (var i=0; i<chboxSpans.length; i++) {'+
        '  checkbox=chboxSpans(i).all.tags("input")(0);\n'+
        '  checkbox.autoUncheck=true;'+ //<--to avoid infinite looping when unchecking checkbox automatically
        '  checkbox.checked=((val==checkbox.value) ? true:false);\n'+
		    '  checkbox.autoUncheck=false;'+
        ' }';

      //field event "onChange" corresponds to checkbox event "onpropertychange"
        var method_code = getEventHandlerCode(fieldNd, "onchange", false);
        if (method_code != '')
        {
          if (type == "radio")      
            content += "if (event.srcElement.value != \"\")\n"+
              "{\n"+ 
            method_code +
                      "}\n";
          else
            content += method_code;
        }


      content += ' return true;\n'+
        '}';
      if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';
      if (mode != 'print' && !readOnlyProp)
        content += 'var elems=document.all("'+fieldID+'name");\n'+
        'if (elems) {for (var i=0; i<elems.length; i++) elems(i).setExpression("disabled","!document.isEditMode");}\n';
      content += '</script>';
    }
  }
  return content;
}

Aras.prototype.uiDrawFieldCheckboxListEx = function (fieldNd, propNd, mode) {
  return this.uiDrawFieldChbRadListEx('checkbox', fieldNd, propNd, mode);
}

Aras.prototype.uiDrawFieldRadiobuttonListEx = function (fieldNd, propNd, mode) {
  return this.uiDrawFieldChbRadListEx('radio', fieldNd, propNd, mode);
}

Aras.prototype.uiDrawFieldDateEx = function (fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    if (mode=='print') content += '<span ';
    else content += '<input type="text" ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" style="cursor:hand;"';

    var funcName;
    var tmpVal;

    tmpVal = getItemProperty(fieldNd, 'display_length');
    if (tmpVal != '') content += ' size="'+tmpVal+'" ';
    content += ' READONLY ';

    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);
    var userOnClick = '';
    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (propNd) {
        if (readOnlyProp && mode != "search") content += ' DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      if (propNm) content += ' onpropertychange="if (event.propertyName==\'value\') '+
        'if (window.handleItemChange) handleItemChange(\''+propNm+'\',this.value)" ';
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick');
      }

      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      if (!readOnlyProp)

        var pattern = getItemProperty(propNd, 'pattern');
        if (pattern) {
          pattern = pattern.replace(/\\/g,"\\\\").replace(/'/g,"\\'");
        } else {
          pattern = "";
        }
        content += 'var param=new Object(); param.date=this.value; param.format=\''+pattern+'\';var newDate=top.aras.uiShowDialogNearElement(this,top.aras.getScriptsURL()+\'dateDialog.html\',param);'+
        'if (newDate != undefined) { var prevVal=this.value; this.value=newDate; if (prevVal!=this.value) fireEvent(\'onchange\'); }';
      if (method_code != 'return true;') content += '}';
      content += '" ';
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode=='print') content += '></span>';
    else content += '/>';

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) content += userOnClick;



    if (mode != 'edit_form' && mode != 'view_form') {
      funcName = 'system_'+fieldID+'_value';
      content += '<script >';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var input=document.getElementById("'+fieldID+'");\n'+
        ' if (!input) return true;\n'+
        ' if (input.value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' input.value=val;\n'+
        ' input.'+((mode=='print') ? 'innerHTML=top.aras.preserveTags(val);\n':'value=val;\n')+
        ' return true;\n'+
        '}';

      if (propNm)
        content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      if (mode != 'print' && !readOnlyProp)
        content += 'document.getElementById("'+fieldID+'").setExpression("disabled","!document.isEditMode");';
      content += '</script>';
    }
  }
  return content;
}

Aras.prototype.uiDrawFieldItemEx = function Aras_uiDrawFieldItemEx(fieldNd, propNd, mode)
{
  var content = '';
  
  var fieldID = fieldNd.getAttribute('id');
  var fieldNm = this.getItemProperty(fieldNd, "name");
  
  var propNm  = '';
  if (propNd) propNm = this.getItemProperty(propNd, "name");
//    if (propNm == 'current_state') return uiDrawFieldCurrentStateEx(fieldNd, propNd, mode);
  
  content += '<span id="' + fieldID + '" name="' + fieldNm + '" class="' + fieldNm + '" ';
 
  var tmpVal, bg_color;
  var DSName = '';
  var funcName;
  
  var readOnlyProp = this.uiIsFieldReadOnly(fieldNd, propNd);
  
  if (propNd)
  {
    var DS = propNd.selectSingleNode('data_source');
    if (DS) DSName = DS.getAttribute('name');
  }
  
  var onF2DownCode      = "";
  var userOnBlurCode    = "";
  var userOnChangeCode  = "";
  var userOnClickCode   = "";
  var userOnKeyDownCode = "";
  
  if (mode == 'edit_form' || mode == 'view_form')
  {
    content += '><input type="text" ';

    tmpVal = this.getItemProperty(fieldNd, 'display_length');
    if (tmpVal != '') content += '" size="'+tmpVal+'" ';
    content += ' READONLY ';

    if (propNd)
    {
      if (readOnlyProp && mode != "search") content += ' DISABLED ';
      tmpVal = this.getItemProperty(propNd, 'stored_length');
      if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
    }

    tmpVal = this.getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1')
    {
      tmpVal = this.getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';
  }
  else if (mode != "print")
  {
    var hasDataSource = false;
    var onF2DownFunc = "system$" + fieldID + "$OnF2Down";
    
    if (mode != "search")
    {
      content += this.assignFieldEventEx(fieldNd, "onclick,onkeydown,onchange");
    }
    
    // +++ generate onclick event handler
    var userOnClickFunc = "user$" + fieldID + "$onclick";
    userOnClickCode =
      '<script type="text/javascript">\n' +
      'function ' + userOnClickFunc + '()\n' +
      '{\n' +
        this.getEventHandlerCode(fieldNd, "onclick", false, "return true;") + '\n' +
      '}\n' +
      '</script>\n';
    
    content += ' onclick="var ures=' + userOnClickFunc + '();\n' +
      'if (ures)\n'+
      '{\n';
    
    if (propNd && propNm)
    {
      if (DSName)
      {
        //REMOVE
        if (DSName=='File' && mode != "search") return this.uiDrawFieldFileItemEx(fieldNd, propNd, mode);
        //^^^^ REMOVE
        
        content +=
          'var tgName=event.srcElement.tagName;\n' +
          'if (tgName==\'SPAN\')\n' +
          '{\n' +
          ' var itm=top.aras.getItemById(\''+DSName+'\',document.getElementById(\''+propNm+'_system\').value,0);\n' +
          ' if (itm) top.aras.uiShowItemEx(itm,undefined,true);\n' +
          '}\n' +
          'else if (tgName==\'IMG\')\n' +
          '{\n' +
            onF2DownFunc + '(event.srcElement.parentNode);\n' +
          '}\n';
        
        if (!readOnlyProp || mode=="search") hasDataSource = true;
      }
    }
    
    content += '}" ';
    // --- generate onclick event handler
    
    // +++ generate onkeydown event handler
    var userOnKeyDownFunc = "user$" + fieldID + "$onkeydown";
    userOnKeyDownCode =
      '<script type="text/javascript">\n' +
      'function ' + userOnKeyDownFunc + '()\n' +
      '{\n' +
        this.getEventHandlerCode(fieldNd, "onkeydown", false, "return true;") + '\n' +
      '}\n' +
      '</script>\n';
    
    content += ' onkeydown="var ures=' + userOnKeyDownFunc + '();\n' +
      'if (ures)\n' +
      '{\n';
    
    if (hasDataSource)
    {
      onF2DownCode =
      '<script type="text/javascript">\n' +
      'function ' + onF2DownFunc + '(king_span)\n' +
      '{\n'+
      '  var input = king_span.all(\'' + fieldNm + '\');\n' +
      '  res = undefined;\n' +
      '  input.dialogIsShown = true;\n' +
      '  var res=top.showModalDialog(top.aras.getScriptsURL()+\'searchDialog.html\',{aras:window.top.aras,itemtypeName:\''+DSName+'\',itemContext:document.item, sourceItemTypeName:document.item.getAttribute(\'type\'), sourcePropertyName:\''+propNm+'\'},\'dialogHeight: 450px; dialogWidth: 700px; status:0; help:0; resizable:1\');\n' +
      '  input.dialogIsShown = false;\n' +
      '  if (res == undefined)\n' +
      '  {\n' +
      '    input.focus();\n' +
      '    return true;\n' +
      '  }\n' +
      '  bFromSearch = true;\n' +
      '  var prevVal=king_span.value;\n' +
      '  if (res.itemID)\n' +
      '  {\n' +
      '    if (window.handleItemChange) handleItemChange(\'' + propNm + '\', res.' + (mode == 'search' ? 'keyed_name' : 'item') + ');\n' +
      '    if (prevVal!=res.itemID) input.fireEvent(\'onchange\');\n' +
      '   }\n' +
      '  else\n' +
      '  {\n' +
      '    if (window.handleItemChange) handleItemChange(\'' + propNm + '\',\'\');\n' +
      '    if (prevVal!=\'\') input.fireEvent(\'onchange\');\n' +
      '    input.focus();' +
      '  }\n' +
      '}\n' +
      '</script>\n';

      content +=
        ' if (event.keyCode != 113) return true;\n' +
        ' var tgName=event.srcElement.tagName;\n' +
        ' if (tgName==\'INPUT\' && document.isEditMode)\n' +
        ' {\n' +
        onF2DownFunc + '(event.srcElement.parentNode);\n'+
        '}\n';
    }// if hasDataSource
    
    content += '}"';
    // --- generate onkeydown event handler
    
    // +++ generate onchange and onblur event handlers
    var onchangeCode = this.generateOnChangeHandler("item", fieldNd, propNd, mode);
    content += ' onchange="' + onchangeCode.onChangeCode + '" onblur="' + onchangeCode.onBlurCode + '" ';
    userOnBlurCode   = onchangeCode.userOnBlurCode;
    userOnChangeCode = onchangeCode.userOnChangeCode;
    // --- generate onchange and onblur event handlers
    
    content += '>\n';
    
    content += '<input name="' + fieldNm + '" type="text" class="'+fieldNm+'" ';
    if (hasDataSource)
    {
      content += 'onblur="top.aras.utils.toHideMouseInputInScript(false,window,this.name); if (!this.parentNode.onblur) {return true;} this.onblur=this.parentNode.onblur; this.fireEvent(\'onblur\');"\n';
      content += 'onfocus=" top.aras.utils.toHideMouseInputInScript(true,window,this.name); if (!this.parentNode.onfocus) {return true;} this.onfocus=this.parentNode.onfocus; return this.fireEvent(\'onfocus\');" \n';
    }
    else
    {
      content += 'onfocus="if (!this.parentNode.onfocus) {this.onfocus=null; return true;} this.onfocus=this.parentNode.onfocus; return this.fireEvent(\'onfocus\');" \n';
      content += 'onblur="if (!this.parentNode.onblur) {this.onblur=null; return true;} this.onblur=this.parentNode.onblur; this.fireEvent(\'onblur\');"\n';
    }

    content += 'onchange="if (!this.parentNode.onchange) {this.onchange=null; return true;} this.onchange=new Function(this.parentNode.onchange); return this.fireEvent(\'onchange\');" \n';
    content += 'onselect="if (!this.parentNode.onselect) {this.onselect=null; return true;} this.onselect=new Function(this.parentNode.onselect); this.fireEvent(\'onselect\');"\n';
    if (mode != "search")
    {
      if (readOnlyProp) content += ' style="display:none;"';
      else content += ' style="display:expression(document.isEditMode?\'inline\':\'none\');"';
    }

    tmpVal = this.getItemProperty(fieldNd, 'display_length');
    if (tmpVal != '') content += '" size="'+tmpVal+'" ';
//      content += ' READONLY ';

    if (propNd)
    {
      if (readOnlyProp && mode != "search") content += ' DISABLED ';
      tmpVal = this.getItemProperty(propNd, 'stored_length');
      if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
    }

    tmpVal = this.getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1')
    {
      tmpVal = this.getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';
  }//if (mode.search(/^print$|^edit_form$|^view_form$/)==-1)
  
  content += '/>\n';
  
  // +++ draw elipsis
  if (!readOnlyProp || mode=="search")
  {
    content += '<img align="absmiddle" height="12" width="16" border="0" src="../images/Icons/other/12x16_elipsis.gif" style="';
    if (mode != 'edit_form' && mode != 'view_form')
    {
      content += 'display:expression(document.isEditMode?\'inline\':\'none\');';
    }
    content += 'cursor:hand;"/>\n';
  }
  // --- draw elipsis
  
  // +++ draw link
  if (mode != "search")
  {
    content += '<span style="';
    if (!readOnlyProp) content += 'display:expression(document.isEditMode?\'none\':\'inline\');';
    else content += 'display:inline;';
    
    if (mode != "print") content += 'color:blue;text-decoration:underline;cursor:hand;"></span>';
    else content += '"></span>';
  }
  // --- draw link
  
  content += '</span>';
  
  if (mode.search(/^print$|^edit_form$|^view_form$/)==-1)
  {
    content += onF2DownCode;
    content += userOnClickCode;
    content += userOnKeyDownCode;
    content += userOnChangeCode;
    content += userOnBlurCode;
  }
  
  if (propNm && mode != 'edit_form' && mode != 'view_form')
  {
    funcName = 'system_'+fieldID+'_value';
    content += '<script>\n';
    content += 'function '+funcName+'() { try{\n'+
      ' if (event.propertyName!="value") return true;\n'+
      ' var ctrlElem = event.srcElement;\n'+
      ' if (!ctrlElem) return true;\n'+
      ' var itemSpan=document.getElementById("'+fieldID+'");\n'+
      ' if (!itemSpan) return true;\n'+
      ' if (itemSpan.value==ctrlElem.value) return true;\n'+
      ' var val=ctrlElem.value;\n'+
      ' itemSpan.value=val;\n';
    if (mode != 'search') content +=
      ' if (val) {val=top.aras.getKeyedName(val,"'+DSName+'");\n}';
    if (mode != 'print') content +=
      ' var input=itemSpan.all.tags("input");\n'+
      ' if (input) input=input(0);\n'+
      ' if (input) input.value=val;\n';
    content +=
      ' if (itemSpan.all.tags("span")(0)) itemSpan.all.tags("span")(0).innerHTML=top.aras.preserveTags(val);\n'+
      ' return true;\n'+
      '} catch(excep) {} }\n';
    content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';
    content += '</script>';
  }

  if (hasDataSource)
  {
    var checkFunctionName = 'Checks' + fieldID;
    
    var checksFunctionCode = ' var dS = "' + DSName + '";' +
    ' var inputElement = document.getElementsByName(name).item(0);' + 
    ' var oldInputValue = inputElement.value;' +
    ' var val=top.aras.uiGetItemByKeyedName(dS, oldInputValue);' + 
    ' inputElement.onchange=new Function(inputElement.parentNode.onchange); var res = inputElement.fireEvent("onchange");' + 
    ' if (!val && oldInputValue != "" && res == true) return false; ' + 
    ' else return true;';
    
    content += '<script>\n' + 
    ' function startHook() {\n' + 
    ' inputsArray.push("' + fieldNm + '");\n' + 
    ' var methodCode = \'' + checksFunctionCode + '\';\n' + 
    ' top.aras.utils.StartHookingMouseInputInScript(false,window,"' + fieldNm + '", new Function("name",methodCode));\n}\n' + 
    ' document.attachEvent("onload",startHook);\n</script>';
  }
  
  return content;
}

Aras.prototype.uiDrawFieldFileItemEx = function (fieldNd, propNd, mode)
{
  var content = '';
  with (this)
  {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content += '<span id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';
    var tmpVal;
    var DSName = '';
    var funcName;

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1)
    {
      var userOnClick = '';
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick');
      }
      
      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') 
      {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      if (propNd && propNm)
      {
        var DS = propNd.selectSingleNode('data_source');
        if (DS) DSName = DS.getAttribute('name');
        if (DSName)
        {
          content += ''+
          'var elem=event.srcElement;\n'+
          'var tgName=elem.tagName;\n'+
          'var tgName2=elem.name;\n'+
          'if (tgName==\'SPAN\' && tgName2==\'view\') {\n'+
          '  var itm=top.aras.getItemById(\''+DSName+'\',document.getElementById(\''+propNm+'_system\').value,0);\n'+
          '  if (itm) top.aras.uiShowItemEx(itm,undefined,true);\n'+
          '}\n'+
          'else if (tgName==\'INPUT\' || tgName2==\'Add\') {\n'+
          '  var input=((tgName==\'INPUT\') ? elem : elem.parentNode.all.tags(\'input\')(0));\n'+
          '  var fileName = top.aras.vault.selectFile();\n'+
          '  if (!fileName) return;\n'+
          '  var parts = fileName.split(\'\\'+'\\'+'\');\n'+
          '  var brief_fileName = parts[parts.length-1];\n'+
          '  elem.value = brief_fileName;\n'+
          ' top.addNewFile = function(fileName) {\n'+
          '    fileName = fileName.replace(/~/g,\'\\'+'\\'+'\');\n'+
          '    var res=top.aras.newItem(\'File\',fileName);\n'+
          '   if (res) {\n'+
          '      if (window.handleItemChange) handleItemChange(\''+propNm+'\',res);\n'+
          '      if (top.updateMenuState) top.updateMenuState();\n'+
          '      input.fireEvent(\'onchange\');\n'+
          '    }\n'+
          '  }\n'+
          '  var cmd = \'top.addNewFile(\\'+'\'\'+fileName.replace(/\\'+'\\/g,\'~\')+\''+'\\'+'\')\';\n'+
          '  setTimeout(cmd,1);\n'+
          '}\n'+
          'else if (tgName==\'IMG\' && tgName2==\'ScanIn\') {\n'+
          '  var url=top.aras.getScriptsURL()+\'ScanWizard/scanwizardframeset.html\';\n'+
          '  var vals=new Array(top.aras.vault.getWorkingDir());\n'+
          '  var features=\'dialogHeight:370px;dialogWidth:500px;status:no;help:no;scroll:no;\';\n'+
          '  var filename = showModalDialog(url, vals, features);\n'+
          ' if (filename) {\n'+
          '    var res=top.aras.newFileItem(filename);\n'+
          '  if (res) {\n'+
          '      if (window.handleItemChange) handleItemChange(\''+propNm+'\',res);\n'+
          '      if (top.isTearOff && top.updateMenuState) top.updateMenuState();\n'+
          '      input.fireEvent(\'onchange\');\n'+
          '    }\n'+
          '  }\n'+
          '}\n'+
          'else if (tgName==\'IMG\' && tgName2==\'CheckOut\') {\n'+
          '  var fileId = document.getElementById(\''+propNm+'_system\').value;\n'+
          '  if (!fileId) {top.aras.AlertError(\'The file was not specified.\'); return true;}\n'+
          '  var fileNd=document.item.selectSingleNode(\''+propNm+'/Item\');\n'+
          '  if (!fileNd) fileNd=top.aras.getItemById(\'File\',fileId,0);\n'+ // Change this to use granular query
          '  if (!fileNd) {top.aras.AlertError(\'Failed to get the file.\'); return true;}\n'+
          '  if (top.aras.isTempEx(fileNd)) {top.aras.AlertError(\'Failed to save the file.\'); return true;}\n'+
          '  var res=false;\n'+
          '  if (!top.aras.isLockedByUser(fileNd)) res=top.aras.lockItemEx(fileNd, top.aras.getWorkingDir(true, window));\n'+
          '  else res=true;\n'+
          '  if (!res) return true;\n'+
          '' +//success ui changes:
          '  top.aras.uiPopulateFormWithItemEx(document.forms.MainDataForm, document.item, document.itemType, isEditMode);\n'+
          '  if (top.updateMenuState) top.updateMenuState();\n'+
          '  if (top.opener)\n'+
          '    top.opener.main.work.updateRow(document.item);\n'+
          '}\n'+
          'else if (tgName==\'IMG\' && tgName2==\'CheckIn\') {\n'+
          '  if (!top.aras.isLockedByUser(document.item)) {top.aras.AlertError(\'To checkout the file you need to first lock the item to which it is attached.\'); return true;}\n'+
          '  var fileId = document.getElementById(\''+propNm+'_system\').value;\n'+
          '  if (!fileId) {top.aras.AlertError(\'The file was not specified.\'); return true;}\n'+
          '  var fileNd=document.item.selectSingleNode(\''+propNm+'/Item\');\n'+
          ' if (!fileNd) {\n'+
          '    fileNd=top.aras.getItemById(\'File\',fileId,0);\n'+ // Change this to use granular query
          '    document.item.selectSingleNode(\''+propNm+'\').text=\'\';\n'+
          '    document.item.selectSingleNode(\''+propNm+'\').appendChild(fileNd);\n'+
          '  }\n'+
          '  if (!fileNd) {top.aras.AlertError(\'Failed to get the file.\'); return true;}\n'+
          '  if (!top.aras.isLockedByUser(fileNd)) {top.aras.AlertError(\'The file could not be checked in because it is not locked by you.\'); return true;}\n'+
          '  var res=false;\n'+
          '  if (top.aras.getItemProperty(document.item,\'new_version\')==\'0\' '+
             '&& confirm(document.itemTypeName+\' \'+top.aras.getKeyedNameEx(document.item)+\' needs to be saved. Save it ?\')) {\n'+
          '    var newVer=top.aras.saveItemEx(document.item);\n'+
          '  if (newVer) {\n'+
          '      if (top.updateItemsGrid) top.updateItemsGrid(newVer);\n'+
          '      top.aras.uiReShowItemEx(document.itemID, newVer);\n'+
          '    }\n'+
          '  }\n'+
          ' else {\n'+
          '    var res = top.aras.checkinFile(fileNd, window);\n'+
          '    top.aras.uiPopulateFormWithItemEx(document.forms.MainDataForm, document.item, document.itemType, isEditMode);\n'+
          '    if (top.updateMenuState) top.updateMenuState();\n'+
          '    if (top.opener) \n'+
          '      top.opener.main.work.updateRow(document.item);\n'+
          '    if (res) top.aras.AlertSuccess(\'Checkin completed.\');\n'+
          '    else top.aras.AlertError(\'Checkin not completed.\');\n'+
          '  }\n'+
          '}\n'+
          'else if (tgName==\'IMG\' && tgName2==\'ClearFileProp\') {\n'+
          '  var doSetNull = confirm(\'Do you want to clear the file field?\');\n'+
          '  if (doSetNull)\n'+
          '  {\n'+
          '    var i = document.item;\n'+
          '    var fileNd = i.selectSingleNode(\'' + propNm + '/Item\');\n'+
          '    if (window.handleItemChange) handleItemChange(\''+propNm+'\', \'\');\n'+
          '    var input = elem.parentNode.all.tags(\'input\')(0);\n'+
          '    var files = i.selectNodes(\'//Item[@type=&quot;File&quot; and @isDirty=&quot;1&quot;]\');' +
          '    for (var j = 0; j < files.length; j++)' +
          '      top.aras.removeFromCache(files[j]);\n' +
          '    if (input) {input.fireEvent(\'onchange\');}\n'+
          '    if (top.updateMenuState) top.updateMenuState();\n'+
          '    if (fileNd && top.aras.isTempEx(fileNd))\n'+
          '      top.aras.removeFromCache(fileNd);\n'+
          '  }\n'+
          '}\n';
        }
      }

      if (method_code != 'return true;') content += '}';
      content += '">';

      content += '<span style="display:expression(document.isEditMode ? \'inline\':\'none\');">';
      content += '<script>var system_CoreShowScanButtonForFile = null;';
      content += ' function system_SetCoreShowScanButtonForFileVariable(){';
      content += '  if (system_CoreShowScanButtonForFile === null && !top.aras)';
      content += '   setTimeout(\'system_SetCoreShowScanButtonForFileVariable()\', 30);';
      content += '  else ';
      content += '   system_CoreShowScanButtonForFile = top.aras.getVariable(\'ShowScanButtonForFile\');';
      content += ' }';
      content += ' system_SetCoreShowScanButtonForFileVariable();</script>';      
      content += '<img name="ClearFileProp" src="../images/icons/16x16/16x16_delete.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;'+ (propNm ? 'display:expression(document.getElementById(\''+propNm+'_system\').value ? \'inline\':\'none\')': '\'inline\'') + '" '+
      'alt="Clear File Property" />&nbsp;';
      content += '<img name="ScanIn" src="../images/icons/16x16/16x16_scan.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;display:expression(system_CoreShowScanButtonForFile===\'0\' ? \'none\':\'inline\')" '+
      'alt="Scan in File" />&nbsp;';
      content += '<img name="Add" src="../cbin/icons/20x20edit.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;display:expression(document.isTemp ? \'inline\':\'none\')" '+
      'alt="Add File" />&nbsp;';

      content += '<img name="CheckOut" src="../images/Icons/16x16/16x16_checkout.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;display:none;" '+
      'alt="Check Out File" />&nbsp;';

      content += '<img name="CheckIn" src="../images/Icons/16x16/16x16_checkin.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;display:none;" '+
      'alt="Check In File" />&nbsp;';

      content += '<input type="text" style="cursor:hand;" ';
        content += ' onchange="if (!this.parentNode.parentNode.onchange) {this.onchange=null; return true;} this.onchange=new Function(this.parentNode.parentNode.onchange); this.fireEvent(\'onchange\');" ';
      content += ' onfocus="if (!this.parentNode.parentNode.onfocus) {this.onfocus=null; return true;} this.onfocus=this.parentNode.parentNode.onfocus; this.fireEvent(\'onfocus\');" ';
      content += ' onselect="if (!this.parentNode.parentNode.onselect) {this.onselect=null; return true;} this.onselect=new Function(this.parentNode.parentNode.onselect); this.fireEvent(\'onselect\');" ';
      tmpVal = getItemProperty(fieldNd, 'display_length');
      if (tmpVal != '') content += '" size="'+tmpVal+'" ';
      content += ' READONLY ';

      var readonly = uiIsFieldReadOnly(fieldNd, propNd);
      if (propNd)
      {
        if (readonly && mode != "search") content += ' DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      tmpVal = getItemProperty(fieldNd, 'tab_stop');
      if (tmpVal == '1')
      {
        tmpVal = getItemProperty(fieldNd, 'tab_index');
        if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
      }
      else content += ' tabindex="-1"';
      content += '/></span>';
    }//if (mode.search(/^print$|^edit_form$|^view_form$/)==-1)
    else if (mode == 'edit_form' || mode == 'view_form')
    {
      content += '><span>';
      content += '<img name="ClearFileProp" src="../images/icons/16x16/16x16_delete.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;" '+
      'alt="Clear File Property" />&nbsp;';
      content += '<img name="ScanIn" src="../images/icons/16x16/16x16_scan.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;" '+
      'alt="Scan in File" />&nbsp;';
      content += '<img name="Add" src="../cbin/icons/20x20edit.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;" alt="Add File" />&nbsp;';
      content += '<img name="CheckOut" src="../images/Icons/16x16/16x16_checkout.gif" align="absmiddle" '+
      'style="cursor:hand;clear:none;float:none;" alt="Check Out File" />&nbsp;';

      content += '<input type="text" style="cursor:hand;" ';
      tmpVal = getItemProperty(fieldNd, 'display_length');
      if (tmpVal != '') content += '" size="'+tmpVal+'" ';
      content += ' READONLY ';

      if (propNd)
      {
        if (getItemProperty(propNd, 'readonly') == '1' && mode != "search") content += 'DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      tmpVal = getItemProperty(fieldNd, 'tab_stop');
      if (tmpVal == '1')
      {
        tmpVal = getItemProperty(fieldNd, 'tab_index');
        if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
      }
      else content += ' tabindex="-1"';
      content += '/></span>';
    }
    else content += '>';

    if (mode != 'edit_form' && mode != 'view_form')
    {
      content +=
      '<span id="view" name="view" style="text-decoration:underline;color:blue;cursor:hand;display:expression(document.isEditMode ? \'none\':\'inline\');">'+
      '</span>';
    }
    content += '</span>';

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) content += userOnClick;

    if (propNm && mode != 'edit_form' && mode != 'view_form')
    {
      funcName = 'system_'+fieldID+'_value';
      content += '<script>';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var itemSpan=document.getElementById("'+fieldID+'");\n'+
        ' if (!itemSpan) return true;\n'+
        ' if (itemSpan.value==ctrlElem.value) return true;\n'+
        ' var val="", fileID=ctrlElem.value, fileNd=null;\n'+
        ' itemSpan.value=fileID;\n'+
        ' if (fileID) {\n'+
        '  fileNd=top.aras.getItemFromServer("File", fileID,"keyed_name,locked_by_id").node;\n'+
        '  if (!fileNd) fileNd=document.item.selectSingleNode("'+propNm+'/Item")\n'+
        '  if (fileNd) val=top.aras.getKeyedNameEx(fileNd); else val="";\n'+
        ' }\n';
      
      if (mode != "print")
      {
        content +=
          ' var input=itemSpan.all.tags("input");\n'+
          ' if (input) {\n'+
          '  input=input(0);\n'+
          '  input.value=val;'+
          ' }\n'+
          ' if (fileNd) {\n'+
          '  var locked_by_id = top.aras.getItemProperty(fileNd, "locked_by_id");\n'+
          '  var isNewFile = top.aras.isTempEx(fileNd);\n'+
          '  if (locked_by_id==top.aras.getCurrentUserID()) {\n'+
          '   itemSpan.all("CheckOut").style.display = "none";\n'+
          '   itemSpan.all("CheckIn").style.display = "inline";\n'+
          '  }\n'+
          '  else if (locked_by_id=="" && !isNewFile) {\n'+
          '   itemSpan.all("CheckOut").style.display = "inline";\n'+
          '   itemSpan.all("CheckIn").style.display = "none";\n'+
          '  }\n'+
          '  else {\n'+
          '   itemSpan.all("CheckOut").style.display = "none";\n'+
          '   itemSpan.all("CheckIn").style.display = "none";\n'+
          '  }\n'+
          ' }\n'+
          ' else {\n'+
          '  itemSpan.all("CheckOut").style.display = "none";\n'+
          '  itemSpan.all("CheckIn").style.display = "none";\n'+
          ' }\n';
      }
      
      content +=
        ' itemSpan.all("view").innerHTML=top.aras.preserveTags(val);\n'+
        ' return true;\n'+
        '}';
      content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      content += '</script>';
    }
  }
  return content;
}

Aras.prototype.uiDrawFieldImageEx = function (fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content += '<span id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" ';
    var tmpVal;
    var funcName;
    if (propNd) if (getItemProperty(propNd, 'readonly') == '1' && mode != "search") content += ' DISABLED ';
    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      var userOnClick = '';
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick, onchange');
      }

      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') 
      {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      if (propNd && propNm) {
        content += 'if (!document.isEditMode) return true;'+
        'var params = new Object();'+
        'params.aras=top.aras;'+
        'params.image=document.getElementById(\''+propNm+'_system\').value;'+
        'var newImg=top.showModalDialog(top.aras.getScriptsURL()+\'ImageBrowser/imageBrowser.html\',params,\'dialogHeight: 450px; dialogWidth: 700px; status:0; help:0; resizable:1\');'+
        'if (newImg && window.handleItemChange) {if(newImg==\'set_nothing\')newImg=\'\'; handleItemChange(\''+propNm+'\',newImg);}';
      }

      if (method_code != 'return true;') content += '}';
      content += '">';
    }
    else content += '>';

    if (mode=='edit_form' || mode == 'view_form') {
      content += '<span style="cursor:hand;color:blue;text-decoration:underline;">Select an image...</span><br>';
      content += '<img style="cursor:hand;" src="../cbin/icons/image.gif"/>';
    }
    else {
      content += '<span style="cursor:hand;color:blue;text-decoration:underline;display:expression(document.isEditMode ? \'inline\':\'none\');">Select an image...</span><br>';
      content += '<img style="cursor:expression(document.isEditMode ? \'hand\':\'default\');display:none;"/>';
    }

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) content += userOnClick;

    if (propNm && mode != 'edit_form' && mode != 'view_form') {
      funcName = 'system_'+fieldID+'_value';
      content += '<script >';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var itemSpan=document.getElementById("'+fieldID+'");\n'+
        ' if (!itemSpan) return true;\n'+
        ' if (itemSpan.value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' itemSpan.value=val;\n'+
        ' var img=itemSpan.all.tags("img")(0);\n'+
        ' if (!val) {\n'+
        '  img.style.display="none";\n'+
        '  img.src="";\n'+
        ' }\n'+
        ' else {\n'+
        '  img.style.display="inline";\n'+
        '  img.src=val;\n'+
        ' }\n'+
        ' return true;\n'+
        '}';
      content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      
      //+++ onchange field event
      var method_code = getEventHandlerCode(fieldNd, "onchange", true,'return true;');
      
      if (method_code != 'return true;') {
        funcName = 'user_'+fieldID+'_onchange';
        content += 'function '+funcName+'() {\n'+
            'if (event.propertyName!="value") return true;\n'+
            method_code + '\n'+
          '}\n';
        content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      //--- onchange field event
      }      
      content += '</script>';
    }
  }
  return content;
}

Aras.prototype.uiDrawFieldColorEx = function (fieldNd, propNd, mode, itemTypeNd) {
//itemTypeNd is required for bg_color of Body item type Only
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    if (mode=='print') content += '<span ';
    else content += '<input type="text" ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" style="cursor:hand;';

    var tmpVal = getItemProperty(fieldNd, 'display_length');
    if (tmpVal=='') {
    /*
      tmpVal = '100%';
      if (getItemProperty(fieldNd, 'width') == '') tmpVal = '*';
      content += 'width:'+tmpVal+'; ';
      tmpVal = '100%';
      if (getItemProperty(fieldNd, 'height') == '') tmpVal = '*';
      content += 'height:'+tmpVal+'; ';*/
      content += '" ';
    }
    else content += '" size="'+tmpVal+'" ';
    content += ' READONLY ';

    var userOnClick = '';
    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (propNd) {
        tmpVal = getItemProperty(propNd, 'readonly');
        if (tmpVal == '1' && mode != "search") content += ' DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick');
      }
      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      var allowComboParam = 'false';
      if (propNm=='bg_color')
      {
        if (itemTypeNd && getItemProperty(itemTypeNd, 'name')=='Body') allowComboParam = 'true';
      }
      if (propNm) {
        content += 'if (!document.isEditMode) return true;'+
        'var appl=null;'+
        'if (top.main && top.main.menu) appl=top.main.menu;'+
        'else if (top.tearoff_menu) appl=top.tearoff_menu;'+
        'if (!appl) return true;'+
        'var input=event.srcElement;'+
        'var currVal=document.getElementById(\''+propNm+'_system\').value;'+
        'var ca = appl.document.applets.colorApplet;'+
        'var c = (ca && ca.object) ? ca.getColor(currVal, '+allowComboParam+') : null;'+
        'if (c && window.handleItemChange) {'+
        ' handleItemChange(\''+propNm+'\', c);'+
        ' if (currVal!=c) input.fireEvent(\'onchange\');'+
        '}';
      }

      if (method_code != 'return true;') content += '}';
      content += '" ';
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode=='print') content += '></span>';
    else content += '/>';

    if (mode != 'edit_form' && mode != 'view_form') {
      var funcName = 'system_'+fieldID+'_value';
      content += '<script>';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var input=document.getElementById("'+fieldID+'");\n'+
        ' if (!input) return true;\n'+
        ' if (input.i_value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' input.i_value=val;\n'+
        ' var bgc = (val && val.substring(0,1)!=\'#\') ? \'buttonface\' : val;\n'+
        ' try {\n'+
        '  input.style.backgroundColor=bgc;\n'+
        ' }\n'+
        ' catch (excep) {\n'+
        ' }\n'+
        ' input.style.width="130px";\n'+
        ' return true;\n'+
        '}';
      if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      content += '</script>';
    }
  if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) content += userOnClick;
  }

  return content;
}

Aras.prototype.uiDrawFieldFormattedTextEx = function(fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    content += '<table border="0" cellpadding="0" cellspacing="0" cols="1"><tr><td>'+
    '<span id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" '+
    'style="word-wrap:break-word;display:block;width:expression(this.parentNode.all(\'template\').offsetWidth);height:expression(this.parentNode.all(\'template\').offsetHeight);border-style:inset;border-width:2px;padding:2px;overflow:auto;cursor:hand;" ';
    var tmpVal;

    var userOnClick = '';
    var readOnlyProp = uiIsFieldReadOnly(fieldNd, propNd);

    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick, onchange');
      }
      //+++ onclick event
      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {\n';
      }

      if (propNm && !readOnlyProp) {
        content += 'if (!document.isEditMode) return true;\n'+
        'var spanElem = document.getElementById(\''+fieldID+'\');\n'+
        'if (spanElem.value==undefined) spanElem.value=\'\';\n'+
        'var currVal = spanElem.value;\n'+
        'var param=new Object();\n'+
        'param.sHTML=currVal;\n'+
        'param.aras=top.aras;\n'+
        'var newCont = top.showModalDialog(top.aras.getScriptsURL()+\'HTMLEditorDialog.html\',param,\'status:0; help:0; resizable:yes; dialogHeight:500px; dialogWidth:820px \');\n'+
        'if (newCont==undefined) return true;\n'+
        'if (window.handleItemChange) handleItemChange(\''+propNm+'\', newCont);\n';
      }

      if (method_code != 'return true;') content += '}\n';
      content += '" ';
      //--- onclick event
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    content += '></span>';
    
    content += userOnClick;
    
    if (mode != 'edit_form' && mode != 'view_form') {
      var funcName = 'system_'+fieldID+'_value';
      content += '<script>\n';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var spanElem=document.getElementById("'+fieldID+'");\n'+
        ' if (!spanElem) return true;\n'+
        ' if (spanElem.value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' spanElem.value=val;\n'+
        ' spanElem.innerHTML=val;\n';

      //field event "onChange" corresponds to checkbox event "onpropertychange"
      var onchange = fieldNd.selectSingleNode('Relationships/Item[@type="Field Event" and ./field_event="onchange" and '+
        './related_id/Item/@type="Method" and ./related_id/Item/method_code!=""]');
      if (onchange) 
      {
        var method_code = getItemProperty(onchange.selectSingleNode('related_id/Item[@type="Method"]'), 'method_code');
        content += prepareEventHandlerCode(method_code, false);
      }
      
      content += ' return true;\n'+
        '}\n';
      if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');\n';
      content += '</script>\n';
    }

  content += '<textarea id="template" style="position:absolute;top:0px;left:0px;visibility:hidden;overflow:auto;" ';  
  tmpVal = top.aras.getItemProperty(fieldNd, 'textarea_rows');
  if (tmpVal != '') content += 'rows="'+tmpVal+'" ';
  tmpVal = top.aras.getItemProperty(fieldNd, 'textarea_cols');
  if (tmpVal != '') content += 'cols="'+tmpVal+'" ';
  content += '></textarea></tr></td></table>';

  }

  return content;
}

Aras.prototype.uiDrawFieldClassStructureEx = function(fieldNd, propNd, mode, itemTypeNd)
{
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');
    
    var class_structure = null;
    
    if (mode=='print') content += '<span ';
    else content += '<input type="text" ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" style="cursor:hand;';

    var tmpVal = getItemProperty(fieldNd, 'display_length');
    if (tmpVal=='') {
      content += '" ';
    }
    else content += '" size="'+tmpVal+'" ';
    content += ' READONLY ';

    var userOnClick = '';
    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (propNd) {
        tmpVal = getItemProperty(propNd, 'readonly');
        if (tmpVal == '1' && mode != "search") content += ' DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick');
      }
      content += ' onclick="';
      var method_code = getEventHandlerCode(fieldNd, "onclick", true,'return true;');
      
      if (method_code != 'return true;') {
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      if (propNm)
      {
        var itName = getItemProperty(itemTypeNd, 'name');
        class_structure = getItemProperty(itemTypeNd, 'class_structure');
        if (class_structure == '') class_structure = "<class name='"+itName+"'/>";

        var correctModeClause = '((!top.aras.isTempEx(document.item) && \'' + mode + '\'==\'add\') ? \'edit\' : ((\'' + mode + '\'==\'add\') ? \'add\' : \'edit\'))';
        content +=
        'if (!document.isEditMode) return;'+
        'var input=event.srcElement;'+
        'var currVal=document.getElementById(\''+propNm+'_system\').value;'+
        'var param=new Object();'+
        'param.title=\''+propNm+'\';'+
        'param.isEditMode=true;'+
        'param.aras=top.aras;'+
        'param.class_structure=getClassStructure$'+ fieldID +'();'+
        'param.dialogType=\'classification\';'+
        'param.selectLeafOnly=true;'+
        'var res=showModalDialog(top.aras.getScriptsURL()+\'ClassStructureDialog.html\',param,\'help:0;resizable:1;status:0;\');'+
        'if (document.isEditMode && res!=undefined && window.handleItemChange) {'+
        ' var f1 = (document.formID) ? document.formID : top.aras.uiGetFormID4ItemEx(document.item, '+(mode!='edit_form' ? correctModeClause : '\'edit\'') + ');'+
        ' handleItemChange(\''+propNm+'\',res);'+
        ' var newVal=document.getElementById(\''+propNm+'_system\').value;'+
        ' if (newVal!=currVal) input.fireEvent(\'onchange\');'+
        ' var f2 = top.aras.uiGetFormID4ItemEx(document.item, '+(mode!='edit_form' ? correctModeClause : '\'edit\'') + ');'+
        ' if (currVal!=res && f1!=f2) top.aras.uiShowItemInFrameEx(parent.frames[\'instance\'],document.item,'+correctModeClause+');'+
        '}';

      }

      if (method_code != 'return true;') content += '}';
      content += '" ';
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode=='print') content += '></span>';
    else content += '/>';
    
    content += userOnClick;
    
    if (mode != 'edit_form' && mode != 'view_form') {
      var funcName = 'system_'+fieldID+'_value';
      content += '<script>';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var input=document.getElementById("'+fieldID+'");\n'+
        ' if (!input) return true;\n'+
        ' if (input.i_value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' input.title=val;\n'+
        ' input.i_value=val;\n'+
        ' val=val.split("/");\n'+
        ' val=val.pop();\n'+
        ' input.value=val;\n'+
        (propNm == 'classification' ? ' if (parent.relationships && parent.relationships.try2RefreshParametersTab) try{parent.relationships.try2RefreshParametersTab();}catch (excep) {}\n' : '')+
        ' var relTabBar = (parent.relationships) ? parent.relationships.tabbarApplet : null;\n'+
        ' var isParamTabVisible = top.aras.uiIsParamTabVisible(parent.item);\n'+
        (propNm == 'classification' ? ' if (relTabBar) relTabBar.setTabVisible("Parameters", isParamTabVisible);\n' : '')+
        (propNm == 'classification' ? ' if (relTabBar && isParamTabVisible) { var firstTabID = parent.relationships.getFirstEnabledTabID(true); \n' : '')+
        (propNm == 'classification' ? '   if (!firstTabID) {parent.relationships.currTabID = ""; relTabBar.selectTab("Parameters");}}\n' : '')+
        ' return true;\n'+
        '}';
      if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      content += '</script>';
    }
  }
  
  if (class_structure != null)
  {
    class_structure = class_structure.replace(/\\/g, '\\\\').replace(/'/g, '\\\'');
    content += '<scr' + 'ipt>\n';
    content += 'function getClassStructure$'+ fieldID +'()\n';
    content += '{\n';
    content += '  return \''+ class_structure +'\';\n';
    content += '}\n';
    content += '</script>\n';
  }
  
  return content;
}

/*
Aras.prototype.uiDrawFieldCurrentStateEx = function Aras_uiDrawFieldCurrentStateEx(fieldNd, propNd, mode) {
  var content = '';
  with (this) {
    var fieldID = fieldNd.getAttribute('id');
    var fieldNm = getItemProperty(fieldNd, 'name');
    var propNm  = '';
    if (propNd) propNm = getItemProperty(propNd, 'name');

    if (mode=='print') content += '<span ';
    else content += '<input type="text" ';

    content += ' id="'+fieldID+'" name="'+fieldNm+'" class="'+fieldNm+'" style="cursor:hand;';

    var tmpVal = getItemProperty(fieldNd, 'display_length');
    if (tmpVal=='') {
      content += '" ';
    }
    else content += '" size="'+tmpVal+'" ';
    content += ' READONLY ';

    var userOnClick = '';
    if (mode.search(/^print$|^edit_form$|^view_form$/)==-1) {
      if (propNd) {
        tmpVal = getItemProperty(propNd, 'readonly');
        if (tmpVal == '1') content += ' DISABLED ';
        tmpVal = getItemProperty(propNd, 'stored_length');
        if (tmpVal != '') content += ' maxlength="'+tmpVal+'" ';
      }

      if (mode != "search")
      {
        content += assignFieldEventEx(fieldNd, 'onclick');
      }

      var onclick = fieldNd.selectSingleNode('Relationships/Item[@type="Field Event" and ./field_event="onclick" and '+
        './related_id/Item/@type="Method" and ./related_id/Item/method_code!=""]');
      content += ' onclick="';

      if (onclick) {
        var method_code = getItemProperty(onclick.selectSingleNode('related_id/Item[@type="Method"]'), 'method_code');
        funcName = 'user_'+fieldID+'_onclick';
        userOnClick = '<script>function '+funcName+'() {\n'+method_code+'\n}\n</script>';
        content += 'var ures='+funcName+'(); if (ures) {';
      }

      if (propNm) {
        content += 'if (!document.isEditMode) return true;'+
        'var input=event.srcElement;'+
        'var currVal=document.getElementById(\''+propNm+'_system\').value;'+
        'var params=new Object();'+
        'params.aras=top.aras;'+
        'params.item=document.item;'+
        'var res=showModalDialog(top.aras.getScriptsURL()+\'LifeCycle/LifeCycleDialog.html\',params,\'help:0;resizable:1;status:0;\');'+
        'if (res && window.handleItemChange) {'+
        ' handleItemChange(\''+propNm+'\',res);'+
        ' if (currVal!=res) input.fireEvent(\'onchange\');'+
        '}';

      }

      if (onclick) content += '}';
      content += '" ';
    }

    tmpVal = getItemProperty(fieldNd, 'tab_stop');
    if (tmpVal == '1') {
      tmpVal = getItemProperty(fieldNd, 'tab_index');
      if (tmpVal != '') content += ' tabindex="'+tmpVal+'"';
    }
    else content += ' tabindex="-1"';

    if (mode=='print') content += '></span>';
    else content += '/>';

    if (mode != 'edit_form' && mode != 'view_form') {
      var funcName = 'system_'+fieldID+'_value';
      content += '<script>';
      content += 'function '+funcName+'() {\n'+
        ' if (event.propertyName!="value") return true;\n'+
        ' var ctrlElem = event.srcElement;\n'+
        ' if (!ctrlElem) return true;\n'+
        ' var input=document.getElementById("'+fieldID+'");\n'+
        ' if (!input) return true;\n'+
        ' if (input.i_value==ctrlElem.value) return true;\n'+
        ' var val=ctrlElem.value;\n'+
        ' input.i_value=val;\n'+
        ' input.value=top.aras.getKeyedName(val,\'Life Cycle State\');\n'+
        ' return true;\n'+
        '}';
      if (propNm) content += 'document.getElementById("'+propNm+'_system").attachEvent("onpropertychange", '+funcName+');';
      content += '</script>';
    }
  }

  return content;
}
*/

/*
* assignFormEventEx
*
*/
Aras.prototype.assignFormEventEx = function(formNd) {
  if (!formNd) return '';

  var events = formNd.selectNodes('Relationships/Item[@type="Form Event" and ./form_event!="" and '+
    './related_id/Item/@type="Method" and ./related_id/Item/method_code!=""]');
  var event, eventName, method_code;
  var eventsRes = new Object();
   var content =
  "<script type=\"text/javascript\">\n";
  var functionNames = new Array();
  var functionNumber = new Array();
  for (var i=0; i<events.length; i++) {
    event = events[i];
    eventName = this.getItemProperty(event, 'form_event').toLowerCase();
    if (eventsRes[eventName] === undefined) eventsRes[eventName] = "";

    method_code = this.getItemProperty(event.selectSingleNode('related_id/Item[@type="Method"]'), 'method_code');
    eventsRes[eventName] = method_code + "\n";

    if (functionNumber[eventName] == undefined)
      functionNumber[eventName]=1;
    else
      functionNumber[eventName]++;

    content +=
      "function " + eventName + functionNumber[eventName] + "() {\n" +
        method_code +
      "\n}\n";
      
    if (functionNames[eventName] == undefined)  
      functionNames[eventName] = eventName + functionNumber[eventName] + ",";
    else
      functionNames[eventName] += eventName + functionNumber[eventName] + ",";
      
  }

  for (eventName in eventsRes) {
    content +=
      "function " + eventName + "$user$handler () {\n";
    
    var functionNameArray = functionNames[eventName].split(',');
    
    content += "try {\n"
    for (var i=0; i<functionNumber[eventName]; i++)
    {
        content += "if (" + functionNameArray[i] + "() === false)\n" + 
          "  return false;\n";
    }
    
    content += "} catch(exp) { \n top.aras.AlertError('Internal Error: event handler failed.','Event handler failed with message:'+exp.description, 'Client Side Error');\n" + 
         "return false;}";
    content += "\n}\n";
  }
  
  content +=
  "with (document) {\n";

  for (eventName in eventsRes) content += eventName + " = " + eventName + "$user$handler;\n"

  content +=
  "}\n" +
  "</script>\n";

  return content;
}//assignFormEventEx

Aras.prototype.getEventHandlerCode = function Aras_getEventHandlerCode(fieldNode, eventName, useAsAttributeValue, defaultReturnStmt)
{
  /* for internal use only */
  if (defaultReturnStmt === undefined) defaultReturnStmt = "";
  defaultReturnStmt = this.prepareEventHandlerCode(defaultReturnStmt, useAsAttributeValue)
  
  var addToContent;  
  var eventNodes = fieldNode.selectNodes('Relationships/Item[@type="Field Event" and ./field_event="' + eventName + '" and '+
            './related_id/Item/@type="Method" and ./related_id/Item/method_code!=""]');
  
  if (!eventNodes.length) return defaultReturnStmt;
  addToContent = "try{\n";
  for (var i=0; i<eventNodes.length; i++)
  {
    var functionName = "func" + "$" + fieldNode.getAttribute('id') + '$_' +eventName+ functionsCount;
    functionsCount++;          
    var method_code = this.getItemProperty(eventNodes[i].selectSingleNode('related_id/Item[@type="Method"]'), 'method_code');  
    method_code = this.prepareEventHandlerCode(method_code, false);
    var newFunction = "function " + functionName + "(){\n" + method_code + "\n}\n"; 
    allFieldsEventsfunctions.push(newFunction);
    addToContent += "if(" +functionName + "()===false) return false;\n";    
  }

  addToContent += "} catch(exp){top.aras.AlertError('Internal Error: event handler failed.','Event handler failed with message:'+exp.description, 'Client Side Error');return false;}\n";
  addToContent += defaultReturnStmt + "\n";
  return addToContent;
}

Aras.prototype.prepareEventHandlerCode = function Aras_prepareEventHandlerCode(jsCode, useAsAttributeValue)
{
  /* for internal use only */
  /* replace "this" with "srcElement". Escape & and " if required. */
  
  var this_re = /(^|\W)this(\W|$)/mg;
  function srcElement(p1, p2, p3, p4, p5) {return p2 + "srcElement" + p3;}

  var res = "var srcElement=window.event.srcElement;\n" + jsCode.replace(this_re, srcElement).replace(this_re, srcElement);
  if (useAsAttributeValue) res = res.replace(/&/g,"&amp;").replace(/"/g, "&quot;");
  
  return res;
}

var allFieldEventsNames = new Array();
var allFieldsEventsfunctions = new Array();
var functionsCount=0;

Aras.prototype.assignFieldEventEx = function (fieldNd, skipEvents)
{
  var content = '';
  if (skipEvents==undefined) skipEvents = '';

  var events = fieldNd.selectNodes('Relationships/Item[@type="Field Event" and ./field_event!="" and '+
    './related_id/Item/@type="Method" and ./related_id/Item/method_code!=""]');
  var event, eventName, method_code;
  var addToContent = new Array();
  var tempArr = new Array();
  var count=0;
  for (var i=0; i<events.length; i++) with (this)
  {
    event = events[i];
    eventName = getItemProperty(event, 'field_event').toLowerCase();
    if (skipEvents.search(eventName) != -1) continue;
    var functionName = "func" + "$" + fieldNd.getAttribute('id') + '$_' +eventName+ functionsCount;
    functionsCount++;        
    method_code = getItemProperty(event.selectSingleNode('related_id/Item[@type="Method"]'), 'method_code');
    method_code = this.prepareEventHandlerCode(method_code, false);
    var newFunction = "function " + functionName + "(){\n" + method_code + "\n}\n"; 
    allFieldsEventsfunctions.push(newFunction);
    if (addToContent[eventName] == undefined)
    {
      tempArr[count++] = eventName;
      addToContent[eventName] = eventName + '="' +  'try{';
    }
    addToContent[eventName] += "if (" + functionName + "()===false) return false;";    
  }

  for (var i=0; i<count; i++)
  {
    content += addToContent[tempArr[i]] + 
    "}catch(exp){top.aras.AlertError('Internal Error: event handler failed.','Event handler failed with message:'+exp.description, 'Client Side Error');return false;}\"";  
  }
  return content;
}  

Aras.prototype.uiPopulateFormWithItemEx = function(form, itemNd, itemTypeNd, isEditMode)
{
  if (!form) return false;
  var formParent = form.document;
  while (formParent.parentElement) formParent = formParent.parentElement;

  var doc = null;
  if (!formParent.document && formParent.body) doc = formParent;
  else doc = formParent.document;

  if (!doc)
  {
    top.aras.AlertError("Failed to get the parent document for the form.");
    return false;
  }

  doc.isFormPopulated = false;

  if (!itemNd) return false;

  var iomItem = new Item();
  iomItem.dom = itemNd.ownerDocument;
  iomItem.node = itemNd;

  doc.item = itemNd;
  doc.thisItem = iomItem;
  doc.itemID = itemNd.getAttribute('id');
  doc.isTemp = (itemNd.getAttribute('isTemp')=='1');
  if (isEditMode==undefined) isEditMode = (doc.isTemp || this.getItemProperty(itemNd, 'locked_by_id')==this.getCurrentUserID());
  doc.isEditMode = isEditMode;

  var cssPropNm;
  for (var stepNum=1; stepNum<3; stepNum++)
  {
    if (stepNum==1)
      cssPropNm = 'fed_css';
    else
      cssPropNm = 'css';
    var css = this.getItemProperty(itemNd, cssPropNm);
    if (css!='')
    {
      var ss = doc.styleSheets[doc.styleSheets.length - 1];
      var styleTmplt = new RegExp(/^\.(\w)+(\s)*\{(\w|\s|\:|\-|\#|\;)*\}$/);//look getItemStyles
      var styles = css.split('\n');
      for (var i=0; i<styles.length; i++)
      {
        var style = styles[i];
        if (!styleTmplt.test(style)) continue;
        var tmp = style.split('{');
        ss.addRule(tmp[0], tmp[1].split('}')[0]);
      }
    }
  }

  var i, scrpt;
  for (i=0; i<doc.scripts.length; i++)
  {
    scrpt = doc.scripts[i];
    if (scrpt.defer) scrpt.defer = false;
  }

  if (!itemTypeNd)
  {
    itemTypeNd = this.getItemTypeDictionary(itemNd.getAttribute('type')).node;
    if (!itemTypeNd) return false;
  }

  var propNds = itemTypeNd.selectNodes('Relationships/Item[@type="Property" and name!="" and '+
    '(not(@action) or (@action!="delete" and @action!="purge"))]');

  if (!propNds.length)
  {
    itemTypeNd = this.getItemTypeDictionary(itemNd.getAttribute('type')).node;
    if (!itemTypeNd) return false;
  }

  var propNds = itemTypeNd.selectNodes('Relationships/Item[@type="Property" and name!="" and '+
    '(not(@action) or (@action!="delete" and @action!="purge"))]');

  var propNm, elem, newVal;

  for (i=0; i<propNds.length; i++)
  {
    with (this)
    {
      propNm = getItemProperty(propNds[i],'name');
      elem = doc.getElementById(propNm+'_system');
      if (!elem) continue;

      newVal = getItemProperty(itemNd, propNm);
      if (elem.value != newVal) elem.value = newVal;
      else if (newVal != '')
      {
        elem.value = '';
        elem.value = newVal;
      }
    }
  }

  doc.isFormPopulated = true;

  try
  {
    if (doc.parentWindow.parent.updateMenuState) doc.parentWindow.parent.updateMenuState();
  }
  catch (excep) {}
  
  //to fire onformpopulated event.
  //if onformpopulated is defined on the window which contains just populated form then we call onformpopulated();
  if (doc.parentWindow && doc.parentWindow.onformpopulated && typeof(doc.parentWindow.onformpopulated)=="function") doc.parentWindow.onformpopulated();
}


Aras.prototype.uiNewItemEx = function(itemTypeName)
{
  if (!itemTypeName) return null;

  var newItemNd = null;
  var newItemID = '';

  with (this)
  {
    if (itemTypeName == 'RelationshipType')
    {
      newItemNd = newRelationship(getRelationshipTypeId('RelationshipType'), null, false, null);
      setItemProperty(newItemNd, "related_id", null);
    }
    else
      newItemNd = newItem(itemTypeName);

    if (!newItemNd)
      return null;

    newItemID = newItemNd.getAttribute('id');
    uiShowItemEx(newItemNd, 'new');
  }

  return newItemNd;
}

Aras.prototype.makeItemsGridBlank = function Aras_makeItemsGridBlank(saveSetups)
{
  //this method is for internal purposes only.
  if (saveSetups === undefined) saveSetups = true;
  
  var mainWindow = this.getMainWindow();
  var w;
  try{ w = mainWindow.main.work;} catch (ex){}
  if (w)
  {
    if (w.location)
    {
      if (!saveSetups)
      {
        if (w.saveSetups) w.saveSetups = new Function("");
      }
      
      w.location.replace("about:blank");
    }
    w.isItemsGrid = false;
  }
  var m;
  try{ m = mainWindow.main.menu;} catch (ex){}
  if (m && m.setAllControlsEnabled) m.setAllControlsEnabled(false);
}
Aras.prototype.uiIsFieldReadOnly = function Aras_uiIsFieldReadOnly(fieldNd, propNd)
{
  if (!fieldNd) return false;
  var isFieldDisabled = (this.getItemProperty(fieldNd, 'is_disabled')=='1');
  var readOnlyProp = false;
  if (propNd) readOnlyProp = (this.getItemProperty(propNd, 'readonly')=='1');
  if (isFieldDisabled && !readOnlyProp) readOnlyProp = true;
  return readOnlyProp;
}