﻿// (c) Copyright by Aras Corporation, 2006-2007.

/*
This file contains logic common for all search grids (grid + searchbar)
*/

var gridApplet = null;
var inputCol = -1;
var savedInputCol = inputCol;
var isMainGrid = false;//this flag is used because behavior is not completely identical
var soapController = null;//controller to manage async soap requests
var statusId;//variable to store message id during async search
var prevQryItem;//previos search results
//------------------------

function setupSearchButtonsStates(searchIsInProgress)
{
/*
setups states of search buttons:
stop_search, search, prev_page, next_page
----
searchIsInProgress - boolean flag indicating if search is in progress
*/

  if (!document.searchbar) return;
  
	var t = searchbar.getActiveToolbar();
  var tb = t.getElement('stop_search'); if (tb) tb.setEnabled(searchIsInProgress);
  
  var f = !searchIsInProgress;
  tb = t.getElement('search'); if (tb) tb.setEnabled(f);
  tb = t.getElement('prev_page'); if (tb) tb.setEnabled(f);
  tb = t.getElement('next_page'); if (tb) tb.setEnabled(f);
}

function whenGetResponse(result)
{
  soapController = null;

  if (result.getFaultCode() != 0)
  {
    setupSearchButtonsStates(false);
    clearSearchInProgressMessage();
    top.aras.AlertError(result.getFaultDetails(), result.getFaultString(), result.getFaultActor());
    return;
  }
  
  currQryItem.setResponse(result);

  setupPageNumber();
  
  if (isMainGrid)
  {
    top.aras.sGridsSetups[itemTypeName]['pagesize'] = ps;
  }

  clearSearchInProgressMessage();
  
  setupSearchButtonsStates(false);
  
  setupGrid(false);
  updateToolStatusBar();
}

function clearSearchInProgressMessage()
{
  if (!statusId) return;
  
  if (isMainGrid)
    top.aras.clearStatusMessage(statusId);
  else
  {
    if (document.searchbar)
      document.statusbar.clearStatus(statusId);
  }
  
  statusId = "";
}

function doSearch_internal()
{
  if (top.aras.getVariable('UseWildcards')=='true')
    currQryItem.replaceConditionEverywhere('eq', 'like');
  else
    currQryItem.replaceConditionEverywhere('like', 'eq');

  stopSearch(false);
  
  setupSearchButtonsStates(true);
  
  if (isMainGrid)
  {
    statusId = top.aras.showStatusMessage(4, '', '../images/animated/ProgressSmall.gif');
  }
  else
  {
    if (document.statusbar != undefined)
    {
      statusId = document.statusbar.setStatus(0, '   Searching...', '../images/Animated/ProgressSmall.gif');
    }
  }
  
  // prevQryItem = currQryItem.dom.xml; //direction was removed to outside the function
  prevSearchVis = top.aras.getVariable(varName_searchVis);
  
  soapController = new SoapController(whenGetResponse);
  currQryItem.execute(undefined, soapController);
}

onunload = function onunload_handler()
{
  stopSearch(false);
}

function stopSearch(refresh)
{
  if (refresh === undefined) refresh = true;
  
  if (soapController && soapController.stop)
  {
    soapController.stop();
    setupSearchButtonsStates(false);
    soapController = null;
  }
  else return;

  if (!isMainGrid)
  {
    var ps = searchbar.getActiveToolbar().getElement('page_size').getText();
    ps = parseInt(ps);
    if ( !isNaN(ps) && ps>0 ) top.aras.setVariable(varName_pagesize, ps);
  }

  clearSearchInProgressMessage();

  if (refresh && prevQryItem)
  {
    currQryItem.dom.loadXML(prevQryItem);
    currQryItem.item = currQryItem.dom.documentElement;
    top.aras.sGridsSetups[itemTypeName]['page'] = currQryItem.getPage();
    if (!isMainGrid)
    {
      page = top.aras.sGridsSetups[itemTypeName]['page'];
    }
    top.aras.sGridsSetups[itemTypeName]['visible_search_row'] = prevSearchVis.split(";");
    top.aras.setVariable(varName_searchVis, prevSearchVis);
    setupGrid(false,false);
    if (isMainGrid)
    {
      updateToolStatusBar();
    }
  }
  
  if (!isMainGrid)
  {
    if (refresh) showStatus();
  }
}

function initGrid()
{
  gridApplet = grid;
}

function saveInputCol() 
{
  savedInputCol = inputCol;
}

function onKeyPressed( kEv )
{
  var keyCode = kEv.getKeyCode();

  if( keyCode==113)
  {
    saveInputCol();
    gridApplet.turnEditOff();
    
    setTimeout("lookup()", 1);
  }
  
  return true;
}

function lookup()
{
  var col = savedInputCol;
  savedInputCol = -1;

  if (col < 1) return;

  var prop = visiblePropNds[col-1];
  var propDT = top.aras.getItemProperty(prop, 'data_type');

  var val = '';
  
  var inputCell = gridApplet.cells('input_row', parseInt(col));

  if (propDT == 'date')
  {
    var format = top.aras.getItemProperty(prop, 'pattern');

    var param = new Object();
    param.format = format;

    var newDate = top.aras.uiShowDialogNearElement(grid, top.aras.getScriptsURL() + 'dateDialog.html', param, undefined, undefined, inputCell.getBounds());

    if (newDate) val = newDate;
    else return;
  }
  else if (propDT == 'image')
  {
    var params = new Object();
    params.aras = top.aras;
    params.image = inputCell.GetValue();
    
    var res = showModalDialog('ImageBrowser/imageBrowser.html', params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0');

    if (res!=undefined && res != 'set_nothing') val = res;
    else
      if (res == 'set_nothing') val = '';
      else return;    
  }
  else if (propDT == 'text')
  {
    var param = new Object();
    param.isEditMode = true;
    param.content = inputCell.GetValue();
            
    var res = showModalDialog("textDialog.html", param, "resizable:yes;status:no;help:no;dialogWidth:600px;dialogHeight:450px;");
    
    if (res!=undefined) val = res;
    else return;    
  }
  else if (propDT == 'formatted text')
  {
    var param=new Object();
    param.aras = top.aras;
    param.sHTML = inputCell.GetValue();
    var res = top.showModalDialog('HTMLEditorDialog.html', param, 'status:0; help:0; resizable:1;');
    if (res!=undefined) val = res;
    else return;    
  }  
  else if (propDT == 'color')
  {
    var oldColor = inputCell.GetValue();
    var newColor = '';
    newColor = top.main.menu.document.colorApplet.getColor(oldColor);
    
    if (newColor != undefined)  val = newColor;
    else return;
  }    
  else if (propDT == 'item')
  {
    var propDS = top.aras.getItemProperty(prop, 'data_source');
    if (!propDS) return;

    var it = top.aras.getItemFromServer('ItemType',propDS,'name');
    if (!it) return;

    var it_name = it.getProperty('name');


    var res = showModalDialog('searchDialog.html', {aras:window.top.aras, itemtypeName:it_name}, 'dialogHeight:450px; dialogWidth:700px; status:0; help:0; resizable:1');

    if (res == undefined) return;
    else val = res.keyed_name;
  }
  else
  {
    top.aras.AlertError('Lookup for ' + propDT + 's is not available.');
    return;
  }

  inputCell.setValue(val);
  setSearchCriteria(col, val);

  var searchSetups = top.aras.sGridsSetups[itemTypeName];
  if (searchSetups)
  {
    searchSetups.page = 1;
    currQryItem.setPage(1);
  }
}
