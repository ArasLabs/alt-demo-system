﻿// © Copyright by Aras Corporation, 2004-2007.

function updateItemsGrid (updatedItem) {
  if (!updatedItem || !window.isTearOff) return false;
  var updatedID = updatedItem.getAttribute('id');

  if (opener.main.work.isItemsGrid) {
    if (opener.main.work.itemTypeName==itemTypeName) {
      var gridApplet = opener.main.work.gridContainer;
      if (gridApplet.getRowIndex(itemID) > -1 ) {
        var wasSelected = (gridApplet.getSelectedItemIds(';').search(itemID) > -1);

        if (updatedID != itemID) opener.main.work.deleteRow(item);
        opener.main.work.updateRow(updatedItem);

        if (wasSelected) {
          if (updatedID == itemID) opener.main.work.onSelectItem(itemID);
          else {
            var currSel = gridApplet.getSelectedId();
            //if (currSel)
            opener.main.work.onSelectItem(currSel);
          }
        }//if (wasSelected)
      }
    }
  }//if (opener.main.work.isItemsGrid)
}

function updateMenuState() {
  if (top.isTearOff && document.frames['editor'] && document.frames['editor'].refreshMenuState) {
    document.frames['editor'].refreshMenuState();
  }
}

function onSaveCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);

  var res;
  with (editor) {
    currLCNode.setAttribute('levels', 3);
    res = top.aras.saveItemEx(currLCNode);
    if (res) {
    setEditMode();
      if (top.isTearOff) updateItemsGrid(res);
    }
  }
  window.system_res = res;
  return true;
}

function onUnlockCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var res = top.aras.unlockItemEx(editor.currLCNode);
  if (res) {
    editor.setViewMode();
    if (top.isTearOff) updateItemsGrid(res);
  }

}

function onUndoCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);

  with (editor) {
    if (!top.aras.isDirtyEx(currLCNode)) {
      top.aras.AlertError('Nothing to undo.');
      return true;
    }

    if (!confirm('Undo will discard your changes. Are you sure?')) return true;

    top.aras.removeFromCache(currLCID);
    setEditMode();
  }

  return true;
}

function onLockCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var res = top.aras.lockItemEx(editor.currLCNode);
  if (res) {
    editor.setEditMode();
    if (top.isTearOff) updateItemsGrid(res);
  }
}

function onPurgeCommand() {
  return onPurgeDeleteCommand('purge');
}

function onDeleteCommand() {
  return onPurgeDeleteCommand('delete');
}

function onPurgeDeleteCommand(command)
{
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var res = false;

  with (editor)
  {
    if (command == 'purge') res = top.aras.purgeItem('Life Cycle Map', currLCID, false);
    else res = top.aras.deleteItem('Life Cycle Map', currLCID, false);
  }

  if (res)
  {
    if (top.isTearOff)
    {
      window.close();
    }
    else
    {
      var lcIT = top.aras.getItemFromServerByName('ItemType', 'Life Cycle Map', 'id');
      if (lcIT) top.main.work.location.replace('itemsGrid.html?itemtypeID='+lcIT.getID());
      else top.main.work.location.replace('about:blank');
    }
  }

  if (top.isTearOff && opener.main.work.isItemsGrid && opener.main.work.itemTypeName==itemTypeName)
  {
    var gridApplet = opener.main.work.gridContainer;
    if (gridApplet.getRowIndex(itemID) > -1 ) gridApplet.deleteRow(itemID);
  }

  return true;
}

function onPrintCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  top.aras.uiShowItemEx(editor.currLCNode, 'print view', true);
  return true;
}

function onExport2OfficeCommand(targetAppType)
{
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var itm = editor.currLCNode;
  if (itm)
  {
    top.aras.export2Office("", targetAppType, itm); 
  }
}

function onSaveUnlockAndExitCommand() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);

  var res = null;
  with (editor) {
    var statusId;
    if (top.isTearOff) statusId = top.aras.showStatusMessage(0, 'saving...', '../images/Animated/ProgressSmall.gif');
    res = top.aras.saveItemEx(currLCNode, false);
    if (top.isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
    if (!res) return true;

    if (top.isTearOff) statusId = top.aras.showStatusMessage(0, 'unlocking...', '../images/Animated/ProgressSmall.gif');
    res = top.aras.unlockItemEx(res);
    if (top.isTearOff) if (statusId) top.aras.clearStatusMessage (statusId);
    if (!res) return true;
  }

  if (top.isTearOff) {
    updateItemsGrid(res);
    window.close();
  }

  return true;
}

function onCloseCommand() {
  if (window.isTearOff) window.close();
  return true;
}

function onShowAccess() {
}

function onShowHistory() {
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var editmode = editor.isEditMode ? 1 : 0;
  var url = 'historyGrid.html?ITName='+itemTypeName+'&itemID='+itemID+'&editMode=' + editmode + '&toolbar=1&where=dialog';
  var params = new Object;
  params.aras = top.aras;
  params.item = item;
  showModalDialog(url, params, 'dialogHeight:200px; dialogWidth:800px; status:0; help:0; resizable:yes; scroll:no;');
}

function onShowWhereUsed()
{
  var url = 'whereUsed.html?id=' + itemID + '&type_name=' + itemTypeName + '&curLy='+top.aras.getVariable("StructureLayout")+'&toolbar=1&where=dialog';
  var params = new Object;
  params.aras = top.aras;
  showModalDialog(url, params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0; resizable:yes; scroll:no;');

}

function onShowWorkflow()
{
  var editor = (top.isTearOff ? document.frames['editor'] : window);
  var editmode = editor.isEditMode ? 1 : 0;
  var relTypeID = top.aras.getItemFromServerByName('RelationshipType', 'Workflow', 'id').getID();
  var url = 'relationships.html';
  var params = new Object;
  params.LocationSearch = '?db='+top.aras.getDatabase()+'&ITName='+itemTypeName+'&itemID='+itemID+'&relTypeID='+relTypeID+'&editMode='+editmode+'&tabbar=0&toolbar=1&where=dialog';
  params.aras = top.aras;
  params.item = item;
  showModalDialog(url, params, 'dialogHeight:500px; dialogWidth:750px; status:0; help:0; resizable:yes; scroll:no;');
}

function onShowLifeCycle() {
  var url = 'LifeCycleDialog.html';
  var params = new Object;
  params.aras = top.aras;
  params.item = item;
  var res = showModalDialog(url, params, 'dialogHeight:400px; dialogWidth:600px; status:0; help:0; resizable:yes; scroll:no;');

  if (typeof(res)=='string' && res=='null') {
    deleteRowFromItemsGrid(itemID);

    window.close();
    return true;
  }
  if (!res) return true;

  if (window.isTearOff) updateItemsGrid(res);

  isEditMode = false;
  top.aras.uiReShowItemEx(itemID, res, viewMode);
  return true;

}
var windowReady = true;

