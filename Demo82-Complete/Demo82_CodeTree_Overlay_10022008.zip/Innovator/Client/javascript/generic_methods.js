﻿// © Copyright by Aras Corporation, 2004-2007.

///--- Generic methods ---///

Aras.prototype.updateDOM = function(xpath,xml) {
  var node = this.dom.selectSingleNode(xpath);
  if (! node) return;

  var tmpDom = this.createXMLDocument();
  tmpDom.loadXML(xml);

  node.parentNode.replaceChild(tmpDom.documentElement,node);

  return node;
}

Aras.prototype.setNodeElement = function(node,element,value) {
  var elm = node.selectSingleNode(element);
  if (! elm) {
    elm = this.dom.createElement(element);
    node.appendChild(elm);
  }
  if (element.search(/^html_code$|^method_code$/) == 0) {
    var cdata = this.dom.createCDATASection(value);
    if  (elm.childNodes.length)
         elm.replaceChild(cdata,elm.firstChild);
    else elm.appendChild(cdata);
  } else elm.text = value;

  return node;
}

Aras.prototype.getNodeElement = function(node,element) {
  if (! node) return;
  var value = (node.selectSingleNode(element)) ? node.selectSingleNode(element).text : '';
  return value;
}

Aras.prototype.setNodeElementAttribute = function(node,element,attribute,value) {
  if (! node) return;
  var elm = node.selectSingleNode(element);
  if (elm) elm.setAttribute(attribute,value);
  else     newNodeElementAttribute(node,element,attribute,value)
}

Aras.prototype.newNodeElementAttribute = function(node,element,attribute,value) {
  var elm = this.dom.createElement(element);
  elm.setAttribute(attribute,value);
  return node.appendChild(elm);
}

Aras.prototype.getValueByXPath = function(xpath,node) {
  if (arguments.length < 2) var node = this.dom;
  if (!node.selectSingleNode(xpath)) return;
  return node.selectSingleNode(xpath).text
}

Aras.prototype.removeNodeByXPath = function(xpath) {
  var node = this.dom.selectSingleNode(xpath);
  if (node) node.parentNode.removeChild(node);
}
