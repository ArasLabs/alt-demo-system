﻿// (c) Copyright by Aras Corporation, 2004-2007.
 
/*
 *   Aras Object used to expose the Client Side API for the Innovator Server.
 *
 */

/*
global Aras variables: to (set/get) these variables use aras.(set/get)Variable

ShowLabels
UseWildcards
AppendItems
NoTabsInTabView
ShowItemProperties
TearOff
ViewMode
DEBUG
StructureLayout
*/

var system_progressbar1_gif = "../images/Animated/ProgressSmall.gif";

/*-- Aras
 *
 *   Constructor for the Aras object.
 */
function Aras(parent)
{
  if(parent)
  {
    this.parentArasObj = parent;
    for(var prop in parent)
    {
      if(prop!="privateProperties"&&prop!="parentArasObj"&&!Aras.prototype[prop])
      {
        this[prop] = parent[prop];
      }
    }
    this.IomInnovator = this.newIOMInnovator();
  }
  else
  {
    this.commonProperties = new ArasCommonProperties();
    this.SetupURLs(window.location.href);
    this.varsStorage = null;
    this.vault = null;
    this.calendar = null;
    this.dom = Aras_createXMLDocument();
    this.dom.loadXML('<Innovator><Items/></Innovator>');
    this.itemsCache = new ClientCache(this);
    this.windows = new Array();
    this.windowsByName = new Array();
    this.mainWindowName = top.name;
    if(!this.mainWindowName)
    {
      var d = new Date();
      top.name = 'innovator_'+d.getHours()+'h'+d.getMinutes()+'m'+d.getSeconds()+'s';
      this.mainWindowName = top.name;
    }
    this.maxNestedLevel = 3; //constant to prevent recurrsion of nested forms (zero based)
    this.newFieldIndex = 0; //variable used in formtool to generate new field name
    this.sGridsSetups = new Object();
    this.items2gridXSL = new Object();
    this.rels2gridXSL = new Object();
    this.clipboard = new Clipboard(this);
    this.VaultServerURLCache = new Object();
    this.IDPool = new Array();//pool of IDs to reduce number of requests to Server
    
    // The semaphore is used for managing main vs. background
    // calls to the server. The value of the semaphore is set
    // at the end of loading setup.aspx page before background
    // loading of meta-data is started.
    this.semaphore = null;
    
    this.IomFactory = null;
    this.IomInnovator = null;
  }

  this.privateProperties = new ArasPrivateProperties(this);
}

/*
 * ArasCommonProperties - object to store common for all Aras objects properties
 */
function ArasCommonProperties()
{
  this.formsCacheById = new Object();
  this.userDom = Aras_createXMLDocument();
  this.userDom.loadXML('<Empty/>');
  this.userID = '';
  this.loginName = '';
  this.password = '';
  this.database = '';
  this.identityList = '';
  this.scriptsURL = '';
  this.baseURL = '';
  this.serverBaseURL = '';
  this.serverEXT = '.aspx';
  this.user_type = '';
  this.idsBeingProcessed = new Object();
  
  // Array of meta-data item names\ids that most often used by the user
  // Each element of the array contains a counter that is increased every
  // time user tries to load the meta-data
  this.favoriteMetaData = new FavoriteMetaData();
}

/*
 * ArasPrivateProperties - object to store private properties of each of Aras objects
 */
function ArasPrivateProperties(owner)
{
  this.soap = new SOAP(owner);
  this.runAsCalls = new Array();
}

function Aras_onerror_handler(sMsg, sUrl, sLine) {
//there are cases when exception is not passed to a caller function but error is displayed to user
//when call is executed from different frame
  var re = /^(Known exception [^:]+):::([^:]+):::(.*)$/;
  if ( re.test(sMsg) ) {
    //known exception
    re = /^([^:]+):::(.*)$/;
    if ( re.test(RegExp.$3) ) {
      var msg = RegExp.$1;
      var faultstring = RegExp.$2;

      if (aras && aras.AlertError) aras.AlertError(msg, faultstring);
    }

    return false;
  }
  else {
    //to simulate onerror handler absence
    //to generate standard UI error if the exception is not from the known place.
    window.onerror = null;//turn OFF our special handler
    throw new Error(1, sMsg);
    window.onerror = Aras_onerror_handler;//turn ON our special handler
    return true;
  }
}

if ((!top.aras) || (!top.aras.DEBUG)) onerror = Aras_onerror_handler;

Aras.prototype.assignEventhandlerToControl = function Aras_AssignEventhandlerToControl(obj, eventName, parameters, body)
{
  if (obj && eventName)
    eval("function obj::" + eventName + "(" + parameters + ") {" + body + "}");
  else
    throw new Error(1, "You must specify object and event name!");
}

Aras.prototype.ShowSplashScreen = function Aras_ShowSplashScreen(wnd, maxProgressValue, OnTimeInterval_handler_str,  msg)
{
  var initSplashFailed = false;
  // try->catch here because of control may fail for some reason.
  try
  {
    var obj = this.utils.GetSplashScreen();
    obj.IntervalLength = 100;
    wnd.focus(); //because of a frame inside the window frameset may be active.
    var ev = wnd.document.createEventObject('onload');
    dTop = ev.screenY - ev.clientY;
    dLeft = ev.screenX - ev.clientX;
    var res = this.getDocumentBodySize(wnd.document);
    obj.SetBounds(dLeft, dTop, parseInt(res.width), parseInt(res.height));
    obj.MaximumProgressValue = maxProgressValue;
    var message = (msg !== undefined) ? msg : "Please wait while all open Innovator windows are being closed…";
    obj.SetSubscriptionMessage(message);
    this.assignEventhandlerToControl(obj, "OnTimeInterval", "", OnTimeInterval_handler_str + "(obj);");
  }
  catch (Excep)
  {
    initSplashFailed = true;
  }
  
  if (!initSplashFailed)
    obj.ShowSplashScreen();
}

Aras.prototype.getOpenedWindowsCount = function Aras_GetOpenedWindowsCount(closeAllDuringLooping)
{
  var winCount = 0;
  for (var wn in this.windowsByName)
  {
    var wnd = this.windowsByName[wn];
    
    if (this.isWindowClosed(wnd))
    {
      delete this.windowsByName[wn];
    }
    else
    {
      winCount++;
      if (closeAllDuringLooping) wnd.close();
    }
  }
  return winCount;
}

Aras.prototype.updateOfWindowsClosingProgress = function Aras_updateOfWindowsClosingProgress(splashScreen)
{
  var cntrName = this.updateOfWindowsClosingProgress.toString();
  cntrName = cntrName.substring(0, cntrName.indexOf("(")) + "_calls_count";
  if (this[cntrName] === undefined)
    this[cntrName] = 0;
  var nowOpenedWindowsCount = this.getOpenedWindowsCount();
  if (nowOpenedWindowsCount > 0)
  {
    //check if any window is closed
    //if (no window were closed since last check then) count++;
    if (splashScreen.CurrentProgressValue == (splashScreen.MaximumProgressValue - nowOpenedWindowsCount))
      this[cntrName]++;
    else
      this[cntrName] = 0;
  }

  var newProgrV = splashScreen.MaximumProgressValue - nowOpenedWindowsCount;
  splashScreen.CurrentProgressValue = newProgrV;

  //treat the rest of windows cannot be closed automatically. User has to close them manually.
  var timeout = 5000;//5 seconds
  var maxTries = timeout / splashScreen.IntervalLength;
  if (nowOpenedWindowsCount == 0 || this[cntrName] >= maxTries)
  {
    delete this[cntrName];
    splashScreen.CloseSplashScreen(100);
  }
}

Aras.prototype.getCommonPropertyValue = function Aras_getCommonPropertyValue(propertyName, propertyDescription)
{
  return this.CommonPropertyValue("get", propertyName, propertyDescription);
}

Aras.prototype.setCommonPropertyValue = function Aras_setCommonPropertyValue(propertyName, propertyValue, propertyDescription)
{
  return this.CommonPropertyValue("set", propertyName, propertyValue, propertyDescription);
}

Aras.prototype.CommonPropertyValue = function Aras_CommonPropertyValue(action, propertyName, propertyValue, propertyDescription)
{
  var res;
  try {
    if (action == "get")
      res = this.commonProperties[propertyName];
    else
      this.commonProperties[propertyName] = propertyValue;
  }
  catch (excep) {
    //only one known exception may occur here:
    //-2147418094: The callee (server [not server application]) is not available and disappeared; all connections are invalid. The call did not execute.

    var num = excep.number;
    if (num == -2147418094) {
      if (!propertyDescription) propertyDescription = propertyName;

      var specialDescr = "Known exception during getCommonPropertyValue:::" +
                         num + ":::Application was unable to determine " + propertyDescription +
                         ":::The callee (server [not server application]) is not available and disappeared; all connections are invalid. The call did not execute.";//because description is empty for this particular error
      throw new Error(num, specialDescr);
    }
    else {
      //such exceptions are unknown and thus not processed here
      throw excep;
    }
  }

  return res;
}

/*
 * Adds id to a list of ids which are being processed in async operation.
 * Parameters are item id and operation description.
 */
Aras.prototype.addIdBeingProcessed = function Aras_addIdBeingProcessed(id, operationDescription)
{
  this.commonProperties.idsBeingProcessed[id] = operationDescription;
}

/*
 * Removes id from a list of ids which are being processed in async operation.
 * Parameter is item id.
 */
Aras.prototype.removeIdBeingProcessed = function Aras_removeIdBeingProcessed(id)
{
  delete this.commonProperties.idsBeingProcessed[id];
}

/*
 * Checks if id is being processed in async operation.
 * Parameter is item id.
 */
Aras.prototype.isIdBeingProcessed = function Aras_isIdBeingProcessed(id)
{
  return (this.commonProperties.idsBeingProcessed[id] !== undefined);
}



/*
 * User item representing the user logged in is a special item
 * and thus is stored in the separate DOM.
 */
Aras.prototype.getLoggedUserItem = function Aras_getLoggedUserItem(showError)
{
  var showFaultDetails;
  if(showError==undefined)
  {
    showFaultDetails = false;
  }
  else
  {
    showFaultDetails = showError;
  }

  var item = this.commonProperties.userDom.selectSingleNode("//Item[@type='User']");
  if(!item)
  {
    var soapBody = '<Item type="User" action="get" '+
      'select="first_name,last_name,login_name,logon_enabled,starting_page,working_directory,keyed_name,default_vault" '+
      'id="'+this.getUserID()+'">'+
        '<Relationships>'+
          '<Item type="Alias" action="get" select="related_id(name,is_alias,keyed_name)" />'+
        '</Relationships>'+
      '</Item>';

    var res = this.soapSend('ApplyItem',soapBody);
    if(res.getFaultCode()!=0)
    {
      if(top.aras.DEBUG)
      {
        top.aras.AlertError('Fault loading '+typeName+': '+res.getFaultCode());
      }
      return false;
    }
    if(this.debugWindow)
    {
      this.uiViewXMLInFrame(this.debugWindow,res.results);
    }

    var items = res.results.selectNodes(top.aras.XPathResult('/Item'));
    if(items.length==0)
    {
      top.aras.AlertError('User is not found.');
    }
    var newItem = items(0);

    if(newItem)
    {
      this.commonProperties.userDom.loadXML("<Innovator>"+newItem.xml+"</Innovator>");
      item = this.commonProperties.userDom.selectSingleNode("//Item[@type='User']");
    }
    else
    {
      if(showFaultDetails)
      {
        var tmpUserInfo = this.newObject();
        var res = this.validateUser(tmpUserInfo);
        if(res!="ok")
        {
          top.aras.AlertError("Failed to get user: "+res);
        }
      }
      item = null;
    }
  }
  return item;
}


Aras.prototype.getLoginName = function Aras_getLoginName()
{
  return this.commonProperties.loginName;
}

Aras.prototype.getUserType = function Aras_getUserType()
{
  if (this.commonProperties.user_type != "")
   return(this.commonProperties.user_type);

  if((this.commonProperties.loginName=="root")||(this.commonProperties.loginName=="admin"))
    return ("admin");

  return("user");
}

Aras.prototype.isAdminUser = function Aras_isAdminUser() {
 if (this.getUserType() == "admin")
  return(true);
 else
  return(false);
}

Aras.prototype.setUserType = function Aras_setUserType(usertype) {
 this.commonProperties.user_type = usertype;
}

Aras.prototype.setLoginName = function Aras_setLoginName(loginName)
{
  this.commonProperties.loginName = loginName;
}

Aras.prototype.getPassword = function Aras_getPassword()
{
  return this.commonProperties.password;
}

Aras.prototype.setPassword = function Aras_setPassword(pwdPlain,dohash)
{
  if(dohash==undefined)
  {
    dohash = true;
  }
  if(dohash)
  {
    this.commonProperties.password = calcMD5(pwdPlain);
  }
  else
  {
    this.commonProperties.password = pwdPlain;
  }
}

Aras.prototype.SetupURLs = function Aras_SetupURLs(start_url)
{
  var s = start_url.replace(/(^.+scripts\/)(.+)/i,"$1");
  this.commonProperties.scriptsURL = s;
  this.commonProperties.BaseURL = s.replace(/\/scripts\/$|\/reports\/$/i, '');
  this.commonProperties.serverBaseURL = this.commonProperties.BaseURL.replace(/\/client$/i,'/Server/');
  this.scriptsURL = this.commonProperties.scriptsURL;
}

Aras.prototype.setServer = function Aras_setServer(baseURL,EXT)
{
  if(baseURL!='')
  {
    this.commonProperties.serverBaseURL = baseURL;
  }
  if(EXT!='')
  {
    this.commonProperties.serverEXT = EXT;
  }
}

Aras.prototype.getServerBaseURL = function Aras_getServerBaseURL()
{
  return this.commonProperties.serverBaseURL;
}

Aras.prototype.getScriptsURL = function Aras_getScriptsURL()
{
  return this.commonProperties.scriptsURL;
}

Aras.prototype.getServerURL = function Aras_getServerURL() {
  var res = this.getCommonPropertyValue("serverBaseURL", "Innovator server base URL") +
            "InnovatorServer" + this.getCommonPropertyValue("serverEXT", "Innovator server pages extension");
  return res;
}

Aras.prototype.getBaseURL = function Aras_getBaseURL()
{
  return this.commonProperties.BaseURL;
}

Aras.prototype.getTopHelpUrl = function Aras_getTopHelpUrl()
{
  var topHelpVariable = top.aras.getItemFromServerByName("Variable", "TopHelpUrl", "value");
  var topHelpUrl;
  if (topHelpVariable) topHelpUrl = topHelpVariable.getProperty("value");
  
  return topHelpUrl;
}

Aras.prototype.getUserID = function Aras_getUserID()
{
  return this.commonProperties.userID;
}

Aras.prototype.setUserID = function Aras_setUserID(userID)
{
  this.commonProperties.userID = userID;
}

Aras.prototype.getDatabase = function Aras_getDatabase()
{
  return this.commonProperties.database;
}

Aras.prototype.setDatabase = function Aras_setDatabase(database)
{
  this.commonProperties.database = database;
}

Aras.prototype.getIdentityList = function Aras_getIdentityList()
{
  return this.commonProperties.identityList;
}

Aras.prototype.setIdentityList = function Aras_setIdentityList(identityList)
{
  this.commonProperties.identityList = identityList;
}

Aras.prototype.setVarsStorage = function Aras_setVarsStorage(varsStorage)
{
  this.varsStorage = new VarsStorageClass();
}

Aras.prototype.getVariable = function Aras_getVariable(varName)
{
  try
  {
    if(varName=="TearOff")
      return "true";
    if(!this.varsStorage)
      return "";

    return this.varsStorage.getVariable(varName);
  }
  catch (excep)
  {
    return "";
  }
}

Aras.prototype.resetUserPreferences = function Aras_resetUserPreferences()
{
  this.varsStorage = new VarsStorageClass();
}

Aras.prototype.setVariable = function Aras_setVariable(varName,varValue)
{
  if(!this.varsStorage) 
    return 1;
  
  try
  {
    if(this.getVariable(varName)!=varValue)
    {
      var pp = this.varsStorage.setVariable(varName,varValue);

      params = new Object();
      params.varName = varName;
      params.varValue = varValue;
      this.fireEvent("VariableChanged",params);
    }
  }
  catch (excep)
  {
    return 2;
  }

  return 0;
}

Aras.prototype.removeVariable = function Aras_removeVariable(varName)
{
  if(!this.varsStorage) return 2;
  
  return this.setVariable(varName,null);
}

//url - location of new document if window with nameForNewWindow hasn't defined. Optional parameter. Created for IR-008617 "One Window (Main) Service report gives Access Denied"
Aras.prototype.getActionTargetWindow = function Aras_getActionTargetWindow(nameForNewWindow, url)
{
  var win = this.commonProperties.actionTargetWindow;

  if(win)
  {
    try
    {
      //IR-007415 "Status Bar/Indicator never ceases"
      //Check win.document to avoid access denied error
      if(!this.isWindowClosed(win) && win.document)
      {
        win = win;
      }
      else
      {
        win = null;
      }
    }
    catch(excep)
    {
      win = null;
    }
  }

  if(!win)
  {
    var width = 710; // This is a printable page width.
    var height = screen.availHeight/2;
    var x = (screen.availHeight-height)/2;
    var y = (screen.availWidth-width)/2;
    var args = "scrollbars=yes,resizable=yes,status,width="+width+",height="+height+",left="+y+",top="+x;    
    var loc = (url != undefined) ? url : "about:blank"; 
    win = window.open(loc);

    this.setActionTargetWindow(win);
  }

  return win;
}

Aras.prototype.setActionTargetWindow = function Aras_setActionTargetWindow(win)
{
  this.commonProperties.actionTargetWindow = win;
}

Aras.prototype.showStatusMessage = function Aras_showStatusMessage(colNumber,text,imgURL)
{
  try
  {
    if(top.main&&top.main.statusbar)
    {
      return top.main.statusbar.setStatus(colNumber,text,imgURL);
    }

    var statusbar = top.document.frames['statusbar'];
    if(!statusbar)
    {
      return false;
    }
    return statusbar.setStatus(colNumber,text,imgURL);
  }
  catch(excep)
  {
    return false;
  }
}

Aras.prototype.clearStatusMessage = function Aras_clearStatusMessage(messageID)
{
  try
  {
    if(top.main&&top.main.statusbar)
    {
      return top.main.statusbar.clearStatus(messageID);
    }

    if(!top.isTearOff)
    {
      return false;
    }
    if(!top.document.frames['statusbar'])
    {
      return false;
    }
    var statusbar = top.document.frames['statusbar'];
    if(!statusbar)
    {
      return false;
    }
    return statusbar.clearStatus(messageID);
  }
  catch(excep)
  {
    return false;
  }
}

Aras.prototype.setDefaultMessage = function Aras_setDefaultMessage(colNumber,infoOrText,imgURL)
{
  var info;
  if(imgURL!=undefined)
  {
    info = new Object();
    info.text = infoOrText;
    info.imgURL = imgURL;
  }
  else
  {
    info = infoOrText;
  }

  try
  {
    if(top.main&&top.main.statusbar)
    {
      return top.main.statusbar.setDefaultMessage(colNumber,info);
    }

    if(!top.isTearOff)
    {
      return false;
    }
    if(!top.document.frames['statusbar'])
    {
      return false;
    }
    var statusbar = top.document.frames['statusbar'];
    if(!statusbar)
    {
      return false;
    }
    return statusbar.setDefaultMessage(colNumber,info);
  }
  catch(excep)
  {
    return false;
  }
}


Aras.prototype.setStatus = function Aras_setStatus(text,image)
{
  return this.showStatusMessage(0,text,image);
}

Aras.prototype.setStatusEx = function Aras_setStatusEx(text,colNumber,image)
{
  return this.showStatusMessage(colNumber,text,image);
}

/*-- clearStatus
 *
 *   Method to set the clear status bar value.
 *
 */
Aras.prototype.clearStatus = function ArasObject_clearStatus(statID)
{
  return this.clearStatusMessage(statID);
}

Aras.prototype.soapSend = function Aras_soapSend(methodName,xmlBody,url,saveChanges, soapController,is_bgrequest)
{
  return this.privateProperties.soap.send(methodName,xmlBody,url,saveChanges, soapController,is_bgrequest);
}

/*
 * For internal use only
 */
Aras.prototype.getEmptySoapResult = function Aras_getEmptySoapResult()
{
  return new SOAPResults(this, "");
}

/*----------------------------------------
 * getCurrentLoginName
 *
 * Purpose:
 * returns login name to communicate with Server (runAs or logged user login name)
 *
 * Arguments: none
 */
Aras.prototype.getCurrentLoginName = function Aras_getCurrentLoginName()
{

  var runAs = this.privateProperties.runAsCalls.length;
  if(runAs>0)
  {
    return this.privateProperties.runAsCalls[runAs-1][0];
  }
  else
  {
    return this.getLoginName();
  }
}

/*----------------------------------------
 * getCurrentPassword
 *
 * Purpose:
 * returns password to communicate with Server (runAs or logged user password)
 *
 * Arguments: none
 */
Aras.prototype.getCurrentPassword = function Aras_getCurrentPassword()
{
  var runAs = this.privateProperties.runAsCalls.length;
  if(runAs>0)
  {
    return this.privateProperties.runAsCalls[runAs-1][1];
  }
  else
  {
    return this.getPassword();
  }
}

/*----------------------------------------
 * getCurrentUserID
 *
 * Purpose:
 * returns User id to communicate with Server (runAs or logged user password)
 *
 * Arguments: none
 */
Aras.prototype.getCurrentUserID = function Aras_getCurrentUserID()
{
  var runAs = this.privateProperties.runAsCalls.length;
  if(runAs>0)
  {
    return this.privateProperties.runAsCalls[runAs-1][2];
  }
  else
  {
    return this.getUserID();
  }
}

Aras.prototype.login = function Aras_login(login_name,password,database,dohash_flag,server_BaseURL,server_EXT)
{
  this.setLoginName(login_name);
  this.setPassword(password,dohash_flag);
  this.setDatabase(database);
  this.setServer(server_BaseURL,server_EXT);

  var userInfo = this.newObject();
  var validateRes = this.validateUser(userInfo);
  if(validateRes=="ok")
  {
    this.setUserID(userInfo.id);
    if (userInfo.user_type != null) this.setUserType(userInfo.user_type);
    this.setVarsStorage();
  }

  return validateRes;
}

/*-- logout
 *
 *   Method to logoff the Innovator Server and close the session.
 *
 */
Aras.prototype.logout = function()
{
  this.setCommonPropertyValue("ignoreSessionTimeoutInSoapSend", true);
  with(this)
  {
    try { if(varsStorage) varsStorage.save(); } catch(e) {} // removed from setup.aspx/onunload, because innovator.aspx/onunload(aras.logout) fires earlier and we cannot soapSend
    
    if(getUserID())
    {
      // Save in prefs the statistics about meta-data requested in this session
      // from the server. The statistics is used to preload meta-data in background.
      this.commonProperties.favoriteMetaData.saveInPrefs( this );

      soapSend("Logoff","<logoff skip_unlock='0'/>");
      commonProperties.userID = null;
      commonProperties.login;
      commonProperties.loginName = "";
      commonProperties.password = "";
      commonProperties.database = "";
      commonProperties.identityList = "";
    }
  }
  this.setCommonPropertyValue("ignoreSessionTimeoutInSoapSend", undefined);
}

Aras.prototype.XPathResult = function Aras_XPathResult(str)
{
  var path = "//Result";
  if(str==undefined)
  {
    return (path);
  }
  if(!str)
  {
    return (path);
  }
  if(str=="")
  {
    return (path);
  }
  return (path+str);
}

Aras.prototype.XPathFault = function Aras_XPathResult(str)
{
  var path = SoapConstants.EnvelopeBodyFaultXPath;
  if(str==undefined)
  {
    return (path);
  }
  if(!str)
  {
    return (path);
  }
  if(str=="")
  {
    return (path);
  }
  return (path+str);
}

Aras.prototype.XPathMessage = function Aras_XPathMessage(str)
{
  var path = "//Message";
  if(str==undefined)
  {
    return (path);
  }
  if(!str)
  {
    return (path);
  }
  if(str=="")
  {
    return (path);
  }
  return (path+str);
}

/*----------------------------------------
 * hasMessage
 *
 * Purpose:
 * check if xmldom (soap message) contains Message
 *
 * Arguments:
 * xmlDom - xml document with soap message
 */
Aras.prototype.hasMessage = function Aras_hasMessage(xmlDom)
{
  return (xmlDom.selectSingleNode(top.aras.XPathMessage())!=null);
}

/*----------------------------------------
 * getMessageNode
 *
 * Arguments:
 * xmlDom - xml document with soap message
 */
Aras.prototype.getMessageNode = function Aras_getMessageNode(xmlDom)
{
  return xmlDom.selectSingleNode(top.aras.XPathMessage());
}



/*-- validateUser
 *
 *   Method to validate the user and is used by the login method.
 *   The reason you do not see the users creadentions here is
 *   because they are automatically sent in the SOAP HTTP header.
 *
 * Arguments:
 *   userInfo - object to return User ID
 */
Aras.prototype.validateUser = function Aras_validateUser(userInfo)
{
  var res = this.soapSend('ValidateUser','');
  if(!res)
  {
    return "validateUser: Failed to communicate with Innovator Server.";
  }
  
  var passwordExpired_const = 100;
  if (res.getFaultCode()==passwordExpired_const)
  {
    var url = this.getScriptsURL()+"changeMD5Dialog.html";
    var newPwd;
    var serverMsg = res.getServerMessage();
    var tmpDom = this.createXMLDocument();
    tmpDom.loadXML(serverMsg);
    var methodCodeNd = tmpDom.selectSingleNode("//Item[@type='Method']/method_code");
    var data = new Object();
    data['title'] = 'Your password has expired.';
    data['md5'] = this.getPassword();
    data['oldMsg'] = 'Old Password: ';
    data['newMsg1'] = 'New Password: ';
    data['newMsg2'] = 'Confirm New Password: ';
    data['errMsg1'] = 'Old Password Is Wrong!';
    data['errMsg2'] = 'Check New Password And Its Confirmation.';
    data['errMsg3'] = 'Password cannot be empty';
    data['check_empty'] = true;
    data['code_to_check_pwd_policy'] = (methodCodeNd) ? methodCodeNd.text : "return 'Method to check the password policy is not found.';";
    data['vars_to_check_pwd_policy'] = serverMsg;
    data.aras = this;
    var isPwdChanged = false;
    while (!isPwdChanged)
    {
      newPwd = showModalDialog(url, data, "dialogHeight:180px; dialogWidth:300px; center:yes; resizable:no; status:no; help:no;");
      if (newPwd === undefined)
      {
        return "New password is not set.";
      }
      else
      {
        isPwdChanged = true;
        var r2 = this.soapSend("ChangeUserPassword", "<new_password>"+newPwd+"</new_password>");
        if(r2.getFaultCode()!=0)
        {
          this.AlertError(r2.getFaultDetails(),r2.getFaultString(),r2.getFaultActor());
          isPwdChanged = false;
        }
      }
    }
    this.setPassword(newPwd, false);
    res = this.soapSend('ValidateUser','');
    if(!res)
    {
      return "validateUser: Failed to communicate with Innovator Server.";
    }
  }

  if(res.getFaultCode()==0)
  {
    var node = res.results.selectSingleNode(top.aras.XPathResult('/id'));
    if(!node)
    {
      return "validateUser: Wrong Innovator Server response.";
    }

    if(userInfo)
    {
      userInfo.id = node.text;
      node = res.results.selectSingleNode(top.aras.XPathResult('/user_type'));
      if (node) userInfo.user_type = node.text;
    }

    return 'ok';
  }
  else
  {
    return res.getFaultDetails();
  }
}

/*-- generateNewGUID
 *
 *   Method to generate a new ID by getting it from the server
 *
 */
Aras.prototype.generateNewGUID = function Aras_generateNewGUID() {
  var id = this.IDPool.pop();
  if (id === undefined) {//pool is empty. populate it.
    this.IDPool = this.generateNewGUIDsEx(10);
    id = this.IDPool.pop();
  }

  if (id === undefined) return "";
  return id;
}

/*-- generateNewGUIDsEx
 *
 *   Method to generate a requested number of IDs by getting them from the server
 *   Returns an Array with the requested length;
 */
Aras.prototype.generateNewGUIDsEx = function Aras_generateNewGUIDsEx(count) {
  var mainArasObj = this.getMainArasObject();

  if (mainArasObj && mainArasObj!=this) return mainArasObj.generateNewGUIDsEx(count);

  if(isNaN(parseInt(count))||parseInt(count)<1)
  {
    return new Array();
  }

  var res = this.soapSend('GenerateNewGUIDEx','<Item quantity="'+count+'" />');
  if(!res||res.getFaultCode()!=0)
  {
    return new Array();
  }
  if(res.results.selectSingleNode(top.aras.XPathResult('/ids')))
  {
    return res.results.selectSingleNode(top.aras.XPathResult('/ids')).text.split(';');
  }
  else
  {
    return new Array();
  }
}

/*-- isTempID
 *
 *   Method to test id value to be temporary.
 *
 */
Aras.prototype.isTempID = function Aras_isTempID(id)
{
  if(id.substring(0,6)=='ms__id')
  {
    return true;
  }
  else
  {
    var item = this.dom.selectSingleNode('//Item[@id="'+id+'"]');
    if(!item)
    {
      return false;
    }
    return (item.getAttribute('isTemp')=='1');
  }
}

/*-- applyXsltString
 *
 *   Method to transform a dom using the XSLT style sheet passed as string.
 *
 */
Aras.prototype.applyXsltString = function(domObj,xslStr)
{
  var xsl = this.createXMLDocument();
  xsl.loadXML(xslStr);
  return domObj.transformNode(xsl);
}

/*-- applyXsltFile
 *
 *   Method to transform a dom using the XSLT style sheet passed as a URL.
 *
 */
Aras.prototype.applyXsltFile = function(domObj,xslFile)
{
  var xsl = this.createXMLDocument();
  xsl.load(xslFile);
  return domObj.transformNode(xsl);
}

/*-- evalJavaScript
 *
 *   Method to evaluate the JavaScript code in the Aras object space.
 *
 */
Aras.prototype.evalJavaScript = function Aras_evalJavaScript(jsCode)
{
  eval('with(this){'+jsCode+'}');
}

/*-- evalJavaScriptByURL
 *
 *   Method to evaluate JavaScript by URL
 *   url = the URL to the file
 *
 */
Aras.prototype.evalJavaScriptByURL = function Aras_evalJavaScriptByURL(url)
{
  var http = new ActiveXObject("Msxml2.XMLHTTP.3.0");
  http.open('GET',url,false);

  try
  {
    http.send();
  }
  catch(excep)
  {
    return;
  }

  eval('with(top){'+http.responseText+'}');
}

/*-- evalJavaScriptByURL
 *
 *   Method to print the frame
 *   frame = the frame object
 *
 */
Aras.prototype.printFrame = function Aras_printFrame(frame)
{
  frame.focus();
  frame.print();
}

/*-- evalEventMethod
 *
 *   Method to evaluate the JavaScript code in the Aras object space for a client side event.
 *
 */
Aras.prototype.evalEventMethod = function(callingId,eventName,sourceId)
{
  with(this)
  {
    var event = getItemFromServerByName('Event',eventName,'id').node;
    if(!event)
    {
      return;
    }

    var eventID = getItemProperty(event,'id');

    var caller = getItemById('',callingId);
    if(!caller)
    {
      return;
    }

    var rel = caller.selectSingleNode('Relationships/Item[@type="Event" and relationship_id/Item/@id="'+eventID+'"]/related_id');
    if(!rel)
    {
      return;
    }

    var method = getItemFromServer('Method',rel.getAttribute('id'),'name,method_type,method_code').node;
    if(!method)
    {
      return;
    }

    var methodCode = getItemProperty(method,'method_code');
    eval('with(top){\n'+methodCode+'\n}');
  }
}

/*-- installMethod
 *
 *   Method to evaluate JavaScript stored as a Method item on the client side.
 *   This method is just like evalMethod() but does not need the rest of the client API
 *   and is used to install API code stored as Method items.
 *   methodName = the name of the Method item
 *
 */
Aras.prototype.installMethod = function Aras_installMethod(methodName)
{
  var res = this.soapSend('GetItem','<Item type="Method"><name>'+methodName+'</name></Item>');
  if(!res)
  {
    return;
  }

  var method_code = res.results.selectSingleNode('//method_code');
  if(method_code)
  {
    var methodType = res.results.selectSingleNode('//method_type').text;
    if(methodType.search(/^JavaScript$/)!=0)
    {
      top.aras.AlertError('Error in installStoredMethod\n\n the Method: '+methodName+'\nmust be JavaScript.',"","");
      return;
    }
    eval('with(top){'+method_code.text+'}');
  }
}

/*-- evalMethod
 *
 *   Method to evaluate JavaScript stored as a Method item on the client side.
 *   methodName = the name of the Method item
 *   XMLinput   = XML string that is loaded into the top.inDom
 *
 */
Aras.prototype.evalMethod = function Aras_evalMethod(methodName,XMLinput)
{
  var methodNd = this.getItemFromServerByName('Method',methodName,'name,method_type,method_code').node;
  if(!methodNd)
  {
    return;
  }

  var methodType = this.getItemProperty(methodNd,'method_type');
  if(methodType.search(/^JavaScript$/)!=0)
  {
    this.AlertError('Error in evalMethod\n\n the Method: '+methodName+'\nmust be JavaScript.',"","");
    return;
  }

  var runasFlag = false;

  var methodCode = this.getItemProperty(methodNd,'method_code');
  var inDom = this.createXMLDocument();
  inDom.loadXML(XMLinput);

  var self = this;

  function evalMethod_work()
  {
    var item = self.newIOMItem();
    
    item.dom = inDom;
    var itemNode = item.dom.selectSingleNode("//Item");
    if(itemNode)
    {
      item.node = itemNode;
    }
    else
    {
      item.node = undefined;
    }

    item.SetThisMethodImplementation( new Function("inDom",methodCode) );

    return item.ThisMethod(item.node);
  }

  if(!this.DEBUG)
  {
    try
    {
      return (evalMethod_work());
    }
    catch(excep)
    {
      this.AlertError("The method "+methodName+" failed.","aras_object: "+excep.number+" "+excep.description,"Client Side Error");
      return;
    }
    finally
    {
    }
  }
  else
  {
    //IR-007020
    var error1=window.onerror;
    window.onerror = null;//turn OFF our special handler
    return (evalMethod_work());
    window.onerror=error1;
    error1=null;
  }
}

/*
 * AlertError
 * params:  detail = client-facing error message
 *      faultstring = the technical error message
 *      faultactor = the stack trace
 *      ardwin = the window to use
 *
 */
Aras.prototype.AlertError = function Aras_AlertError(msg,faultstring,faultactor,argwin)
{
  return this.AlertInternal(msg,"error",argwin, faultstring, faultactor);
}

Aras.prototype.AlertSuccess = function Aras_AlertSuccess(msg,argwin)
{
  this.AlertInternal(msg,"success",argwin);
}

Aras.prototype.AlertAbout = function Aras_AlertAbout(argwin)
{
  this.AlertInternal(this.aboutInnovatorMessage, "about", argwin);
}

Aras.prototype.AlertInternal_1 = function Aras_AlertInternal_1(argwin)
{
  var win = window;
  if(argwin && !this.isWindowClosed(argwin))
  {
    win = argwin;
  }

  var doc = null;
  try
  {
    doc = win.document;
  }
  catch(excep)
  {
  }

  var actEl = null;
  if(doc)
  {
    actEl = doc.activeElement;
  }

  if(actEl&&actEl.tagName=="FRAMESET")
  {
    var frms = doc.getElementsByTagName("FRAME");
    if(frms.length>0)
    {
      var frm = frms[0];
      frm.setActive();
      actEl = doc.activeElement;
    }
  }

  try
  {
    if(actEl)
    {
      actEl.focus();
    }
  }
  
  catch(excep)
  {
  }
  win.focus();

  return win;
}

/*
Displays a confirmation dialog box which contains a message and OK and Cancel buttons.
Parameters:
message - string. Message to display in a dialog.
win - parent window for the dialog.

Returns:
true  - if a user clicked the OK button.
false - if a user clicked Cancel button.
*/
Aras.prototype.confirm = function Aras_confirm(message, win)
{
  var res = this.AlertInternal(message, "confirm", win);
  return Boolean(res);
}

Aras.prototype.prompt = function Aras_prompt(msg,defValue,argwin) {

  if (this.getCommonPropertyValue("exitWithoutSavingInProgress")) return;
  var win = this.AlertInternal_1(argwin);

  var title="Aras User Prompt";
  
  var htmlContent =
    "<base href='"+this.getScriptsURL()+"'/>" +
    "<title>" + title + "</title>" +
    "<style>" +
      "body {background:buttonface; border:0 solid #eeeeee; font-family:arial; font-size:12px; margin: 0;}\n" +
      "p{font-family: arial; font-size: 12px; margin-left: 10px; margin-right: 10px;color: black}\n" +
    "</style>" +
    "<body onkeydown='if(event.keyCode==27){window.returnValue=null; window.close()}'>" +
      "<table border=0 cellspacing=0 cellpadding=10 width=500px>" +
        "<tr>" +
        
          "<td>" +
            "<p style=\"width:360px; overflow:hidden;\">Script Prompt:</p>" +
          "</td>" + 

          "<td align=\"center\">" + 
            "<button style=\"width=70px\" id=\"ok\" onclick=\"returnValue=textInput.value; window.close()\">OK</button>" + 
          "</td>" + 
          
        "</tr>" + 
        "<tr>" +
        
          "<td valign=top>" +
            "<p style=\"width:360px; overflow:hidden;\" id=msg>"+msg+ "</p>" +
          "</td>" +
          
          "<td align=\"center\">" + 
            "<button style=\"width=70px\" id=\"cancel\" onclick=\"returnValue=null; window.close()\">Cancel</button>" + 
          "</td>" +
          
        "</tr>" +
        "<tr>" + 
          "<td colspan=\"2\"><input style=\"width:480; overflow:hidden;\" type=text id='textInput' value=" + defValue + "></td>" + 
        "</tr>" +
      "</table>";
    
  var width    = 500;
  var height   = 170;
    
  function writeContent(w)
  {    
    var doc = w.document;
    doc.write(htmlContent);
    
    doc.write(
      "<script>" +
      "onload = function onload_handler()\n"+
      "{\n" +
      "  var textInput = document.getElementById('textInput');\n" +
      "  if (textInput) textInput.focus();\n" +
      "}\n" +
      "onunload = function onunload_handler()\n" + 
      "{\n" +
      "  if (window.returnValue==undefined) window.returnValue=null;" + 
      "}\n" +
      "</script>");      
  }

  var writer = new Object();
  writer.writeContent = writeContent;

  var sFeatures = "status:0; help:0; resizable:no; dialogHide:1; scroll:no;";
  sFeatures += "dialogHeight:"+height+"px; ";
  sFeatures += "dialogWidth:"+width+"px; ";

  var res = win.showModalDialog(this.getScriptsURL()+"modalDialog.html", writer, sFeatures);

  var w = this.getMainWindow();
  if (w && w.DoFocusAfterAlert)
  {
    w.focus();
  }

  return res;
}

Aras.prototype.AlertInternal = function Aras_AlertInternal(msg,type,argwin, faultstring, faultactor) {
  if (this.getCommonPropertyValue("exitWithoutSavingInProgress")) return;
  var win = this.AlertInternal_1(argwin);

  var imageSrc;
  var title;
  var imageTDStyle = "padding-left:8px; padding-top:16px;";
  var msgTDStyle   = "padding-top:16px;";
  switch (type)
  {
    case "confirm":
      title = "";
      imageSrc = "../images/icons/32x32/32x32_infoicon.gif";
      
    case "success":
      title = "Aras Innovator";
      imageSrc = "../images/icons/32x32/32x32_infoicon.gif";
      break;
    
    case "about":
      title =    "About Aras Innovator";
      imageSrc = "../Images/Logos/branding_03.jpg";
      imageTDStyle = "padding-left:8px;";
      msgTDStyle   = "padding-left:40px; padding-top:12px;";
      break;
    
    case "error":
      title =    "Error";
      imageSrc = "../images/icons/32x32/32x32_warning.gif";
      break;
  }
  
  var htmlContent =
    "<base href='"+this.getScriptsURL()+"'/>" +
    "<title>" + title + "</title>" +
    "<style>" +
      "body {background:white; border:10 solid #eeeeee; font-family:arial; font-size:12px; margin: 0;}\n" +
      "p{font-family: arial; font-size: 12px; margin-left: 10px; margin-right: 10px;color: black}\n" +
      "button{margin:0; border:1 solid #000000; background:#eeeeee; color:black; font-family:arial; width:100}" +
    "</style>" +
    "<body onkeydown='if(event.keyCode==27)window.close()'>" +
      "<table border=0 cellspacing=0 cellpadding=0>" +
        "<tr>" +
          "<td valign=top style='" + imageTDStyle + "'>" +
            "<img src=\"" + imageSrc + "\">" +
          "</td>";
  if (type == "about")
  {
    htmlContent +=
        "</tr>" +
        "<tr>";
  }

  htmlContent +=
          "<td valign=top style='" + msgTDStyle + "'>" +
            "<p id=msg>"+msg+ "</p>" +
          "</td>" +
        "</tr>" +
      "</table>" +
      "<br>" +
      "<table style=\"width:100%;\" cellspacing=0 cellpadding=10><tr>";

  var noDetail = ((faultstring==undefined||!faultstring||faultstring=="")&&(faultactor==undefined||!faultactor||faultactor=="")) ? true : false;
  if (type=="error" && noDetail==false) {
      htmlContent+="<td><button onclick='\nif (infoArea.style.display!=\"block\"){infoArea.style.display=\"block\";dHeight = window.dialogHeight;\nwindow.dialogHeight=\"370px\";this.innerText=\"Hide Details\";}";
      htmlContent+="else{infoArea.style.display=\"none\"; rcts = window.document.getElementById(\"copyBuffer\").getClientRects();";
      htmlContent+="clHeight = window.document.body.clientHeight;window.dialogHeight = dHeight; this.innerText=\"Show Details\";}'>Show Details</button></td>";
  }
  htmlContent+="<td align=\"RIGHT\"><button id=\"ok\" onclick=\"returnValue=true; window.close()\">OK</button>";
  if (type == "confirm")
  {
    htmlContent += "<button id=\"cancel\" onclick=\"returnValue=false; window.close()\">Cancel</button>";
  }

  if(!noDetail)
  {
    htmlContent+="<br><br><button id=\"copyBuffer\" onclick=CopyToBuffer()>Copy buffer</button>";
    htmlContent+="</td></tr>";
    htmlContent+="<script>function CopyToBuffer()";
    htmlContent+="{ var  buffer='' , faultstring = document.getElementById('faultstring');";
    htmlContent+="  var faultactor = document.getElementById('faultactor');";
    htmlContent+="  var msg        = document.getElementById('msg');";
    htmlContent+="  if(msg!=null)";
    htmlContent+="  {  buffer+= msg.innerHTML; }";
    htmlContent+="  if(faultstring!=null)";
    htmlContent+="  { buffer+=faultstring.innerHTML; }";
    htmlContent+="  if(faultactor!=null)";
    htmlContent+="  { buffer+=faultactor.innerHTML; }";
    htmlContent+="  window.clipboardData.setData('Text',buffer);}</script>";
 }
 else
    htmlContent+="</td></tr>";

  if (type=="error" && noDetail==false) {
      htmlContent+="<tr><td colspan=\"2\"><div id=\"infoArea\" style=\"display:none;\"><div id=\"info\" style=\"overflow:auto; background:#eeeeee; margin:10; margin-bottom:0; border:1 solid #ffffff;\">"+
      "<table><tr><td valign=\" TOP \"><p><b>Technical Message</b></p></td><td><p  id=faultstring >"+faultstring+
      "</p></td></tr><tr><td valign=\" TOP \"><p><b>Stack Trace</b></p></td><td><p id=faultactor >"+faultactor+
      "</p></td></tr></table></div></div></td></tr>";
  }
  htmlContent+="</table>";
    
  var width    = 500;
  var height   = 240;
    
  function writeContent(w)
  {    
    var doc = w.document;
    doc.write(htmlContent);
    
    doc.write(
      "<script>" +
      "onload = function onload_handler()\n"+
      "{\n" +
      "  //At first you should change dialogWidth and only then make calculations for \n" +
      "  //dialogHeight because one depends on another.\n" +
      "  var dw = document.body.scrollWidth - document.body.clientWidth;\n" +
      "  window.dialogWidth = " + width + " + dw + 'px';\n" +
      "  var dh = document.body.scrollHeight - document.body.clientHeight;\n" +
      "  window.dialogHeight = " + height + " + dh + 'px';\n" +
      "  var okButton = document.getElementById('ok');\n" +
      "  if (okButton) okButton.focus();\n" +
      "}\n" +
      "</script>");      
  }

  var writer = new Object();
  writer.writeContent = writeContent;
  if (htmlContent.length < 700)
  {
    width   = 500;
    height  = 170;
  }

  var sFeatures = "status:0; help:0; resizable:1; dialogHide:1;";
  sFeatures += "dialogHeight:"+height+"px; ";
  sFeatures += "dialogWidth:"+width+"px; ";

  var res = win.showModalDialog(this.getScriptsURL()+"modalDialog.html", writer, sFeatures);

  var w = this.getMainWindow();
  if (w && w.DoFocusAfterAlert)
  {
    w.focus();
  }

//  if(top.aras && top.aras.DEBUG)
//  {
//    will_ask_to_enter_the_debugger.yes_it_will();
//  }
  
  return res;
}

/*-- evalItemMethod
 *
 *   Method to evaluate JavaScript stored as a Method item on the client side.
 *   methodName = the name of the Method item
 *   itemDom    = the item dom
 *   addArgs    = optional argument. Object with any additional parameters.
 */
Aras.prototype.evalItemMethod = function Aras_evalItemMethod(methodName,itemNode,addArgs)
{
  var methodNd = this.getItemFromServerByName('Method',methodName,'name,method_type,method_code').node;
  if(!methodNd)
  {
    return;
  }

  var methodType = this.getItemProperty(methodNd,'method_type');
  if(methodType.search(/^JavaScript$/)!=0)
  {
    top.aras.AlertError('Error in evalItemMethod\n\nthe Method: '+methodName+'\nmust be JavaScript.',"","");
    return;
  }

  var runasFlag  = false;
  var methodCode = this.getItemProperty(methodNd,'method_code');

  var self = this;

  function evalItemMethod_work()
  {
    var item = self.newIOMItem();
    item.dom = itemNode.ownerDocument;
    item.node = itemNode;

    item.SetThisMethodImplementation( new Function("inDom","inArgs",methodCode) );

    return item.ThisMethod(item.node,addArgs);
  }

  if(!top.aras.DEBUG)
  {
    try
    {
      return (evalItemMethod_work());
    }
    catch(excep)
    {
      top.aras.AlertError("The method "+methodName+" failed.","aras_object: "+excep.number+": "+excep.description,"Client Side Error");
      return;
    }
    finally
    {
    }
  }
  else
  {
    return (evalItemMethod_work());
  }
}

/*-- applyMethod
 *
 *   Method to invoke an Innovator Method on the server side.
 *   action = the server action to be performed
 *   body   = the message body for the action
 *
 */
Aras.prototype.applyMethod = function Aras_applyMethod(action,body)
{
  var res = this.soapSend('ApplyMethod','<Item type="Method" action="'+action+'">'+body+'</Item>');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return res.getResultsBody();
}

/*-- applyItemMethod
 *
 *   Method to invoke an action on an item on the server side.
 *   action = the the server action to be performed, which is the Innovator Method name
 *   type   = the ItemType name
 *   body   = the message body for the action
 *
 */
Aras.prototype.applyItemMethod = function(action,type,body)
{
  var res = this.soapSend('ApplyItem','<Item type="'+type+'" action="'+action+'">'+body+'</Item>');

  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return res.getResultsBody();
}

/*-- applyAML
 *
 *   Method to apply an item on the server side.
 *   body = the message body for the item
 *
 */
Aras.prototype.applyAML = function(body)
{
  var res = this.soapSend('ApplyAML',body);
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return res.getResultsBody();
}

/*-- compileMethod
 *
 *   Method to compile VB or C# code on the server side to check syntax.
 *   body = the method item xml
 *
 */
Aras.prototype.compileMethod = function(body)
{
  var res = this.soapSend('CompileMethod',body);
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return '';
  }
  return res.getResultsBody();
}

/*-- applyItem
 *
 *   Method to apply an item on the server side.
 *   body = the message body for the item
 *
 */
Aras.prototype.applyItem = function Aras_applyItem(body)
{
  var res = this.soapSend('ApplyItem',body);
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return '';
  }
  return res.getResultsBody();
}

/*-- invokeAction
 *
 *   Invoke the Method associated with an action.
 *   action = the the Action item
 *
 */
Aras.prototype.invokeAction = function Aras_invokeAction(action,itemTypeID,thisSelectedItemID)
{
  with(this)
  {
    var statusId = showStatusMessage(0,'   Invoking action...', system_progressbar1_gif);
    var name        = getItemProperty(action,'name');
    var methodId    = getItemProperty(action,'method');
    var actionType  = getItemProperty(action,'type');
    var target      = getItemProperty(action,'target');
    var location    = getItemProperty(action,'location');
    var body        = getItemProperty(action,'body');
    var on_complete = getItemProperty(action,'on_complete');

    var itemType = null;
    var itemTypeName = null;

    if(itemTypeID != undefined && itemTypeID)
    {
      itemTypeName = getItemTypeName(itemTypeID);
    }

    var method     = getItemFromServer('Method',methodId,'name,method_type,method_code').node;
    var methodName = getItemProperty(method,'name');
    var results;
    var selectedItem;
    
    if (actionType=='item') {
      var item_query = getItemProperty(action,'item_query');
      var xslt = "<xsl:stylesheet xmlns:xsl='http://www.w3.org/1999/XSL/Transform' version='1.0'><xsl:output method='xml' omit-xml-declaration='yes' standalone='yes' indent='yes'/><xsl:template match='/'><xsl:apply-templates/></xsl:template><xsl:template match='Item'>"+item_query+"</xsl:template></xsl:stylesheet>";
      var itemDom = this.createXMLDocument();
      selectedItem = getItemById('',thisSelectedItemID,0);
      if (selectedItem) {
        if (isDirtyEx(selectedItem)) {
          // using this item
        }
        else if (item_query == "") {
          // using this item
        }
        else if (item_query != "") {
          itemDom.loadXML(selectedItem.xml);
          var query = applyXsltString(itemDom, xslt);
          if (query) {
            var result = top.aras.soapSend('ApplyItem', query);
            if (result.getFaultCode()!=0) selectedItem = null; //alert(Result.getFaultDetails());
            else selectedItem = result.getResult().selectSingleNode("Item");
          }
        }
      }
      else {
        itemDom.loadXML("<Item type='"+itemTypeName+"' id='"+thisSelectedItemID+"' preMethodAction='doGet' />");
        if (item_query != "") {
          var query = applyXsltString(itemDom, xslt);
          if (query) {
            var result = top.aras.soapSend('ApplyItem', query);
            if (result.getFaultCode()!=0) selectedItem = null; //alert(Result.getFaultDetails());
            else selectedItem = result.getResult().selectSingleNode("Item");
          }
        }
        else {
          selectedItem = itemDom.selectSingleNode("//Item");
        }
      }

      if(!selectedItem) {
        selectedItem = dom.selectSingleNode('//Item[@id="'+thisSelectedItemID+'"]');
      }

      if (location=='server') {
        //var res = this.soapSend('ApplyItem','<Item type="'+type+'" action="'+action+'">'+body+'</Item>');
        //results = applyItemMethod(methodName,itemTypeName,body);
        var inDom = this.createXMLDocument();
        inDom.loadXML(selectedItem.xml);
        var inItem = inDom.selectSingleNode("//Item");
        inItem.setAttribute("action", methodName);
        var res = this.soapSend('ApplyItem', inItem.xml);
        if(res.getFaultCode()!=0) {
          top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
          clearStatusMessage(statusId);
          return false;
        }
        results = res.getResultsBody();
      }
      else if (location=='client') {
        results = evalItemMethod(methodName,selectedItem,null);
      }

      if(on_complete!='') {
        method     = getItemFromServer('Method',on_complete,'name');
        methodName = method.getProperty('name');
	var methodArgs = new Object();
        methodArgs.results = results;
        results    = evalItemMethod(methodName,selectedItem,methodArgs);
      }
    }
    else if (actionType=='itemtype' || actionType=='generic') {
      if (location=='server') {
        if(body!=''&&actionType=='itemtype') {
          results = applyItemMethod(methodName,itemTypeName,body);
        }
        else if(body!=''&&actionType=='generic') {
          results = applyMethod(methodName,body);
        }
        else {
          if(body=='') {
            body = '<id>'+thisSelectedItemID+'</id>';
          }
          results = applyMethod(methodName,body);
        }
      }
      else if (location=='client') {
        if(actionType=='itemtype') {
          results = evalMethod(methodName,body,method);
        }
        else {
          results = evalMethod(methodName,body,method);
          if(on_complete!='') {
            method     = getItemFromServer('Method',on_complete,'name');
            methodName = method.getProperty('name');
	    var methodArgs = new Object();
            methodArgs.results = results;
            results    = evalItemMethod(methodName,body,methodArgs);
          }
        }
      }
    }

    var doc;

    if(location=='server') {
      var subst = this.createXMLDocument();
      subst.loadXML(results);

      if(subst.documentElement!=null) {
        var content = subst.documentElement.text;
      }
      else {
        var content = "";
      }
      subst = null;
    }
    else {
      var content = results;
    }

    if(target=='window') {
      var width = 710; // This is a printable page width.
      var height = screen.height/2;
      var x = (screen.height-height)/2;
      var y = (screen.width-width)/2;
      var args = "scrollbars=yes,resizable=yes,status,width="+width+",height="+height+",left="+y+",top="+x;
      var win = open('','',args);
      win.focus();
      doc = win.document.open();
      doc.write(content);
      doc.close();
      doc.title = name;
    }
    else if(target=='main') {
      var mainWindow = this.getMainWindow();
      doc = mainWindow.main.work.document.open();
      doc.write(content);
      doc.close();
    }
    else if(target=='none') {}
    else if(target=='one window') {
      var targetWindow = this.getActionTargetWindow(name);
      doc = targetWindow.document;
      doc.write(content);
      doc.write('<br>');
    }
    clearStatusMessage(statusId);
  }
}

Aras.prototype.runReport = function Aras_runReport(report,itemTypeID,item)
{
  if(!report)
  {
    top.aras.AlertError("Failed to get the report.","","");
    return;
  }

  var report_location = this.getItemProperty(report,"location");
  var results = "";

  if(report_location=="client")
  {
    results = this.runClientReport(report,itemTypeID,item);
  }
  else if(report_location=="server")
  {
    results = this.runServerReport(report,itemTypeID,item);
    var tmpDom = this.createXMLDocument();
    if(results)
    {
      tmpDom.loadXML(results);
      results = tmpDom.documentElement.text;
    }
  }
  else if(report_location=="service")
  {
    var url = this.getServerBaseURL() + "RSGateway.aspx?irs:Report=" + this.getItemProperty(report,'name');

    var report_query = this.getItemProperty(report,'report_query');
    if (report_query)
    {
      var xslt = "" +
        "<xsl:stylesheet xmlns:xsl='http://www.w3.org/1999/XSL/Transform' version='1.0'>" +
          "<xsl:output method='xml' omit-xml-declaration='yes' standalone='yes' indent='yes'/>" +
          "<xsl:template match='/'><xsl:apply-templates/></xsl:template>" +
          "<xsl:template match='Item'>"+report_query+"</xsl:template>" +
        "</xsl:stylesheet>";
      var itemDom = this.createXMLDocument();
      if(item)
      {
        itemDom.loadXML(item.xml);
      }

      var qryString = report_query;
      if (item) qryString = this.applyXsltString(itemDom, xslt);
      if (qryString) url += '&' + qryString;
    }
  }

  var target = this.getItemProperty(report,"target");
  if(target=="window")
  {
    var width = 800; // This is a printable page width.
    var height = screen.availHeight/2;
    var x = (screen.availHeight-height)/2;
    var y = (screen.availWidth-width)/2;
    var args = "scrollbars=yes,resizable=yes,status,width="+width+",height="+height+",left="+y+",top="+x;

    if (report_location=="service")
    {
      var win = open(url,'',args);
      return;
    }

    var win = open('','',args);
    var doc = win.document.open();
    var name = "Report: "+this.getItemProperty(report,"name");
    doc.write(results);
    doc.close();
    win.document.title = name;
  }
  else if(target=="main")
  {
    var mainWindow = this.getMainWindow();

    if (report_location=="service")
    {
      mainWindow.main.work.location = url;
      return;
    }

    var doc = mainWindow.main.work.document.open();
    doc.write(results);
    doc.close();
  }
  else if(target=="none")
  {
    return;
  }
  else if(target=="one window")
  {
    var targetWindow;
    
    if (report_location=="service")
    {
      targetWindow = this.getActionTargetWindow(name, url);
      return;
    }

    targetWindow = this.getActionTargetWindow(name);
    var doc = targetWindow.document;
    doc.write(results);
    doc.write("<br>");
  }
}

/*-- runClientReport
 *
 *   Invoke the Method associated with a report.
 *   report = the the Report item
 *
 *   parameter itemTypeID is ignored
 */
Aras.prototype.runClientReport = function Aras_runClientReport(report,itemTypeID,item)
{
  if (!report)
  {
    this.AlertError("Failed to get the report.","","");
    return;
  }

  var results = '';
  var selectedItem = item;

  report = this.getItemFromServer("Report", report.getAttribute("id"), "name,description,report_query,target,type,xsl_stylesheet,location,method(name,method_type,method_code)").node;

  var reportType = this.getItemProperty(report, "type");
  var methodId   = this.getItemProperty(report, "method");

  if (methodId)
  {
    var method = this.getItemFromServer("Method", methodId, "name,method_type,method_code").node;
    if (!method) return;

    var methodName = this.getItemProperty(method, "name");

    if (reportType=="item") results = this.evalItemMethod(methodName, selectedItem)
    else results = this.evalMethod(methodName, "");
  }
  else
  {
    var report_query = this.getItemProperty(report, "report_query");

    if (!report_query)
    {
      if (reportType=="item") report_query = "<Item typeId='{@typeId}' id='{@id}' action='get' levels='1'/>";
      else if (reportType=="itemtype") report_query = "<Item typeId='{@typeId}' action='get'/>";
      else if (reportType=="generic")
      {
        if (!item) return false;
      }
    }

    if (report_query)
    {
      var xslt = "<xsl:stylesheet xmlns:xsl='http://www.w3.org/1999/XSL/Transform' version='1.0'><xsl:output method='xml' omit-xml-declaration='yes' standalone='yes' indent='yes'/><xsl:template match='/'><xsl:apply-templates/></xsl:template><xsl:template match='Item'>"+report_query+"</xsl:template></xsl:stylesheet>";
      var itemDom = this.createXMLDocument();

      if (item) itemDom.loadXML(item.xml);

      var query = this.applyXsltString(itemDom, xslt);
      if (query) results = this.applyItem(query);
      else results = this.applyItem(report_query);

      var xsl_stylesheet = this.getItemProperty(report, "xsl_stylesheet");
      if (xsl_stylesheet)
      {
        var xslt_stylesheetDOM = this.createXMLDocument();
        xslt_stylesheetDOM.loadXML(xsl_stylesheet);

        var toolLogicNode = xslt_stylesheetDOM.selectSingleNode('//script[@userData="Tool Logic"]');
        if (toolLogicNode) toolLogicNode.parentNode.removeChild(toolLogicNode);

        xsl_stylesheet = xslt_stylesheetDOM.xml;

        var res = this.createXMLDocument();
        res.loadXML(results);

        if (reportType=="item") res.loadXML("<Result>"+results+"</Result>");
        else res.loadXML(results);

        results = this.applyXsltString(res,xsl_stylesheet);
      }
    }
  }
  
  return results;
}

Aras.prototype.runServerReport = function Aras_runServerReport(report,itemTypeID,item)
{
  if(!report)
  {
    top.aras.AlertError("Failed to get the report.","","");
    return;
  }

  var report_name = this.getItemProperty(report,"name");

  var AML = "";
  if(item)
  {
    var item_copy = item.cloneNode(true);
    if(itemTypeID)
    {
      item_copy.setAttribute("typeId",itemTypeID);
    }
    AML = item_copy.xml;
  }
  else if(itemTypeID)
  {
    AML = "<Item typeId='"+itemTypeID+"'/>";
  }

  var body = "<report_name>"+report_name+"</report_name><AML>"+AML+"</AML>";
  var results = this.applyMethod("Run Report",body);

  return results;
}

/*-- updateDOM
 *
 *   Method to update the master dom object by replacing the old item with a new item.
 *   xpath  = the XPath to the item
 *   xml    = the new item XML
 *
 */
Aras.prototype.updateDOM = function(xpath,xml)
{
  var node = this.dom.selectSingleNode(xpath);
  if(!node)
  {
    return;
  }

  var tmpDom = this.createXMLDocument();
  tmpDom.loadXML(xml);

  node.parentNode.replaceChild(tmpDom.documentElement,node);
  return node;
}

/*-- setNodeElementWithAction
 *
 *   Method to set the value of an element on the node
 *   and set action attribute on the node, if it is absent.
 *   The item is the node and the property is the element.
 *   node    = the item object
 *   element = the property to set
 *   value   = the value for the property
 *   apply_the_change_to_all_found = flag to signal if the change must be common or local
 *   action - action attribute to be set on the node. By default, if action is not defined 
 *   and node action attribute != 'add' or != 'create' we set action 'update'
 */
Aras.prototype.setNodeElementWithAction = function Aras_setNodeElementWithAction(srcNode, element, value, apply_the_change_to_all_found, action)
{
  this.setNodeElement(srcNode, element, value, apply_the_change_to_all_found);

  if (!srcNode.getAttribute('action') || (srcNode.getAttribute('action') != 'add') && (srcNode.getAttribute('action') != 'create'))
  {
    if (action)
      srcNode.setAttribute('action', action);
    else
      srcNode.setAttribute('action', 'update');      
  }
}

/*-- setItemProperty/setNodeElement
 *
 *   Method to set the value of an element on the node.
 *   The item is the node and the property is the element.
 *   node    = the item object
 *   element = the property to set
 *   value   = the value for the property
 *   apply_the_change_to_all_found = flag to signal if the change must be common or local
 */
Aras.prototype.setNodeElement = Aras.prototype.setItemProperty = function Aras_setItemProperty(srcNode,element,value,apply_the_change_to_all_found) {
  if(apply_the_change_to_all_found===undefined)
  {
    apply_the_change_to_all_found = true;
  }

  var id = srcNode.getAttribute("id");
  var propertyName = element;
  var propertyValue = value;
  if(propertyValue==null)
  {
    propertyValue = "";
  }

  function isEmptyElement(xmlElem) {
    if (xmlElem) {
      if (xmlElem.hasChildNodes || xmlElem.attributes.length != 0) {
        return false;
      }
    }
    return true;
  }

  function getPropertyDataType(arasObj, itemTypeName, propertyName)
  {
    var itemType = arasObj.getItemTypeForClient(itemTypeName).node;
    if (!itemType) return "";

    var data_type = itemType.selectSingleNode('Relationships/Item[@type="Property"][name="' + propertyName + '"]/data_type');
    if (data_type) return data_type.text;
    
    return "";
  }
  
  var LastModifiedOn = Date.parse( new Date() );
  function setItemProperty_internal(arasObj, node)
  {
    var elm = node.selectSingleNode(propertyName);
    if (!elm) elm = node.appendChild(arasObj.dom.createElement(propertyName));

    var elementWasEmpty = isEmptyElement(elm);
    
    var valueIsNode;
    if (propertyValue.xml==undefined)
    {
      valueIsNode = false;
      elm.text = propertyValue;
    }
    else
    {
      valueIsNode = true;
      elm.text = "";
      
      var value2use = propertyValue;

      //check if we insert node into itself
      var item_Type = propertyValue.getAttribute("type");
      var item_ID = propertyValue.getAttribute("id");
      var propertyValueClones = value2use.selectNodes("ancestor-or-self::Item[@type='"+item_Type+"' and @id='"+item_ID+"']");
      var isACopyOfParent = false;
      for (var i=0; i<propertyValueClones.length; i++) {
        if (propertyValue == propertyValueClones[i]) {
          isACopyOfParent = true;
          break;
        }
      }
      
      if (isACopyOfParent || propertyValueWasTransfered) value2use = value2use.cloneNode(true);
      
      propertyValueWasTransfered = true;
      elm.appendChild(value2use);
    }
    
    var updateKeyedName = false;
    if (elm.getAttribute('keyed_name') != null) updateKeyedName = true;
    else if (elementWasEmpty) {
      var srcItemType = srcNode.getAttribute("type");
      if (srcItemType) {
        if (getPropertyDataType(arasObj, srcItemType, propertyName) == "item") updateKeyedName = true;
      }
    }

    if (updateKeyedName) {
      var newKeyedName;
      if (valueIsNode) newKeyedName = arasObj.getKeyedNameEx(propertyValue);
      else {
        var propertyItemType = elm.getAttribute("type");
        if (propertyItemType == null) propertyItemType = "";
        newKeyedName = arasObj.getKeyedName(propertyValue, propertyItemType);
      }
      
      elm.setAttribute("keyed_name", newKeyedName);
      
      if (valueIsNode) {
        var oldKeyedName = arasObj.getItemProperty(propertyValue, "keyed_name");
        if (!oldKeyedName && newKeyedName) {
          arasObj.setItemProperty(propertyValue, "keyed_name", newKeyedName, false);
        }
      }
    }
    
    node.setAttribute("LastModifiedOn", LastModifiedOn);
  }

  var node;
  var skip_src_node = false;
  var xpath = "//Item[@id='"+id+"']";
  var nodes = this.dom.selectNodes(xpath);
  var propertyValueWasTransfered = false;
  
  if(apply_the_change_to_all_found)
  {
    for(var i = 0;i<nodes.length;i++)
    {
      node = nodes[i];
      if(node===srcNode)
      {
        skip_src_node = true;
      }
      setItemProperty_internal(this,node);
    }
  }

  if(!skip_src_node)
  {
    setItemProperty_internal(this,srcNode);
  }

  var oParent = srcNode;
  var nds2MarkAsDirty = oParent.selectNodes("ancestor-or-self::Item");
  var nd;
  for (var i=0; i<nds2MarkAsDirty.length; i++)
  {
    nd = nds2MarkAsDirty[i];
    if (this.isLockedByUser(nd)) nd.setAttribute("isDirty", "1");
  }
  
  return true;
}

/*-- getItemProperty/getNodeElement
 *
 *   Method to get the value of an element on the node.
 *   The item is the node and the property is the element.
 *   node    = the item object
 *   element = the property to set
 *
 */
Aras.prototype.getItemProperty = Aras.prototype.getNodeElement = function(node,element)
{
  if(!node)
  {
    return;
  }
  var value;
  if(node.nodeName=='Item'&&element=='id')
  {
    value = node.getAttribute('id');
  }
  else
  {
    var tmpNd = node.selectSingleNode(element);
    if(tmpNd)
    {
      var tmpNd2 = tmpNd.selectSingleNode('Item');
      if(tmpNd2)
      {
        value = tmpNd2.getAttribute('id');
      }
      else
      {
        value = tmpNd.text;
      }
    }
    else
    {
      value = '';
    }
  }
  return value;
}

/*-- setNodeElementAttribute/setItemPropertyAttribute
 *
 *   Method to set the value of an attribute on an element on the node.
 *   The item is the node and the property is the element.
 *   node      = the item object
 *   element   = the property to set
 *   attribute = the name of the attribute
 *   value     = the value for the attribute
 *
 */
Aras.prototype.setNodeElementAttribute = Aras.prototype.setItemPropertyAttribute = function(node,element,attribute,value)
{
  if(!node)
  {
    return;
  }
  var elm = node.selectSingleNode(element);
  if(elm)
  {
    elm.setAttribute(attribute,value);
  }
  else
  {
    newNodeElementAttribute(node,element,attribute,value);
  }
}

/*-- getNodeElementAttribute/getItemPropertyAttribute
 *
 *   Method to get the value of an attribute on an element on the node.
 *   The item is the node and the property is the element.
 *   node      = the item object
 *   element   = the property to get
 *   attribute = the name of the attribute
 *
 */
Aras.prototype.getNodeElementAttribute = Aras.prototype.getItemPropertyAttribute = function(node,element,attribute)
{
  if(!node)
  {
    return null;
  }
  var value = null;
  var elm = node.selectSingleNode(element);
  if(!elm)
  {
    return null;
  }
  else
  {
    value = elm.getAttribute(attribute);
  }
  return value;
}

/*-- newNodeElementAttribute/newItemPropertyAttribute
 *
 *   Method to create a new element (property) for the item node and set the value of an attribute on an element on the node.
 *   The item is the node and the property is the element.
 *   node      = the item object
 *   element   = the property to set
 *   attribute = the name of the attribute
 *   value     = the value for the attribute
 *
 */
Aras.prototype.newNodeElementAttribute = Aras.prototype.newItemPropertyAttribute = function(node,element,attribute,value)
{
  var elm = this.dom.createElement(element);
  elm.setAttribute(attribute,value);
  return node.appendChild(elm);
}

/*-- getValueByXPath
 *
 *   Method to get the text value for an element by XPath.
 *   xpath = the APath to the element
 *   node  = the optional node otherwise use the global dom
 *
 */
Aras.prototype.getValueByXPath = function(xpath,node)
{
  if(arguments.length<2)
  {
    var node = this.dom;
  }
  if(!node.selectSingleNode(xpath))
  {
    return;
  }
  return node.selectSingleNode(xpath).text
}

/*-- removeNodeByXPath
 *
 *   Method to remove the node by XPath
 *   xpath = the APath to the element
 *   node  = the optional node otherwise use the global dom
 *
 */
Aras.prototype.removeNodeByXPath = function(xpath)
{
  var node = this.dom.selectSingleNode(xpath);
  if(node)
  {
    node.parentNode.removeChild(node);
  }
}


/*-- getItemTypeByFormID
 *
 *   Method to load a ItemType by Form ID
 *   id  = the id for the Form item
 *
 */
Aras.prototype.getItemTypeByFormID = function(id,ignoreFault)
{
  if(ignoreFault==undefined)
  {
    ignoreFault = false;
  }
  var res = this.soapSend('GetItemTypeByFormID','<Item id="'+id+'" />');

  if(res.getFaultCode()!=0)
  {
    if(!ignoreFault)
    {
      top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    }
    return false;
  }

  var itemTypeID = res.results.selectSingleNode('//Item').getAttribute('id');
  return this.getItemTypeDictionary(itemTypeID, "id").node;
}

/*-- setUserWorkingDirectory
 *
 *   Method to set the users working directory
 *   id = the id for the user
 *   workingDir = the working directory
 *
 */
Aras.prototype.setUserWorkingDirectory = function(id,workingDir)
{
  var res = this.soapSend('SetUserWorkingDirectory','<Item id="'+id+'" workingDir="'+workingDir+'" />');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
}

/*-- getNextSequence
 *
 *   Method to get the next value from a sequence item
 *   id      = the id for the sequence (optional if seqName is used)
 *   seqName = the sequence name (optional is the id is used)
 *
 */
Aras.prototype.getNextSequence = function(id,seqName)
{
  if(id==undefined)
  {
    id = '';
  }

  var body = '<Item';
  if(id!='')
  {
    body+=' id="'+id+'"';
  }
  body+='>';
  if(seqName!=undefined)
  {
    body+='<name>'+seqName+'</name>';
  }
  body+='</Item>';

  var res = this.soapSend('GetNextSequence',body);
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }

  return res.results.selectSingleNode(top.aras.XPathResult()).text;
}

/*-- buildIdentityList
 *
 *   Method to get list of identity IDs for those current user is a member.
 *   The list is a string and has following format:
 *       identityID,identityID,...,identityID
 *
 */
Aras.prototype.buildIdentityList = function Aras_buildIdentityList()
{
  var res = this.soapSend('GetIdentityList','<Item/>');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    this.setIdentityList('');
  }
  else
  {
    this.setIdentityList(res.results.selectSingleNode(top.aras.XPathResult()).text);
  }
  return this.getIdentityList();
}

Aras.prototype.applySortOrder = function Aras_applySortOrder(relationshipsArray)
{
  //this method is for internal purposes only.
  var arasObj = this;
  function sortOrderComparer(nd1, nd2)
  {
    var sortOrder1 = parseInt(arasObj.getItemProperty(nd1, "sort_order"));
    if (isNaN(sortOrder1)) return 1;
    
    var sortOrder2 = parseInt(arasObj.getItemProperty(nd2, "sort_order"));
    if (isNaN(sortOrder2)) return -1;
    
    if (sortOrder1>sortOrder2) return 1;
    else if(sortOrder1==sortOrder2) return 0;
    return -1;
  }
  
  //relationshipsArray.sort(sortOrderComparer); doesn't work sometimes with error "Object doesn't support this property or method".
  //in debugger I see that relationshipsArray.sort is defined but call relationshipsArray.sort() throws the exception
  
  //work around:
  var tmpArray = new Array();
  for (var i=0; i<relationshipsArray.length; i++) tmpArray.push(relationshipsArray[i]);
  
  tmpArray.sort(sortOrderComparer);
  
  for (var i=0; i<relationshipsArray.length; i++) relationshipsArray[i] = tmpArray[i];
  
  tmpArray = null;
}

Aras.prototype.getSeveralListsValues = function Aras_getSeveralListsValues(listsArray, is_bgrequest, readyResponseIfNeed)
{
  //this method is for internal purposes only.
  var req = "";
  var res = this.newObject();
  var listIds = new Array();
  var filterListIds = new Array();
  var Cache = this.getCacheObject();
  var listsArrayCopy = new Array();

  for (var i=0; i < listsArray.length; i++)
  {
    var listDescr = listsArray[i];
    var listId    = listDescr.id;
    var relType   = listDescr.relType;
    if (is_bgrequest && !readyResponseIfNeed)
    {
      var listDescrCopy = {id:listId, relType:relType};
      listsArrayCopy.push(listDescrCopy);
    }
    if (!Cache.Lists[listId])
    {
      if (relType == "Value")
        listIds.push(listId);
      else if (relType == "Filter Value")
        filterListIds.push(listId);
    }
  }

  if (listIds.length != 0)
  {
    req +=
      "<Item type='List' idlist='" + listIds.join(",") + "' action='get' select='name'>" +
        "<Relationships>" +
          "<Item type='Value' action='get' select='value,label,sort_order' />" +
        "</Relationships>" +
      "</Item>";
  }
  if (filterListIds != 0)
  {
    req +=
      "<Item type='List' idlist='" + filterListIds.join(",") + "' action='get' select='name'>" +
        "<Relationships>" +
          "<Item type='Filter Value' action='get' select='value,label,sort_order,filter' />" +
        "</Relationships>" +
      "</Item>";
  }

  var response = readyResponseIfNeed;
  var isAsync = (this.semaphore != null && is_bgrequest);
  if (req != "")
  {
    if (!response)
    {
      req = "<AML>" + req + "</AML>";
      
      var asynch_controller = null;
      if (isAsync)
      {
        asynch_controller = new SoapController( cllbck );
        asynch_controller.listsArray = listsArrayCopy;
        function cllbck(soapResult)
        {
          soapResult.arasableObj.semaphore.SetBGRequest( false );
          var curSoapCntrlr = this;
          soapResult.arasableObj.getSeveralListsValues(curSoapCntrlr.listsArray, true, soapResult);
        }
      }
      
      response = this.soapSend("ApplyAML", req, null, null, asynch_controller, is_bgrequest);
      
      if (isAsync)
      {
        return res;
      }
    }
    
    if (response.getFaultCode()!=0) return res;
    
    var items = response.results.selectNodes(this.XPathResult("/Item"));
    for (var i=0; i<items.length; i++)
    {
      var listNd = items[i];
      Cache.Lists[listNd.getAttribute("id")] = listNd;
    }
  }
  else
  {
    if( isAsync )
    {
      this.semaphore.SetBGRequest( false );
    }
  }

  for (var i=0; i < listsArray.length; i++)
  {
    var valuesArr = this.newArray();
    var listDescr = listsArray[i];
    var listId    = listDescr.id;
    var listNode = Cache.Lists[listId];
    if (listNode)
    {
      var values = listNode.selectNodes("Relationships/Item");
      for (var j=0; j < values.length; j++) valuesArr.push(values[j]);

      this.applySortOrder(valuesArr);

      res[listNode.getAttribute("id")] = valuesArr;
    }
  }

  // 1) add stubs for not found lists 
  // 2) mark lists as requested in the session for preloading in future sessions
  for (var i=0; i<listsArray.length; i++)
  {
    var listDescr = listsArray[i];
    var listId    = listDescr.id;
    var relType   = listDescr.relType;
    if (res[listId] === undefined) 
      res[listId] = this.newArray();
    else
    {
      // Mark that the list was requested by main thread in this session
      if( !is_bgrequest && listId )
      {
        if (relType == "Filter Value")
          this.commonProperties.favoriteMetaData.markAsRequested( "FL", "id=" + listId );
        if (relType == "Value")
          this.commonProperties.favoriteMetaData.markAsRequested( "LT", "id=" + listId );          
      }
    }
  }
  
  return res;
}

Aras.prototype.getListValues_implementation = function Aras_getListValues_implementation(listID, relType, is_bgrequest)
{
  //this method is for internal purposes only.
  var listsArray = this.newArray();
  var listDescr = this.newObject();
  listDescr.id = listID;
  listDescr.relType = relType;
  listsArray.push(listDescr);
  
  var res = this.getSeveralListsValues(listsArray, is_bgrequest);
  
  return res[listID];
}

/*-- getListValues
 *
 *   Method to get the Values for a List item
 *   listId = the id for the List
 *
 */
Aras.prototype.getListValues = function Aras_getListValues(listID, is_bgrequest)
{
  return this.getListValues_implementation(listID, "Value", is_bgrequest);
}

/*-- getListFilterValues
 *
 *   Method to get the Filter Value for a List item
 *   listId = the id for the List
 *
 */
Aras.prototype.getListFilterValues = function Aras_getListFilterValues(listID, is_bgrequest)
{
  return this.getListValues_implementation(listID, "Filter Value", is_bgrequest);
}

/*-- loadCache
 *
 *   Method to load the server cache
 *
 */
Aras.prototype.loadCache = function()
{
  var res = this.soapSend('LoadCache','<Item />');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return true;
}

/*-- saveCache
 *
 *   Method to save the server cache
 *
 */
Aras.prototype.saveCache = function()
{
  var res = this.soapSend('SaveCache','<Item />');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return true;
}

/*-- clearCache
 *
 *   Method to clear the server cache
 *
 */
Aras.prototype.clearCache = function()
{
  var res = this.soapSend('ClearCache','<Item />');
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return true;
}

/*-- resetServerCache
 *
 *   Method to repopulate the server cache
 *
 */
Aras.prototype.resetServerCache = function Aras_resetServerCache()
{
  var statusId = this.showStatusMessage(0,'   Repopulating Server Side Cache ...', system_progressbar1_gif);
  var res = this.soapSend('ResetServerCache','');
  this.clearStatusMessage(statusId);
  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return false;
  }
  return true;
}

/*-- getItemStyles
 *
 *   Method to get the style for the item
 *   item - dom object for the item
 *
 */
Aras.prototype.getItemStyles = function(item)
{
  if (!item) return null;

  var css = this.getItemProperty(item, 'css');
  if (css=='') return null;

  var res = new Object();
  var styles = css.split('\n');
  var styleTmplt = new RegExp(/^\.(\w)+(\s)*\{(\w|\s|\:|\-|\#|\;)*\}$/);

  for (var i=0; i<styles.length; i++)
  {
    var style = styles[i];
    if (!styleTmplt.test(style)) continue;

    var tmp = style.split('{');
    var styleNm = tmp[0].substr(1).replace(/\s/g, '');

    var propertiesStr = tmp[1].substr(0, tmp[1].length-1);
    var properties = propertiesStr.split(';');
    var styleObj = new Object();

    for (var j=0; j<properties.length; j++)
    {
      tmp = properties[j].split(':');
      if (tmp.length == 2)
      {
        var propNm = tmp[0].replace(/\s/g, '');
        var propVl = tmp[1].replace(/\s/g, '');
        if (propNm) styleObj[propNm] = propVl;
      }
    }

    res[styleNm] = styleObj;
  }

  return res;
}

/*-- applyCellStyle
 *
 *   Method to to apply the item style to teh grid cell
 *   cell  - the grid cell object
 *   style - the style for the cell
 *   setBg - boolean to set the background for the cell
 *
 */
Aras.prototype.applyCellStyle = function(cell,style,setBg)
{
  if(style['color'])
  {
    cell.setTextColor(style['color']);
  }
  if(setBg&&style['background-color'])
  {
    cell.setBgColor(style['background-color']);
  }
  if(style['font-family'])
  {
    var font = style['font-family'].split(',')[0];
    if(style['font-size'])
    {
      font+='-'+style['font-size'].split('p')[0];
    }
    cell.setFont(font);
  }
  if(style['font-weight']&&style['font-weight']=='bold')
  {
    cell.setTextBold();
  }
}

Aras.prototype.preserveTags = function(str)
{
  if(str==undefined)
  {
    return;
  }

  if(str=='')
  {
    return str;
  }

  str = str.replace(/&/g,'&amp;');
  str = str.replace(/</g,'&lt;');
  str = str.replace(/>/g,'&gt;');
  str = str.replace(/\n/g,'<br>');

  return str;
}

Aras.prototype.escapeXMLAttribute = function(strIn)
{
  if(strIn==undefined)
  {
    return;
  }

  if(strIn=='')
  {
    return strIn;
  }

  strIn = strIn.replace(/&/g,'&amp;');
  strIn = strIn.replace(/</g,'&lt;');
  strIn = strIn.replace(/>/g,'&gt;');
  strIn = strIn.replace(/"/g,/*"*/'&quot;');

  return strIn;
}

/*-- hasFileChanged
 *
 *   Determine if file was changed
 *   file - file item
 *
 */
Aras.prototype.hasFileChanged = function(file)
{
  var oldSize = this.getItemProperty(file,'file_size');
  var filePath = this.getItemProperty(file,'checkedout_path');
  if(filePath=='')
  {
    return true;
  }
  if(filePath.search(/\\$/)==-1)
  {
    filePath+='\\';
  }
  var fileName = filePath+this.getItemProperty(file,'filename');
  var newSize;
  try
  {
    newSize = this.vault.getFileSize(fileName);
  }
  catch(ex)
  {
    return true;//file or directory does not exist.
  }
  if(newSize==oldSize)
  {
    var oldCheckSum = this.getItemProperty(file,'checksum');
    var newCheckSum = this.vault.getFileCheckSum(fileName);
    if(newCheckSum==oldCheckSum)
    {
      return false;
    }
    else
    {
      return true;
    }
  }
  else
  {
    return true;
  }
}

/*-- findMainArasObject
 *
 *  Returns a pointer to the main Aras object (from the main window)
 *
 */
Aras.prototype.findMainArasObject = function Aras_findMainArasObject()
{
  var isMainWindow = (top.name==this.mainWindowName);

  if(!isMainWindow && top.opener && !this.isWindowClosed(top.opener))
  {
    return top.opener.top.aras.findMainArasObject();
  }
  else
  {
    return this;
  }
}

/*-- registerEventHandler
 *
 *  Register Handler for event by win
 *  see fireEvent description for details
 */
Aras.prototype.registerEventHandler = function Aras_registerEventHandler(eventName,win,handler)
{
  var EvHandlers;

  try
  {
    EvHandlers = win.top["Event Handlers"];
  }
  catch(excep)
  {
    return false;
  }

  if(!EvHandlers)
  {
    EvHandlers = new Object();
    win.top["Event Handlers"] = EvHandlers;
  }

  if(!EvHandlers[eventName])
  {
    EvHandlers[eventName] = new Array();
  }

  EvHandlers[eventName].push(handler);

  return true;
}

/*-- unregisterEventHandler
 *
 *  UnRegister Handler for event by win
 *
 */
Aras.prototype.unregisterEventHandler = function Aras_unregisterEventHandler(eventName,win,handler)
{
  var EvHandlers;

  try
  {
    EvHandlers = win.top["Event Handlers"];
  }
  catch(excep)
  {
    return false;
  }

  if(!EvHandlers)
  {
    return true;
  }

  var handlersArr = EvHandlers[eventName];
  if(!handlersArr)
  {
    return true;
  }

  for(var i=0; i<handlersArr.length; i++)
  {
    if(handlersArr[i]==handler)
    {
      handlersArr.splice(i,1);
      return true;
    }
  }

  return false;
}

/*-- fireEvent
 *
 *  fires event in all windows
 *  supported events:
 *  "VariableChanged": {varName, varValue}
 *  "ItemLock": {itemID, itemNd, newLockedValue}
 *  "ItemSave": {itemID, itemNd}
 *
 */
Aras.prototype.fireEvent = function Aras_fireEvent(eventName,params)
{
  var mainAras = this.findMainArasObject();
  if(this!=mainAras)
  {
    return mainAras.fireEvent(eventName,params);
  }

  if(!eventName)
  {
    return false;
  }

  var topWindow = top;

  for(var winId in this.windowsByName)
  {
    var win = null;
    try
    {
      win = this.windowsByName[winId];
      if(this.isWindowClosed(win))
      {
        continue;
      }
      if(win.top==topWindow)
      {
        continue;
      }
    }
    catch(excep)
    {
      continue;
    }

    var EvHandlers = null;
    try
    {
      EvHandlers = win.top["Event Handlers"];
      if(!EvHandlers)
      {
        continue;
      }
    }
    catch(excep)
    {
      continue;
    }

    var handlersArr = EvHandlers[eventName];
    if(!handlersArr)
    {
      continue;
    }

    for(var i=0; i<handlersArr.length; i++)
    {
      try
      {
        handlersArr[i](params);
      }
      catch(excep)
      {
      }
    }
  }

  var EvHandlers = topWindow["Event Handlers"];
  if(!EvHandlers)
  {
    return true;
  }

  var handlersArr = EvHandlers[eventName];
  if(!handlersArr)
  {
    return true;
  }

  var handlers2Remove = new Array();

  for(var i=0; i<handlersArr.length; i++)
  {
    var f = handlersArr[i];
    try
    {
      f(params);
    }
    catch(e)
    {
      if(e.number==-2146823277)
      {
        handlers2Remove.push(f);
      }
      else
      {
        throw e;
      }
    }
  }

  for(var i=handlers2Remove.length-1; i>=0; i--)
  {
    this.unregisterEventHandler(eventName,topWindow,handlers2Remove[i]);
  }
}

Aras.prototype.soapErrorDialog = function Aras_soapErrorDialog(msg,argwin)
{
  var win;
  if(argwin==undefined)
  {
    win = window;
  }
  else if(!argwin)
  {
    win = window;
  }
  else if(this.isWindowClosed(argwin))
  {
    win = window;
  }
  else
  {
    win = argwin;
  }
  if(top.aras.DEBUG)
  {
    top.aras.AlertError("SOAP Error: \n"+msg,"","",win);
  }
  var param = new Object();
  param.errorText = msg;
  win.showModalDialog('SoapErrorDialog.html',param,'dialogHeight:200px; dialogWidth:400px; status:0; help:0; resizable:0;');
  return true;
}

/*-- openDebugWindow
 *
 *   Method to open a debug window.
 *
 */
Aras.prototype.openDebugWindow = function Aras_openDebugWindow()
{

  this.commonProperties.debugWindow = open('debugWin.html','DebugWin','');
}

Aras.prototype.getMainWindow = function Aras_getMainWindow()
{
  try
  {
    if (this.getCommonPropertyValue('mainWindow')){return this.getCommonPropertyValue('mainWindow');}

    var isMainWindow = (top.name==this.mainWindowName);

    if(!isMainWindow && top.opener && !this.isWindowClosed(top.opener) && top.opener.top && !this.isWindowClosed(top.opener.top) && top.opener.top.aras)
    {
      return top.opener.top.aras.getMainWindow();
    }
    else if(!isMainWindow&&top.dialogOpener && !this.isWindowClosed(top.dialogOpener) && top.dialogOpener.top && !this.isWindowClosed(top.dialogOpener.top) && top.dialogOpener.top.aras)
    {
      return top.dialogOpener.top.aras.getMainWindow();
    }
    else
    {
      return top;
    }
  }
  catch(excep)
  {
    return null;
  }
}

Aras.prototype.getMainArasObject = function Aras_getMainArasObject()
{
  var res = null;

  var mainWnd = this.getMainWindow();
  if(mainWnd && !this.isWindowClosed(mainWnd))
  {
    res = mainWnd.aras;
  }

  return res;
}

Aras.prototype.newQryItem = function Aras_newQryItem(itemTypeName)
{
  var mainArasObj = this.getMainArasObject();

  if(mainArasObj&&mainArasObj!=this)
  {
    return mainArasObj.newQryItem(itemTypeName);
  }
  else
  {
    return (new top.QryItem(top.aras,itemTypeName));
  }
}

Aras.prototype.newObject = function Aras_newObject() {
  var mainArasObj = this.getMainArasObject();

  if(mainArasObj&&mainArasObj!=this) {
    return mainArasObj.newObject();
  }
  else {
    return (new Object());
  }
}

Aras.prototype.newIOMItem = function Aras_newIOMItem(itemTypeName, action)
{
  return this.IomInnovator.newItem(itemTypeName, action);
}

Aras.prototype.newIOMInnovator = function Aras_newIOMInnovator()
{
  var connector = this.IomFactory.CreateComISConnection(new InnovatorServerConnector(this));
  return this.IomFactory.CreateInnovator(connector);
}

Aras.prototype.newArray = function Aras_newArray()
{
  var mainArasObj = this.getMainArasObject();

  if (mainArasObj && mainArasObj!=this)
  {
    var str2eval = "";
    for (var i=0; i<arguments.length; i++)
    {
      str2eval += "args[" + i + "],";
    }
    if (str2eval != "") str2eval = str2eval.substr(0, str2eval.length-1);
    str2eval = "return mainArasObj.newArray(" + str2eval + ");";

    var f = new Function("mainArasObj", "args", str2eval);
    return f(mainArasObj, arguments);
  }
  else
  {
    var res;
    if (arguments.length == 1)
    {
      res = new Array(arguments[0]);
    }
    else
    {
      res = new Array();
      for (var i=0; i<arguments.length; i++) res.push(arguments[i]);
    }

    res.concat =  function newArray_concat()
    {
      var resArr = new Array();
      for (var i = 0; i < this.length; i++)
      {
        resArr[i] = this[i];
      }

      for (var i=0; i<arguments.length; i++)
      {
        if (arguments[i].pop)
        {
          for (var j = 0; j < arguments[i].length; j++)
          {
            resArr.push(arguments[i][j])
          }
        }
        else
        {
          resArr.push(arguments[i]);
        }
      }

      return resArr;
    }

    return res;
  }
}

Aras.prototype.getFileItemTypeID = function Aras_getFileItemTypeID()
{
  if(this.const_FileItemTypeID!=undefined)
  {
    return this.const_FileItemTypeID;
  }

  var qry = new top.Item('ItemType','get');
  qry.setAttribute('select','id');
  qry.setProperty('name','File');

  var results = qry.apply();
  if(results.isError())
  {
    alert(results.getErrorDetail());
    return false;
  }

  this.const_FileItemTypeID = results.getItemByIndex(0).getID();
  return this.const_FileItemTypeID;
}

Aras.prototype.cloneForm = function Aras_cloneForm(formID,newFormName)
{
  if(!formID||!newFormName)
  {
    return false;
  }

  var bodyStr = '<Item type="Form" id="'+formID+'" newFormName="'+newFormName+'" do_lock="true" />';
  var res = null;

  with(this)
  {
    var statusId = showStatusMessage(0,'   Copying Form ...', system_progressbar1_gif);
    res = soapSend('CloneForm',bodyStr);
    clearStatusMessage(statusId);
  }

  if(res.getFaultCode()!=0)
  {
    var win = this.uiFindWindowEx(formID);
    if(!win)
    {
      win = window;
    }
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor(),win);
    return false;
  }

  return true;
}

/*----------------------------------------
 * getVaultServerURL
 *
 * Purpose:
 * get Vault Server url for current User
 *
 * Arguments:
 * none
 */
Aras.prototype.getVaultServerURL = function Aras_getVaultServerURL()
{
  var vaultServerID = this.getVaultServerID();
  if (!vaultServerID) return '';

  if (this.vaultServerURL!=undefined)
  {
    return this.vaultServerURL;
  }

  var vaultNd = this.getItemById('Vault', vaultServerID, 0, '', 'vault_url,name');
  if (!vaultNd)
  {
    return '';
  }

  var vaultServerURL = this.getItemProperty(vaultNd, 'vault_url');
  this.VaultServerURL = this.TransformVaultServerURL(vaultServerURL);
  return this.VaultServerURL;
}

Aras.prototype.TransformVaultServerURL = function Aras_TransformVaultServerURL(url)
{
  var xform_url = this.VaultServerURLCache[url];
  if(xform_url!=undefined)
  {
    return (xform_url);
  }

  var res = this.soapSend('TransformVaultServerURL','<url>'+url+'</url>');

  if(res.getFaultCode()!=0)
  {
    top.aras.AlertError(res.getFaultDetails(),res.getFaultString(),res.getFaultActor());
    return url;
  }

  var rb = res.getResult();
  xform_url = rb.text;
  this.VaultServerURLCache[url] = xform_url;
  return xform_url;
}

/*----------------------------------------
 * getVaultServerURL
 *
 * Purpose:
 * get Vault Server ID for current User
 *
 * Arguments:
 * none
 */
Aras.prototype.getVaultServerID = function Aras_getVaultServerID()
{
  var userNd = null;
  var tmpUserID = this.getCurrentUserID();

  if(tmpUserID==this.getUserID())
  {
    userNd = this.getLoggedUserItem();
  }
  else
  {
    userNd = getItemFromServer('User',tmpUserID,'default_vault').node;
  }

  if(!userNd)
  {
    return "";
  }

  var vaultServerID = this.getItemProperty(userNd,'default_vault');
  return vaultServerID;
}

/*----------------------------------------
 * createXMLDocument
 *
 * Purpose:
 * provide simple way to create xml documents without specifing needed attributes each time
 *
 * Arguments:
 * none
 */
Aras.prototype.createXMLDocument = function Aras_createXMLDocument()
{
  var xmlDom = new ActiveXObject("MSXML2.FreeThreadedDOMDocument.4.0");
  xmlDom.async = false;
  xmlDom.preserveWhiteSpace = true;
  xmlDom.validateOnParse = false;

  return xmlDom;
}


/*----------------------------------------
 * hasFault
 *
 * Purpose:
 * check if xmldom (soap message) contains Fault
 *
 * Arguments:
 * xmlDom - xml document with soap message
 * ignoreZeroFault - boolean. ignore zero faultcode or not
 */
Aras.prototype.hasFault = function Aras_hasFault(xmlDom,ignoreZeroFault)
{
  if(ignoreZeroFault)
  {
    return (xmlDom.selectSingleNode(top.aras.XPathFault("[faultcode!='0']"))!=null);
  }
  else
  {
    return (xmlDom.selectSingleNode(top.aras.XPathFault())!=null);
  }

}

/*----------------------------------------
 * getFaultDetails
 *
 * Purpose:
 * get text with fault details
 *
 * Arguments:
 * xmlDom - xml document with soap message
 */
Aras.prototype.getFaultDetails = function Aras_getFaultDetails(xmlDom)
{
  var fdNd = xmlDom.selectSingleNode(top.aras.XPathFault('/detail'));

  if(fdNd==null)
  {
    return '';
  }
  else
  {
    return fdNd.text;
  }
}

/*----------------------------------------
 * getFaultString
 *
 * Purpose:
 * get text with faultstring
 *
 * Arguments:
 * xmlDom - xml document with soap message
 */
Aras.prototype.getFaultString = function Aras_getFaultString(xmlDom)
{
  var fdNd = xmlDom.selectSingleNode(top.aras.XPathFault('/faultstring'));

  if(fdNd==null)
  {
    return '';
  }
  else
  {
    return fdNd.text;
  }
}

/*----------------------------------------
 * getFaultString
 *
 * Purpose:
 * get text with faultactor (contains stack trace)
 *
 * Arguments:
 * xmlDom - xml document with soap message
 */
Aras.prototype.getFaultActor = function Aras_getFaultActor(xmlDom)
{
  var fdNd = xmlDom.selectSingleNode(top.aras.XPathFault('/faultactor'));

  if(fdNd==null)
  {
    return '';
  }
  else
  {
    return fdNd.text;
  }
}

Aras.prototype.isInCache = function Aras_isInCache(itemID)
{
  return this.itemsCache.hasItem(itemID);
}

Aras.prototype.addToCache = function Aras_addToCache(item)
{
  if(!item)
  {
    return (new CacheResponse(false,'nothing to add',item));
  }

  var itemID = item.getAttribute('id');
  if(this.isInCache(itemID))
  {
    return (new CacheResponse(false,'already in cache',this.getFromCache(itemID)));
  }

  this.itemsCache.addItem(item);
  return (new CacheResponse(true,'',this.getFromCache(itemID)));
}

Aras.prototype.updateInCache = function Aras_updateInCache(item)
{
  if(!item)
  {
    return (new CacheResponse(false,'nothing to update',item));
  }

  var itemID = item.getAttribute('id');
  this.itemsCache.updateItem(item);
  return (new CacheResponse(true,'',this.getFromCache(itemID)));
}

Aras.prototype.updateInCacheEx = function Aras_updateInCacheEx(oldItm,newItm)
{
  if(!oldItm)
  {
    return this.addToCache(newItm);
  }
  if(!newItm)
  {
    return (new CacheResponse(false,'nothing to update',newItm));
  }

  var itemID = newItm.getAttribute('id');
  this.itemsCache.updateItemEx(oldItm,newItm);
  return (new CacheResponse(true,'',this.getFromCache(itemID)));
}

Aras.prototype.removeFromCache = function Aras_removeFromCache(item)
{
  if(!item)
  {
    return (new CacheResponse(false,'nothing to remove',item));
  }

  var paramType = typeof(item);
  var itemID;
  if(paramType=='string')
  {
    itemID = item;
  }
  else if(paramType=='object')
  {
    itemID = item.getAttribute('id');
  }

  if(this.isInCache(itemID))
  {
    this.itemsCache.deleteItem(itemID);
  }

  return (new CacheResponse(true,'',null));
}

Aras.prototype.getFromCache = function getFromCache(itemID)
{
  if(!itemID)
  {
    return null;
  }
  else
  {
    return this.itemsCache.getItem(itemID);
  }
}

Aras.prototype.isPropFilledOnServer = function isPropFilledOnServer(propName)
{
  if(!propName)
  {
    return false;
  }

  var props = '^permission_id$|^created_on$|^created_by_id$|^config_id$';
  return (propName.search(props)!=-1);
}


Aras.prototype.generateExceptionDetails = function Aras_generateExceptionDetails(err,func)
{
  var resXMLDOM = this.createXMLDocument();

  resXMLDOM.loadXML("<Exception />");

  var callStackCounter = 0;
  var callStack = null;

  function addChNode(pNode,chName,chValue)
  {
    var tmp = pNode.appendChild(resXMLDOM.createElement(chName));
    if(chValue!="")
    {
      tmp.text = chValue;
    }
    return tmp;
  }

  function getFunctionName(func)
  {
    if(!func)
    {
      return "incorrect parameter !";
    }
    if(typeof(func)!="function")
    {
      return "not a function !";
    }

    var funcDef = func.toString();
    funcDef = funcDef.replace(/\/\*([^\*\/]|\*[^\/]|\/)*\*\//g, "");
    funcDef = funcDef.replace(/^\s\/\/.*$/gm, "");

    /^function([^\(]*)/.exec(funcDef);
    var funcName = RegExp.$1;
    funcName = funcName.replace(/\s/g, "");

    return funcName;
  }

  function addCallStackEntry(aCaller)
  {
    var funcName;
    var funcBody;

    if(aCaller)
    {
      funcName = getFunctionName(aCaller);
      funcBody = aCaller.toString();
    }
    else
    {
      funcName = "global code";
      funcBody = "unknown";
    }

    var fNd = addChNode(callStack,"function","");
    fNd.setAttribute("name",funcName);
    fNd.setAttribute("order",callStackCounter);

    var callArgsNd = addChNode(fNd,"call_arguments","");
    if(aCaller)
    {
      for(var i=0; i<aCaller.arguments.length; i++)
      {
        var argVal = aCaller.arguments[i];
        var argType = "string";

        if (argVal != undefined)
        {
          if(argVal.xml != undefined)
          {
            argType = "xml";
            argVal = argVal.xml;
          }
        }

        var argNd = addChNode(callArgsNd,"argument",argVal);
        argNd.setAttribute("order",i);
        argNd.setAttribute("type",argType);
      }
    }

    addChNode(fNd,"body",funcBody);

    callStackCounter++;
  }

  var root = resXMLDOM.documentElement;
  try
  {
    addChNode(root,"number",err.number);
    addChNode(root,"message",err.message);

    var aCaller = func;
    callStack = addChNode(root,"call_stack","");

    while(aCaller)
    {
      addCallStackEntry(aCaller);
      aCaller = aCaller.caller;
    }
    addCallStackEntry(aCaller);
  }
  catch(ex2)
  {
    root.text = ex2.message;
  }

  return resXMLDOM.xml;
}

Aras.prototype.showExceptionDetails = function Aras_showExceptionDetails(err)
{
  var anErr = err;
  var aCaller = this.showExceptionDetails.caller;

  var xmlDesc = this.generateExceptionDetails(anErr,aCaller);

  var xmlDoc = this.createXMLDocument();
  xmlDoc.loadXML(xmlDesc);
  var exNd = xmlDoc.selectSingleNode("//Exception");
  if (!exNd) return;
  var self = this;
  
  var htmlPrefix = '<html><head><style type="text/css">' +
      '.h1 {font-size:150%;}.h2 {font-size:120%;}pre {float:left;}</style></head>' +
    '<scr'+'ipt>function f(){window.clipboardData.setData("Text", document.getElementById("ta").value);}</scr'+'ipt>' + 
    '<body>' +
    '<table cellpadding="0" cellspacing="0" width="100%">' +
      '<tr><td colspan="2" class="h1">Exception&nbsp;<input type="button" value="Copy Details" onclick="f()"/></td></tr>' +
      '<tr><td class="h2">Number&nbsp;</td><td width="100%"><pre>'+getNdVal(exNd.selectSingleNode('number'))+'</pre></td></tr>' +
      '<tr><td class="h2">Message&nbsp;</td><td><pre>'+getNdVal(exNd.selectSingleNode('message'))+'</pre></td></tr>' +
      '<tr><td class="h2" valign="top">Details</td><td style="width:100%;height:300;"><textarea id="ta" style="width:400;height:95%;" readonly>';
  var htmlSfx = '</textarea></td></tr>' +
    '</table>' +
    '</body></html>';
  htmlPrefix = htmlPrefix.replace(/'/g, "\\\'");
  
  truncateExDetails();
  
  var maxHtmlLen = 2070;
  var dtls = exNd.xml;
  dtls = dtls.replace(/'/g, "\\\'");
  var maxLen = maxHtmlLen-htmlPrefix.length-htmlSfx.length - 4;
  if (maxLen>0 && dtls && dtls.length > maxLen) dtls = dtls.substr(0, maxLen) + "...";
  if (maxLen<=0) dtls = "";
  var html = htmlPrefix + dtls + htmlSfx;
  if (html.length > maxHtmlLen) html = html.substr(0, maxHtmlLen);
  showModalDialog("javascript:'"+html+"'", "", "dialogHeight:450px; dialogWidth:500px; center:1; resizable:1; status:0; help:0;");
  
  function getNdVal(nd)
  {
    if (!nd) return '';
    return self.EscapeSpecialChars(nd.text);
  }
  function truncateExDetails()
  {
    var nd;
    var nds = exNd.selectNodes("call_stack/function/body");
    for (var i = 0; i<nds.length; i++)
    {
      nd = nds[i];
      if (nd.text && nd.text.length > 80) nd.text = nd.text.substr(0, 80) + "...";
    }
    nds = exNd.selectNodes("call_stack/function/call_arguments/argument");
    for (var i = 0; i<nds.length; i++)
    {
      nd = nds[i];
      if (nd.text && nd.text.length > 20) nd.text = nd.text.substr(0, 30) + "...";
    }
  }
}

Aras.prototype.copyRelationship = function Aras_copyRelationship(relationshipType,relationshipID)
{
  var item = new top.Item(relationshipType,'get');
  item.setID(relationshipID);
// Need the select here...

  var relResult = item.apply();

  var sourceType = relResult.getPropertyAttribute('source_id','type');
  var sourceID   = relResult.getProperty('source_id');
  var sourceKeyedName = relResult.getPropertyAttribute('source_id','keyed_name');

  var relatedItem = relResult.getRelatedItem();
  var relatedType = "";
  var relatedID   = "";
  var relatedKeyedName = "";

  if(relatedItem != null)
  {
    var is_polymorphic = relatedItem.getAttribute("is_polymorphic") == "1";
    if(is_polymorphic)
    {
      var queryXml = "<Item type='RelationshipType' action='get' select='related_id' related_expand='0'><name>" + relationshipType + "</name></Item>";
      var qry = new top.Item();
      qry.loadAML(queryXml);
      var res = qry.apply();
      if(res.isError()) return;
      relatedType = res.getPropertyAttribute("related_id","name");
    }
    else relatedType = relatedItem.getType();
    relatedID = relResult.getProperty('related_id');
    relatedKeyedName = relResult.getPropertyAttribute('related_id','keyed_name');
  }
  else
  {
    var queryXml = "<Item type='RelationshipType' action='get' select='related_id' related_expand='0'><name>" + relationshipType + "</name></Item>";
    var qry = new top.Item();
    qry.loadAML(queryXml);
    var res = qry.apply();
    if (!res.isError())
    {
      relatedType = res.getPropertyAttribute("related_id","name");
      relatedKeyedName = res.getPropertyAttribute('related_id','keyed_name');
    }
  }

  var clipboardItem = this.newObject();
  clipboardItem.source_id = sourceID;
  clipboardItem.source_itemtype = sourceType;
  clipboardItem.source_keyedname = sourceKeyedName;
  clipboardItem.relationship_id = relationshipID;
  clipboardItem.relationship_itemtype = relationshipType;
  clipboardItem.related_id = relatedID;
  clipboardItem.related_itemtype = relatedType;
  clipboardItem.related_keyedname = relatedKeyedName;

  return clipboardItem;
}


Aras.prototype.pasteRelationship = function Aras_pasteRelationship(parentItem,clipboardItem,as_is,as_new,targetRelationshipTN,targetRelatedTN,showConfirmDlg)
{

  function getProperties4ItemType(itemTypeName)
  {
    if(!itemTypeName) return;

    var qryItem = new Item('ItemType','get');
    qryItem.setAttribute('select','name');
    qryItem.setAttribute('page',1);
    qryItem.setAttribute('pagesize',9999);
    qryItem.setProperty('name',itemTypeName);

    var relationshipItem = new Item();
    relationshipItem.setType('Property');
    relationshipItem.setAction('get');
    relationshipItem.setAttribute('select','name,data_type');
    qryItem.addRelationship(relationshipItem);

    var results = qryItem.apply();
    if(results.isError())
    {
      top.aras.AlertError(result.getErrorDetail(),result.getErrorString(),result.getErrorSource());
      return;
    }

    return results.getRelationships('Property');
  }

  function setRelated(targetItem)
  {
    if(relatedType)
    {
      var queryItemRelatedItemType = new Item();
      queryItemRelatedItemType.setType("ItemType");
      queryItemRelatedItemType.setProperty("name",relatedType);
      queryItemRelatedItemType.setAction('get');
      var relatedItemTypeResult = queryItemRelatedItemType.apply();
      if(relatedItemTypeResult.getProperty("is_dependent")=="1")
      {
        as_new = true;
      }

      if(as_new==true)
      {
        var queryItemRelated = new Item();
        queryItemRelated.setType(relatedType);
        queryItemRelated.setID(relatedID);
        queryItemRelated.setAttribute("do_add","0");
        queryItemRelated.setAttribute("do_lock","0");
        queryItemRelated.setAction('copy');
        var newRelatedItem = queryItemRelated.apply();
        if(newRelatedItem.isError())
        {
          top.aras.AlertError("Failed to copy the related item: "+newRelatedItem.getErrorDetail(),newRelatedItem.getErrorString(),newRelatedItem.getErrorSource());
          return false;
        }
        targetItem.setRelatedItem(newRelatedItem);
      }
    }
  }

  if(as_is==undefined||as_new==undefined)
  {
    var qryItem4RelationshipType = new Item();
    qryItem4RelationshipType.setType("RelationshipType");
    qryItem4RelationshipType.setProperty("name",relationshipType);
    qryItem4RelationshipType.setAction('get');
    qryItem4RelationshipType.setAttribute("select", 'copy_permissions, create_related');
    var RelNode = qryItem4RelationshipType.apply();
    if(as_is==undefined)as_is = (RelNode.getProperty("copy_permissions")=="1");
    if(as_new==undefined)as_new = (RelNode.getProperty("create_related")=="1");
  }

  var statusId = this.showStatusMessage(0,'   Pasting In Progress ...', system_progressbar1_gif);
  if(!clipboardItem) return;

  var relationshipType = clipboardItem.relationship_itemtype;
  var relationshipID = clipboardItem.relationship_id;
  var relatedID = clipboardItem.related_id;
  var relatedType = clipboardItem.related_itemtype;

  if(relationshipType==targetRelationshipTN)
  {
    var qryItem4CopyRelationship = new Item();
    qryItem4CopyRelationship.setType(relationshipType);
    qryItem4CopyRelationship.setID(relationshipID);
    qryItem4CopyRelationship.setAction('copy');
    if(as_is!=undefined)  qryItem4CopyRelationship.setAttribute('as_is',as_is);
    if(as_new!=undefined) qryItem4CopyRelationship.setAttribute('as_new',as_new);
    qryItem4CopyRelationship.setAttribute('do_add',"0");
    qryItem4CopyRelationship.setAttribute('do_lock',"0");
    var newRelationship = qryItem4CopyRelationship.apply();
    if(newRelationship.isError())
    {
      top.aras.AlertError("The copy operation failed: "+newRelationship.getErrorDetail(),newRelationship.getErrorString(),newRelationship.getErrorSource());
      this.clearStatusMessage(statusId);
      return false;
    }
    newRelationship.removeProperty("source_id");

    if (newRelationship.getType() == "Property" && newRelationship.getProperty("data_type") == "foreign")
    {
      newRelationship.removeProperty("data_source");
      newRelationship.removeProperty("foreign_property");
    }

    setRelated(newRelationship);

    if(!parentItem.selectSingleNode('Relationships'))
    {
      parentItem.appendChild(parentItem.ownerDocument.createElement('Relationships'));
    }
    var res = parentItem.selectSingleNode("Relationships").appendChild(newRelationship.node.cloneNode(true));
    this.clearStatusMessage(statusId);
    parentItem.setAttribute('isDirty','1');
    return res;
  }

  var item = new top.Item(relationshipType,'get');
  item.setID(relationshipID);
  var sourceItem = item.apply();

  if(sourceItem.getAttribute("isNew")=="1")
  {
    top.aras.AlertError("Failed to get the source item.","","");
    this.clearStatusMessage(statusId);
    return false;
  }
  sourceRelationshipTN = sourceItem.getType();

  var targetItem = new Item();
  targetItem.setType(sourceRelationshipTN);

  if(targetRelationshipTN==undefined) targetRelationshipTN = sourceRelationshipTN;
  if(sourceRelationshipTN!=targetRelationshipTN)
  {
    if((!targetRelatedTN&&!relatedType)||targetRelatedTN==relatedType)
    {
      if(showConfirmDlg)
      {
        var convert = confirm("You are attempting to Paste '"+sourceRelationshipTN+"' relationship type\ninto '"+targetRelationshipTN+"' relationship.\nThey are different relationship types. Do you wish to proceed? ");
        if(!convert)
        {
          this.clearStatusMessage(statusId);
          return "user abort";
        }
      }
      targetItem.setType(targetRelationshipTN);
    }
    else
    {
      this.clearStatusMessage(statusId);
      return false;
    }
  }

  targetItem.setNewID();
  targetItem.setAction('add');
  targetItem.setAttribute('isTemp','1');
  parentItem.setAttribute('isDirty','1');

  var sourceProperties = getProperties4ItemType(sourceRelationshipTN);
  var targetProperties = getProperties4ItemType(targetRelationshipTN);

  var srcCount = sourceProperties.getItemCount();
  var trgCount = targetProperties.getItemCount();

  var sysProperties = "^id$|^created_by_id$|^created_on$|^modified_by_id$|^modified_on$|^classification$|^keyed_name$|^current_state$|^state$|^locked_by_id$|^is_current$|^major_rev$|^minor_rev$|^is_released$|^not_lockable$|^css$|^source_id$|^behavior$|^sort_order$|^config_id$|^new_version$|^generation$|^managed_by_id$|^owned_by_id$|^history_id$|^relationship_id$";

  if(as_is!=true)sysProperties+="|^permission_id$"

  var regSysProperties = new RegExp(sysProperties,"ig");
  for(var i=0; i<srcCount; i++)
  {
    var sourceProperty = sourceProperties.getItemByIndex(i);
    var srcPropertyName = sourceProperty.getProperty('name');
    var srcPropertyDataType = sourceProperty.getProperty('data_type');

    if(srcPropertyName.search(regSysProperties)!=-1) continue;

    for(var j=0; j<trgCount; ++j)
    {
      var targetProperty = targetProperties.getItemByIndex(j);
      var trgPropertyName = targetProperty.getProperty('name');
      var trgPropertyDataType = targetProperty.getProperty('data_type');

      if((srcPropertyName==trgPropertyName)&&(srcPropertyDataType==trgPropertyDataType))
      {
        var item = sourceItem.getPropertyItem(srcPropertyName);
        if(!item)
        {
          var value = sourceItem.getProperty(srcPropertyName);
          targetItem.setProperty(srcPropertyName,value);
        }
        else
        {
          targetItem.setPropertyItem(srcPropertyName,item);
        }
        break;
      }
    }
  }
  setRelated(targetItem);
  if(!parentItem.selectSingleNode('Relationships'))
  {
    parentItem.appendChild(parentItem.ownerDocument.createElement('Relationships'));
  }
  var res = parentItem.selectSingleNode("Relationships").appendChild(targetItem.node.cloneNode(true));
  this.clearStatusMessage(statusId);
  return res;
}


Aras.prototype.isLCNCompatibleWithRT = function Aras_isLastCopyNodeCompatibleWithRelationshipType(targetRelatedTN)
{
  var sourceRelatedTN = this.clipboard.getLastCopyRelatedItemTypeName();
  if(!sourceRelatedTN && !targetRelatedTN) return true;
  if(sourceRelatedTN == targetRelatedTN) return true;
  return false;
}

Aras.prototype.isLCNCompatibleWithRTOnly = function Aras_isLastCopyNodeCompatibleWithRelationshipTypeOnly(targetRelationshipTN)
{
  var sourceRelationshipTN = this.clipboard.getLastCopyRTName();
  if(!sourceRelationshipTN&&!targetRelationshipTN) return true;
  if(sourceRelationshipTN==targetRelationshipTN) return true;
  return false;
}

Aras.prototype.isLCNCompatibleWithIT = function Aras_isLastCopyNodeCompatibleWithItemType(itemTypeID)
{
  var clipboardItem = this.clipboard.getLastCopyItem();
  return this.isClItemCompatibleWithIT(clipboardItem,itemTypeID);
}

Aras.prototype.isClItemCompatibleWithIT = function Aras_IsClipboardItemCompatibleWithItemType(clipboardItem,itemTypeID)
{
  var RelationshipTypeName = clipboardItem.relationship_itemtype;

  if(!RelationshipTypeName||!itemTypeID)
    return false;

  var relTypeId = top.aras.getRelationshipTypeId(RelationshipTypeName);
  return relTypeId != "" ? true : false;
}

Aras.prototype.isClItemCompatibleWithRT = function Aras_IsClipboardItemCompatibleWithRelationshipType(clipboardItem,targetRelatedTN)
{
  var sourceRelatedTN = clipboardItem.related_itemtype;
  if(!sourceRelatedTN&&!targetRelatedTN) return true;
  if(sourceRelatedTN==targetRelatedTN) return true;
  return false;
}

/*-- getAssignedTasks
 *
 *   Returns the Active and Pending tasks for the user (Workflow Activities, Project Activities, FMEA Action Items).
 *   The user's tasks are those assigned to an Identity for which the user is a Member
 *   workflowTasks, projectTasks and actionTasks are booleans (1/0)
 *
 */
Aras.prototype.getAssignedTasks = function(inBasketViewMode, workflowTasks, projectTasks, actionTasks)
{
  with (this)
  {
    var body = '<params><inBasketViewMode>' + inBasketViewMode + '</inBasketViewMode>';
    body += '<workflowTasks>' + workflowTasks + '</workflowTasks>';
    body += '<projectTasks>' + projectTasks + '</projectTasks>';
    body += '<actionTasks>' + actionTasks + '</actionTasks></params>';
    var statusId = showStatusMessage(0, '   Getting user activities...', system_progressbar1_gif);
    var res = soapSend('GetAssignedTasks', body);

    if (statusId != -1)
    {
      clearStatusMessage(statusId);
    }

    if (res.getFaultCode()!=0)
    {
      top.aras.AlertError(res.getFaultDetails(), res.getFaultString(), res.getFaultActor());
      return false;
    }
    return res.results.text;
  }
}

Aras.prototype.getFormForDisplay = function Aras_getFormForDisplay(id, mode, alertError, is_bgrequest, readyResultIfNeed)
{
  // this function is not a part of public API. please do not use it
  if (alertError===undefined) alertError = true;

  // if form is new return form from client cache
  var formNd = this.getItemById('', id, 0);
  if (formNd && this.isTempEx(formNd))
  {
    var formItem =  this.newIOMItem("Form");
    formItem = this.newIOMItem();
    formItem.dom  = formNd.ownerDocument;
    formItem.node = formNd;
    return formItem;
  }

  var isAsync = (this.semaphore != null && is_bgrequest);
  var Cache = this.getCacheObject();
  var resIOMItem = Cache.Forms[id];
  if (!resIOMItem)
  {
    var req = "<Item type='Form'>";
    if (mode=='by-name') req += "<name>" + id + "</name>";
    else req += "<id>" + id + "</id>";

    req += "</Item>";

    var res = readyResultIfNeed;
    
    if (!res)
    {
      var statusId = 0;
      var asynch_controller = null;
      if (isAsync)
      {
        asynch_controller = new SoapController(cllbck);
        asynch_controller.initialParams = {id:id, mode:mode, alertError:alertError};
        function cllbck(soapResult)
        {
          soapResult.arasableObj.semaphore.SetBGRequest( false );
          var curSoapCntrlr = this;
          var obj = curSoapCntrlr.initialParams;
          soapResult.arasableObj.getFormForDisplay(obj.id, obj.mode, obj.alertError, true, soapResult);
        }
      }
      else
      {
        // Show progress image in the status bar for main requests only
        statusId = this.showStatusMessage(0, '   Loading ' + (mode=='by-name' ? id:"") + ' form ...', system_progressbar1_gif);
      }
      
      res = this.soapSend("GetFormForDisplay", req, null, null, asynch_controller, is_bgrequest);
      
      if (isAsync)
      {
        return;
      }
      else
      {
        this.clearStatusMessage(statusId);
      }
    }
    if (res.getFaultCode() > 0)
    {
      if (!is_bgrequest && alertError)
      {
        this.AlertError(res.getFaultDetailsFull(), res.getFaultString());
      }
      
      var resIOMError = this.newIOMInnovator().newError( res.getFaultDetailsFull() );
      return resIOMError;
    }
    res = res.getResult();
    resIOMItem = this.newIOMItem();
    resIOMItem.dom  = res.ownerDocument;
    resIOMItem.node = res.selectSingleNode("Item");

    Cache.Forms[id] = resIOMItem;
  }
  else
  {
    if( isAsync )
    {
      this.semaphore.SetBGRequest( false );
    }
  }

  // Mark that the item type was requested by main thread in this session
  if (!is_bgrequest)
  {
    var ftypeName;
    try
    {
      ftypeName = resIOMItem.getProperty( "name" );
    }
    catch(exc)
    {
      ftypeName = null;
    }
    
    if( ftypeName != null )
      this.commonProperties.favoriteMetaData.markAsRequested( "FR", ftypeName );
  }

  return resIOMItem;
}

Aras.prototype.clearClientMetadataCache = function Aras_resetCachedMetadataOnClient()
//this is private internal function
//returns reset Cache object.
{
  var mainWnd = this.getMainWindow();
  var Cache = mainWnd.Cache;
  if (!Cache) return this.getCacheObject();
  
  //remove cached forms: their metadata (xml) and generated html
  for (var formID in Cache.Forms) this.removeFormFromClientCache(formID);
  
  this.makeItemsGridBlank();
  mainWnd.Cache = null;
  
  return this.getCacheObject();
}

Aras.prototype.getCacheObject = function Aras_getCacheObject() {
  //this is private internal function
  var mainWnd = this.getMainWindow();
  var Cache = mainWnd.Cache;

  if (!Cache) {
    Cache = this.newObject();
    mainWnd.Cache = Cache ;

    Cache.ItemTypes       = this.newObject();
    Cache.ItemTypes.Dictionary = this.newObject();
    Cache.ItemTypes.Names = this.newObject();
    Cache.ItemTypes.Ids   = this.newObject();
    
    Cache.RelationshipTypes = this.newObject();
    Cache.RelationshipTypes.Ids = this.newObject();
    Cache.RelationshipTypes.Names = this.newObject();
    Cache.Forms = this.newObject();
    Cache.Forms.Ids = this.newObject();
    Cache.Lists = this.newObject();
  }

  //for now because there are places where cache is accessed directly instead of call to this function
  if (!Cache.ItemTypes) Cache.ItemTypes = this.newObject();
  if (!Cache.ItemTypes.Dictionary) Cache.ItemTypes.Dictionary = this.newObject();
  if (!Cache.ItemTypes.Names) Cache.ItemTypes.Names = this.newObject();
  if (!Cache.ItemTypes.Ids) Cache.ItemTypes.Ids = this.newObject();
  if (!Cache.RelationshipTypes) Cache.RelationshipTypes = this.newObject();
  if (!Cache.RelationshipTypes.Ids) Cache.RelationshipTypes.Ids = this.newObject();
  if (!Cache.RelationshipTypes.Names) Cache.RelationshipTypes.Names = this.newObject();
  if (!Cache.Forms) Cache.Forms = this.newObject();
  if (!Cache.Forms.Ids) Cache.Forms.Ids = this.newObject();
  if (!Cache.List) Cache.List = this.newObject();

  return mainWnd.Cache;
}

Aras.prototype.cacheItemTypeNameAndId = function Aras_cacheItemTypeNameAndId(itemTypeName, itemTypeId)
{
  //this method is for internal system use *only*
  var Cache = this.getCacheObject();
  Cache.ItemTypes.Names[itemTypeId] = itemTypeName;
  Cache.ItemTypes.Ids[itemTypeName] = itemTypeId;
}

Aras.prototype.cacheRelshipTypeNameAndId = function Aras_cacheItemTypeNameAndId(relTypeName, relTypeId)
{
  //this method is for internal system use *only*
  var Cache = this.getCacheObject();
  Cache.RelationshipTypes.Names[relTypeId] = relTypeName;
  Cache.RelationshipTypes.Ids[relTypeName] = relTypeId;
}


Aras.prototype.getItemTypeDictionary = function Aras_getItemTypeDictionary(criteriaValue, criteriaName) {
  //this function is only a wrapper around for getItemTypeForClient
  //please do not use this function. call getItemTypeForClient instead.
  return this.getItemTypeForClient(criteriaValue, criteriaName);
}

Aras.prototype.getItemTypeForClient = function Aras_getItemTypeForClient(criteriaValue, criteriaName, is_bgrequest, readyResultIfNeed)
{
//this function is a very specific function. please use it only if it is critical for you
//and there is no another good way to solve your task.
  if (criteriaName === undefined) criteriaName = "name";
  
  var isAsync = (this.semaphore != null && is_bgrequest);
  var Cache = this.getCacheObject();
  
  var itemTypeName;
  if (criteriaName == "name") itemTypeName = criteriaValue;
  else if (criteriaName == "id") itemTypeName = Cache.ItemTypes.Names[criteriaValue];
  else throw new Error(1, "Not supported criteria (" + criteriaName + ").");

  var resIOMItem = (itemTypeName ? Cache.ItemTypes.Dictionary[itemTypeName] : undefined);
  if (!resIOMItem)
  {
    var res = readyResultIfNeed;
    if (!res)
    {
      var req = "<Item type='ItemType'><" + criteriaName + ">" + criteriaValue + "</" + criteriaName + "></Item>";
      
      // Show progress image in the status bar for main requests only
      var statusId = 0;
      var asynch_controller = null;
      if (isAsync)
      {
        asynch_controller = new SoapController(cllbck);
        asynch_controller.initialParams = {criteriaValue:criteriaValue, criteriaName:criteriaName};
        function cllbck(soapResult)
        {
          soapResult.arasableObj.semaphore.SetBGRequest( false );
          var curSoapCntrlr = this;
          var obj = curSoapCntrlr.initialParams;
          soapResult.arasableObj.getItemTypeForClient(obj.criteriaValue, obj.criteriaName, true, soapResult);
        }
      }
      else
      {
        statusId = this.showStatusMessage(0, '   Loading ItemType ' + (itemTypeName ? itemTypeName : '') + '   ...', system_progressbar1_gif);
      }
      
      res = this.soapSend("GetItemTypeForClient", req, null, null, asynch_controller, is_bgrequest);
      
      if (isAsync)
      {
        return;
      }
      else
      {
        this.clearStatusMessage(statusId);
      }
    }
    if (res.getFaultCode() > 0)
    {
      if (!is_bgrequest)
        this.AlertError(res.getFaultDetailsFull(), res.getFaultString());
      
      var resIOMError = this.newIOMInnovator().newError( res.getFaultDetailsFull() );
      return resIOMError;
    }
    res = res.getResult();
    resIOMItem = this.newIOMItem();
    resIOMItem.dom  = res.ownerDocument;
    resIOMItem.node = res.selectSingleNode("Item");

    itemTypeName = resIOMItem.getProperty("name");//without this assignment itemTypeName may be undefined
    Cache.ItemTypes.Dictionary[itemTypeName] = resIOMItem;
    this.cacheItemTypeNameAndId(itemTypeName, resIOMItem.getID());

    var relas = resIOMItem.getItemsByXPath('Relationships/Item[@type="RelationshipType"]');
    var c = relas.getItemCount();
    for (var i=0; i<c; i++)
    {
      var rela = relas.getItemByIndex(i);
      Cache.RelationshipTypes[rela.getID()] = rela;
      this.cacheRelshipTypeNameAndId(rela.getProperty("name"), rela.getID());
      if (rela.getProperty("relationship_id") && rela.getPropertyAttribute("relationship_id", "type") == "ItemType")
      {
        var itName = rela.getPropertyAttribute("relationship_id", "name");
        var itId = rela.getProperty("relationship_id");
        if (itName && itId)
          this.cacheItemTypeNameAndId(itName, itId);
      }
    }
    
    var relas = resIOMItem.getItemsByXPath("Relationships/Item[@type='View']/related_id/Item[@type='Form']");
    c = relas.getItemCount();
    for (var i = 0; i < c; i++)
    {
      var rela = relas.getItemByIndex(i);
      Cache.Forms.Ids[rela.getProperty("name")] = rela.getID();
    }
  }
  else
  {
    if( isAsync )
    {
      this.semaphore.SetBGRequest( false );
    }
  }

  // Mark that the item type was requested by main thread in this session
  if( !is_bgrequest && itemTypeName )
    this.commonProperties.favoriteMetaData.markAsRequested( "IT", itemTypeName );

  return resIOMItem;
}

Aras.prototype.getItemTypeId = function Aras_getItemTypeId(name)
{
  var Cache = this.getCacheObject();

  var result = Cache.ItemTypes.Ids[name];
  if( !result )
  {
    var it = this.getItemFromServerByName('ItemType',name,'name',false);
    if (!it) return '';
    
    result = it.getID();
    this.cacheItemTypeNameAndId(name, result);
  }
  
  return result;
}

Aras.prototype.getItemTypeName = function Aras_getItemTypeName(id)
{
  var Cache = this.getCacheObject();

  var result = Cache.ItemTypes.Names[id];
  if (!result)
  {
    var it = this.getItemTypeForClient(id, "id");
    if (it.isError()) return "";
    
    result = it.getProperty("name");
    this.cacheItemTypeNameAndId(result, id);
  }

  return result;
}

Aras.prototype.getRelationshipTypeId = function Aras_getRelationshipTypeId(name)
{
  var Cache = this.getCacheObject();

  var result = Cache.RelationshipTypes.Ids[name];
  if( !result )
  {
    var rt = this.getItemFromServerByName('RelationshipType', name, 'name', false);
    if (!rt) return '';
    
    result = rt.getID();
    this.cacheRelshipTypeNameAndId(name, result);
  }
  
  return result;
}

Aras.prototype.getRelationshipTypeName = function Aras_getRelationshipTypeId(id)
{
  var Cache = this.getCacheObject();

  var result = Cache.RelationshipTypes.Names[id];
  if( !result )
  {
    var rt = this.getItemFromServer('RelationshipType', id, 'id', false);
    if (!rt) return '';
        
    result = rt.getProperty("name");
    this.cacheRelshipTypeNameAndId(result, id);
  }
  
  return result;
}

Aras.prototype.getFormId = function Aras_getFormId(name)
{
  var Cache = this.getCacheObject();

  var result = Cache.Forms.Ids[name];
  if( !result )
  {
    var rt = this.getItemFromServerByName('Form', name, 'name', false);
    if (!rt) return '';
    
    result = rt.getID();
    Cache.Forms.Ids[rt.getProperty("name")] = result;
  }
  
  return result;
}

Aras.prototype.clearCachedRelationshipType = function Aras_clearCachedRelationshipType(id)
{
  var mainWnd = this.getMainWindow();
  if (!mainWnd) return true;
  if(!mainWnd.Cache) return true; 

  var Cache   = mainWnd.Cache;
  if (!Cache.RelationshipTypes) return true;
  
  if (Cache.RelationshipTypes[id])
    Cache.RelationshipTypes[id] = null;
    
  if (Cache.RelationshipTypes.Names[id])
  {
    Cache.RelationshipTypes.Ids[Cache.RelationshipTypes.Names[id]] = null;
    Cache.RelationshipTypes.Names[id] = null;
  }
}

Aras.prototype.getRelationshipType = function Aras_getRelationshipType(id)
{
  var mainWnd = this.getMainWindow();
  if (!mainWnd) return;
  if(!mainWnd.Cache) mainWnd.Cache = mainWnd.aras.newObject();

  var Cache   = mainWnd.Cache;
  if (!Cache.RelationshipTypes) return false;
  if (Cache.RelationshipTypes[id]) return Cache.RelationshipTypes[id];

  var relationshipType = Cache.RelationshipTypes[id];
  if (!relationshipType)
  {
    /*
      a query should be:
        <Item type="RelationshipType" id="{id}" action="get" select="name,label,auto_search,copy_permissions,core,default_page_size,description,grid_view,hide_in_all,inc_rel_key_name,inc_related_key_name,is_list_type,max_occurs,min_occurs,new_show_related,related_notnull,related_option,create_related,use_src_access,source_id,relationship_id,related_id" related_expand="0">
          <Relationships>
            <Item type="Relationship View" action="get" select="grid,start_page,parameters,related_id" related_expand="0" isCriteria="0"/>
            <Item type="Relationship Grid Event" action="get" select="grid_event,related_id(name,method_type,method_code)" isCriteria="0"/>
          </Relationships>
        </Item>
    */
    
  	relationshipType = this.getItemFromServer('RelationshipType', id,
  	  'name,label,auto_search,copy_permissions,core,default_page_size,description,' +
  	  'grid_view,hide_in_all,inc_rel_key_name,inc_related_key_name,is_list_type,'+
  	  'max_occurs,min_occurs,new_show_related,related_notnull,related_option,'+
  	  'create_related,use_src_access,source_id,relationship_id,related_id',
  	  false);
    if (relationshipType)
    {
      Cache.RelationshipTypes[id] = this.newIOMItem();
      Cache.RelationshipTypes[id].loadAML(relationshipType.node.xml);
      this.cacheRelshipTypeNameAndId(relationshipType.getProperty('name'), relationshipType.getID());
      return Cache.RelationshipTypes[id];
    }
  }
  else 
    return relationshipType;
}


Aras.prototype.getItemFromServer = function Aras_getItemFromServer(itemTypeName,id,selectAttr,related_expand)
{
  if(!related_expand)
  {
    related_expand = false;
  }

  var qry = new top.Item(itemTypeName,'get');
  qry.setAttribute('related_expand',(related_expand)?'1':'0');
  qry.setAttribute('select',selectAttr);
  qry.setProperty('id', id);

  var results = qry.apply();

  if (results.isEmpty())
  {
    return false;
  }

  if(results.isError())
  {
    alert(results.getErrorDetail());
    return false;
  }

  return results.getItemByIndex(0);
}

Aras.prototype.getItemFromServerByName = function Aras_getItemFromServer(itemTypeName,name,selectAttr,related_expand)
{
  if(!related_expand)
  {
    related_expand = false;
  }

  var qry = this.newIOMItem(itemTypeName,'get');
  qry.setAttribute('related_expand',(related_expand)?'1':'0');
  qry.setAttribute('select',selectAttr);
  qry.setProperty('name',name);

  var results = qry.apply();

  if (results.isEmpty())
  {
    return false;
  }

  if(results.isError())
  {
    alert(results.getErrorDetail());
    return false;
  }

  return results.getItemByIndex(0);
}

Aras.prototype.getItemFromServerWithRels = function Aras_getItemFromServerWithRels(itemTypeName,id,itemSelect,reltypeName,relSelect,related_expand)
{
  if(!related_expand)
  {
    related_expand = false;
  }

  var qry = new top.Item(itemTypeName,'get');
  qry.setProperty('id',id);
  qry.setAttribute('select',itemSelect);

  if(reltypeName)
  {
    var rel = new top.Item(reltypeName,'get');
    rel.setAttribute('select',relSelect);
    rel.setAttribute('related_expand',(related_expand)?'1':'0');
    qry.addRelationship(rel);
  }

  var results = qry.apply();

  if (results.isEmpty())
  {
    return false;
  }

  if(results.isError())
  {
    alert(results.getErrorDetail());
    return false;
  }

  return results.getItemByIndex(0);
}


// This is not used and should be removed...
Aras.prototype.getFile = function Aras_getFile(value,fileSelect)
{
  var qry = new top.Item('File','get');
  qry.setAttribute('select',fileSelect);
  qry.setID(value);

  var results = qry.apply();

  if (results.isEmpty())
  {
    return false;
  }

  if(results.isError())
  {
    alert(results.getErrorDetail());
    return false;
  }
  return results.getItemByIndex(0);
}

Aras.prototype.refreshWindows = function Aras_refreshWindows(message, results, saveChanges)
{
  var nodeWithIDs = message.selectSingleNode("event[@name='ids_modified']");
  if (saveChanges == undefined)
    saveChanges = true;

  // Skip the refresh if this is the unlock portion of the 'Save, Unlock and Close' operation
  if (!saveChanges)
    return;

  var parentID = "";
  if (nodeWithIDs && results)
  {
    var IDs = nodeWithIDs.getAttribute('value');
    var IDsArray = IDs.split('|');

    var itemNode = results.selectSingleNode("//Item");
    var currentID = 0;
    if (itemNode)
      var currentID = itemNode.getAttribute("id");

    try
    {
      var mainWindow = this.getMainWindow();
      if (mainWindow.main.work.isItemsGrid)
      {
        var gridApplet = mainWindow.main.work.gridContainer;
        for(var chID in IDsArray)
        {
          var schID = IDsArray[chID];
          var itmNode = results.selectSingleNode("//Item[@id='" + schID + "']")
          if (!itmNode || gridApplet.getRowIndex(schID) == -1) continue;
          var nd = this.dom.selectSingleNode("//Item[@id='" + schID + "']");
          if (!nd) continue;
          this.refreshItemsGrid(nd, itmNode);
        }
      }
    }
    catch (excep) { }

    // Check if the window exists for the parent Item
    var doRefresh = false;
    var topWindow = top;

    for(var winId in this.windowsByName)
    {
      var win = null;
      try
      {
        win = this.windowsByName[winId];
        if(this.isWindowClosed(win))
          continue;

        if(win.top==topWindow)
          continue;

        var index = winId.lastIndexOf("_");
        parentID = winId.substr((index + 1), (winId.length - 1));
        doRefresh = true;
        break;
      }
      catch(excep)
      {
        continue;
      }
    }
    // Return if the parent window does not exist
    if (!doRefresh)
      return;

    var IDsNodes1Array = new Array();
    var IDsNodes2Array = new Array();

    for (var i in IDsArray)
    {
      var itemID = IDsArray[i];
      var nodes1 = this.dom.selectNodes("//Item[count(descendant::Item[@isTemp='1'])=0 and string(@isDirty)!='1' and Relationships/Item/related_id/Item[@id='" + itemID + "']]");
      var nodes2 = this.dom.selectNodes("//Item[@id='" + itemID + "' and string(locked_by_id)='']");

      var nodes = nodes2;
      for (var j=0;j<nodes.length;j++)
      {
        var id = nodes[j].getAttribute("id");
        var type = nodes[j].getAttribute("type");
        var bAlreadyRefreshed = false;
        for (var k = 0; k < IDsNodes2Array.length; k++)
        {
          if (id == IDsNodes2Array[k])
          {
            bAlreadyRefreshed = true;
            break;
          }
        }
        
        if (bAlreadyRefreshed)
          continue;
        else
          IDsNodes2Array.push(id);
          
        if (id == currentID)
          continue;
          
        if (type == 'Life Cycle Map' || type == 'Form' || type == 'Workflow Map' || type == 'ItemType' || type == 'RelationshipType')
          continue;
          
        var configIdNode = nodes[j].selectSingleNode("config_id");
        if (configIdNode)
        {
          var configId = configIdNode.text;
          this.itemsCache.deleteItem(id);
          var itemNd = this.getItem(type, "config_id='" + configId + "' and is_current='1'", '<config_id>'+  configId +'</config_id><is_current>1</is_current>');
          var win = this.uiFindWindowEx(id);
          if (win) this.uiReShowItemEx(id, itemNd);
          this.refreshItemsGrid(nodes[j], itemNd);
        }
      }

      nodes = nodes1;
      for (var j=0;j<nodes.length;j++)
      {
        var id = nodes[j].getAttribute("id");
        var type = nodes[j].getAttribute("type");
        var bAlreadyRefreshed = false;
        for (var k = 0; k < IDsNodes1Array.length; k++)
        {
          if (id == IDsNodes1Array[k])
          {
            bAlreadyRefreshed = true;
            break;
          }
        }
        
        if (bAlreadyRefreshed)
          continue;
        else
          IDsNodes1Array.push(id);
          
        if (id == currentID)
          continue;
          
        if (type == 'Life Cycle Map' || type == 'Form' || type == 'Workflow Map' || type == 'ItemType')
          continue;
          
        //IR-006509        
        if (!this.isDirtyEx(nodes[j]))
        {
          var related_ids = nodes[j].selectNodes('Relationships/Item/related_id[Item/@id="'+currentID+'"]');//get related_id list with items with id=currentID
          
          var relship_id;
          var tmpItemNd;
          var res_related_id;
          //update related_id nodes in cache          
          for (var i_r=0; i_r<related_ids.length; i_r++) {
            
            relship_id = related_ids[i_r].parentNode.getAttribute('id');
            relship_type = related_ids[i_r].parentNode.getAttribute('type');            
            res = this.soapSend('GetItem', '<Item type="'+relship_type+'" id="'+relship_id+'" select="related_id"/>', undefined, false);
            
            if (res.getFaultCode()==0)
            {
              res_related_id = res.getResult().selectSingleNode('Item/related_id');
              
              //update attributes and child nodes
              var attr;
              for (var i_att=0; i_att<res_related_id.attributes.length; i_att++)
              {
                attr = res_related_id.attributes[i_att];
                related_ids[i_r].setAttribute(attr.nodeName,attr.nodeValue);
              }
              related_ids[i_r].removeChild(related_ids[i_r].selectSingleNode('Item[@id="'+currentID+'"]'));//delete related_id item
              related_ids[i_r].appendChild(res_related_id.selectSingleNode('Item'));//append related_id item
            }            
          }
        } 
        var itemNd = nodes[j];
        
        var win = this.uiFindWindowEx(id);
        if (win) this.uiReShowItemEx(id, itemNd);
      }
    }
  }
}

Aras.prototype.refreshItemsGrid = function Aras_refreshItemsGrid(oldItem, updatedItem, del_OR_add_Row_ifIDchanged) {

  var mainWindow = this.getMainWindow();
  var itemID = oldItem.getAttribute('id');
  var itemTypeName = oldItem.getAttribute('type');

  if (del_OR_add_Row_ifIDchanged === undefined) del_OR_add_Row_ifIDchanged = true;

  if (!updatedItem) return false;
  var updatedID = updatedItem.getAttribute('id');

  try {
    if (!mainWindow.main.work.isItemsGrid) return false;
  }
  catch (excep) { return false; }

  if (itemTypeName == 'ItemType') {
    if (itemID == mainWindow.main.work.itemTypeID) {
      mainWindow.main.work.location.replace('about:blank');
      return true;
    }
  }

  if (mainWindow.main.work.itemTypeName!=itemTypeName) return false;

  var gridApplet = mainWindow.main.work.gridContainer;
  if (gridApplet.getRowIndex(itemID) == -1 ) return true;

  if (!del_OR_add_Row_ifIDchanged &&
      gridApplet.getRowIndex(updatedItem.getAttribute("id")) == -1) {
    return true;
  }

  var wasSelected = (gridApplet.getSelectedItemIds(';').search(itemID) > -1);

  if (del_OR_add_Row_ifIDchanged && updatedID != itemID) {
    mainWindow.main.work.deleteRow(oldItem);
  }
  mainWindow.main.work.updateRow(updatedItem);

  if (wasSelected) {
    if (updatedID == itemID) mainWindow.main.work.onSelectItem(itemID);
    else {
      var currSel = gridApplet.getSelectedId();
      //if (currSel)
      mainWindow.main.work.onSelectItem(currSel);
    }
  }//if (wasSelected)

  return true;
}

Aras.prototype.dirtyItemsHandler = function Aras_dirtyItemsHandler () {
  if (this.getCommonPropertyValue("exitWithoutSavingInProgress")) return;
  var dirtyExist =
  (
    null != top.aras.dom.selectSingleNode(
      "/Innovator/Items/Item[@action!='' and (@isTemp='1' or (locked_by_id='" +
      top.aras.getUserID() +
      "' and (@isDirty='1' or .//Item/@isDirty='1' or .//Item/@isTemp='1')))]")
  );

  if (dirtyExist)
  {
    var param  = new Object();
    param.aras = top.aras;
    return showModalDialog('dirtyItemsList.html', param, 'dialogHeight:500px; dialogWidth:400px; status:0; help:0; resizable:1; scroll:0;');
  }
}

Aras.prototype.openedWindowsHandler = function Aras_openedWindowsHandler (dhtmlEvent)
{
    var openedExist = (this.getOpenedWindowsCount() > 0);

  if (openedExist)
  {
    var specialFlag = this.getCommonPropertyValue("exitWithoutSavingInProgress");
    if (this.isFirstCall_of_openedWindowsHandler && !specialFlag)
    {
      var param = new Object();
      param.buttons = new Object();
      param.buttons.btnYes = 'Yes';
      param.buttons.btnNo = 'No';
      param.defaultButton = 'btnYes';
      param.message = "There are Innovator windows still open, would you like to try to close them all now?";
      var resButton = showModalDialog(this.getBaseURL()+'/scripts/groupChgsDialog.html', param,  'dialogHeight:130px;dialogWidth:300px;center:yes;resizable:yes;status:no;help:no;');
      if (resButton != 'btnYes')
        delete this.isFirstCall_of_openedWindowsHandler;
    }
    if (this.isFirstCall_of_openedWindowsHandler)
    {
      delete this.isFirstCall_of_openedWindowsHandler;
      var mainWnd = this.getMainWindow();
      var opWndsCount = this.getOpenedWindowsCount(true);
      this.ShowSplashScreen(mainWnd, opWndsCount, "top.aras.updateOfWindowsClosingProgress");
      if (specialFlag) return {logout_confirmed:true};
      
      openedExist = (this.getOpenedWindowsCount() > 0);
    }
    
    if (openedExist && (specialFlag ? (dhtmlEvent == "onunload") : true))
    {
      var param  = new Object();
      param.aras = top.aras;
      param.mode = "opened_windows";
      param.event = dhtmlEvent;
      return showModalDialog('dirtyItemsList.html', param, 'dialogHeight:500px; dialogWidth:400px; status:0; help:0; resizable:1; scroll:0;');
    }
  }
  
  if (openedExist)
    return false;
  else
    return {logout_confirmed:true};
}


Aras.prototype.inner_getConditionForSite = function Aras_inner_getConditionForSite()
{
  var res = "<identity_id>" +
             "<Item type='Identity'>" +
               "<name>World</name>" +
             "</Item>" +
           "</identity_id>";
  return res;
}

Aras.prototype.inner_getConditionForUser = function Aras_inner_getConditionForUser()
{
  var res;
  var userNd = this.getLoggedUserItem();
  var identityNd = userNd.selectSingleNode("Relationships/Item[@type='Alias']/related_id/Item[@type='Identity']");
  if(!identityNd) return "";
  
  res = "<identity_id>" + identityNd.getAttribute("id") + "</identity_id>";
  return res;
}

Aras.prototype.inner_getNewPreferenceItem = function Aras_inner_getNewPreferenceItem()
{
  var prefItem = this.newItem("Preference");

  var userNd = this.getLoggedUserItem();
  var identityNd = userNd.selectSingleNode("Relationships/Item[@type='Alias']/related_id/Item[@type='Identity']");
  if (!identityNd) return "";
  
  this.setItemProperty(prefItem,"identity_id",identityNd.getAttribute("id"));

  return prefItem;
}


/*
getPreference - getting innovator preferences, such as Core_ItemGridLayout,PM_ProjectGridLayout,etc.

It uses two forms of querying:
- using prefITName and levels
- using prefQuery
prefType is for determining preference type, if nothing specified, then
it searches for user type then if nothing found - site type (1 = site,2 = user)

returns Preference node with corresponding relationships
*/

Aras.prototype.getPreference = function Aras_getPreference(prefITName,levels,prefQuery,prefType)
{
  prefType = parseInt(prefType,10);
  var xml = "<Item type='Preference' action='get'>"
  
  if(prefType == 1) // Site
  {
    xml += this.inner_getConditionForSite();
  }
  else if(prefType == 2) // User
  {
    xml += this.inner_getConditionForUser();
  }
  else
  {
    var tmpXml = "<Item type='Preference' action='get' select='id'>";
    tmpXml += this.inner_getConditionForUser();
    tmpXml += "</Item>";
    
    var res = this.applyItem(tmpXml);
    if(!res || typeof(res)!="string" || res.indexOf("Item")==-1)
    {
      prefType = 1; // Site
      tmpXml = "<Item type='Preference' action='get' select='id'>";
      tmpXml += this.inner_getConditionForSite();
      tmpXml += "</Item>";
      res = this.applyItem(tmpXml);
      if(res && typeof(res)=="string" && res.indexOf("Item")!=-1)
      {
        var tmpDom = this.createXMLDocument();
        tmpDom.loadXML(res);
        var prefItem = tmpDom.selectSingleNode("//Item[@type='Preference']");
        xml += "<id>" + prefItem.getAttribute("id") + "</id>";
      }
      else
      {
        return null;
      }
    }
    else if(res && typeof(res)=="string" && res.indexOf("Item")!=-1)
    {
      prefType = 2; // User
      var tmpDom = this.createXMLDocument();
      tmpDom.loadXML(res);
      var prefItem = tmpDom.selectSingleNode("//Item[@type='Preference']");
      xml += "<id>" + prefItem.getAttribute("id") + "</id>";
    }
  }
  
  xml += "<Relationships>";
  if(prefITName)
  {
    xml += "<Item type='" + prefITName + "'" + (levels ? " levels='" + levels + "'" : "") + "/>";
  }
  else
  {
    xml += prefQuery;
  }
  xml += "</Relationships></Item>";

  var res = this.applyItem(xml);
  var resDom = this.createXMLDocument();
  resDom.loadXML(res);
  
  
  var items = resDom.selectNodes("//Item[@type='Preference']/Relationships/Item");
  var resObj = {itemNode:null,itemNodes:null,prefType:prefType};
  
  if(items.length == 0) return null;
  else if(items.length == 1)
  {
    resObj.itemNode = items[0];
  }
  else
  {
    resObj.itemNodes = items;
  }
  
  return resObj;
}

Aras.prototype.setPreference = function Aras_setPreference(pref,prefType)
{
  if(!pref) return 1; // this is error code, which will help to find fault reason, provided because no error messages is allowed in preferences
  if(prefType) prefType = parseInt(prefType,10);
  var prefItem;

  switch(prefType)
  {
    case 1: // Site
      var xml = "<Item type='Preference' action='get' select='id'>"
      xml += this.inner_getConditionForSite();
      xml += "</Item>";
      var res = this.applyItem(xml);
      if(!res || typeof(res)!="string" || res.indexOf("Item")==-1) return 2;
      var tmpDom = this.createXMLDocument();
      tmpDom.loadXML(res);
      prefItem = tmpDom.selectSingleNode("//Item");
      prefItem.setAttribute("action","edit");
      break;
    case 2: // User
    default:
      var xml = "<Item type='Preference' action='get' select='id'>"
      xml += this.inner_getConditionForUser();
      xml += "</Item>";
      var res = this.soapSend('ApplyItem', xml);
      if (res.getFaultCode()!=0)
      {
        if (this.getCommonPropertyValue("ignoreSessionTimeoutInSoapSend") && res.isSessionTimeOutFault())
          return 6;
        else
          res = '';
      }
      else
        res = res.getResultsBody();
      if(!res || typeof(res)!="string" || res.indexOf("Item")==-1)
      {
        prefItem = this.inner_getNewPreferenceItem("Preference");
      }
      else
      {
        var tmpDom = this.createXMLDocument();
        tmpDom.loadXML(res);
        prefItem = tmpDom.selectSingleNode("//Item");
        prefItem.setAttribute("action","edit");
      }
      break;
  }
  
  if(typeof(pref) == "object")
  {
    if(pref.length)
    {
      var rels = prefItem.appendChild(prefItem.ownerDocument.createElement("Relationships"));
      var prefItemAction = prefItem.getAttribute("action");
      for(var i=0;i<pref.length;i++)
      {
        var nd = rels.appendChild(pref[i]);
        var ndAction = nd.getAttribute("action");
        if (ndAction == "add")
        {
          var whereArr = new Array();
          switch (nd.getAttribute("type"))
          {
            case "Core_GlobalLayout" :
              whereArr.push("[Core_GlobalLayout].source_id='"+prefItem.getAttribute("id")+"'");
              break;
            case "Core_ItemGridLayout" :
              whereArr.push("[Core_ItemGridLayout].source_id='"+prefItem.getAttribute("id")+"'");
              whereArr.push("[Core_ItemGridLayout].item_type_id='"+this.getItemProperty(nd, "item_type_id")+"'");
              whereArr.push("[Core_ItemGridLayout].search_mode='"+this.getItemProperty(nd, "search_mode")+"'");
              break;
            case "Core_RelGridLayout" :
              whereArr.push("[Core_RelGridLayout].source_id='"+prefItem.getAttribute("id")+"'");
              whereArr.push("[Core_RelGridLayout].rel_type_id='"+this.getItemProperty(nd, "rel_type_id")+"'");
              break;
            case "Core_FavoriteMetaData" :
              whereArr.push("[Core_FavoriteMetaData].source_id='"+prefItem.getAttribute("id")+"'");
              break;
          }
          if (whereArr.length)
          {
            nd.setAttribute("action", "merge");
            nd.setAttribute("where", whereArr.join(" AND "));
            nd.removeAttribute("id");
          }
        }
      }
      
      if (prefItemAction == "add")
      {
        prefItem.setAttribute("action", "merge");
        prefItem.setAttribute("where", "[Preference].identity_id='"+this.getItemProperty(prefItem, "identity_id")+"'");
        prefItem.removeAttribute("id");
      }
    }
    else return 3;
  }
  else return 4;

  try { this.soapSend('applyItem', prefItem.xml); } catch(e) { return 5; }
  return 0; // success code
}

Aras.prototype.mergeItemRelationships = function Aras_mergeItemRelationships(oldItem, newItem) {
  //this method is for internal purposes only.
  
  var newRelationships = newItem.selectSingleNode("Relationships");
  if (newRelationships != null) {
    var oldRelationships = oldItem.selectSingleNode("Relationships");
    if (oldRelationships == null) {
      var oldDoc = oldItem.ownerDocument;
      oldRelationships = oldItem.appendChild(oldDoc.createElement("Relationships"));
    }
    
    this.mergeItemsSet(oldRelationships, newRelationships);
  }
}

Aras.prototype.mergeItem = function Aras_mergeItem(oldItem, newItem)
{
  //this method is for internal purposes only.
  var oldId = oldItem.getAttribute("id");
  if (oldId)
  {
    var newId = newItem.getAttribute("id");
    if (newId && oldId !== newId)
    {
      return;//do not merge Items with different ids.
    }
  }
  
  var allPropsXpath = "*[local-name()!='Relationships']";
  
  var oldAction = oldItem.getAttribute("action");
  if (!oldAction) oldAction = "skip";
  
  if (oldAction == "delete")
  {
    //do not merge newItem into oldSet
  }
  else if (oldAction == "add")
  {
    //this should never happen because getItem results cannot return not saved Item. do nothing here.
  }
  else if (oldAction == "update" || oldAction == "edit")
  {
    //we can add only missing properties here and merge relationships
    var newProps = newItem.selectNodes(allPropsXpath);
    for (var i=0; i<newProps.length; i++)
    {
      var newProp = newProps[i];
      
      var propNm  = newProp.baseName;
      var oldProp = oldItem.selectSingleNode(propNm);
      
      if (!oldProp)
        oldItem.appendChild(newProp.cloneNode(true));
      else
      {
        var oldPropItem = oldProp.selectSingleNode("Item");
        if (oldPropItem)
        {
          var newPropItem = newProp.selectSingleNode("Item");
          if (newPropItem) this.mergeItem(oldPropItem, newPropItem);
        }
      }
    }
    
    //merge relationships
    this.mergeItemRelationships(oldItem, newItem);
  }
  else if (oldAction == "skip")
  {
    //all properties not containing Items can be replaced here.
    
    //process oldItem properies with * NO * Item inside
    var oldProps = oldItem.selectNodes(allPropsXpath + "[not(Item)]");
    for (var i=0; i<oldProps.length; i++)
    {
      var oldProp = oldProps[i];
      
      var propNm  = oldProp.baseName;
      var newProp = newItem.selectSingleNode(propNm);
      
      if (newProp) oldItem.replaceChild(newProp.cloneNode(true), oldProp);
      else oldItem.removeChild(oldProp);
      }
    
      //process oldItem properies with Item inside
      var oldItemProps = oldItem.selectNodes(allPropsXpath + "[Item]");
      for (var i=0; i<oldItemProps.length; i++)
      {
        var oldProp = oldItemProps[i];
        
        var propNm  = oldProp.baseName;
        var newProp = newItem.selectSingleNode(propNm);
        
        if (newProp)
        {
          var oldPropItem = oldProp.selectSingleNode("Item");
          var newPropItem = newProp.selectSingleNode("Item");
          if (newPropItem) this.mergeItem(oldPropItem, newPropItem);
          else
          {
            var oldPropItemAction = oldPropItem.getAttribute("action");
            if (!oldPropItemAction) oldPropItemAction = "skip";
            
            if (oldPropItemAction == "skip") oldItem.replaceChild(newProp.cloneNode(true), oldProp);
          }
        }
        else oldItem.removeChild(oldProp);
      }
    
      //process all newItem properties which are missing in oldItem
      var newProps = newItem.selectNodes(allPropsXpath);
      for (var i=0; i<newProps.length; i++)
      {
        var newProp = newProps[i];
        
        var propNm  = newProp.baseName;
        var oldProp = oldItem.selectSingleNode(propNm);
        
        if (!oldProp) oldItem.appendChild(newProp.cloneNode(true));
      }
    
    //merge relationships
    this.mergeItemRelationships(oldItem, newItem);
  }
}

Aras.prototype.mergeItemsSet = function Aras_mergeItemsSet(oldSet, newSet) {
  //this method is for internal purposes only.
  
  //both oldSet and newSet are nodes with Items inside. (oldSet and newSet normally are AML or Relationships nodes)
  var oldDoc = oldSet.ownerDocument;
  
  //we don't expect action attribute specified on Items from newSet
  var newItems = newSet.selectNodes("Item[not(@action)]");
  for (var i=0; i<newItems.length; i++) {
    var newItem = newItems[i];
    var newId   = newItem.getAttribute("id");
    var newType = newItem.getAttribute("type");
    
    var oldItem = oldSet.selectSingleNode("Item[@id=\"" + newId + "\"][@type=\"" + newType + "\"]");
    if (!oldItem) {
      //
      oldItem = oldSet.appendChild(oldDoc.createElement("Item"));
      oldItem.setAttribute("id", newId);
      oldItem.setAttribute("type", newType);
    }
    
    this.mergeItem(oldItem, newItem);
  }
}

// +++ Export to Office section +++
Aras.prototype.export2Office = function Aras_export2Office(gridXml, toTool, itemNd) 
  //this method is for internal purposes only.
{
  var statusId = this.showStatusMessage(0,'   Exporting...', system_progressbar1_gif);  
  var html = this.generateHtml(gridXml);
  if (itemNd && itemNd.xml)
  {
    var itemTypeNd = this.getItemTypeForClient(itemNd.getAttribute("type"), "name").node;
    if (itemTypeNd)
    {
      var itemTypeID = itemTypeNd.getAttribute("id");
      var resDom = this.createXMLDocument();
      resDom.loadXML("<Result>" + itemNd.xml + "</Result>");
      
      var xpath = 'Relationships/Item[@type="Property"]';
      var propNds = itemTypeNd.selectNodes(xpath);
  
      this.uiPrepareDOM4GridXSLT(resDom);
      var grid_xml = this.uiGenerateGridXML(resDom, propNds, null, itemTypeID, {mode:"forExport2Html"}, true);
      var tmpHtml = this.generateHtml(grid_xml);
      if (tmpHtml.indexOf("<th")==-1)
      {
        var a = tmpHtml.indexOf("<tr");
        tmpHtml = tmpHtml.substr(0, a) + getThs(propNds, this) + tmpHtml.substr(a);
      }
      
      var i = html.indexOf("<table");
      var i2 = tmpHtml.indexOf("<table");
      var i3 = tmpHtml.lastIndexOf("</table>");
      if (i>0) html = html.substr(0, i) + tmpHtml.substr(i2, i3-i2+8) + "<br/>" + html.substr(i);
      
      function getThs(propNds, arasObj)
      {
        var res = "<tr/>";
        var tmpDom = arasObj.createXMLDocument();
        tmpDom.loadXML(res);
        var styleAttr = "background-color:#d4d0c8;";
        for (var i=0; i<propNds.length; i++)
        {
          var pNd = propNds[i];
          var lbl = arasObj.getItemProperty(pNd, "label");
          var nm = arasObj.getItemProperty(pNd, "name");
          var newTh = tmpDom.documentElement.appendChild(tmpDom.createElement("th"));
          newTh.setAttribute("align", "center");
          newTh.setAttribute("style", styleAttr);
          newTh.text = (lbl ? lbl : nm);
        }
        res = tmpDom.xml;
        return res;
      }
    }
  }
  this.clearStatusMessage(statusId); 
  if (html) this.saveString2File(html, toTool);
}

Aras.prototype.generateHtml = function Aras_generateHtml(gridXml) 
  //this method is for internal purposes only.
{
  var res = "";
  var gridDom = top.aras.createXMLDocument();
  if (!gridXml) gridXml = "<table></table>";
  gridDom.loadXML(gridXml);
  if (gridDom.parseError.errorCode == 0) 
  {
    var tblNd = gridDom.selectSingleNode("//table");
    if (tblNd) tblNd.setAttribute("base_href", this.getScriptsURL());
    res = top.aras.applyXsltFile(gridDom, this.getScriptsURL()+'../styles/printGrid4Export.xsl');
  }
  return res;
}

Aras.prototype.saveString2File = function Aras_saveString2File(str, flag2DefineExtType) 
  //this method is for internal purposes only.
{
  flag2DefineExtType = flag2DefineExtType.toLowerCase();
  var ext = "unk";
  var fileNamePrefix = "export2unknown_type";
  var str4ActiveXObject = "";
  if (flag2DefineExtType.indexOf("excel")!=-1)
  {
    ext = "xls";
    fileNamePrefix = "Book";
    str4ActiveXObject = "Excel.Application";
  }
  else if (flag2DefineExtType.indexOf("word")!=-1)
  {
    ext = "doc";
    fileNamePrefix = "Doc";
    str4ActiveXObject = "Word.Application";
  }
  
  try 
  {
    var vaultApplet = top.aras.vault;
    var fn = vaultApplet.fileCreateWithSaveAsDialog(fileNamePrefix, ext);
  	if (fn != "")
  	{
      f = vaultApplet.fileOpenAppend(fn);    
      vaultApplet.fileWriteLine(str);
      vaultApplet.fileClose();
	  }
  }
  catch (excep) 
  {
    fn = "";
  }

  if (fn) 
  {
    this.AlertSuccess("File is saved as " + fn);
  }

  return true;
}
// --- Export to Office section ---

Aras.prototype.EscapeSpecialChars = function Aras_EscapeSpecialChars(str)
{
  if (!this.utilDoc) this.utilDoc = this.createXMLDocument();
  var element_t = this.utilDoc.createElement("t");
  element_t.text = str;
  var result = element_t.xml;
  return result.substr(3,result.length-7);
}

// value returned as xpath function concat(), ie addition quotes aren't needed
Aras.prototype.EscapeXPathStringCriteria = function Aras_EscapeXPathStringCriteria(str)
{
  var res = str.replace(/'/g ,"',\"'\",'");
  if (res != str) 
    return "concat('" + res + "')";
  else 
    return "'" + res + "'"
}

/*
//unit tests for Aras_isPropertyValueValid function
Boolean ? value is 0 or 1. (*)
Color ? must satisfy regexp /^#[a-f0-9]{6}$|^btnface$/i. (*)
Color List ? must satisfy regexp /^#[a-f0-9]{6}$|^btnface$/i. (*)
Date ? input string must represent a date in a supported format. (*)
Decimal ? must be a number. (*)
Federated ? read-only. No check.
Filter List ? string length must be not greater than 64. (*)
Float ? must be a number. (*)
Foreign ? read-only. No check.
Formatted Text ? No check.
Image ? string length must be not greater than 128. (*)
Integer ? must be an integer number. (*)
Item ? must be an item id (32 characters from [0-9A-F] set). (*)
List ? string length must be not greater than 64. (*)
MD5 ? 32 characters from [0-9A-F] set. (*)
Sequence ? read-only. No check.
String ? check if length of inputted string is not greater than maximum permissible string length.
         Verify against property pattern if specified. (*)
Text ? No check.

Where (*) means: Empty value is not permissible if property is marked as required.

Property definition:
 data_type - string
 pattern   - string
 is_required - boolean
 stored_length - integer
*/
/*common tests part* /
var allDataTypes = new Array("boolean", "color", "color list", "date", "decimal", "federated", "filter list", "float", "foreign", "formatted text", "image", "integer", "item", "list", "md5", "sequence", "string", "text");
function RunTest(testDescription, testDataArr, expectedResults)
{
  var failedTests = new Array();
  for (var i=0; i<testDataArr.length; i++)
  {
    var testData = testDataArr[i];
    var data_type = testData.propertyDef.data_type;
    var expectedRes = expectedResults[data_type.replace(/ /g, "_")];
    
    var r = Aras_isPropertyValueValid(testData.propertyDef, testData.propertyValue);
    
    if (r !== expectedRes)
    {
      failedTests.push(data_type);
    }
  }
  
  var resStr = (failedTests.length == 0) ? "none" : failedTests.toString();
  alert(testDescription + "\n\nFailed tests: " + resStr);
}
/**/
/*empty value tests* /
var expectedRes_EmptyValue =
  {
    boolean: true,
    color  : true,
    color_list: true,
    date   : true,
    decimal: true,
    federated: true,
    filter_list: true,
    float  : true,
    foreign: true,
    formatted_text: true,
    image  : true,
    integer: true,
    item   : true,
    list   : true,
    md5    : true,
    sequence: true,
    string : true, 
    text   : true
  };

var expectedRes_EmptyValueAndIsRequired =
  {
    boolean: false,
    color  : false,
    color_list: false,
    date   : false,
    decimal: false,
    federated: true,
    filter_list: false,
    float  : false,
    foreign: true,
    formatted_text: true,
    image  : false,
    integer: false,
    item   : false,
    list   : false,
    md5    : false,
    sequence: true,
    string : false, 
    text   : true
  };

var testData_EmptyValueAndIsRequired = new Array();
var testData_EmptyValue = new Array();
for (var i=0; i<allDataTypes.length; i++)
{
  var propertyDef = {data_type: allDataTypes[i], is_required:true};
  var testData    = {propertyDef: propertyDef, propertyValue: ""};
  testData_EmptyValueAndIsRequired.push(testData);

  propertyDef = {data_type: allDataTypes[i], is_required:false};
  testData    = {propertyDef: propertyDef, propertyValue: ""};
  testData_EmptyValue.push(testData);
}

RunTest("Empty value", testData_EmptyValue, expectedRes_EmptyValue);
RunTest("Empty value and property is required", testData_EmptyValueAndIsRequired, expectedRes_EmptyValueAndIsRequired);
/**/

Aras.prototype.isInteger = function Aras_isInteger(propertyValue)
{
  return (String(parseInt(propertyValue)) == propertyValue);
}

Aras.prototype.isPositiveInteger = function Aras_isPositiveInteger(propertyValue)
{
  return (this.isInteger(propertyValue) && parseInt(propertyValue) > 0);
}

Aras.prototype.isNegativeInteger = function Aras_isPositiveInteger(propertyValue)
{
  return (this.isInteger(propertyValue) && parseInt(propertyValue) < 0);
}

Aras.prototype.isPropertyValueValid = function Aras_isPropertyValueValid(propertyDef, propertyValue)
{
  function testFloat(s)
  {
    var testValueName = "isPropertyValueValid_testFloat_testValue";
    window[testValueName] = NaN;
    window.execScript(
      "On Error Resume Next\n" +
        "window." + testValueName + " = CDbl(\"" + s + "\")\n" +
      "On Error GoTo 0\n",
      "VBScript");
    
    return ! isNaN(window[testValueName]);
  }
  
  this.ValidationMsg = "";
  var data_type   = propertyDef.data_type;
  
  if (propertyValue !== "")
  {
    switch (data_type)
    {
      case "boolean":
        if (!propertyValue == "0" && !propertyValue == "1")
		      this.ValidationMsg = "Value of the property must be boolean.";
        break;
      case "color":
      case "color list":
	    if (!/^#[a-f0-9]{6}$|^btnface$/i.test(propertyValue))
		  this.ValidationMsg = "Value of the property is invalid. It contains incorrect symbols.";
        break;
      case "date":
        //.Net code should validate dates
        break;      
      case "decimal":
        if (!testFloat(propertyValue))
          this.ValidationMsg = "Value of the property is invalid. It must be Decimal.";
		    break;
      case "federated":
		    break;
      case "filter list":
        if (propertyValue.length > 64)
    		  this.ValidationMsg = "Length of propertie's value of type \"Filter List\" cannot be larger then 64 symbols.";
	    	break;
      case "float":
        if (!testFloat(propertyValue))
          this.ValidationMsg = "Value of the property is invalid. It must be Float.";
		    break;
      case "foreign":
      case "formatted text":
        break;      
      case "image":
        if (propertyValue.length > 128);
		      this.ValidationMsg = "Length of property of type \"Image\" cannot be larger then 128 symbols.";
        break;
      case "integer":
        if (!this.isInteger(propertyValue))
		      this.ValidationMsg = "Value of the property is invalid. It must be Integer.";
        break;      
      case "item":
        if (typeof(propertyValue) == "string" && !/^[0-9a-f]{32}$/i.test(propertyValue))
          this.ValidationMsg = "Value of the property is invalid. It must be Item ID.";
		    break;
      case "list":
        if (propertyValue.length > 64)
		      this.ValidationMsg = "Length of propertie's value of type \"List\" cannot be larger then 64 symbols.";      
		    break;
      case "md5":
        if (!/^[0-9a-f]{32}$/i.test(propertyValue))
          this.ValidationMsg = "Value of the property is invalid. It must be MD5.";
        break;
      case "sequence":
        break;      
      case "string":
        if (propertyDef.stored_length < propertyValue.length) 
        {
    		  this.ValidationMsg = "Length of the propertie's value cannot be larger then " + propertyDef.stored_length + " symbols.";
  	  	  break;
	      }        
        if (propertyDef.pattern)
        {
          var re = new RegExp(propertyDef.pattern);
          if ( !re.test(propertyValue) ) 
          {
      		  this.ValidationMsg = "Value of the property is invalid. It must correspond with pattern '" + propertyDef.pattern + "'.";
    	  	  break;
          }
        }        
        break;              
      case "text":
        break;
      default:
        throw new Error(5, "Invalid parameter propertyDef.data_type.");          
        break;
    }
  }

  if (this.ValidationMsg != "")
    this.ValidationMsg += " Edit again?";
  return this.ValidationMsg == "";
}

Aras.prototype.ValidationMsg = "";

Aras.prototype.showValidationMsg = function Aras_showValidationMsg()
{
  return confirm(this.ValidationMsg);
}
/// Indicate whether IE window is closed. 
/// Supposition: sometimes invoking of property window.closed launch exception "Permission denied". (After applying patch KB918899)
Aras.prototype.isWindowClosed = function Aras_isWindowClosed(window)
{
  var res = false;
  try
  {
    res = window.closed;
  }
  catch (e)
  {
    if (e.number != -2146828218) //"Permission denied."
      throw e;
    else
      res = true;
  }
  return res;
}

//+++ some api for classification +++
Aras.prototype.isClassPathRoot = function Aras_isClassPathRoot(class_path, itemTypeName)
{
  var r = (!class_path || class_path=="/*" || class_path=="/"+itemTypeName);
  return r;
}

Aras.prototype.getPossibleClassPaths = function Aras_getPossibleClassPaths(class_path, itemTypeName)
//returns array of possible class paths using root class path polymorphism
{
  var r = new Array();
  if (this.isClassPathRoot(class_path, itemTypeName))
  {
    r.push("");
    r.push("/*");
    r.push("/"+itemTypeName);
  }
  else
  {
    var c = class_path;
    if (c.substring(0, 1)!="/") c = "/" + c;
    var tmpArr = c.split("/");
    var tmpArr2 = new Array();
    for (var i = 2; i <tmpArr.length; i++) tmpArr2.push(tmpArr[i]);
    var lastPartOfPath = tmpArr2.join("/");
    r.push("/*/"+lastPartOfPath);
    r.push("/"+itemTypeName+"/"+lastPartOfPath);
    if (class_path!=r[0] && class_path!=r[1]) r.push(class_path);
  }
  return r;
}

Aras.prototype.areClassPathsEqual = function Aras_areClassPathsEqual(class_path1, class_path2, itemTypeName)
{
  return this.doesClassPath1StartWithClassPath2(class_path1, class_path2, itemTypeName, true);
}

Aras.prototype.doesClassPath1StartWithClassPath2 = function Aras_doesClassPath1StartWithClassPath2(class_path1, class_path2, itemTypeName, equals)
{
  var r = false;
  var arr1 = this.getPossibleClassPaths(class_path1, itemTypeName);
  var arr2 = this.getPossibleClassPaths(class_path2, itemTypeName);
  var cp1;
  var cp2;
  for (var i=0; i<arr1.length; i++)
  {
    cp1 = arr1[i];
    for (var j=0; j<arr2.length; j++)
    {
      cp2 = arr2[j];
      if (equals)
      {
        if (cp1 == cp2)
        {
          r = true;
          break;
        }
      }
      else
      {
        if (cp2.length<=cp1.length && cp1.substring(0, cp2.length)==cp2)
        {
          r = true;
          break;
        }
      }
    }
    if (r) break;
  }
  return r;
}

/*
Aras.prototype.fireUnitTestsForSelectPropNdsByClassPath = function Aras_fireUnitTestsForSelectPropNdsByClassPath()
{
  var pNms = new Array("simple classpath", "with chars to escape", "root1", "root2", "root3", "child class path", "wrong root");
  //!!!before testing remove // and the second occurence of /* in the next code line
  //var cps = new Array("/test/simple Classpath", "/*//*with \\chars\\ \" to escape<<>>[[[[]:-))))B!!!!", "", "/*", "/test", "/test/simple Classpath/its child", "/WRONG ROOT/simple Classpath");
  var checkSums = new Array(4, 4, 3, 3, 3, 5, 5);//numbers of nodes returned according to class paths stored in cps array.
  
  if (pNms.length!=cps.length || pNms.length!=checkSums.length)
  {
    alert("test setup is incorrect");
    return;
  }
  var xml = "<Item type='ItemType'><name>test</name>"+
            "<Relationships>"+
              "<Item type='Property'>"+
                "<name>"+pNms[0]+"</name>"+
                "<class_path>"+cps[0]+"</class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[1]+"</name>"+
                "<class_path><![CDATA["+cps[1]+"]]></class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[2]+"</name>"+
                "<class_path>"+cps[2]+"</class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[3]+"</name>"+
                "<class_path>"+cps[3]+"</class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[4]+"</name>"+
                "<class_path>"+cps[4]+"</class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[5]+"</name>"+
                "<class_path>"+cps[5]+"</class_path>"+
              "</Item>"+
              "<Item type='Property'>"+
                "<name>"+pNms[6]+"</name>"+
                "<class_path>"+cps[6]+"</class_path>"+
              "</Item>"+
            "</Relationships></Item>"
  var d = this.createXMLDocument();
  d.loadXML(xml);
  var itemTypeNd = d.documentElement;
  var propNds;
  var res = "Result:\n";
  var class_path;
  for (var i=0; i<cps.length; i++)
  {
    class_path = cps[i];
    propNds = this.selectPropNdsByClassPath(class_path, itemTypeNd);
    res += "class_path="+class_path + ", result="+((propNds && propNds.length==checkSums[i]) ? "true" : "false") + "\n";
  }
  alert(res);
}
*/

Aras.prototype.selectPropNdsByClassPath = function Aras_selectPropNdsByClassPath(class_path, itemTypeNd, excludePropsWithThisClassPath, ignoreProps2Delete)
{
  if (!itemTypeNd || !itemTypeNd.xml) return null;
  
  var xp = "Relationships/Item[@type='Property']";
  if (ignoreProps2Delete) xp += "[string(@action)!='delete' and string(@action)!='purge']";
  if (!class_path) class_path = "";
  var possiblePaths = this.getPossibleClassPaths(class_path, this.getItemProperty(itemTypeNd, "name"));
  for (var i=0; i<possiblePaths.length; i++)
  {
    possiblePaths[i] = "starts-with("+this.EscapeXPathStringCriteria(possiblePaths[i])+", class_path)";
  }
  var tmpXp = possiblePaths.join(" or ");
  if (excludePropsWithThisClassPath) tmpXp = "not("+tmpXp+")";
  xp += "["+tmpXp+"]";
  return itemTypeNd.selectNodes(xp);
}
//--- some api for classification ---
