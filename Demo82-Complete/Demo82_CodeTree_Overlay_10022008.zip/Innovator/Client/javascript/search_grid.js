﻿// (c) Copyright by Aras Corporation, 2004-2007.

function sortPropertiesNodes(propNd1, propNd2) {
  var sorder1 = top.aras.getNodeElement(propNd1, 'sort_order');
  if (sorder1=='') sorder1 = 1000000;
  sorder1 = parseInt(sorder1);
  if (isNaN(sorder1)) return 1;
  var sorder2 = top.aras.getNodeElement(propNd2, 'sort_order');
  if (sorder2=='') sorder2 = 1000000;
  sorder2 = parseInt(sorder2);
  if (isNaN(sorder2)) return -1;

  if (sorder1<sorder2) return -1;
  else if (sorder1==sorder2) {
    sorder1 = top.aras.getNodeElement(propNd1, 'name');
    sorder2 = top.aras.getNodeElement(propNd2, 'name');
    if (sorder1<sorder2) return -1;
    else if (sorder1==sorder2) return 0;
    else return 1;
  }
  else return 1;
}
//////////////////////////////////

var currItemType = null, itemTypeID = '', itemTypeName = '', itemTypeLabel = '', visiblePropNds, implementationType = '';
var currQryItem = null;
var currQryItemInitial = null;
var varName_pagesize = '';
var varName_colOrder = '';
var varName_colWidths = "";
var varName_searchVis;
var userMethodColumnCfgs = new Object(); //to support OnSearchDialog grid event

var logicalColumnOrderArr;//array of columns names. to store applet's logical column order (can be different from visible order)

var page = 1, pagemax = 1, itemmax = 0, pagesize = '', maxRecords = '';
var inputCol = -1;
var ps;
var timerId;
var prevQryItem;
var prevSearchVis;

var doAutosearchAndHideSearchBar = false;

function initPage(isPopup)
{
  var criteriaName;
  var criteriaValue;
  
  if (itemTypeID)
  {
    //itemTypeID has higher priority because of poly items
    //see searchDialog2.onTbItemClick("implementation_type")
    criteriaName = "id";
    criteriaValue = itemTypeID;
  }
  else if (itemTypeName)
  {
    criteriaName = "name";
    criteriaValue = itemTypeName;
  }
  else
  {
    top.aras.AlertError("Neither input Item Type name nor id is specified.");
    if (isPopup) window.close();
    return false;
  }
  var iomItemType = top.aras.getItemTypeForClient(criteriaValue, criteriaName);
  if(iomItemType.isError())
  {
    if (isPopup) window.close();
    return false;
  }

  currItemType = iomItemType.node;
  itemTypeID = currItemType.getAttribute('id');
  itemTypeName = top.aras.getItemProperty(currItemType, 'name');
  implementationType = top.aras.getItemProperty(currItemType, 'implementation_type');
  itemTypeLabel = top.aras.getItemProperty(currItemType, 'label');
  if (!itemTypeLabel) itemTypeLabel = itemTypeName;

  with (top.aras)
  {
    visiblePropNds = new Array();
    varName_pagesize = 'IT_' + itemTypeID + '_pageSize';
    varName_colOrder = 'IT_' + itemTypeID + '_colOrder';
    varName_colWidths = 'IT_' + itemTypeID + '_colWidths';
    varName_searchVis= 'IT_' + itemTypeID + '_searchVis';

    var specialSearchNds = null;
    var onSearchDialogNds = null;//to support OnSearchDialog grid event
    var colNamesWhereDefaultSearch = new Object();

    if (itemTypeID)
    {
      if (isPopup)
      {
        specialSearchNds = currItemType.selectNodes
          (
            'Relationships/Item[@type="Property"]/' +
            'Relationships/Item[@type="Grid Event" and grid_event="default_search"]/' +
            'related_id/Item[@type="Method"]'
          );

        if (sourceItemTypeName && sourcePropertyName)
        {
          var sourceItemTypeNd;
          try{ sourceItemTypeNd = top.aras.getItemTypeForClient(sourceItemTypeName, "name").node} catch (e){};
          if (sourceItemTypeNd)
          {
            onSearchDialogNds = sourceItemTypeNd.selectNodes
              (
                'Relationships/Item[@type="Property"][name="' + sourcePropertyName + '"]/' +
                'Relationships/Item[@type="Grid Event" and grid_event="onsearchdialog"]/' +
                'related_id/Item[@type="Method"]'
              );
          }
        }
      }
    }

    if (isPopup)
    {
      currQryItem = aras2.newQryItem(itemTypeName);
      currQryItemInitial = aras2.newQryItem(itemTypeName);
    }
//    if (isPopup) currQryItem = newQryItem(itemTypeName);

    var xpath;
    var loginName = getLoginName();
    if ( top.aras.isAdminUser() && itemTypeName == 'ItemType')
      xpath = 'Relationships/Item[@type="Property" and (not(is_hidden) or is_hidden=0 or name="label")]';
    else
      xpath = 'Relationships/Item[@type="Property" and (not(is_hidden) or is_hidden=0)]';
    visiblePropNds = currItemType.selectNodes(xpath);

    var nodes_tmp = new Array();
    var i;
    for (i=0; i<visiblePropNds.length; i++) nodes_tmp[i] = visiblePropNds[i];
    var val = getVariable(varName_colOrder);
    if (val != null)
    {
      val = val.split(';');
      var res = new Array();
      var newPropFlg = false;
      for (var i=0; i<nodes_tmp.length; i++)
      {
        var propNm = top.aras.getItemProperty(nodes_tmp[i], 'name');
        var j = 0;
        for (j=0; j < val.length; j++)
        {
          if (propNm == val[j])
          {
            res[j] = nodes_tmp[i];
            break;
          }
        }
        if (j == val.length)
        {
          newPropFlg = true;
          break;
        }
      }

      var duplicatedProp = false;
      if (!newPropFlg) for (var i=0; i<res.length; i++) if (res[i] == undefined)
      {
        duplicatedProp = true;
        break;
      }

      if (newPropFlg || duplicatedProp) nodes_tmp = nodes_tmp.sort(sortPropertiesNodes);
      else nodes_tmp = res;
    }
    else nodes_tmp = nodes_tmp.sort(sortPropertiesNodes);
    visiblePropNds = nodes_tmp;

    uiInitItemsGridSetups(itemTypeName, itemTypeID,  visiblePropNds);

    if ( top.aras.isAdminUser() && itemTypeName == 'ItemType')
      xpath = 'Relationships/Item[@type="Property" and (not(is_hidden) or is_hidden=0 or name="label")';
    else
      xpath = 'Relationships/Item[@type="Property" and (not(is_hidden) or is_hidden=0)';
    xpath += ' and default_search!=""]';

    var defaultSearchNds = currItemType.selectNodes(xpath);
    var condition = aras.getVariable('UseWildcards')=='true' ? 'like' : 'eq';

    for (i=0; i<defaultSearchNds.length; i++)
    {
      var defaultSearchNd = defaultSearchNds(i);
      var propNm = getItemProperty(defaultSearchNd, 'name');
      var val = getItemProperty(defaultSearchNd, 'default_search');
      currQryItem.setCriteria(propNm, val, condition);
    }

    function getVisibleColNum (propName)
    {
      for (var i=0; i<visiblePropNds.length; i++)
        if (top.aras.getItemProperty(visiblePropNds[i], "name") == propName) return (++i);

      return -1;
    }

    var methodArgs = new Object();
    methodArgs.itemTypeName  = itemTypeName;
    methodArgs.QryItem       = currQryItem;
    methodArgs.windowContext = dialogArguments.aras;
    methodArgs.itemContext   = dialogArguments.itemContext;
    methodArgs.itemSelectedID= dialogArguments.itemSelectedID;

    if (specialSearchNds && specialSearchNds.length > 0) {

      var visSR = top.aras.getVariable(varName_searchVis).split(";");
      var flg2Save = false;

      for (var i=0; i<specialSearchNds.length; i++) {
        var methodNd = specialSearchNds[i];
        var methodName = top.aras.getItemProperty(methodNd, "name");

        var propNd   = methodNd.selectSingleNode("../../../..");
        var propName = top.aras.getItemProperty(propNd, "name");
        var propDT   = top.aras.getItemProperty(propNd, "data_type");

        var colNum = getVisibleColNum(propName);
        methodArgs.property_name = propName;
        var defSearch = top.aras.evalItemMethod(methodName, currQryItem.item, methodArgs);
        if (defSearch) colNamesWhereDefaultSearch[propName] = true;

        if (colNum == -1) {
          if (defSearch) currQryItem.setCriteria(propName, defSearch, condition);
          else currQryItem.removeCriteria(propName);
        }
        else {
          flg2Save = true;

          if (defSearch) {
            visSR[colNum] = defSearch;
            currQryItem.setCriteria(propName, defSearch, condition);
          }
          else {
            visSR[colNum] = "";
            currQryItem.removeCriteria(propName);
          }
        }
      }

      if (flg2Save) top.aras.setVariable(varName_searchVis, visSR.join(";"));
    }
    if (onSearchDialogNds && onSearchDialogNds.length>0){
      
      var visSR = top.aras.getVariable(varName_searchVis).split(";");
      var flg2Save = false;
      
      var methodNd = onSearchDialogNds[0];
      var methodName = top.aras.getItemProperty(methodNd, "name");

      var propNd   = methodNd.selectSingleNode("../../../..");
      var propName = top.aras.getItemProperty(propNd, "name");
      userMethodColumnCfgs = top.aras.evalItemMethod(methodName, currQryItem.item, methodArgs);
      if (!userMethodColumnCfgs || typeof(userMethodColumnCfgs)!="object") userMethodColumnCfgs = new Object();
      var filteredPropName;
      for (filteredPropName in userMethodColumnCfgs){
        if (filteredPropName in colNamesWhereDefaultSearch) {
          delete userMethodColumnCfgs[filteredPropName];
          continue;
        }
        if (!userMethodColumnCfgs[filteredPropName].filterValue) userMethodColumnCfgs[filteredPropName].filterValue = "";
        if (!userMethodColumnCfgs[filteredPropName].isFilterFixed) userMethodColumnCfgs[filteredPropName].isFilterFixed = false;
      }
      for (filteredPropName in userMethodColumnCfgs){
      
        var colNum = getVisibleColNum(filteredPropName);
        var filterValue = userMethodColumnCfgs[filteredPropName].filterValue;
      
        if (colNum == -1) {
          if (filterValue) currQryItem.setCriteria(filteredPropName, filterValue, condition);
          else currQryItem.removeCriteria(filteredPropName);
        }
        else {
          flg2Save = true;

          if (filterValue) {
            visSR[colNum] = filterValue;
            currQryItem.setCriteria(filteredPropName, filterValue, condition);
          }
          else {
            visSR[colNum] = "";
            currQryItem.removeCriteria(filteredPropName);
          }
        }
      }
      if (flg2Save) top.aras.setVariable(varName_searchVis, visSR.join(";"));
    }

    if (currQryItemInitial && ((onSearchDialogNds && onSearchDialogNds.length>0) || (specialSearchNds && specialSearchNds.length > 0)))
    {
      currQryItemInitial.dom.loadXML(currQryItem.dom.xml);
      currQryItemInitial.item = currQryItemInitial.dom.documentElement;
      for (filteredPropName in userMethodColumnCfgs)
      {
        if (!userMethodColumnCfgs[filteredPropName].isFilterFixed)
        {
          currQryItemInitial.removeCriteria(filteredPropName);
        }
      }
      for (filteredPropName in colNamesWhereDefaultSearch)
      {
        currQryItemInitial.removeCriteria(filteredPropName);
      }
    }

    logicalColumnOrderArr = new Array();
    logicalColumnOrderArr.push("L");
    for (var i=0; i<visiblePropNds.length; i++) {
      logicalColumnOrderArr.push( top.aras.getItemProperty(visiblePropNds[i], "name") + "_D" );
    }

    var colOrderArr = top.aras.getVariable(varName_colOrder).split(";");
    var VSArr = top.aras.getVariable(varName_searchVis).split(";");
    for (var j=0; j < colOrderArr.length; j++) {
      var propNm = colOrderArr[j];
      if (propNm == "L") continue;
      setSearchCriteria(propNm, VSArr[j]);
    }

    var selectAttr = '';
    for (i=0; i<visiblePropNds.length; i++) {
      if (selectAttr != '') selectAttr += ',';
      selectAttr += getItemProperty(visiblePropNds[i], 'name');
    }

    if (selectAttr == '') selectAttr = 'id';
    selectAttr += ',css,keyed_name,locked_by_id';

    var ps = top.aras.getVariable(varName_pagesize);
    pagesize = (parseInt(ps)) ? ps : top.aras.getItemProperty(currItemType, 'default_page_size');

    maxRecords = top.aras.getItemProperty(currItemType, 'maxrecords');

    currQryItem.setPageSize(pagesize);
    currQryItem.setPage(1);
    currQryItem.setMaxRecords(maxRecords);
    currQryItem.setSelect(selectAttr);
  }
  doAutosearchAndHideSearchBar = (currQryItem.item.getAttribute("idlist") !== null);
  setTimeout('showStatus()', 300);
}

function initToolbar()
{
  var tb = document.searchbar.getActiveToolbar();

  tb.getElement('search').setEnabled(true);
  tb.getElement('newsearch').setEnabled(!doAutosearchAndHideSearchBar);
  tb.getElement('set_nothing').setEnabled(true);
  tb.getElement('exit').setEnabled(true);
  tb.getElement('ready_btn').setEnabled(true);
  tb.getElement('page_size').setEnabled(true);
  tb.getElement('max_search').setEnabled(true);

  var ps = top.aras.getVariable(varName_pagesize);
  pagesize = (parseInt(ps)) ? ps : top.aras.getItemProperty(currItemType, 'default_page_size');
  tb.getElement('page_size').setText(pagesize);

  maxRecords = top.aras.getItemProperty(currItemType, 'maxrecords');
  tb.getElement('max_search').setText(maxRecords);

  if (top.aras.isPolymorphic(currItemType))
  {
    var cb = searchbar.getActiveToolbar().getElement('implementation_type');
    cb.removeAll();
    cb.Add(itemTypeID, (itemTypeLabel==null || itemTypeLabel==='') ? itemTypeName : itemTypeLabel);
    var morphae = currItemType.selectNodes("Relationships/Item[@type='Morphae']/related_id/Item");
    for(var i=0; i<morphae.length; i++) {
      var m = morphae(i);
			var id = m.getAttribute("id");
			var name = aras.getItemProperty(m,"name");
			var label = aras.getItemProperty(m,"label");
			if (label==null || label==='') label = name;
      cb.Add(id, label);
      m = null;
    }
    morphae = null;
    cb = null;
    searchbar.showItem("implementation_type");
  }
  else
    searchbar.hideItem('implementation_type');
  updateToolBar();
}//initToolbar()

function emptyGrid() {
	grid.RemoveAllRows();
}

function updateToolBar()
{
  if (isNaN(page)) page = 1;
  if (isNaN(pagemax)) pagemax = 1;
  if (isNaN(itemmax)) itemmax = 0;
  if (isNaN(pagesize)) pagesize = '';
  if (isNaN(maxRecords)) maxRecords = '';

  var tb = searchbar.getActiveToolbar();

  if (page-1 <= 0)
    tb.getElement('prev_page').setEnabled(false);
  else
    tb.getElement('prev_page').setEnabled(true);

  if (pagemax - page > 0)
    tb.getElement('next_page').setEnabled(true);
  else
    tb.getElement('next_page').setEnabled(false);
}

function setSearchCriteria(property, criteria) {
  var condition = (top.aras.getVariable("UseWildcards")=="true" ? "like" : "eq");

  var prop = null;
  var propertyName = '';
  var Lcol = 0;
  var colNm = "";

  var tp  = typeof(property);

  if ( !isNaN(parseInt(property)) ) tp = 'number';

  if (tp == 'number') {
    Lcol = parseInt(property);
    prop = visiblePropNds[Lcol - 1];
    colNm = logicalColumnOrderArr[Lcol];
    propertyName = colNm.substr(0, colNm.length-2);
  }

  else {
    colNm = property;

    Lcol = 0;
    for (Lcol=0; Lcol<logicalColumnOrderArr.length; Lcol++) {
      if (logicalColumnOrderArr[Lcol] == colNm) break;
    }

    propertyName = colNm.substr(0, colNm.length-2);

    if (Lcol >= logicalColumnOrderArr.length) return;

    prop = visiblePropNds[Lcol - 1];
  }
  
  if (!prop) return;
  
  var propDT = top.aras.getItemProperty(prop, 'data_type');
  if (propDT == 'item') {
    if (criteria == '') currQryItem.removePropertyCriteria(propertyName, 'keyed_name');
    else currQryItem.setPropertyCriteria(propertyName, 'keyed_name', criteria, condition);
  }
  else {
    if (criteria == '') currQryItem.removeCriteria(propertyName);
    else currQryItem.setCriteria(propertyName, criteria, condition);
  }

  var VSArr = top.aras.getVariable(varName_searchVis).split(";");
  var vColOrder = top.aras.getVariable(varName_colOrder).split(";");
  var Vcol = -1;
  for (Vcol=0; Vcol<vColOrder.length; Vcol++) {
    if (vColOrder[Vcol] == colNm) break;
  }

  if (VSArr[Vcol] != criteria) {
    VSArr[Vcol] = criteria;
    top.aras.setVariable(varName_searchVis, VSArr.join(";"));
  }
}

function clearSearchCriteria() {
  currQryItem.removeAllCriterias();
  if (isAdvSearchVisible) advancedSearchFrame.initSearch(currQryItem, true);
  if (isFormSearchVisible) initSearchForm();

  var setups = top.aras.sGridsSetups[itemTypeName];
  var VSArr = new Array();
  for (var i=0; i<logicalColumnOrderArr.length; i++) {
    VSArr.push("");
    if (isInputRowVisible) {
      var val = "";
      if (logicalColumnOrderArr[i] == "L") val = "<img src=\"\">";
      grid.cells("input_row", i).setValue(val);
    }
  }//for

  top.aras.setVariable(varName_searchVis, VSArr.join(";"));
}

function doSearch(isAutoSearch)
{
  if (isAutoSearch)
  {
  }
  else
  {
    currQryItem.syncWithClient();
    if (inputCol>-1)
    {
      var cell = grid.cells('input_row', inputCol);
      var val = cell.getValue();
  
      setSearchCriteria(inputCol, val);

      var searchSetups = top.aras.sGridsSetups[itemTypeName];
      if (searchSetups && cell.wasChanged())
      {
        searchSetups.page = 1;
        currQryItem.setPage(1);
      }
      inputCol = -1;
    }

    var ps = document.searchbar.getActiveToolbar().getElement('page_size').getText();
    pagesize = parseInt(ps);

    var maxRecords = document.searchbar.getActiveToolbar().getElement('max_search').getText();
    mrN = parseInt(maxRecords);
    
    if ((isNaN(pagesize) && ps != '') || pagesize <=0)
    {
      top.aras.AlertError('The page size should be a positive integer.');
      return;
    }
    else
      currQryItem.setPageSize(ps);

    if ((isNaN(mrN) && maxRecords != '') || mrN <=0)
    {
      top.aras.AlertError('Max search value should be a positive integer.');
      return;
    }
    else
      currQryItem.setMaxRecords(maxRecords);
  }

  doSearch_internal();
}//doSearch

function setupPageNumber()
{
  var res = currQryItem.getResponseDOM();
  var anyItem = res.selectSingleNode('//Item');
  if (anyItem) {
    page    = anyItem.getAttribute('page');
    pagemax = anyItem.getAttribute('pagemax');
    itemmax = anyItem.getAttribute('itemmax');
    if (!page) page = 1;
    if (!pagemax) pagemax = 1;
    if (!itemmax) itemmax = 0;
  } else {
    page = 1;
    pagemax = 1;
    itemmax = 0;
  }
}

function updateToolStatusBar()
{
  updateToolBar();
  showStatus();
}

function setupGrid(isFirstTime)
{
  grid.setPaintEnabled(false);

  currQryItem.syncWithClient();

  var resDom = currQryItem.getResultDOM();

  function prepareDOM4XSLT(dom)
  {
    // +++ add information about columns order and columns width
    var colWidths = top.aras.getVariable(varName_colWidths);
    var colOrder  = top.aras.getVariable(varName_colOrder);

    var colWidthsArr = colWidths.split(";");
    var colOrderArr  = colOrder.split(";");

    var L2Vorder = new Array();

    top.aras.uiPrepareDOM4GridXSLT(dom);
    var tableNd = dom.selectSingleNode(top.aras.XPathResult("/table"));
    tableNd.setAttribute("editable", "false");

    var columns = tableNd.selectSingleNode("columns");
    for (var i=0; i<colOrderArr.length; i++) {
    var Vorder = i;
    var Lorder = 0;
    var colName = colOrderArr[i];

    for (var j=0; j<logicalColumnOrderArr.length; j++)
    {
      if (logicalColumnOrderArr[j] == colName)
      {
        Lorder = j;
        break;
      }
    }

    L2Vorder[Lorder] = Vorder;

      var column = dom.createElement("column");
      column.setAttribute("name", colOrderArr[i]);
      column.setAttribute("order", i);
      column.setAttribute("width", colWidthsArr[i]);
      columns.appendChild(column);
    }
    // --- add information about columns order and columns width

    // +++ add search row information
    var searchStrsArr = top.aras.getVariable(varName_searchVis).split(";");
    var inputrow = tableNd.selectSingleNode("inputrow");
    if (doAutosearchAndHideSearchBar)
      inputrow.parentNode.removeChild(inputrow);
    else
    for (var i=0; i<searchStrsArr.length; i++)
    {
      var LOrder = i;
      var td = dom.createElement("td");
      td.text = searchStrsArr[ L2Vorder[LOrder] ];
      inputrow.appendChild(td);
    }
    // --- add search row information
  }

  prepareDOM4XSLT(resDom)

  var grid_xml = aras.uiGenerateItemsGridXML(resDom, visiblePropNds, itemTypeID);
  grid.initXML(grid_xml);
}//setupGrid

function onXmlLoaded() {
  grid.setPaintEnabled(true);
  grid.showContent();
}

function onLink(itemTypeName, itemID) {
  setTimeout("top.aras.uiShowItem('" + itemTypeName + "', '" + itemID + "');", 10);
}

function onEditCell(type, rowid, col) {
  if (rowid != "input_row") return false;
  var colNm = logicalColumnOrderArr[col];
  if (colNm.toUpperCase() == "L") return false;//ignore locked_by_id column
  var propertyName = colNm.substr(0, colNm.length-2);
  if (propertyName && userMethodColumnCfgs[propertyName] && userMethodColumnCfgs[propertyName].isFilterFixed) return false;

  if (rowid == "input_row") {
    if (type == 0) {
      inputCol = col;
      setupFilteredListIfNeed();
    }
    else if (type == 1) {
    }
    else if (type == 2) {
      inputCol = -1;
      var cell = grid.cells('input_row', col);
      var val = cell.getValue();

      setSearchCriteria(col, val);
      if (cell.wasChanged()) removeFilterListValueIfNeed();

      var searchSetups = top.aras.sGridsSetups[itemTypeName];
      if (searchSetups && cell.wasChanged()) {
        searchSetups.page = 1;
          currQryItem.setPage(1);
      }
      return true;
    }
    else if (type == 21) {
      if (top.aras.sGridsSetups  && top.aras.sGridsSetups[itemTypeName]) {
         setSearchCriteria(col, grid.cells('input_row', col).getValue());
      }

      setTimeout('doSearch()', 100);
      return true;
    }
  }
  function setupFilteredListIfNeed(){
    if (rowid!='input_row') return;
    
    var propNd = visiblePropNds[col-1];
    if (!propNd || !propNd.xml) return;
    
    var propName = top.aras.getItemProperty(propNd, 'name');
    var prop_data_type = top.aras.getItemProperty(propNd, 'data_type');
    if (prop_data_type!="filter list") return;
    
    var prop_pattern_name = top.aras.getItemProperty(propNd, 'pattern');
    if (!prop_pattern_name) return;
    
    var patternColIndexArr = new Array();
    for (var j=0; j<visiblePropNds.length; j++){
      var curPropNd = visiblePropNds[j];
      var curPropName = top.aras.getItemProperty(curPropNd, 'name');
      if (curPropName == prop_pattern_name) patternColIndexArr[patternColIndexArr.length] = j;
    }
    for (var j=0; j<patternColIndexArr.length; j++){
      var patternColIndex = patternColIndexArr[j]
      var filterValue = "";
      var cell = grid.cells(rowid, patternColIndex+1);
      var filterValue = cell.getValue();
      if (!filterValue) filterValue="";
      
      var resObj = top.aras.uiGetFilteredObject4Grid( itemTypeID, propName, filterValue );
      if (resObj.hasError) return;
      
      grid.cells(rowid, parseInt(col)).setCombo( resObj.labels, resObj.values );
    }
  }
  function removeFilterListValueIfNeed(){
    if (rowid!='input_row') return;
    
    var propNd = visiblePropNds[col-1];
    if (!propNd || !propNd.xml) return;
    
    var propName = top.aras.getItemProperty(propNd, 'name');
    var prop_data_type = top.aras.getItemProperty(propNd, 'data_type');
    
    var filteredColIndexArr = new Array();
    for (var j=0; j<visiblePropNds.length; j++){
      var curPropNd = visiblePropNds[j];
      var curPropPattern = top.aras.getItemProperty(curPropNd, 'pattern');
      if (curPropPattern == propName) filteredColIndexArr[filteredColIndexArr.length] = j;
    }
    for (var j=0; j<filteredColIndexArr.length; j++){
      var cell = grid.cells(rowid, filteredColIndexArr[j]+1);
      cell.setValue("");
      setSearchCriteria(filteredColIndexArr[j]+1, "");
    }
  }
}

function clearSearchCriteria() {
  if (doAutosearchAndHideSearchBar) return;
  grid.turnEditOff();
  if (inputCol>-1) {
    inputCol = -1;
  }
  currQryItem.removeAllCriterias();
  if (currQryItemInitial)
  {
    currQryItem.dom.loadXML(currQryItemInitial.dom.xml);
    currQryItem.item = currQryItem.dom.documentElement;
  }
  var VSArr = new Array();
  for (var i=0; i<logicalColumnOrderArr.length; i++) {
    var colNm = logicalColumnOrderArr[i];
    var propName = colNm.substr(0, colNm.length-2);
    var isFilterFixed = (userMethodColumnCfgs[propName]) ? userMethodColumnCfgs[propName].isFilterFixed : false;
    
    if (!isFilterFixed) VSArr.push("");
    else VSArr.push(userMethodColumnCfgs[propName].filterValue);

    var val = "";
    if (logicalColumnOrderArr[i] == "L") val = "<img src=\"\">";
    if (!isFilterFixed) grid.cells("input_row", i).setValue(val);
  }//for

  for (var k in userMethodColumnCfgs){
    if (userMethodColumnCfgs[k].isFilterFixed) currQryItem.setCriteria(k, userMethodColumnCfgs[k].filterValue);
  }
  top.aras.setVariable(varName_searchVis, VSArr.join(";"));
}

function onSearchCommand() {
  top.aras.sGridsSetups[itemTypeName]['page'] = 1;
  currQryItem.setPage(1);
  doSearch();
}

var counter = 0;
function showStatus()
{
  try
  {
    document.statusbar.setStatus(0, '', '');
  }
  catch (ex)
  {
    if (counter >= 200) return;
    counter++;
    setTimeout('showStatus();', 40);
    return;
  }

  if (pagesize)
  {
    var i1 = pagesize*(page - 1) + 1;
    var i2 = i1 + (page<pagemax?(pagesize-1):(itemmax-(page-1)*pagesize-1));

    if (i2 == 0) document.statusbar.setStatus(1, '0 Items found.');
    else
    {
      var msg = 'Items '+i1+'-'+i2+' of '+itemmax+'. Page '+page+' of '+pagemax;
      document.statusbar.setStatus(1, msg);
    }
  }
  else if (pagemax)
  {
    if (itemmax == 0)
      document.statusbar.setStatus(1, '0 Items found.');
    else
    {
      var msg = 'Items 1-'+itemmax+' of '+itemmax+'. Page '+page+' of '+pagemax;
      document.statusbar.setStatus(1, msg);
    }
  }
  else if (pagemax == 0)
    document.statusbar.setStatus(1, '0 Items found.');
}

onload = function onload_handler()
{
  if (top.aras.getItemProperty(currItemType, "auto_search") == "1" || doAutosearchAndHideSearchBar)
  {
    doSearch(true);
  }
}